import React from 'react';
import ReactDOM from 'react-dom/client';
import './index.css';
import App from './App';
import { BrowserRouter } from 'react-router-dom';
import { ThemeSwitcherProvider } from 'react-css-theme-switcher';

const themes = {
  light:  `light.css`,
  dark: `dark.css`,
};
const root = ReactDOM.createRoot(document.getElementById('root'));
root.render(
  <React.StrictMode>
    <ThemeSwitcherProvider defaultTheme="light" themeMap={themes}>
    <BrowserRouter>
    <App />
    </BrowserRouter>
    </ThemeSwitcherProvider>
  </React.StrictMode>,
  document.getElementById('root')
);
