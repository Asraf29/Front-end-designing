import { useRoutes } from "react-router-dom";
import MainRoutes from "./mainRoutes";

const AppRoutes = () => {
    return useRoutes([MainRoutes])
}

export default AppRoutes;