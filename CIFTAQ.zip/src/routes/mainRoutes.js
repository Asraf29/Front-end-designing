import { Outlet } from 'react-router-dom'
//Common Two Pieces
import Navbar from '../components/Navbar';
import Footer from '../components/Footer';
//end
//Pages
import Homepage from '../pages/HomePage'
import Login from '../pages/Auth/login';
import Signup from '../pages/Auth/signup';
import MarketFavourites from '../pages/MarketFavourites';
import Profile from '../pages/Profile/profile';
import Exchange from '../pages/MarketFavourites/exchange';
import WithdrawSetting from '../pages/Profile/WithdrawSetting/index';
import PrimaryKYC from '../pages/Profile/VerifyYourIdentity/primaryKYC';
import API from '../pages/Profile/API/index';
import TradingFee from '../pages/Profile/TradingFee/index';
import Preference from '../pages/Profile/Preferences/index';
import MarketBuy from '../pages/P2P/marketBuy';
import AlertBox from '../components/AlertBox/alertBox';
import AlertBoxOne from '../components/AlertBox1/alertBoxOne';
import VerifyModal from '../components/verifyPopup';
import SecurityCenter from '../pages/Profile/SecurityCenter/securityCenter';
import VerifyIdentity from '../pages/Profile/VerifyYourIdentity/index'
import SetAntiPishing from '../pages/Profile/SecurityCenter/setAntiPishing';
import GoogleAuth from '../pages/Profile/GoogleAuthentication/googleAuth';
import DisableAccount from '../pages/Profile/SecurityCenter/disableAccount';
import OfficialVerification from '../pages/Profile/OfficialVerification/officialverification';
import NotificationExpand from '../pages/NotificationExpand';
import Spot from '../pages/Spot';
import InviteFriends from '../pages/inviteFriends';
import AccountDepositOne from '../pages/AccountDeposit/DepositOne';
import AccountWithdraw from '../pages/AccountDeposit/accountWithdraw';
import LoopAlliance from '../pages/AccountDeposit/LoopAlliance';
import TabRecordWithdraw from '../pages/AccountDeposit/Records/RecordWithdraw'
import AccountDeposit from '../pages/AccountDeposit/accountDeposit';
import RewardCenter from '../pages/RewardCenter';
import ETFIndex from '../pages/ETFIndex';
import LaunchPad from '../pages/Launchpad/launchPad';
import OrderMainTab from '../pages/Launchpad/OrderTabs/index'
import LaunchpadViewProduct from '../pages/Launchpad/ProductView';
import Kickstarter from '../pages/Launchpad/Kickstarter';
import FuturesMarkets from '../pages/FuturesMarkets';
import KickstartMore from '../pages/Launchpad/Kickstarter/more';
import Defi from '../pages/MX DEFI/mxDefi';
import NewToken from '../pages/MX DEFI/NewToken/newToken';
import KickstarterTab from '../pages/Launchpad/Kickstarter/KickstartTabs';
import Mday from '../pages/Mday/mday';
import MdayOrder from '../pages/Mday/mdayOrder';
import SlotAuction from '../pages/SlotAuction/slotAuction'
import SlotAuctionTab from '../pages/SlotAuction/slotTab';
import MdayPastEvent from '../pages/Mday/PastEvent/mdayPastEvent';
import Voting from '../pages/Mday/Vote/voting';
import MXZone from '../pages/MXZone';
import StakingRecords from '../pages/POS/StackingRecords';
import POSPool from '../pages/POS/POSPool';
import ETHDetails from '../pages/StakeETH/ETHDetails';
import FutureOrder from '../pages/FutureOrderTabs';
import StakeETH from '../pages/StakeETH/StakeETH2.0';
const MainRoutes = {
    path: '',
    element: (
        <>
            <Outlet />
        </>
    ),

    children: [
        {
            path: '/',
            element: (
                <>
                    <Navbar />
                    <Homepage />
                    <Footer />
                </>
            )

        },
        {
            path: '/market',
            element: (
                <>
                    <Navbar />
                    <MarketFavourites />
                    <Footer />
                </>
            )

        },
        {
        path: '/rewardCenter',
        element:(
            <>
                <Navbar/>
                <RewardCenter/>
                <Footer/>
            </>
        )
       },
        { 
            path: '/exchange',
            element:(
                <>
                    <Navbar/>
                    <Exchange/>
                    <Footer />
                </>
            )

        },
        {
            path: '/userlogin',
            element: (
                <>
                    <Navbar />
                    <Login />
                </>
            )
    },
    {
        path: '/register',
        element:(
            <>
                <Navbar/>
                <Signup/>
          
            </>
        )
    },
    {
        path: '/Profile',
        element:(
            <>
                <Navbar/>
                <Profile/>
                <Footer/>
            </>
        )
    },
    {
        path: '/verifyIdentity',
        element:(
            <>
                <Navbar/>
                <VerifyIdentity/>
                <Footer/>
            </>
        )
    },
    {
        path: '/securityCenter',
        element:(
            <>
                <Navbar/>
                <SecurityCenter/>
                <Footer/>
            </>
        )
    },
    {
        path: '/primaryKYC',
        element:(
            <>
                <Navbar/>
                <PrimaryKYC/>
                <Footer/>
            </>
        )
    },
    {
        path: '/api',
        element:(
            <>
                <Navbar/>
                <API/>
                <Footer/>
            </>
        )
    },
    {
        path: '/withdrawsetting',
        element:(
            <>
                <Navbar/>
                <WithdrawSetting/>
                <Footer/>
            </>
        )
    },
    {
        path: '/preference',
        element:(
            <>
                <Navbar/>
                <Preference/>
                <Footer/>
            </>
        )
    },
    {
        path: '/tradingFee',
        element:(
            <>
                <Navbar/>
                <TradingFee/>
                <Footer/>
            </>
        )
    },
    {
        path: '/marketBuy',
        element:(
            <>
                <Navbar/>
                <MarketBuy/>
                <Footer/>
            </>
        )
    },
    {
        path: '/authentication',
        element:(
            <>
                <Navbar/>
                <GoogleAuth/>
                <Footer/>
            </>
        )
    },
    {
        path: '/setAntiPishing',
        element:(
            <>
                <Navbar/>
                <SetAntiPishing/>
                <Footer/>
            </>
        )
    },
    {
        path: '/disableAccount',
        element:(
            <>
                <Navbar/>
                <DisableAccount/>
                <Footer/>
            </>
        )
    },
    {
        path: '/alertbox',
        element:(
            <>
                <Navbar/>
                <AlertBox/>
                <Footer/>
            </>
        )
    },
    {
        path: '/alertboxOne',
        element:(
            <>
                <Navbar/>
                <AlertBoxOne/>
                <Footer/>
            </>
        )
    },
    {
        path: '/verifyModal',
        element:(
            <>
                <Navbar/>
                <    VerifyModal/>
                <Footer/>
            </>
        )
    },
    {
        path: '/authentication',
        element:(
            <>
                <Navbar/>
                <GoogleAuth/>
                <Footer/>
            </>
        )
    },
     {
        path: '/officialVerification',
        element:(
            <>
                <Navbar/>
                <OfficialVerification/>
                <Footer/>
            </>
        )
    },
    {
        path: '/notificationExpand',
        element:(
            <>
                <Navbar/>
                <NotificationExpand/>
                <Footer/>
            </>
        )
    },
    {
        path: '/spot',
        element:(
            <>
                <Navbar/>
                <Spot/>
                <Footer/>
            </>
        )
    },
 {
        path: '/inviteFriends',
        element:(
            <>
                <Navbar/>
                <InviteFriends/>
                <Footer/>
            </>
        )
    },
    {
        path: '/accountDepositOne',
        element:(
            <>
                <Navbar/>
                <AccountDepositOne/>
                <Footer/>
            </>
        )
    },
    {
        path: '/accountWithdraw',
        element:(
            <>
                <Navbar/>
                <AccountWithdraw/>
                <Footer/>
            </>
        )
    },
    {
        path: '/loopAlliance',
        element:(
            <>
                <Navbar/>
                <LoopAlliance/>
                <Footer/>
            </>
        )
    },
    {
        path: '/record',
        element:(
            <>
                <Navbar/>
                <TabRecordWithdraw/>
                <Footer/>
            </>
        )
    },
    {
    
           path: '/accountDeposit',
           element:(
               <>
                   <Navbar/>
                   <AccountDeposit/>
                   <Footer/>
               </>
           )
       },
       {
       
              path: '/indexETF',
              element:(
                  <>
                      <Navbar/>
                      <ETFIndex/>
                      <Footer/>
                  </>
              )
          } ,
          {
                 path: '/launchpad',
                 element:(
                     <>
                         <Navbar/>
                         <LaunchPad/>
                         <Footer/>
                     </>
                 )
             } ,
             {
                    path: '/myOrder',
                    element:(
                        <>
                            <Navbar/>
                            <OrderMainTab/>
                            <Footer/>
                        </>
                    )
                },
                {
                    path: '/productView',
                    element:(
                        <>
                            <Navbar/>
                            <LaunchpadViewProduct/>
                            <Footer/>
                        </>
                    )
                },
                {
                    path: '/kickstart',
                    element:(
                        <>
                            <Navbar/>
                            <Kickstarter/>
                            <Footer/>
                        </>
                    )
                },
          {
          
                 path: '/futuresMarkets',
                 element:(
                     <>
                         <Navbar/>
                         <FuturesMarkets/>
                         <Footer/>
                     </>
                 )
             },
             {
                 path: '/kickstartTab',
                 element: (
                     <>
                         <Navbar />
                         <KickstarterTab />
                         <Footer />
                     </>
                 )
             },
             {
                 path: '/kickstartMore',
                 element: (
                     <>
                         <Navbar />
                         <KickstartMore />
                         <Footer />
                     </>
                 )
             },
             {
                 path: '/mxDefi',
                 element: (
                     <>
                         <Navbar />
                         <Defi/>
                         <Footer />
                     </>
                 )
             },
             {
                 path: '/newtoken',
                 element: (
                     <>
                         <Navbar />
                         <NewToken/>
                         <Footer />
                     </>
                 )
             },
             {
                path: '/mday',
                element: (
                    <>
                        <Navbar />
                        <Mday/>
                        <Footer />
                    </>
                )
            },
            {
                path: '/mdayOrder',
                element: (
                    <>
                        <Navbar />
                        <MdayOrder/>
                        <Footer />
                    </>
                )
            },
            {
                path: '/slotAuction',
                element: (
                    <>
                        <Navbar />
                        <SlotAuction/>
                        <Footer />
                    </>
                )
            },
            {
                path: '/slotVote',
                element: (
                    <>
                        <Navbar />
                        <SlotAuctionTab/>
                        <Footer />
                    </>
                )
            },
            {

            
                 path: '/mdayPastEvent',
                 element: (
                     <>
                         <Navbar />
                         <MdayPastEvent/>
                         <Footer />
                     </>
                 )
             },
             {

            
                path: '/voting',
                element: (
                    <>
                        <Navbar />
                        <Voting/>
                        <Footer />
                    </>
                )
            },
            {
             
                  path: '/mxZone',
                  element: (
                      <>
                          <Navbar />
                          <MXZone/>
                          <Footer />
                      </>
                  )
              },
     {
                path: '/stakingRecords',
                element: (
                    <>
                        <Navbar />
                        <StakingRecords/>
                        <Footer />
                    </>
                )
            },
            {
                       path: '/posPool',
                       element: (
                           <>
                               <Navbar />
                               <POSPool/>
                               <Footer />
                           </>
                       )
                   },
                   {
                    path: '/ethDetails',
                    element: (
                        <>
                            <Navbar />
                            <ETHDetails/>
                            <Footer />
                        </>
                    )
                },
                {
                    path: '/futureOrder',
                    element: (
                        <>
                            <Navbar/>
                            <FutureOrder/>
                            <Footer />
                        </>
                    )
                },
                {
                    path: '/ETH2.0',
                    element: (
                        <>
                            <Navbar/>
                            <StakeETH/>
                            <Footer />
                        </>
                    )
                }
    ]
}
export default MainRoutes;