import * as React from "react";
import Box from "@mui/material/Box";
import Card from "@mui/material/Card";
import CardContent from "@mui/material/CardContent";
import NODATA from "../../components/assets/images/nodata.png";
import Table from "@mui/material/Table";
import TableBody from "@mui/material/TableBody";
import TableCell from "@mui/material/TableCell";
import StarIcon from "@mui/icons-material/Star";
import TableContainer from "@mui/material/TableContainer";
import TableHead from "@mui/material/TableHead";
import TableRow from "@mui/material/TableRow";
import Paper from "@mui/material/Paper";
import Button from "@mui/material/Button";
import Typography from "@mui/material/Typography";
import { Grid } from "@mui/material";
import Tab from "@mui/material/Tab";
import VerticalSplitIcon from "@mui/icons-material/VerticalSplit";
import SegmentIcon from "@mui/icons-material/Segment";
import lgGraph from "../../components/assets/images/largeSizeGraph.png";
import { TabContext, TabList, TabPanel } from "@mui/lab";
import InfoOutlinedIcon from '@mui/icons-material/InfoOutlined';
import CachedOutlinedIcon from '@mui/icons-material/CachedOutlined';
import ArticleIcon from '@mui/icons-material/Article';
import StarsOutlinedIcon from '@mui/icons-material/StarsOutlined';
import { styled } from '@mui/material/styles';
import FormControlLabel from '@mui/material/FormControlLabel';
import Switch from '@mui/material/Switch';
import SpeedSharpIcon from '@mui/icons-material/SpeedSharp';
import AttachFileSharpIcon from '@mui/icons-material/AttachFileSharp';
import ZoomOutMapSharpIcon from '@mui/icons-material/ZoomOutMapSharp';
import "./index.css";
import TransferCrypto from "../../components/CryptoTransferModel/cryptoTransfer";
import FuturesCalculator from "../../components/FuturesCalculatorModal";
/*Toggle switch */
const IOSSwitch = styled((props) => (
    <Switch focusVisibleClassName=".Mui-focusVisible" disableRipple {...props} />
))(({ theme }) => ({
    width: 37,
    height: 20,
    padding: 0,
    '& .MuiSwitch-switchBase': {
        padding: 0,
        margin: 2,
        transitionDuration: '300ms',
        '&.Mui-checked': {
            transform: 'translateX(16px)',
            color: '#fff',
            '& + .MuiSwitch-track': {
                backgroundColor: theme.palette.mode === 'dark' ? '#1a94ae' : '#1a94ae',
                opacity: 1,
                border: 0,
            },
            '&.Mui-disabled + .MuiSwitch-track': {
                opacity: 0.5,
            },
        },
        '&.Mui-focusVisible .MuiSwitch-thumb': {
            color: '#33cf4d',
            border: '6px solid #fff',
        },
        '&.Mui-disabled .MuiSwitch-thumb': {
            color:
                theme.palette.mode === 'light'
                    ? theme.palette.grey[100]
                    : theme.palette.grey[600],
        },
        '&.Mui-disabled + .MuiSwitch-track': {
            opacity: theme.palette.mode === 'light' ? 0.7 : 0.3,
        },
    },
    '& .MuiSwitch-thumb': {
        boxSizing: 'border-box',
        width: 17,
        height: 17,
    },
    '& .MuiSwitch-track': {
        borderRadius: 26 / 2,
        backgroundColor: theme.palette.mode === 'light' ? '#E9E9EA' : '#39393D',
        opacity: 1,
        transition: theme.transitions.create(['background-color'], {
            duration: 500,
        }),
    },
}));
const FuturesMarkets = () => {
    ////TABS///
    const [trend, setTrending] = React.useState("1");
    const trending = (event, trendingTab) => {
        setTrending(trendingTab);
    };
    const [coin, setCoin] = React.useState("1");
    const coins = (event, coinTab) => {
        setCoin(coinTab);
    };
     //CRYPTO TRANSFER MODEL
  const [openCryptoTransferModal, setOpenCryptoTransferModal] = React.useState(false);
  const handleCryptoClickOpen = () => {
    setOpenCryptoTransferModal(true);
  };

  const handleCryptoModalClose = () => {
    setOpenCryptoTransferModal(false);
  };
  //FUTURE CALCULATOR MODEL
  const [openCalculatorModal, setOpenCalculatorModal] = React.useState(false);
  const handleCalculatorClickOpen = () => {
    setOpenCalculatorModal(true);
  };

  const handleCalculatorModalClose = () => {
    setOpenCalculatorModal(false);
  };
    /*Index Market */
    const dublicateData = ["1", "2", "3", "4"]
    return (
        <div>
            <FuturesCalculator openCalculatorModal={openCalculatorModal}  handleCalculatorClickOpen ={ handleCalculatorClickOpen} handleCalculatorModalClose={handleCalculatorModalClose}/>
             <TransferCrypto openCryptoTransferModal={openCryptoTransferModal} handleCryptoClickOpen ={handleCryptoClickOpen} handleCryptoModalClose={handleCryptoModalClose}/>
            <div className="container-fluid my-4">
                <Grid container spacing={1}>
                    <Grid item xs={12} md={12} lg={12} className="mb-5">
                        <Grid container spacing={1}>
                            <Grid item xs={12} md={9} lg={9}>
                                <Grid container spacing={1}>
                                    {/* Graph Main Card */}
                                    <Grid item xs={12} md={8} lg={8} sx={{ marginBottom: 2 }}>
                                        <TabContext value={coin}>
                                            <Box className="d-flex align-items-center borderY py-1">
                                                <div className="d-flex align-items-center">
                                                    <StarIcon className="mb-2 text-warning" />
                                                    <Typography className="text-white ms-1">SOS_USDT SWAP<span className="text-blue ps-2 fs-small-lg">+1.38%</span></Typography>
                                                </div>
                                                <div>
                                                    <TabList variant="scrollable" onChange={coins} aria-label="lab API tabs example" id="indicator">
                                                        <Tab sx={{ fontSize: "15px", fontWeight: 500, textTransform: "none" }}
                                                            label="USDT-🅜" value="1" className="colorTab text-white"/>
                                                        <Tab sx={{ fontSize: "15px", fontWeight: 500, textTransform: "none" }}
                                                            label="Coin-🅜" value="2" className="colorTab text-white"/>
                                                    </TabList>
                                                </div>
                                            </Box>
                                        </TabContext>
                                        {/* Data With Selcetion */}
                                        <Box className="py-3">
                                            <div className="d-flex flex-wrap justifyContent">
                                                <Box className="borderRight">
                                                    <select className="indexSelect form-select option-fs-sm text-white fs-6" aria-label="Default select example">
                                                        <option className='text-dark option-fs-sm' selected>BTC_USDT SWAP</option>
                                                        <option className='text-dark option-fs-sm' value="1">BTC_USD SWAP</option>
                                                        <option className='text-dark option-fs-sm' value="2">BTC_USDT SWAP</option>
                                                        <option className='text-dark option-fs-sm' value="3">BTC_USD SWAP</option>
                                                    </select>
                                                </Box>
                                                <Box className="d-flex align-items-center">
                                                    <Typography className="fs-sm index-text-green wrapText px-2 px-sm-0 px-lg-1" >
                                                        42562.00
                                                    </Typography>
                                                </Box>
                                                <Box>
                                                    <div>
                                                        <Typography className="fs-sm index-text-green wrapText  px-2 px-sm-0 px-lg-1">
                                                            +2.01%
                                                        </Typography>
                                                    </div>
                                                    <Typography className="textClr-subTitle wrapText  px-2 px-sm-0 px-lg-1">
                                                        Change
                                                    </Typography>
                                                </Box>
                                                <Box>
                                                    <div>
                                                        <Typography className="wrapText text-white  px-2 px-sm-0 px-lg-1">42562.90</Typography>
                                                    </div>
                                                    <Typography className="textClr-subTitle text-center wrapText  px-2 px-sm-0 px-lg-1">
                                                        Index Price
                                                    </Typography>
                                                </Box>
                                                <Box>
                                                    <div>
                                                        <Typography sx={{ color: "white" }} className="wrapText  px-2 px-sm-0 px-lg-1">
                                                            42562.90
                                                        </Typography>
                                                    </div>
                                                    <Typography className="textClr-subTitle text-center wrapText  px-2 px-sm-0 px-lg-1">
                                                        Fair Price
                                                    </Typography>
                                                </Box>
                                                <Box>
                                                    <div>
                                                        <Typography sx={{ color: "white" }} className="wrapText  px-2 px-sm-0 px-lg-1">
                                                            0.0119%
                                                        </Typography>
                                                    </div>
                                                    <Typography className="textClr-subTitle text-center wrapText  px-2 px-sm-0 px-lg-1">
                                                        Funding Rate
                                                    </Typography>
                                                </Box>
                                                <Box>
                                                    <div>
                                                        <Typography sx={{ color: "white" }} className="wrapText  px-2 px-sm-0 px-lg-1">
                                                            43088.00
                                                        </Typography>
                                                    </div>
                                                    <Typography className="textClr-subTitle text-center wrapText  px-2 px-sm-0 px-lg-1">
                                                        24h High
                                                    </Typography>
                                                </Box>
                                                <Box>
                                                    <div>
                                                        <Typography sx={{ color: "white" }} className="wrapText  px-2 px-sm-0 px-lg-1">
                                                            42274.00
                                                        </Typography>
                                                    </div>
                                                    <Typography className="textClr-subTitle text-center wrapText  px-2 px-sm-0 px-lg-1">
                                                        24h Low
                                                    </Typography>
                                                </Box>
                                                <Box>
                                                    <div>
                                                        <Typography sx={{ color: "white" }} className="wrapText  px-2 px-sm-0 px-lg-1">
                                                            64128311 Cont
                                                        </Typography>
                                                    </div>
                                                    <Typography className="textClr-subTitle text-center wrapText  px-2 px-sm-0 px-lg-1">
                                                        24h Volume
                                                    </Typography>
                                                </Box>
                                            </div>
                                        </Box>
                                        {/* Data With Selcetion End */}
                                        {/* Center Graph Card */}
                                        <Box sx={{ width: "100%", typography: "body1" }} className="">
                                            <div className="d-lg-flex align-items-lg-center justify-content-lg-between">
                                                <div>
                                                    <ul className="nav nav-pills pills mb-2 my-2" id="pills-tab pills-icons" role="tablist">
                                                        <li className="nav-item" role="presentation">
                                                            <button className="nav-link  btn-sm btn" style={{ color: "white" }} id="pills-basic-tab" data-bs-toggle="pill" data-bs-target="#pills-basic" role="tab">
                                                                1 min
                                                            </button>
                                                        </li>
                                                        <li className="nav-item" role="presentation">
                                                            <button className="nav-link btn-sm btn" id="pills-proffessional-tab" style={{ color: "white" }} data-bs-toggle="pill" data-bs-target="#pills-proffessional" role="tab">
                                                                5 min
                                                            </button>
                                                        </li>
                                                        <li className="nav-item" role="presentation">
                                                            <button className="nav-link btn-sm btn" id="pills-depth-tab" style={{ color: "white" }} data-bs-toggle="pill" data-bs-target="#pills-depth" role="tab">
                                                                15 min
                                                            </button>
                                                        </li>
                                                        <li className="nav-item" role="presentation">
                                                            <button className="nav-link btn-sm btn" id="pills-depth-tab" style={{ color: "white" }} data-bs-toggle="pill" data-bs-target="#pills-depth" role="tab">
                                                                30 min
                                                            </button>
                                                        </li>
                                                        <li className="nav-item" role="presentation">
                                                            <button className="nav-link btn-sm btn" id="pills-depth-tab" style={{ color: "white" }} data-bs-toggle="pill" data-bs-target="#pills-depth" role="tab">
                                                                1 hour
                                                            </button>
                                                        </li>
                                                        <li className="nav-item" role="presentation">
                                                            <button className="nav-link btn-sm btn" id="pills-depth-tab" style={{ color: "white" }} data-bs-toggle="pill" data-bs-target="#pills-depth" role="tab">
                                                                4 hour
                                                            </button>
                                                        </li>
                                                        <div className="dropdown">
                                                            <button className="btn btn-sm text-white dropdown-toggle p-0 ps-1 pe-1 my-lg-1" id="dropdownMenuButton1" data-bs-toggle="dropdown">
                                                                1 day
                                                            </button>
                                                            <ul className="dropdown-menu bg-dropdown" aria-labelledby="dropdownMenuButton1">
                                                                <li>
                                                                    <a className="dropdown-item text-white" href="#">
                                                                        1 min <StarIcon sx={{ fontSize: "10px", color: "#fff" }} />
                                                                    </a>
                                                                </li>
                                                                <li>
                                                                    <a className="dropdown-item text-white" href="#">
                                                                        1 min <StarIcon sx={{ fontSize: "10px", color: "#fff" }} />
                                                                    </a>
                                                                </li>
                                                                <li>
                                                                    <a className="dropdown-item text-white" href="#">
                                                                        1 min <StarIcon sx={{ fontSize: "10px", color: "#fff" }} />
                                                                    </a>
                                                                </li>
                                                            </ul>
                                                        </div>
                                                        <li className="nav-item" role="presentation">
                                                            <AttachFileSharpIcon className="nav-link btn-sm btn" id="pills-depth-tab" style={{ color: "white" }} data-bs-toggle="pill" data-bs-target="#pills-depth" role="tab" />
                                                        </li>
                                                        <li className="nav-item" role="presentation">
                                                            <button className="nav-link btn-sm btn" id="pills-depth-tab" style={{ color: "white" }} data-bs-toggle="pill" data-bs-target="#pills-depth" role="tab">
                                                                fx
                                                            </button>
                                                        </li>
                                                        <li className="nav-item" role="presentation">
                                                            <SpeedSharpIcon className="nav-link btn-sm btn" id="pills-depth-tab" style={{ color: "white" }} data-bs-toggle="pill" data-bs-target="#pills-depth" role="tab" />
                                                        </li>
                                                        <li className="nav-item" role="presentation">
                                                            <ZoomOutMapSharpIcon className="nav-link btn-sm btn" id="pills-depth-tab" style={{ color: "white" }} data-bs-toggle="pill" data-bs-target="#pills-depth" role="tab" />
                                                        </li>
                                                    </ul>
                                                </div>
                                                <div>
                                                    <ul className="nav nav-pills pills mb-2 my-2" id="pills-tab pills-icons" role="tablist">
                                                        <li className="nav-item" role="presentation">
                                                            <button className="nav-link active btn-sm btn" style={{ color: "white" }} id="pills-basic-tab" data-bs-toggle="pill" data-bs-target="#pills-basic" role="tab">
                                                                Basic
                                                            </button>
                                                        </li>
                                                        <li className="nav-item" role="presentation">
                                                            <button className="nav-link btn-sm btn" id="pills-proffessional-tab" style={{ color: "white" }} data-bs-toggle="pill" data-bs-target="#pills-proffessional" role="tab">
                                                                Professional
                                                            </button>
                                                        </li>
                                                        <li className="nav-item" role="presentation">
                                                            <button className="nav-link btn-sm btn" id="pills-depth-tab" style={{ color: "white" }} data-bs-toggle="pill" data-bs-target="#pills-depth" role="tab">
                                                                Depth
                                                            </button>
                                                        </li>
                                                    </ul>
                                                </div>
                                            </div>
                                            <div>
                                                <div className="tab-content" id="pills-tabContent">
                                                    <div className="tab-pane fade show active" id="pills-basic" role="tabpanel">
                                                        <div className=" d-flex justify-content-center">
                                                            <img src={lgGraph} className="imageSize" />
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                        </Box>
                                    </Grid>
                                    {/* Graph Main Card ends*/}
                                    {/* Right Side Card small card-1 */}
                                    <Grid item xs={12} md={4} lg={4}>
                                        <Card sx={{ minWidth: 100, background: "var(--market-fav-card-bg-color)" }}>
                                            <CardContent>
                                                <Box sx={{ width: "100%", typography: "body1" }}>
                                                    <div className="d-flex justify-content-between">
                                                        <Box>
                                                            <Typography variant="h5" className="text-blue">Order Book</Typography>
                                                            <hr className="text-blue title-border" />
                                                        </Box>
                                                        <div>
                                                            <ul
                                                                className="nav nav-pills pills mb-2 my-2"
                                                                id="pills-tab pills-icons"
                                                                role="tablist">
                                                                <li className="nav-item" role="presentation">
                                                                    <button className="nav-link active btn-sm btn" id="pills-home-tab" data-bs-toggle="pill" data-bs-target="#pills-home" role="tab">
                                                                        <VerticalSplitIcon sx={{ color: "var(--icon-color)" }} />
                                                                    </button>
                                                                </li>
                                                                <li className="nav-item" role="presentation">
                                                                    <button className="nav-link btn-sm btn" id="pills-home-tab" data-bs-toggle="pill" data-bs-target="#pills-home" role="tab">
                                                                        <SegmentIcon sx={{ color: "var(--icon-color)", }} />
                                                                    </button>
                                                                </li>
                                                                <li className="nav-item" role="presentation">
                                                                    <button className="nav-link btn-sm btn" id="pills-home-tab" data-bs-toggle="pill" data-bs-target="#pills-home" role="tab">
                                                                        <SegmentIcon sx={{ color: "#DD2942" }} />
                                                                    </button>
                                                                </li>
                                                            </ul>
                                                        </div>
                                                    </div>
                                                    {/* Table_one */}
                                                    <TableContainer className="tableProperty overflowX" component={Paper}>
                                                        <Table sx={{ minWidth: "auto" }} aria-label="simple table" className="tableProperty">
                                                            <TableHead className="border-0">
                                                                <TableRow>
                                                                    <TableCell className="textClr-thead  border-0 p-0" align="left">
                                                                        Price(USDT)
                                                                    </TableCell>
                                                                    <TableCell className="textClr-thead  border-0 p-0" align="center">
                                                                        Quantity(Cont)
                                                                    </TableCell>
                                                                    <TableCell className="textClr-thead  border-0 p-0" align="center">
                                                                        Total(Cont)
                                                                    </TableCell>
                                                                </TableRow>
                                                            </TableHead>
                                                            <TableBody>
                                                                {dublicateData.map((data) => (<TableRow className="border-0">
                                                                    <TableCell className="index-text-red border-0 p-0" align="left">
                                                                        <span className="index-text-red ">0.0000067312</span>
                                                                    </TableCell>
                                                                    <TableCell className="index-text  border-0 p-0" align="center">
                                                                        2.555M
                                                                    </TableCell>
                                                                    <TableCell className="index-text  border-0 py-1" align="center">
                                                                        <Typography className="thead-red-bg px-sm-2 px-lg-2 p-1">17.1952814660</Typography>
                                                                    </TableCell>
                                                                </TableRow>))}
                                                            </TableBody>
                                                        </Table>
                                                    </TableContainer>
                                                    {/* Table_two */}
                                                    <TableContainer className="tableProperty overflowX pt-2" component={Paper}>
                                                        <Table sx={{ minWidth: "auto" }} aria-label="simple table" className="tableProperty">
                                                            <TableHead className="border-0">
                                                                <TableRow>
                                                                    <TableCell className="textClr-thead  border-0 p-0" align="left">
                                                                        <Typography className="text-green fs-5">42562.00</Typography>
                                                                    </TableCell>
                                                                    <TableCell className="textClr-thead  border-0 p-0" align="center">
                                                                        <Typography className="text-white">42562.90</Typography>
                                                                    </TableCell>
                                                                </TableRow>
                                                            </TableHead>
                                                            <TableBody>
                                                                {dublicateData.map((data) => (<TableRow className="border-0">
                                                                    <TableCell className=" border-0  p-0" align="left">
                                                                        <Typography className="text-green ">0.0000067312</Typography>
                                                                    </TableCell>
                                                                    <TableCell className="index-text  border-0 p-0" align="center">
                                                                        2.555M
                                                                    </TableCell>
                                                                    <TableCell className="index-text  border-0 py-1" align="center">
                                                                        <Typography className="thead-green-bg p-1">17.1952814660</Typography>
                                                                    </TableCell>
                                                                </TableRow>))}
                                                            </TableBody>
                                                        </Table>
                                                    </TableContainer>
                                                    <hr className="text-blue" />
                                                    {/* Market Traders */}
                                                    {/*Market Traders Table */}
                                                    <Box>
                                                        <Typography variant="h5" className="text-blue ">Market Trades</Typography>
                                                        <hr className="text-blue title-border-1" />
                                                    </Box>
                                                    <TableContainer className="tableProperty overflowX" component={Paper}>
                                                        <Table sx={{ minWidth: "auto" }} aria-label="simple table" className="tableProperty">
                                                            <TableHead className="border-0">
                                                                <TableRow>
                                                                    <TableCell className="textClr-thead  border-0 py-1" align="left">
                                                                        Price(USDT)
                                                                    </TableCell>
                                                                    <TableCell className="textClr-thead  border-0 py-1" align="left">
                                                                        Quantity(Cont)
                                                                    </TableCell>
                                                                    <TableCell className="textClr-thead  border-0 py-1" align="center">
                                                                        Time
                                                                    </TableCell>
                                                                </TableRow>
                                                            </TableHead>
                                                            <TableBody>
                                                                <TableRow className="border-0">
                                                                    <TableCell className="index-text-red border-0 py-1" align="left">
                                                                        <span className="index-text-red">0.0000067312</span>
                                                                    </TableCell>
                                                                    <TableCell className="index-text  border-0 py-0" align="left">
                                                                        11.066M
                                                                    </TableCell>
                                                                    <TableCell className="index-text  border-0 py-0" align="center">
                                                                        <span className="p-1">10:54:13</span>
                                                                    </TableCell>
                                                                </TableRow>
                                                                <TableRow className="border-0">
                                                                    <TableCell className="index-text-red border-0 py-1" align="left">
                                                                        <span className="index-text-red">0.0000067312</span>
                                                                    </TableCell>
                                                                    <TableCell className="index-text  border-0 py-0" align="left">
                                                                        11.066M
                                                                    </TableCell>
                                                                    <TableCell className="index-text  border-0 py-0" align="center">
                                                                        <span className="p-1">10:54:13</span>
                                                                    </TableCell>
                                                                </TableRow>
                                                                <TableRow className="border-0">
                                                                    <TableCell className="index-text-red border-0 py-1" align="left">
                                                                        <span className="index-text-red">0.0000067312</span>
                                                                    </TableCell>
                                                                    <TableCell className="index-text  border-0 py-0" align="left">
                                                                        11.066M
                                                                    </TableCell>
                                                                    <TableCell className="index-text  border-0 py-0" align="center">
                                                                        <span className="p-1">10:54:13</span>
                                                                    </TableCell>
                                                                </TableRow>
                                                                <TableRow className="border-0">
                                                                    <TableCell className="index-text-red border-0 py-1" align="left">
                                                                        <span className="index-text-green">0.0000067312</span>
                                                                    </TableCell>
                                                                    <TableCell className="index-text  border-0 py-0" align="left">
                                                                        11.066M
                                                                    </TableCell>
                                                                    <TableCell className="index-text  border-0 py-0" align="center">
                                                                        <span className=" p-1">10:54:13</span>
                                                                    </TableCell>
                                                                </TableRow>
                                                                <TableRow className="border-0">
                                                                    <TableCell className="index-text-red border-0 py-1" align="left">
                                                                        <span className="index-text-green">0.0000067312</span>
                                                                    </TableCell>
                                                                    <TableCell className="index-text  border-0 py-0" align="left">
                                                                        11.066M
                                                                    </TableCell>
                                                                    <TableCell className="index-text  border-0 py-0" align="center">
                                                                        <span className=" p-1">10:54:13</span>
                                                                    </TableCell>
                                                                </TableRow>
                                                            </TableBody>
                                                        </Table>
                                                    </TableContainer>
                                                </Box>
                                            </CardContent>
                                        </Card>
                                    </Grid>
                                    {/* Right Side Card small card-1 end*/}
                                    {/* Bottom Table */}
                                    <Grid item xs={12} md={12} lg={12}>
                                    <TabContext value={trend}>
                                        <div className="d-lg-flex justify-content-lg-between align-items-center">
                                            <div>
                                                <Box sx={{ marginTop: "10px" }} id="indicator">
                                                    <TabList variant="scrollable" onChange={trending} aria-label="lab API tabs example">
                                                        <Tab sx={{ fontSize: "15px", color: "#fff", fontWeight: 500, textTransform: "none" }}
                                                            label="Current positions(0)" value="1" className="greenColorTab" />
                                                        <Tab sx={{ fontSize: "15px", color: "#fff", fontWeight: 500, textTransform: "none" }}
                                                            label="Stop-limit(0)" value="2" className="greenColorTab" />
                                                        <Tab sx={{ fontSize: "15px", color: "#fff", fontWeight: 500, textTransform: "none" }}
                                                            label="position records" value="3" className="greenColorTab" />
                                                        <Tab sx={{ fontSize: "15px", color: "#fff", fontWeight: 500, textTransform: "none" }}
                                                            label="Limit order(0)" value="4" className="greenColorTab" />
                                                        <Tab sx={{ fontSize: "15px", color: "#fff", fontWeight: 500, textTransform: "none" }}
                                                            label="Trigger order(0)" value="5" className="greenColorTab" />
                                                        <Tab sx={{ fontSize: "15px", color: "#fff", fontWeight: 500, textTransform: "none" }}
                                                            label="Order records" value="6" className="greenColorTab" />
                                                    </TabList>
                                                </Box>
                                            </div>
                                            <div className="d-flex align-items-center mt-2 ms-sm-5 ms-lg-0">
                                                <Typography className="pe-3 textClr-thead">Show all</Typography>
                                                <FormControlLabel control={<IOSSwitch defaultChecked />} />
                                            </div>
                                        </div>
                                        <TabPanel value="1">
                                            <TableContainer className="tableBox-shadow border-0">
                                                <Table sx={{ minWidth: "auto", background: "transparent" }} className="" aria-label="simple table">
                                                    <TableHead>

                                                        <TableRow>
                                                            <TableCell className="textClr-thead  border-0 fw-bold" align="center">
                                                                Futures
                                                            </TableCell>
                                                            <TableCell className="textClr-thead  border-0  fw-bold" align="center">
                                                                Position/Available for Closing (Cont)
                                                            </TableCell>
                                                            <TableCell className="textClr-thead  border-0 fw-bold" align="center">
                                                                Avg.Price/Est.Liq Price
                                                            </TableCell>
                                                            <TableCell className="textClr-thead  border-0  fw-bold" align="center">
                                                                Floating P&L/Yield
                                                            </TableCell>
                                                            <TableCell className="textClr-thead   border-0 fw-bold" align="center">
                                                                Position margin
                                                            </TableCell>
                                                            <TableCell className="textClr-thead   border-0 fw-bold" align="center">
                                                                Realized P&L
                                                            </TableCell>
                                                            <TableCell className="textClr-thead  border-0  fw-bold" align="center">
                                                                Auto deleveraging [ADL]
                                                            </TableCell>
                                                            <TableCell className="textClr-thead index-fontSiz  border-0 fw-bold" align="center">
                                                                Operating
                                                            </TableCell>
                                                        </TableRow>
                                                    </TableHead>
                                                    <TableBody>
                                                        <TableRow>
                                                            <TableCell align="center" colSpan={8} sx={{ justifyContent: "center", alignItems: "center" }} className="border-0">
                                                                <img src={NODATA} className="pt-5" />
                                                            </TableCell>
                                                        </TableRow>
                                                    </TableBody>
                                                </Table>
                                            </TableContainer>
                                        </TabPanel>
                                    </TabContext>
                                    </Grid>
                                    {/* Bottom Table End*/}
                                </Grid>
                            </Grid>
                            {/* Right Side Card small card-2 */}
                            <Grid item xs={12} md={3} lg={3}>
                                <Card sx={{ minWidth: 100, background: "var(--market-fav-card-bg-color)" }}>
                                    <CardContent>
                                        <Box sx={{ width: "100%", typography: "body1" }}>
                                            <Grid container sx={{ display: 'flex', alignItems: 'center' }} spacing={6}>
                                                <Grid item xs={6} sm={6} md={6} lg={6} className="d-flex justify-content-center mb-3">
                                                    <Box>
                                                        <Typography variant="h6" className="text-white text-center mb-2">Open</Typography>
                                                        <Typography className="text-center index-text-green thead-green-bg px-2 p-1">Isolated.69X</Typography>
                                                    </Box>
                                                </Grid>
                                                <Grid item xs={6} sm={6} md={6} lg={6} className="d-flex justify-content-center mb-3">
                                                    <Box>
                                                        <Typography variant="h6" className="text-white text-center mb-2">Close</Typography>
                                                        <Typography className=" text-center index-text-red thead-red-bg px-2 p-1">Isolated.71X</Typography>
                                                    </Box>
                                                </Grid>
                                            </Grid>
                                            <Box className="d-flex align-items-center justify-content-between mb-2">
                                                <div><Typography className="text-white fs-sm" >Limit price</Typography></div>
                                                <div><Typography className="text-white fs-sm">BBO</Typography></div>
                                                <div className="d-flex">
                                                    <select style={{ fontWeight: 600 }} className="indexSelect form-select option-fs-sm text-blue" aria-label="Default select example">
                                                        <option className='text-blue option-fs-sm' selected>Trigger-Limit</option>
                                                        <option className='text-blue option-fs-sm' value="1">0x202x0</option>
                                                        <option className='text-blue option-fs-sm' value="2">0xx545</option>
                                                        <option className='text-blue option-fs-sm' value="3">0x789x</option>
                                                    </select>
                                                    <InfoOutlinedIcon className="textClr-thead" />
                                                </div>
                                            </Box>
                                            <Box className="d-flex align-items-center justify-content-between mb-3">
                                                <div><Typography className="textClr-thead fs-sm" >Available<span className="text-white ps-1">0.0000 USDT</span></Typography></div>
                                                <div className="d-flex align-items-center">
                                                    <CachedOutlinedIcon className="textClr-thead pe-1" />
                                                    <ArticleIcon className="textClr-thead pe-1" />
                                                    <Typography className="textClr-thead pe-1 pt-2" role="button" onClick={()=>{handleCalculatorClickOpen()}}>%</Typography>
                                                </div>
                                            </Box>
                                            <div className="">
                                                <Box className="d-flex">
                                                    <div className="col-6">
                                                        <select className="futuresSelect form-select option-fs-sm text-light" aria-label="Default select example">
                                                            <option className='text-light option-fs-sm' selected>Trigger-Limit</option>
                                                            <option className='text-light option-fs-sm' value="1">0x202x0</option>
                                                            <option className='text-light option-fs-sm' value="2">0xx545</option>
                                                            <option className='text-light option-fs-sm' value="3">0x789x</option>
                                                        </select>
                                                    </div>
                                                    <div className="col-6 d-grid">
                                                        <Button className="futuresButton ms-3" sx={{ textTransform: 'none' }}>Long-term effectiven</Button>
                                                    </div>
                                                </Box>
                                                {/* Input Field */}
                                                <Box>
                                                    <div className="d-flex  mt-3" style={{ height: "60px" }}>
                                                        <span className="priceTag pe-2">
                                                            <b className="text-center text-muted">
                                                                Trigger price
                                                            </b>
                                                        </span>
                                                        <input type="text" className="form-control futureInput-bg form-input-usd" style={{ border: "none", borderTopRightRadius: 0, borderBottomRightRadius: 0, height: "40px" }} />
                                                        <select
                                                            className="form-select form-select-sm form-select option-fs-sm text-light form-control-usd futuresSelect"
                                                            style={{ width: "5rem", height: "40px", fontWeight: 700, fontSize: "15px", border: "none", borderTopLeftRadius: 0, borderBottomLeftRadius: 0 }}>
                                                            <option value="1" className="text-white">
                                                                USDT
                                                            </option>
                                                            <option value="2" className="text-white">
                                                                USDT
                                                            </option>
                                                            <option value="3" className="text-white">
                                                                USDT
                                                            </option>
                                                        </select>
                                                    </div>
                                                    <div className="d-flex" style={{ height: "60px" }}>
                                                        <span className="priceTag pe-2">
                                                            <b className="text-center text-muted">
                                                                Price
                                                            </b>
                                                        </span>
                                                        <input type="text" className="form-control futureInput-bg form-input-usd" style={{ border: "none", borderTopRightRadius: 0, borderBottomRightRadius: 0, height: "40px" }} />
                                                        <select
                                                            className="form-select form-select-sm form-select option-fs-sm text-light form-control-usd futuresSelect"
                                                            style={{ width: "5rem", height: "40px", fontWeight: 700, fontSize: "15px", border: "none", borderTopLeftRadius: 0, borderBottomLeftRadius: 0 }}>
                                                            <option value="1" className="text-white">
                                                                USDT
                                                            </option>
                                                            <option value="2" className="text-white">
                                                                USDT
                                                            </option>
                                                            <option value="3" className="text-white">
                                                                USDT
                                                            </option>
                                                        </select>
                                                    </div>
                                                    <div className="d-flex" style={{ height: "60px" }}>
                                                        <div class="input-group mb-3">
                                                            <b className="input-group-text text-muted startInput-bg fw-bold">Quantity</b>
                                                            <input type="text" className="form-control futuresInput-bg" />
                                                            <span class="input-group-text text-white endInput-bg">Cont</span>
                                                        </div>
                                                    </div>
                                                    <input type="range" style={{ width: "98%" }} id="green" className="input-green" name="vol" min="0" max="100" />
                                                    <div className="d-flex justify-content-between ms-1">
                                                        <Typography sx={{ color: "white" }}>
                                                            Buy 0Cont
                                                        </Typography>
                                                        <Typography sx={{ color: "white" }}>
                                                            Sell 0Cont
                                                        </Typography>
                                                    </div>
                                                </Box>
                                                {/* end */}
                                                {/* Button  Section */}
                                                <hr className="text-blue" />
                                                <Box className="row d-flex my-4">
                                                    <div className=" col-6 d-grid">
                                                        <button className="btn fs-sm mb-2 walletBtn-text" style={{ background: "#1B9368", color: "white" }} type="button">
                                                            Buy/Long-69X
                                                        </button>
                                                        <Box className="d-flex justify-content-between">
                                                            <div><Typography className="textClr-thead">Margin</Typography></div>
                                                            <div><Typography className="text-white">USDT</Typography></div>
                                                        </Box>
                                                        <Box className="d-flex justify-content-between">
                                                            <div><Typography className="textClr-thead">Buy Long</Typography></div>
                                                            <div><Typography className="text-white">0 Cont</Typography></div>
                                                        </Box>
                                                    </div>
                                                    <div className="d-grid col-6">
                                                        <button className="btn fs-sm mb-2 walletBtn-text" style={{ background: "#DD2942", color: "white" }} type="button">
                                                            Sell/Short-71X
                                                        </button>
                                                        <Box className="d-flex justify-content-between">
                                                            <div><Typography className="textClr-thead">Margin</Typography></div>
                                                            <div><Typography className="text-white">USDT</Typography></div>
                                                        </Box>
                                                        <Box className="d-flex justify-content-between">
                                                            <div><Typography className="textClr-thead">Sell Short</Typography></div>
                                                            <div><Typography className="text-white">0 Cont</Typography></div>
                                                        </Box>
                                                    </div>
                                                </Box>
                                                <hr className="text-blue" />
                                                {/* end */}
                                                <Box className="d-flex align-items-center justify-content-between mb-2">
                                                    <div><Typography className="text-white fs-sm" >Wallet</Typography></div>
                                                    <div>
                                                        <select className="indexSelect form-select option-fs-sm text-white" aria-label="Default select example">
                                                            <option className='text-dark option-fs-sm' selected>USDT</option>
                                                            <option className='text-dark option-fs-sm' value="1">USDT</option>
                                                            <option className='text-dark option-fs-sm' value="2">USDT</option>
                                                            <option className='text-dark option-fs-sm' value="3">USDT</option>
                                                        </select>
                                                    </div>
                                                </Box>
                                                {/* Wallet Button */}
                                                <Box className="row d-flex mt-4 mb-2">
                                                    <div className=" col-6 d-grid">
                                                        <button className="btn fs-sm mb-2" style={{ background: "#577A88", color: "white" }} type="button">
                                                            Deposit
                                                        </button>
                                                    </div>
                                                    <div className=" col-6 d-grid">
                                                        <button className="btn fs-sm mb-2" style={{ background: "#577A88", color: "white" }} type="button" onClick={()=>{handleCryptoClickOpen()}}>
                                                            Transfer
                                                        </button>
                                                    </div>
                                                </Box>
                                                {/* end */}
                                                {/* Wallet Data */}
                                                <Typography className="text-white">Unrealished P&L</Typography>
                                                <Typography className="index-text-red mt-2">0.00000000</Typography>
                                                <Box>
                                                    <Box className="d-flex justify-content-between my-1">
                                                        <div><Typography className="textClr-thead">Wallet balance</Typography></div>
                                                        <div><Typography className="text-white">0.00000000</Typography></div>
                                                    </Box>
                                                    <Box className="d-flex justify-content-between mb-1">
                                                        <div><Typography className="textClr-thead">Total equity</Typography></div>
                                                        <div><Typography className="text-white">0.00000000</Typography></div>
                                                    </Box>
                                                    <Box className="d-flex justify-content-between mb-1">
                                                        <div><Typography className="textClr-thead">Margin of order</Typography></div>
                                                        <div><Typography className="text-white">0.00000000</Typography></div>
                                                    </Box>
                                                    <Box className="d-flex justify-content-between mb-1">
                                                        <div><Typography className="textClr-thead">Position margin</Typography></div>
                                                        <div><Typography className="text-white">0.00000000</Typography></div>
                                                    </Box>
                                                    <Box className="d-flex justify-content-between mb-1">
                                                        <div><Typography className="textClr-thead">Available balance</Typography></div>
                                                        <div><Typography className="text-white">0.00000000</Typography></div>
                                                    </Box>
                                                    <Box className="d-flex justify-content-between mb-1">
                                                        <div><Typography className="textClr-thead">Net-asset balance</Typography></div>
                                                        <div><Typography className="text-white">0.00000000</Typography></div>
                                                    </Box>
                                                </Box>
                                                {/* end */}
                                                <div className="d-flex align-items-center">
                                                    <Typography className="text-white my-2">Risk limit</Typography>
                                                    <i className="ps-1 bi bi-pencil-square textClr-thead"></i>
                                                </div>
                                                <Box>
                                                    <Box className="d-flex justify-content-between ">
                                                        <div><Typography className="index-text-green">Total equity</Typography></div>
                                                        <div><Typography className="index-text-green">0.00000000</Typography></div>
                                                    </Box>
                                                    <Box className="d-flex justify-content-between">
                                                        <div><Typography className="index-text-red">Wallet balance</Typography></div>
                                                        <div><Typography className="index-text-red my-1">0.00000000</Typography></div>
                                                    </Box>
                                                </Box>
                                            </div>
                                        </Box>
                                    </CardContent>
                                </Card>
                            </Grid>
                            {/* Right Side Card small card-2 end*/}
                        </Grid>
                    </Grid>
                </Grid>
            </div>
        </div >
    );
}
export default FuturesMarkets;