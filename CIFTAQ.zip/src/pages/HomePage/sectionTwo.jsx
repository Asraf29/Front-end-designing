import React from "react";
import Box from "@mui/material/Box";
import Tab from "@mui/material/Tab";
import redWave from '../../components/assets/images/redwave.png'
import Carousel from "react-multi-carousel";
import "react-multi-carousel/lib/styles.css";
import { TabPanel, TabList, TabContext } from "@mui/lab";
import { Container } from "@mui/system";
import ChevronRightIcon from '@mui/icons-material/ChevronRight';
import { makeStyles } from "@mui/styles";
import TableActivity from "./tableActivity";
import { Button, Grid, Typography } from "@mui/material";
import item1 from '../../components/assets/images/item1.png'
import item2 from '../../components/assets/images/item2.png';
import item3 from '../../components/assets/images/item3.png'
import item4 from '../../components/assets/images/item4.png'
import "./index.css";
const useStyles = makeStyles({
  MUITab: {
    color: 'white !important',
    fontWeight: 500,
    fontSize: '16px !important'
  }
});
const responsive = {
  superLargeDesktop: {
    // the naming can be any, depends on you.
    breakpoint: { max: 4000, min: 3000 },
    items: 5
  },
  desktop: {
    breakpoint: { max: 3000, min: 1025 },
    items: 4
  },
  desktopview: {
    breakpoint: { max: 1035, min: 1024 },
    items: 3
  },
  tablet: {
    breakpoint: { max: 1023, min: 464 },
    items: 2
  },
  mobile: {
    breakpoint: { max: 464, min: 0 },
    items: 1
  }
};

export default function SectionTwo() {

  const [value, setValue] = React.useState("1");
  const handleChange = (event, newValue) => {
    setValue(newValue);
  };
  const classes = useStyles();
  return (
    <div className="sectionTwo">
      <Box sx={{ width: "100%", typography: "body1", color: "white" }}>
        <Box>
          <div className='box-style mb-4 d-flex p-1' style={{ width: '100%', overflowX: 'scroll' }}>
            <div className='col-lg-2 col-md-3 col-sm-6 p-3 border-style mb-2'>
              <Typography sx={{ fontWeight: 700, lineHeight: '38px' }}>
                BTC/USDT <span className='ms-2' style={{ color: 'red' }}>-1.17%</span>
              </Typography>
              <div className='d-flex justify-content-between'>
                <Typography sx={{ fontWeight: 700, lineHeight: '38px', marginTop: 1 }}>
                  48306.49
                </Typography>
                <img src={redWave} className="img-size" />
              </div>

              <Typography className='vol-color' sx={{ lineHeight: '38px', color: 'grey' }}>
                24H VOL  1,222.279
              </Typography>
            </div>
            <div className='col-lg-2 col-md-3 col-sm-6 p-3 border-style mb-2'>
              <Typography sx={{ fontWeight: 700, lineHeight: '38px' }}>
                BTC/USDT <span className='ms-2' style={{ color: 'red' }}>-1.17%</span>
              </Typography>
              <div className='d-flex justify-content-between'>
                <Typography sx={{ fontWeight: 700, lineHeight: '38px', marginTop: 1 }}>
                  48306.49
                </Typography>
                <img src={redWave} className="img-size" />
              </div>

              <Typography className='vol-color' sx={{ fontWeight: 700, lineHeight: '38px' }}>
                24H VOL  1,222.279
              </Typography>
            </div>
            <div className='col-lg-2 col-md-3 col-sm-6 p-3 border-style mb-2'>
              <Typography sx={{ fontWeight: 700, lineHeight: '38px' }}>
                BTC/USDT <span className='ms-2' style={{ color: 'red' }}>-1.17%</span>
              </Typography>
              <div className='d-flex justify-content-between'>
                <Typography sx={{ fontWeight: 700, lineHeight: '38px', marginTop: 1 }}>
                  48306.49
                </Typography>
                <img src={redWave} className="img-size" />
              </div>

              <Typography className='vol-color' sx={{ lineHeight: '38px' }}>
                24H VOL  1,222.279
              </Typography>
            </div>
            <div className='col-lg-2 col-md-3 col-sm-6 p-3 border-style mb-2'>
              <Typography sx={{ fontWeight: 700, lineHeight: '38px' }}>
                BTC/USDT <span className='ms-2' style={{ color: 'red' }}>-1.17%</span>
              </Typography>
              <div className='d-flex justify-content-between'>
                <Typography sx={{ fontWeight: 700, lineHeight: '38px', marginTop: 1 }}>
                  48306.49
                </Typography>
                <img src={redWave} className="img-size" />
              </div>

              <Typography className='vol-color' sx={{ fontWeight: 700, lineHeight: '38px' }}>
                24H VOL  1,222.279
              </Typography>
            </div>
            <div className='col-lg-2 col-md-3 col-sm-6 p-3 border-style mb-2'>
              <Typography sx={{ fontWeight: 700, lineHeight: '38px' }}>
                BTC/USDT <span className='ms-2' style={{ color: 'red' }}>-1.17%</span>
              </Typography>
              <div className='d-flex justify-content-between'>
                <Typography sx={{ fontWeight: 700, lineHeight: '38px', marginTop: 1 }}>
                  48306.49
                </Typography>
                <img src={redWave} className="img-size" />
              </div>

              <Typography className='vol-color' sx={{ fontWeight: 700, lineHeight: '38px' }}>
                24H VOL  1,222.279
              </Typography>
            </div>
            <div className='col-lg-2 col-md-3 col-sm-6 p-3  mb-2'>
              <Typography sx={{ fontWeight: 700, lineHeight: '38px' }}>
                BTC/USDT <span className='ms-2' style={{ color: 'red' }}>-1.17%</span>
              </Typography>
              <div className='d-flex justify-content-between'>
                <Typography sx={{ fontWeight: 700, lineHeight: '38px', marginTop: 1 }}>
                  48306.49
                </Typography>
                <img src={redWave} className="img-size" />
              </div>

              <Typography className='vol-color' sx={{ fontWeight: 700, lineHeight: '38px' }}>
                24H VOL  1,222.279
              </Typography>
            </div>
          </div>

        </Box>
        <Container>
          <div class="container" style={{ padding: "15px" }}>
            <div class="row mb-4">
              <div class="col-lg-2">
                <div className="polygon">
                  <Typography gutterBottom color="white">
                    New Listing
                  </Typography>
                </div>
              </div>

              <div class="polygon-marquee col-lg-10">
                <div className="d-flex justify-content-between align-items-center">
                  <marquee
                    style={{ marginLeft: '15px' }}
                    direction="up"
                    loop=""
                    scrolldelay="500"
                    hspace="50"
                    vspace="50"
                  >
                    <Typography gutterBottom color="black" className="marqueeText" sx={{ fontWeight: 600 }}>
                      [ Initial Listing ] MEXC Kickstarter - Vote to win Free
                      290,000 Battle Saga [BTL] Airdrops!
                    </Typography>
                  </marquee>
                  <div >
                    <Typography sx={{ paddingTop: 1 }} gutterBottom color="black">
                      <Button className="More-btn" sx={{ color: '#1A94AE', fontWeight: 700, textTransform: 'none', textAlign: 'center' }}>More <span><ChevronRightIcon sx={{ marginBottom: 0.1 }} /></span></Button>
                    </Typography>
                  </div>
                </div>
              </div>
            </div>
          </div>
          <Grid container rowSpacing={1}>
            <Carousel responsive={responsive} className="container d-flex justify-content-between slider" >
              <div className="c-item">
                <div className="image">
                  <img src={item4} alt="" />
                </div>

              </div>
              <div className="c-item">
                <div className="image">
                  <img src={item1} alt="" />
                </div>

              </div>
              <div className="c-item">
                <div className="image">
                  <img src={item3} alt="" />
                </div>

              </div>
              <div className="c-item">
                <div className="image">
                  <img src={item2} alt="" />
                </div>

              </div>
              <div className="c-item">
                <div className="image">
                  <img src={item3} alt="" />
                </div>

              </div>
              <div className="c-item">
                <div className="image">
                  <img src={item1} alt="" />
                </div>

              </div>
              <div className="c-item">
                <div className="image">
                  <img src={item2} alt="" />
                </div>

              </div>
              <div className="c-item">
                <div className="image">
                  <img src={item4} alt="" />
                </div>

              </div>

            </Carousel>
          </Grid>
          <TabContext value={value}>
            <Box sx={{ borderBottom: 1, borderColor: "divider" }}>
              <Container sx={{ marginTop: 4 }}>
                <TabList
                  onChange={handleChange}
                  aria-label="lab API tabs example"
                >
                  <Tab
                    className={classes.MUITab}
                    label="Top Gainers (Daily)"
                    value="1"
                  />
                  <Tab
                    className={classes.MUITab}
                    label="Top Gainers (Weekly)"
                    value="2"
                  />
                  <Tab
                    className={classes.MUITab}
                    label="Top Activity (New Tokens)"
                    value="3"
                  />
                  <Tab
                    className={classes.MUITab}
                    label=" Top Futures List"
                    value="4"
                  />
                </TabList>
              </Container>
            </Box>
            <TabPanel value="1">
              <TableActivity />
            </TabPanel>
            <TabPanel value="2">
              <TableActivity />
            </TabPanel>
            <TabPanel value="3">
              <TableActivity />
            </TabPanel>
            <TabPanel value="4">
              <TableActivity />
            </TabPanel>
          </TabContext>
        </Container>
      </Box>
    </div>
  );
}
