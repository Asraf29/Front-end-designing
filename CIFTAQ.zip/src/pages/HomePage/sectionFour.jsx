import { Grid, Typography } from '@mui/material';
import React from 'react'

const SectionFour = () => {
    return (
        
        <div  className='bgImage'>
            <div sx={{ width: "100%", typography: "body1", color: "white" }} className="py-5">
                <Typography className="sectionTilte" variant='h4'>Join the CIFDAQ community today</Typography>
                <Typography className='sec4SubTitle'>Question? Contact our 24/7 Customer Support</Typography>
                <Grid container sx={{ mt: 3 }}>
                    <Grid item xs={6} sm={6} md={6} lg={6}>
                        <button className='btn d-flex align-items-center twitter-btn  ms-auto px-4 py-2'><i class="bi bi-twitter iconColor pe-1"></i>Twitter</button>
                        <Grid />
                    </Grid>
                    <Grid item xs={6} sm={6} md={6} lg={6}>
                        <button className='btn  d-flex align-items-center telegram-btn ms-2  px-4 py-2'><i class="bi bi-telegram iconColor pe-1"></i>Telegram</button>
                    </Grid>
                </Grid>
                <div className='d-flex justify-content-center gap-1 pt-4'>
                    <i class="bi bi-facebook fbIcon icon p-3"></i>
                    <i class="bi bi-linkedin LinkedInIcon icon p-3"></i>
                    <i class="bi bi-reddit redditIcon icon p-3" ></i>
                    <i class="bi bi-skype skypeIcon icon p-3"></i>
                    <i class="bi bi-instagram instaIcon icon p-3"></i>
                    <i class="bi bi-github gitIcon icon p-3"></i>
                </div>
            </div>
        </div>
    )
}
export default SectionFour;
