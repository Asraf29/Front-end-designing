import { Typography } from "@mui/material";
import React from "react";
import USDT from "../../components/assets/images/USDT.png";
export default function SectionOne() {
  return (
    <div className="sectionOne">
      <div className="col-lg-4 col-sm-12 col-md-6 col ms-5 ps-lg-4 pt-lg-5 pt-md-5 ">
        <Typography
          className="width-set pt-5"
          sx={{ color: "white", fontSize: "40px", fontWeight: 600 }}
        >
          Welcome to MEXC
        </Typography>
        <Typography sx={{ color: "white", fontSize: "20px", fontWeight: 500 }}>
          Trade crypto fast with MEXC
        </Typography>
        <div>
          <div className="mb-2 d-flex  mt-4 pe-5" style={{ height: "60px" }}>
            <span className="coin-icon pe-2 border-inputed">
              <img src={USDT} /> <b className="input-text">USDT</b>
            </span>
            <input
              type="text"
              className="form-control form-control-usd form-input-usd"
              style={{
                border: "none",
                borderTopRightRadius: 0,
                borderBottomRightRadius: 0,
              }}
            />

            <select
              className="form-select form-select-sm form-control-usd selction-bg"
              style={{
                width: "7rem",
                fontWeight: 700,
                fontSize: "20px",
                border: "none",
                borderTopLeftRadius: 0,
                borderBottomLeftRadius: 0,

              }}
              aria-label="Default select example"
            >
              <option value="1" className="selectionText"> USD </option>
              <option value="2" className="selectionText"> USDT</option>
              <option value="3" className="selectionText"> USTD</option>
            </select>
          </div>
        </div>
      </div>
    </div>
  );
}
