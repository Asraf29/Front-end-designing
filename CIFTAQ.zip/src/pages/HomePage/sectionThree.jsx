import { Box, Grid, Typography } from '@mui/material';
import { Container } from '@mui/system';
import React from 'react'
import screenPic from '../../components/assets/images/ScreenPic.png'
import QRCode from '../../components/assets/images/QRCode.png'
import Card from '@mui/material/Card';
import CardContent from '@mui/material/CardContent';
import cardImage1 from '../../components/assets/images/profit.png'
import cardImage2 from '../../components/assets/images/weight.png'
import cardImage3 from '../../components/assets/images/IncMoney.png'
const bull = (
    <Box
        component="span"
        sx={{ display: 'inline-block', mx: '2px', transform: 'scale(0.8)' }}
    >
        •
    </Box>
);
const SectionThree = () => {
    return (
        <div className='backgroundImage' >
            <div >
                <Typography className="sectionTilte" variant='h4'>Trade AnyWhere With the MEXC App</Typography>
                <Typography className='subTitle'>Full ios, Andriod & Windows Support</Typography>
            </div>
            <div >
                <Container className="px-md-5">
                    <Grid container sx={{ mt: 4 }}>
                        <Grid item xs={12} sm={6} md={6} lg={6}>
                            <Box
                                component="img"
                                className='img-fluid'
                                alt="Image"
                                src={screenPic}/>
                        </Grid>
                        <Grid item xs={12} sm={6} md={6} lg={6}>
                            <Grid container>
                                <Grid item xs={6} sm={6} md={6} lg={6}>
                                    <p className='text-center'><Box
                                        component="img"
                                        className='img-fluid'
                                        alt="Image"
                                        src={QRCode}
                                    /></p>
                                </Grid>
                                <Grid item xs={6} sm={6} md={6} lg={6}>
                                    <Typography className='ps-2 appDescription'>Scan to download
                                        for a seamless
                                        MEXC mobile
                                        trading
                                        experience
                                    </Typography>
                                </Grid>
                            </Grid>
                            <Grid container>
                                <Grid item xs={6} sm={6} md={6} lg={6}>
                                    <div className="d-grid gap-3 px-lg-5">
                                        <button className='btn  d-flex align-items-center playstorBtn'><i class="bi bi-play-fill fs-3"></i>Playstore</button>
                                        <button className='btn  d-flex align-items-center apiBtn'><i class="bi bi-link-45deg fs-3"></i>API</button>
                                    </div>
                                    <Grid />
                                </Grid>
                                <Grid item xs={6} sm={6} md={6} lg={6}>
                                    <div className="d-grid ps-1 pe-lg-5">
                                        <button className='btn  d-flex align-items-center windowsBtn'><i class="bi bi-windows fs-5 me-1"></i> Windows</button>
                                    </div>
                                </Grid>
                            </Grid>
                        </Grid>
                    </Grid>
                </Container>
                <Box sx={{ flexGrow: 1 }} className="px-lg-5 px-4 mx-lg-5 mt-4 mt-lg-3 mb-5">
                    <Grid container spacing={4}>
                        <Grid item xs={12} lg={4} md={4} sm={6}>
                            <Card className='cardBg cardProperty py-3'>
                                <CardContent>
                                    <p className='text-center'><Box
                                        component="img"
                                        className='img-fluid'
                                        alt="Logo"
                                        src={cardImage1}
                                    />
                                     <Typography variant="h6" className='cardText'>Maximise profit with leverage</Typography></p>
                                </CardContent>
                            </Card>
                        </Grid>
                        <Grid item xs={12} lg={4} md={4} sm={6}>
                            <Card className='cardBg cardProperty py-3'>
                                <CardContent>
                                    <p className='text-center'><Box
                                        component="img"
                                        className='cardImageTwo'
                                        alt="Logo"
                                        src={cardImage2}
                                    />
                                        <Typography variant="h6" className='cardText pt-3'>Up to 125x leverage with better
                                            Spreads</Typography></p>
                                </CardContent>
                            </Card>
                        </Grid>
                        <Grid item xs={12} lg={4} md={4} sm={6}>
                            <Card className='cardBg cardProperty py-3'>
                                <CardContent>
                                    <p className='text-center'><Box
                                        component="img"
                                        className='img-fluid'
                                        alt="Logo"
                                        src={cardImage3}
                                    />
                                        <Typography variant="h6" className='cardText'>Increased leverage, no liquidation
                                            risk</Typography>
                                    </p>
                                </CardContent>
                            </Card>
                        </Grid>
                    </Grid>
                </Box>
            </div>
        </div>
    )
}
export default SectionThree;