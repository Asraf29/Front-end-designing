import React from 'react'
import { styled } from '@mui/material/styles';
import Table from '@mui/material/Table';
import TableBody from '@mui/material/TableBody';
import TableCell, { tableCellClasses } from '@mui/material/TableCell';
import TableContainer from '@mui/material/TableContainer';
import TableHead from '@mui/material/TableHead';
import TableRow from '@mui/material/TableRow';
import { Button } from '@mui/material';
import ChevronRightIcon from '@mui/icons-material/ChevronRight';
import Paper from '@mui/material/Paper';

const StyledTableCell = styled(TableCell)(({ theme }) => ({
  [`&.${tableCellClasses.head}`]: {
    backgroundColor: theme.palette.common.white,
    color: theme.palette.common.grey,
    fontWeight: 700,
    color: 'grey'
  },
  [`&.${tableCellClasses.body}`]: {
    fontSize: 14,
  },
}));
const StyledTableRow = styled(TableRow)(({ theme }) => ({
  '&:nth-of-type(odd)': {
    backgroundColor: theme.palette.action.hover,
  },
  // hide last border
  '&:last-child td, &:last-child th': {
    border: 0,
  },
}));



const Item = styled(Paper)(({ theme }) => ({
  backgroundColor: theme.palette.mode === 'dark' ? '#000' : '#fff',
  ...theme.typography.body2,
  padding: theme.spacing(1),
  textAlign: 'center',
  color: theme.palette.text.secondary,
}));

export default function TableActivity() {
  function createData(TradingPair, price, change, hour, low, volume) {
    return { TradingPair, price, change, hour, low, volume };
  }

  const rows = [
    createData('PLANETS/USDT ', 159, 6.0, 24, 4.0, 266.069),
    createData('FREE3L/USDT ', 237, 9.0, 37, 4.3, 269.069),
    createData('XFIN/USDT', 262, 16.0, 24, 6.0, 268.069),
    createData('PLANETS/USDT ', 305, 3.7, 67, 4.3, 278.069),
    createData('XFIN/USDT', 356, 16.0, 49, 3.9, 298.069),
  ];


  return (
    <div>
      <TableContainer sx={{background:'var(--card-bg-color)'}} component={Paper}>
        <Table sx={{ minWidth: 700, background:'var(--card-bg-color)'}} aria-label="customized table">

          <TableHead>
            <TableRow sx={{ fontWeight: 'bold !important',background:'var(--card-bg-color) !important' }}>
              <StyledTableCell sx={{background:'var(--card-bg-color)!important'}}>Trading Pair </StyledTableCell>
              <StyledTableCell sx={{background:'var(--card-bg-color)!important'}} align="right">Price</StyledTableCell>
              <StyledTableCell sx={{background:'var(--card-bg-color)!important'}} align="right">Change[%] </StyledTableCell>
              <StyledTableCell sx={{background:'var(--card-bg-color)!important'}} align="right">24h High</StyledTableCell>
              <StyledTableCell sx={{background:'var(--card-bg-color)!important'}} align="right">24h Low </StyledTableCell>
              <StyledTableCell sx={{background:'var(--card-bg-color)!important'}} align="right">24h Volume </StyledTableCell>
            </TableRow>
          </TableHead>
          <TableBody>
            {rows.map((row) => (
              <StyledTableRow key={row.name}>
                <StyledTableCell  component="th" scope="row" sx={{ fontWeight: '700' ,color:'var(--table-txt)' }}>
                  {row.TradingPair}
                </StyledTableCell>
                <StyledTableCell sx={{color:'var(--table-txt)'}} align="right">{row.price}</StyledTableCell>
                <StyledTableCell sx={{color:'green'}} align="right">{row.change}</StyledTableCell>
                <StyledTableCell sx={{color:'var(--table-txt)'}} align="right">{row.hour}</StyledTableCell>
                <StyledTableCell sx={{color:'var(--table-txt)'}} align="right">{row.low}</StyledTableCell>
                <StyledTableCell sx={{color:'var(--table-txt)'}} align="right">{row.volume}</StyledTableCell>
              </StyledTableRow>
            ))}
          </TableBody>
          <TableCell align="center" sx={{border:'none !important'}} colSpan={6} > <Button sx={{ color: '#1A94AE', fontWeight: 700, textTransform: 'none' }}>More <span><ChevronRightIcon sx={{ marginBottom: 0.1 }} /></span></Button></TableCell>
        </Table>
      </TableContainer>
    </div>
  )
}
