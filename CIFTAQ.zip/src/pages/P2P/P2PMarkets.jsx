import { Avatar, Card, CardContent, ListItemText, Table, TableBody, TableCell, TableContainer, TableHead, TableRow, Typography } from '@mui/material'
import { Box } from '@mui/system'
import React from 'react'
import creditCard from "../../components/assets/images/creditCard.png";
import Trading from "../../components/assets/images/trading.png";
import VisibilityIcon from '@mui/icons-material/Visibility';
import ChainIcon from '../../components/assets/images/blockchain.png'
import { green } from '@mui/material/colors';
import Badge from '@mui/material/Badge';
import { styled } from '@mui/material/styles';
import TransferModal from '../../components/TransferModal/transferModal';
/*Avatar Style */
const dataLength = ['1', '2', '3'];
const StyledBadge = styled(Badge)(({ theme }) => ({
    '& .MuiBadge-badge': {
        backgroundColor: '#44b700',
        color: '#44b700',
        boxShadow: `0 0 0 2px ${theme.palette.background.paper}`,
        '&::after': {
            position: 'absolute',
            top: 0,
            left: 0,
            width: '100%',
            height: '100%',
            borderRadius: '50%',
            animation: 'ripple 1.2s infinite ease-in-out',
            border: '1px solid currentColor',
            content: '""',
        },
    },
    '@keyframes ripple': {
        '0%': {
            transform: 'scale(.8)',
            opacity: 1,
        },
        '100%': {
            transform: 'scale(2.4)',
            opacity: 0,
        },
    },
}));
const P2PMarkets = () => {
    const [tranferModal, setTransferModal] = React.useState(false);
    const openTransferModal = () => {
        setTransferModal(true);
    };

    const TransferhandleClose = () => {
        setTransferModal(false);
    };
    return (
        <>
            <TransferModal tranferModals={tranferModal} openTransferModal={openTransferModal} TransferhandleClose={TransferhandleClose} />
            <Card className="profile-page-card mt-3" sx={{ minWidth: 'auto', maxWidth: "auto" }}>
                <div className="d-lg-flex justify-content-lg-between mb-2 mt-4">
                    <div className="ms-4">
                        <ul id="tabs" className="nav nav-pills" role="tablist">
                            <li className="nav-item " role="presentation">
                                <button className="greenBtn nav-link  active" id="pills-buy-tab" data-bs-toggle="pill" data-bs-target="#BuyTab" type="button" role="tab">Buy</button>
                            </li>
                            <li className="nav-item ms-2 ms-md-4" role="presentation">
                                <button className="redBtn nav-link" id="pills-sell-tab" data-bs-toggle="pill" data-bs-target="#sellTab" type="button" role="tab">Sell</button>
                            </li>
                            <li className="nav-item ms-md-2 ms-md-4  ps-2 ps-sm-0">
                                <select id="form-select"
                                    className="form-select py-2"
                                    aria-label="Default select example">
                                    <option value="1" className='textClr'>USDT</option>
                                    <option value="2" className='textClr' >BNB</option>
                                    <option value="3" className='textClr'>Bit Coin</option>
                                </select>
                            </li>
                            <li className="nav-item ms-md-4 mt-2 mt-sm-0">
                                <select id="form-select"
                                    className="form-select py-2"
                                    aria-label="Default select example">
                                    <option value="1" className='textClr'> U.S.Dollar(USD)</option>
                                    <option value="2" className='textClr' >U.S.Dollar(USD)</option>
                                    <option value="3" className='textClr'>U.S.Dollar(USD)</option>
                                </select>
                            </li>
                        </ul>
                    </div>
                    <div className="ms-4 me-lg-4 ms-lg-0 mt-2 mt-lg-0 d-flex align-items-center">
                        <Typography className="textClr">Balance Frozen</Typography>
                        <span className="ms-2 mb-1 textClr"><VisibilityIcon /></span>
                        <Typography className="textGreen ms-2" role="button" onClick={openTransferModal}>Transfer</Typography>
                    </div>
                </div>
                <div className="tab-content container px-md-4" id="pills-tabContent">
                    {/* Buy Tab Data */}
                    <div className="tab-pane fade show active" id="BuyTab" role="tabpanel">
                        <CardContent >
                            <Box className='tab-border-bottom d-lg-flex justify-content-lg-around align-items-center'>
                                <div className="d-flex align-items-center py-2">
                                    <Box component="img" alt="Type of Trading" src={Trading} className="img-fluid " />
                                    <ListItemText className="ps-3 APITitle secondaryText" primary={'Flash Trading'} secondary={'Small amount purchases made safe and quick'} />
                                </div>
                                <div className="d-block d-sm-flex justify-content-center justify-content-lg-start ms-lg-5 ps-lg-5">
                                    <div>
                                        <input
                                            type="text" id="input-bg"
                                            className="form-control input-typing-space-transfer px-lg-2"
                                        />
                                        <span className="input-txt-left d-flex justify-content-between pe-2 text-dark">
                                            <div> <p className='textClr'>pay</p> </div>
                                        </span>
                                        <span className='input-txt-right me-2'>
                                            <p className='APITitle'>USD</p>
                                        </span>
                                    </div>
                                    <p className="text-center text-sm-start pt-2"><Box component="img" alt="chain" src={ChainIcon} className="img-fluid px-3" /></p>
                                    <div>
                                        <input
                                            type="text" id="input-bg"
                                            className="form-control input-typing-space-transfer px-lg-2"
                                        />
                                        <span className="input-txt-left d-flex justify-content-between pe-2 text-dark">
                                            <div> <p className='textClr'>Get</p> </div>
                                        </span>
                                        <span className='input-txt-right me-2'>
                                            <p className='APITitle'>USDT</p>
                                        </span>
                                    </div>
                                </div>
                                <div className="d-grid pb-sm-2  mx-sm-0 pb-2 pb-sm-0 me-sm-0 pe-sm-2 px-sm-2 px-lg-0 mt-2 mt-sm-0">
                                    <button className="btn KYC-btn-green mb-lg-3">KYC</button>
                                </div>
                            </Box>
                            <Box className="d-flex justify-content-between align-items-center my-3">
                                <div className='d-flex'>
                                    <Typography className="APITitle ">Single Orders</Typography>
                                    <Typography className="ms-3 textClr">Bulk Orders <span class="badge bg-orange text-white">&#x1F525;HOT</span></Typography>
                                </div>
                                <div>
                                    <select id="form-select"
                                        className="form-select py-2"
                                        aria-label="Default select example">
                                        <option value="1" className='textClr'> All payment methods</option>
                                        <option value="2" className='textClr' >U.S.Dollar(USD)</option>
                                        <option value="3" className='textClr'>U.S.Dollar(USD)</option>
                                    </select>
                                </div>
                            </Box>
                            {/* Table */}
                            <TableContainer className="mt-4 px-4 pb-5">
                                <Table sx={{ minWidth: 650, background: "var( --card-bg-color)" }} aria-label="simple table" className='table-border-color'>
                                    <TableHead className='table-head-bg'>
                                        <TableRow>
                                            <TableCell sx={{ fontWeight: "bolder !important" }} className="table-head-color" align="start">Seller(order Completion Rate)</TableCell>
                                            <TableCell sx={{ fontWeight: "bolder !important" }} className="table-head-color" align="start">Range(per Transaction)</TableCell>
                                            <TableCell sx={{ fontWeight: "bolder !important" }} className="table-head-color" align="start">Balance</TableCell>
                                            <TableCell sx={{ fontWeight: "bolder !important" }} className="table-head-color" align="center">Price</TableCell>
                                            <TableCell sx={{ fontWeight: "bolder !important" }} className="table-head-color" align="start">Payment Methods</TableCell>
                                            <TableCell sx={{ fontWeight: "bolder !important" }} className="table-head-color" align="center">Action</TableCell>
                                        </TableRow>
                                    </TableHead>
                                    <TableBody>
                                        {dataLength.map((data) => (<TableRow>
                                            <TableCell align="start" className="d-flex align-items-center border-bottom-0">
                                                <StyledBadge
                                                    overlap="circular"
                                                    anchorOrigin={{ vertical: 'bottom', horizontal: 'right' }}
                                                    variant="dot"
                                                >
                                                    <Avatar sx={{ bgcolor: green[400] }} alt="Remy Sharp" src="/static/images/avatar/1.jpg" />
                                                </StyledBadge>
                                                <Typography className="avatarText ps-2">Masterpiece (8 / 100%)</Typography>
                                            </TableCell>
                                            <TableCell align="start" className="avatarText border-bottom-0">5,000 - 50,000 USD</TableCell>
                                            <TableCell align="start" className="avatarText border-bottom-0">150000 USDT</TableCell>
                                            <TableCell align="center" className="text-success border-bottom-0">1 USD</TableCell>
                                            <TableCell align="start" className="text-success border-bottom-0">
                                                <Box component="img" alt="CreditCard border-bottom-0" src={creditCard} />
                                            </TableCell>
                                            <TableCell align="center" className="avatarText border-bottom-0">need<span className="text-blue ps-2">Primary KYC</span></TableCell>
                                        </TableRow>))}
                                    </TableBody>
                                </Table>
                            </TableContainer>
                        </CardContent>
                    </div>
                    {/* Sell Tab Data */}
                    <div className="tab-pane fade" id="sellTab" role="tabpanel">
                        <CardContent>
                            <Box className='tab-border-bottom d-lg-flex justify-content-lg-around align-items-center'>
                                <div className="d-flex align-items-center py-2">
                                    <Box component="img" alt="Type of Trading" src={Trading} className="img-fluid " />
                                    <ListItemText className="ps-3 APITitle secondaryText" primary={'Flash Trading'} secondary={'Small amount purchases made safe and quick'} />
                                </div>
                                <div className="d-block d-sm-flex justify-content-center justify-content-lg-start ms-lg-5 ps-lg-5">
                                    <div>
                                        <input
                                            type="text" id="input-bg"
                                            className="form-control input-typing-space-transfer px-lg-2"
                                        />
                                        <span className="input-txt-left d-flex justify-content-between pe-2 text-dark">
                                            <div> <p className='textClr'>Sell</p> </div>
                                        </span>
                                        <span className='input-txt-right me-2'>
                                            <p className='APITitle'>USDT</p>
                                        </span>
                                    </div>
                                    <p className="text-center text-sm-start pt-2"><Box component="img" alt="chain" src={ChainIcon} className="img-fluid px-3" /></p>
                                    <div>
                                        <input
                                            type="text" id="input-bg"
                                            className="form-control input-typing-space-transfer px-lg-2"
                                        />
                                        <span className="input-txt-left d-flex justify-content-between pe-2 text-dark">
                                            <div> <p className='textClr'>Get</p> </div>
                                        </span>
                                        <span className='input-txt-right me-2'>
                                            <p className='APITitle'><span className='text-danger pe-2'>All</span>USD</p>
                                        </span>
                                    </div>
                                </div>
                                <div className="d-grid pb-sm-2  mx-sm-0 pb-2 pb-sm-0 me-sm-0 pe-sm-2 px-sm-2 px-lg-0 mt-2 mt-sm-0">
                                    <button className="btn KYC-btn-red mb-lg-3">KYC</button>
                                </div>

                            </Box>
                            <Box className="d-flex justify-content-between align-items-center my-3">
                                <div className='d-flex'>
                                    <Typography className="APITitle ">Single Orders</Typography>
                                    <Typography className="ms-3 textClr">Bulk Orders <span class="badge bg-orange text-white">&#x1F525;HOT</span></Typography>
                                </div>
                                <div>
                                    <select id="form-select"
                                        className="form-select py-2"
                                        aria-label="Default select example">
                                        <option value="1" className='textClr'> All payment methods</option>
                                        <option value="2" className='textClr' >Master</option>
                                        <option value="3" className='textClr'>Platinum</option>
                                    </select>
                                </div>
                            </Box>
                            {/* Table */}
                            <TableContainer className="mt-4 px-4 pb-5">
                                <Table sx={{ minWidth: 650, background: "var( --card-bg-color)" }} aria-label="simple table" className='table-border-color'>
                                    <TableHead className='table-head-bg'>
                                        <TableRow>
                                            <TableCell sx={{ fontWeight: "bolder !important" }} className="table-head-color" align="start">Seller(order Completion Rate)</TableCell>
                                            <TableCell sx={{ fontWeight: "bolder !important" }} className="table-head-color" align="start">Range(per Transaction)</TableCell>
                                            <TableCell sx={{ fontWeight: "bolder !important" }} className="table-head-color" align="start">Balance</TableCell>
                                            <TableCell sx={{ fontWeight: "bolder !important" }} className="table-head-color" align="center">Price</TableCell>
                                            <TableCell sx={{ fontWeight: "bolder !important" }} className="table-head-color" align="start">Payment Methods</TableCell>
                                            <TableCell sx={{ fontWeight: "bolder !important" }} className="table-head-color" align="center">Action</TableCell>
                                        </TableRow>
                                    </TableHead>
                                    <TableBody>
                                        {dataLength.map((data) => (<TableRow sx={{ "&:last-child td, &:last-child th": { border: 0 } }}>
                                            <TableCell align="start" className="d-flex align-items-center">
                                                <StyledBadge
                                                    overlap="circular"
                                                    anchorOrigin={{ vertical: 'bottom', horizontal: 'right' }}
                                                    variant="dot"
                                                >
                                                    <Avatar sx={{ bgcolor: green[400] }} alt="Remy Sharp" src="/static/images/avatar/1.jpg" />
                                                </StyledBadge>
                                                <Typography className="avatarText ps-2">Masterpiece (8 / 100%)</Typography>
                                            </TableCell>
                                            <TableCell align="start" className="avatarText">5,000 - 50,000 USD</TableCell>
                                            <TableCell align="start" className="avatarText">150000 USDT</TableCell>
                                            <TableCell align="center" className="text-danger">1 USD</TableCell>
                                            <TableCell align="start">
                                                <Box component="img" alt="CreditCard" src={creditCard} />
                                            </TableCell>
                                            <TableCell align="center" className="avatarText">need<span className="text-blue ps-2">Primary KYC</span></TableCell>
                                        </TableRow>))}
                                    </TableBody>
                                </Table>
                            </TableContainer>
                        </CardContent>
                    </div>
                </div>
            </Card>
            <Card className="footerCard-bg mt-4" sx={{ minWidth: 'auto', maxWidth: "auto" }}>
                <CardContent>
                    <Typography variant="h6" className="Text-Color">
                        Trade statement
                    </Typography>
                    <ol>
                        <li className='Text-Color Text-Size'>Open trades listed on the platform are verified by MEXC. Trades will only proceed once it has been ascertained that both buyers and sellers have sufficient balance in their accounts.</li>
                        <li className='Text-Color Text-Size'>When transferring funds, do refrain from placing sensitive words like “BTC”, “USDT” and “MEXC” in the remarks field to avoid delays or transaction failures.</li>
                        <li className='Text-Color Text-Size'>Fund transfers to the listed merchants are to be performed with a payment mode that has been verified with your real identity. Otherwise, the listed merchants have the right to refuse yourtransactions and lodge complaints.</li>
                        <li className='Text-Color Text-Size'>MEXC reserves the right to disable user accounts, freeze funds and report users to the relevant authorities should illegal or suspicious activity be detected.</li>
                    </ol>
                </CardContent>
            </Card>
        </>
    )
}
export default P2PMarkets;