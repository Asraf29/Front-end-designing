import React, { useState } from 'react'
import {
    Table,
    TableBody,
    TableCell,
    TableHead,
    TableRow,
  } from "@mui/material";
import NODATA from "../../components/assets/images/nodata.png";
export default function P2PTab() {
    const [type, setType] = useState("text");
  return (
    <>
    <div className="d-block d-lg-flex justify-content-between">
    <div className="d-block d-md-flex col-lg-6 mb-3 mb-sm-0">
      <div className="col-lg-3 col-sm-12 col-md-3 mb-2 mb-sm-0">
        <input
          style={{ height: "40px" }}
          className="input-sizes inputBg"
          placeholder="Start ~ End date"
          type={type}
          onFocus={() => setType("date")}
          onBlur={() => setType("text")}
          id="date"
        />
      </div>
      <div className="d-block d-sm-flex ms-0 ms-md-5 ms-lg-5 ">
        <div className="col-lg-2 ms-0 ms-lg-5 mb-2 mb-sm-0">
          <select
            id="form-select"
            className="form-select"
            aria-label="Default select example"
          >
            <option value="1" className="textClr">
              {" "}
              All{" "}
            </option>
          </select>
        </div>

        <div className="col-lg-2  ms-0 ms-md-2 mb-2 mb-sm-0">
          <select
            id="form-select"
            className="form-select py-2  ms-0 ms-md-2"
            aria-label="Default select example"
          >
            <option value="1" className="textClr">
              {" "}
              All{" "}
            </option>
          </select>
        </div>
        <div className="col-lg-2 ms-0 ms-md-2 mb-2 mb-sm-0">
          <select
            id="form-select"
            className="form-select py-2  ms-0 ms-md-2"
            aria-label="Default select example"
          >
            <option value="1" className="textClr">
              {" "}
              All{" "}
            </option>
          </select>
        </div>
        <div className="col-lg-2  ms-0 ms-md-4">
          <input
            type="text"
            className="input-sizes inputBg"
            placeholder="Order ID"
            style={{ height: "40px" }}
          />
        </div>
      </div>
    </div>
    <div className="d-grid d-lg-flex">
      <button
        className="btn btn-sm my-2 my-lg-0"
        style={{ background: "#1a94ae", color: "white" }}
      >
        Search
      </button>
      <button
        className="btn btn-sm btn-outline-secondary ms-0 ms-lg-2 fw-bold"
        style={{ color: "var(--profile-textClr)" }}
      >
        Reset
      </button>
    </div>
  </div>
  <div>
  </div>
  <div className="my-3 mb-0">
    <Table
      sx={{
        minWidth: 650,
        background: "var( --card-bg-color)",
      }}
      aria-label="simple table"
      className="table-border-color"
    >
      <TableHead className="table-head-bg">
        <TableRow>
          <TableCell
            className="table-head-color"
            align="start"
          >
            Order ID
          </TableCell>
          <TableCell
            className="table-head-color"
            align="start"
          >
            <div className="d-flex me-2">
              Time
              {
                <div className="my-1">
                  <i
                    className="bi bi-caret-up d-block ms-2"
                    style={{ fontSize: "9px" }}
                  ></i>{" "}
                  <i
                    className="bi bi-caret-down ms-2"
                    style={{ fontSize: "9px" }}
                  ></i>{" "}
                </div>
              }{" "}
            </div>
          </TableCell>
          <TableCell
            className="table-head-color"
            align="start"
          >
            Type
          </TableCell>
          <TableCell
            className="table-head-color"
            align="center"
          >
            Price
          </TableCell>
          <TableCell
            className="table-head-color"
            align="start"
          >
            Amount
          </TableCell>
          <TableCell
            className="table-head-color"
            align="center"
          >
            Quality
          </TableCell>
          <TableCell
            className="table-head-color"
            align="center"
          >
            Trading Partners(Verified)
          </TableCell>
          <TableCell
            className="table-head-color"
            align="center"
          >
            Action
          </TableCell>
        </TableRow>
      </TableHead>
      <TableBody>
        <TableRow>
          <TableCell align="center" colSpan={8}>
            <img src={NODATA} />
          </TableCell>
        </TableRow>
      </TableBody>
    </Table>
  </div>
  </>
  )
}
