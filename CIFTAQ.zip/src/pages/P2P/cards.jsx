import * as React from "react";
import Box from "@mui/material/Box";
import Card from "@mui/material/Card";
import CardActions from "@mui/material/CardActions";
import CardContent from "@mui/material/CardContent";
import Tab from "@mui/material/Tab";
import { TabPanel, TabList, TabContext } from "@mui/lab";
import { Button, Grid, makeStyles, Table, TableCell, TableHead, TableRow, Tabs, Typography } from "@mui/material";
import { Container } from "@mui/system";
import Visa from '../../components/assets/images/visa.png'
import cardCircle from '../../components/assets/images/card-circle.png'
import "./index.css";
const Cards = () => {
    const [value, setValue] = React.useState("1");
    const handleChange = (event, newValue) => {
        setValue(newValue);
    };
    const [passwordShown, setPasswordShown] = React.useState(false);
    const togglePassword = () => {
        setPasswordShown(!passwordShown);
    };
    return (
        <>
            <Card className="CenterCard mb-3" sx={{ maxWidth: 600 }} >
                <Box className="px-3 pt-3 d-flex justify-content-between align-items-center">
                    <div><Typography variant="h6" className="fw-bold APITitle textsize-sm">Credit/Debit Card</Typography></div>
                    <div>
                        <Box component="img" alt="Icon" src={Visa} className="pe-1" />
                        <Box component="img" alt="Icon" src={cardCircle} />
                    </div>
                </Box>
                <CardContent>
                    <div className="borderLine border-radius">
                        <label className="textClr ms-2 ps-1 pt-2">Pay</label>
                        <div className="d-flex">
                            <input
                                type="text"
                                className="form-control background-none  py-3"
                                placeholder="Enter purchase Amount"
                                style={{ border: "none"}} />
                            <select className="form-select background-none selection-bg" id="pay" style={{
                                width: "7rem", fontWeight: 700, fontSize: "18px",
                                border: "none", borderTopLeftRadius: 0, borderBottomLeftRadius: 0
                            }}
                                aria-label="Default select example">
                                <option value="1" className="selectionValue"> TWD </option>
                                <option value="2" className="selectionValue"> USDT</option>
                                <option value="3" className="selectionValue"> USTD</option>
                            </select>
                        </div>
                    </div>
                    <div className="borderLine border-radius mt-3">
                        <label className="textClr ms-2 ps-1 pt-2">Get=</label>
                        <div className="d-flex">
                            <input
                                type="text"
                                className="form-control background-none  py-3"
                                placeholder="Enter Quality"
                                style={{ border: "none"}} />
                            <select className="form-select background-none selection-bg" id="get" style={{
                                width: "7rem", fontWeight: 700, fontSize: "18px",
                                border: "none"
                            }}
                                aria-label="Default select example">
                                <option value="1" className="selectionValue"> BTC </option>
                                <option value="2" className="selectionValue"> USDT</option>
                                <option value="3" className="selectionValue"> USTD</option>
                            </select>
                        </div>
                    </div>
                    <Typography className="pt-2 APITitle textsize-sm">Please select a payment service provider</Typography>
                    <div className="borderLine border-radius mt-3 ">
                        <div className="d-flex">
                            <select className="form-select selection-bg" style={{
                                fontWeight: 700, fontSize: "18px",
                                border: "none"
                            }}
                                aria-label="Default select example">
                                <option value="1" className="optionText">Simplex</option>
                                <option value="2" className="optionText"> USDT</option>
                                <option value="3" className="optionText"> USTD</option>
                            </select>
                        </div>
                        <div className="ms-2 ps-1 pb-2">
                            <Box component="img" alt="Icon" src={Visa} className="pe-1 img_Size" />
                            <Box component="img" alt="Icon" src={cardCircle} className="img_Size" />
                        </div>
                    </div>
                    <Box className="pt-3 d-flex justify-content-between">
                        <div><Typography className=" APITitle textsize-sm">You will get:--BTC</Typography></div>
                        <div><Typography className=" APITitle textsize-sm">Total(including fee):--TWD</Typography></div>
                    </Box>
                    <Typography className="textClr pt-3">All fees are levied by third party service providers. MEXC does not impose additional transaction charges.</Typography>
                    <div className="borderLine border-radius mt-3 ">
                        <div className="py-3 px-3">
                            <Typography className="APITitle textsize-sm">Your cryptocurrency will be sent to the following address:</Typography>
                            <Typography className="APITitle textsize-sm">3Hb7kSJYP4jUtkpG61sjat5d8dbHseZ3BZ</Typography>
                        </div>
                    </div>
                    <Box className="d-grid mt-3">
                        <Button variant="contained" className="backgroundClr py-3">Buy BTC</Button>
                    </Box>
                </CardContent>
            </Card>
            <Card className="CenterCard" sx={{ maxWidth: 600 }} >
                <Box className="px-3 pt-3">
                    <Typography  className="fw-bold APITitle">Credit Card Purchase Terms & Conditions:</Typography>
                    <ul className="paddingZero pt-3">
                        <li className="textClr">This service is not offered in countries where cryptocurrency is deemed illegal.</li>
                        <li className="textClr">The cryptocurrency price reflected above is based on the market rate and does not reflect the final transaction price. Please verify your purchase amount before placing your order.</li>
                        <li className="textClr">If your transaction is unsuccessful, your funds will be returned to your account.</li>
                        <li className="textClr">If you encounter any issues, do contact our help centre directly.</li>

                    </ul>
                </Box>
                <CardContent>
                </CardContent>
            </Card>

        </>
    );
}
export default Cards;
