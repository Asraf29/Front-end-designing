import React from "react";
import { Checkbox, Grid, Typography } from "@mui/material";
import FormControlLabel from "@mui/material/FormControlLabel";
import FormControl from "@mui/material/FormControl";
import FormLabel from "@mui/material/FormLabel";
import FormGroup from "@mui/material/FormGroup";
import { green } from "@mui/material/colors";
import email from "../../components/assets/images/email.png";
import { styled } from "@mui/material/styles";
import { Avatar, Box, Card, CardContent } from "@mui/material";
import { Container } from "@mui/system";
import AddIcon from "@mui/icons-material/Add";
import msg from "../../components/assets/images/msg.png";
import Badge from "@mui/material/Badge";
import AddCollectionModal from "../../components/AddCollectionModal/addCollection";
const StyledBadge = styled(Badge)(({ theme }) => ({
  "& .MuiBadge-badge": {
    backgroundColor: "#44b700",
    color: "#44b700",
    boxShadow: `0 0 0 2px ${theme.palette.background.paper}`,
    "&::after": {
      position: "absolute",
      top: 0,
      left: 0,
      width: "100%",
      height: "100%",
      borderRadius: "50%",
      animation: "ripple 1.2s infinite ease-in-out",
      border: "1px solid currentColor",
      content: '""',
    },
  },
  "@keyframes ripple": {
    "0%": {
      transform: "scale(.8)",
      opacity: 1,
    },
    "100%": {
      transform: "scale(2.4)",
      opacity: 0,
    },
  },
}));

export default function SettingTab() {
  const [addCollectionModal, setAddCollectionModal] = React.useState(false);

  const handleClickOpen = () => {
    setAddCollectionModal(true);
  };

  const handleClose = () => {
    setAddCollectionModal(false);
  };

  return (
    <>
      <AddCollectionModal
        addCollectionModal={addCollectionModal}
        handleClickOpen={handleClickOpen}
        handleClose={handleClose}
      />
      <Grid item xs={12} lg={12} md={12}>
        <Card
          sx={{
            minWidth: 100,
            borderRadius: "10px",
            background: "var(--card-bg-color)",
          }}
        >
          <CardContent>
            <Box>
              <Typography
                className="fw-bold mb-4"
                sx={{ color: "var(--text-color)" }}
              >
                OTC Settings
              </Typography>
              <div className="d-flex">
                <div>
                  <StyledBadge
                    overlap="circular"
                    className="mb-2"
                    anchorOrigin={{
                      vertical: "bottom",
                      horizontal: "right",
                    }}
                    variant="dot"
                  >
                    <Avatar sx={{ bgcolor: green[400] }} alt="Prabhu" />
                  </StyledBadge>
                </div>
                <div className="d-block">
                  <Typography className="Vol ps-2">----</Typography>
                  <div className="d-block d-md-flex ps-1 ps-sm-0">
                    <Typography
                      sx={{ fontSize: "14px" }}
                      className="Vol ps-md-2"
                    >
                      Total volume:: 0 times(Buy0/Sell0)
                    </Typography>
                    <Typography
                      sx={{ fontSize: "14px" }}
                      className="Vol ps-2 TxtOrderComplete ms-2 fw-bold"
                    >
                      Order Completion Rate: 0%
                    </Typography>
                  </div>
                </div>
              </div>
              <div className="d-block d-md-flex my-0 my-4">
                <Typography
                  sx={{ color: "var(--text-color)", fontSize: "15px" }}
                  className="payment me-0 me-lg-2 fw-bold"
                >
                  Payment Mode Management
                </Typography>
                <Typography
                  className="text-bg my-2 my-sm-0"
                  sx={{ fontSize: "14px", color: "#1A94AE" }}
                >
                  Please use a verified payment mode; your payment mode will be
                  shown to your counterparty upon transaction confirmation. Each
                  user may activate a maximum of 3 payment modes.
                </Typography>
              </div>
              <Box className="border-btn">
                <Container>
                  <button
                    className="btn"
                    style={{ border: "1px solid #1A94AE", color: "#1A94AE" }}
                    onClick={() => {
                      handleClickOpen();
                    }}
                  >
                    <AddIcon fontSize={"small"} />
                    Add Collection Method
                  </button>
                </Container>
              </Box>
              <div className="d-block d-md-flex my-0 my-4">
                <Typography
                  sx={{ color: "var(--text-color)", fontSize: "15px" }}
                  className="payment me-0 me-lg-2 fw-bold"
                >
                  Notification Settings
                </Typography>
                <Typography
                  className="text-bg my-2 my-sm-0"
                  sx={{ fontSize: "14px", color: "#1A94AE" }}
                >
                  We’ll update you on the progress of your orders through your
                  selected notification channel(s)
                </Typography>
              </div>
              <div className="d-block d-sm-flex">
                <span className="d-flex">
                  {" "}
                  <img
                    src={email}
                    className="img-fluid my-3"
                    style={{ width: "24px", height: "18px" }}
                  />
                  <Typography
                    sx={{ color: "var(--text-color)", fontSize: "15px" }}
                    className="payment ms-2 my-3 me-0 me-lg-2 fw-bold"
                  >
                    Email Notification
                  </Typography>
                </span>
                <FormControl component="fieldset" className="ms-2">
                  <FormGroup aria-label="position" row>
                    <FormControlLabel
                      sx={{
                        color: "var(--text-color)",
                        fontSize: "15px",
                        fontWeight: 500,
                      }}
                      value="end"
                      control={<Checkbox className="mb-2" />}
                      label="Receive When Online/Offline"
                      labelPlacement="end"
                    />
                  </FormGroup>
                </FormControl>
                <FormControl component="fieldset" className="ms-2">
                  <FormGroup aria-label="position" row>
                    <FormControlLabel
                      sx={{
                        color: "var(--text-color)",
                        fontSize: "15px",
                        fontWeight: 500,
                      }}
                      value="end"
                      control={<Checkbox className="mb-2" />}
                      label="Receive When Only Online"
                      labelPlacement="end"
                    />
                  </FormGroup>
                </FormControl>
                <FormControl component="fieldset" className="ms-2">
                  <FormGroup aria-label="position" row>
                    <FormControlLabel
                      value="end"
                      sx={{
                        color: "var(--text-color)",
                        fontSize: "15px",
                        fontWeight: 500,
                      }}
                      control={<Checkbox className="mb-2" />}
                      label="Receive When Only Offline"
                      labelPlacement="end"
                    />
                  </FormGroup>
                </FormControl>
              </div>
              <div className="d-block d-sm-flex">
                <span className="d-flex">
                  {" "}
                  <img
                    src={msg}
                    className="img-fluid my-3"
                    style={{ width: "24px", height: "24px" }}
                  />
                  <Typography
                    sx={{ color: "var(--text-color)", fontSize: "15px" }}
                    className="payment ms-2 my-3 me-0 me-lg-2 fw-bold"
                  >
                    SMS Notification
                  </Typography>
                </span>
                <FormControl component="fieldset" className="ms-2">
                  <FormGroup aria-label="position" row>
                    <FormControlLabel
                      value="end"
                      sx={{
                        color: "var(--text-color)",
                        fontSize: "15px",
                        fontWeight: 500,
                      }}
                      control={<Checkbox className="mb-2" />}
                      label="Receive When Online/Offline"
                      labelPlacement="end"
                    />
                  </FormGroup>
                </FormControl>
                <FormControl component="fieldset" className="ms-2">
                  <FormGroup aria-label="position" row>
                    <FormControlLabel
                      sx={{
                        color: "var(--text-color)",
                        fontSize: "15px",
                        fontWeight: 500,
                      }}
                      value="end"
                      control={<Checkbox className="mb-2" />}
                      label="Receive When Only Online"
                      labelPlacement="end"
                    />
                  </FormGroup>
                </FormControl>
                <FormControl component="fieldset" className="ms-2">
                  <FormGroup aria-label="position" row>
                    <FormControlLabel
                      sx={{
                        color: "var(--text-color)",
                        fontSize: "15px",
                        fontWeight: 500,
                      }}
                      value="end"
                      control={<Checkbox className="mb-2" />}
                      label="Receive When Only Offline"
                      labelPlacement="end"
                    />
                  </FormGroup>
                </FormControl>
              </div>
            </Box>
          </CardContent>
        </Card>
      </Grid>
    </>
  );
}
