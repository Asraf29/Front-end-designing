import React, { useState } from "react";
import {
  Avatar,
  Box,
  Button,
  Card,
  CardContent,
  Paper,
  Table,
  TableBody,
  TableCell,
  TableContainer,
  TableHead,
  TableRow,
} from "@mui/material";
import { Container } from "@mui/system";
import NotificationsIcon from "@mui/icons-material/Notifications";
import ArticleOutlinedIcon from "@mui/icons-material/ArticleOutlined";
import InfoOutlinedIcon from "@mui/icons-material/InfoOutlined";
import "./index.css";
import {
  Grid,
  ListItemButton,
  ListItemIcon,
  Typography,
} from "@mui/material";
import SettingsOutlinedIcon from "@mui/icons-material/SettingsOutlined";
import button1 from "../../components/assets/images/card-profile.png";
import button2 from "../../components/assets/images/dollar.png";
import NODATA from "../../components/assets/images/nodata.png";
import Tab from "@mui/material/Tab";
import TabContext from "@mui/lab/TabContext";
import TabList from "@mui/lab/TabList";
import TabPanel from "@mui/lab/TabPanel";
import P2PMarkets from "./P2PMarkets";
import Cards from './cards'
import P2PTab from "./P2PTab";
import CreditTab from "./creditTab";
import PendingOrder from "./pendingOrder";
import SettingTab from "./settingTab";
const MarketBuy = () => {
  const [value, setValue] = React.useState("1");
  const [pushBtn, setPushBtn] = React.useState(false);
  const [pushValue, setPushValue] = React.useState("1001");
  const [pushValueTab, setPushValueTab] = React.useState("1001");
  const handleChange = (event, newValue) => {
    setValue(newValue);
  };

  const pushHandleChange = (event, newPushValue) => {
    setPushValue(newPushValue);
  };
  const pushHandleChangeTab = (event, newPushValue) => {
    setPushValueTab(newPushValue);
  };
  return (
    <div>
      <div className=" container-fluid background-color">
        <Container className="px-md-5 p-0 py-3">
          <div className="d-flex align-items-center">
            <Typography className="verifyTitle fontsizeTitle" variant="h5">
              Validate your account & Start trading
            </Typography>
            <button className="btn market-buy-btn py-2 ms-md-5">
              <img src={button1} className="img-fluid me-2" />
              KYC Verification
            </button>
            <button className="btn market-buy-btn py-2 ms-3">
              <img src={button2} className="img-fluid me-2" />
              Collection setting
            </button>
          </div>
        </Container>
      </div>

      <Container sx={{ width: "100%", typography: "body1" }}>
        <TabContext value={value}>
          <Box className="borderBtm container-fluid">
            <TabList
              variant="scrollable"
              onChange={handleChange}
              aria-label="lab API tabs example"
            >
              <Tab
                sx={{ fontSize: "14px", color: "white" }}
                className="TabColor"
                label="P2P Markets"
                value="1"
              />
              <Tab
                sx={{ fontSize: "14px", color: "white" }}
                className="TabColor"
                label="Credit/Debit Card"
                value="2"
              />
              <Tab
                sx={{ fontSize: "14px", color: "white" }}
                className="TabColor"
                label="PUSH"
                value="3"
              />
              <div className="ms-auto d-none d-sm-block">
                <TabList onChange={handleChange}>
                  <Tab
                    sx={{
                      fontSize: "14px",
                      color: "white",
                      textTransform: "none",
                    }}
                    className="TabColor"
                    icon={<ArticleOutlinedIcon fontSize={"small"} />}
                    iconPosition="start"
                    label="Order"
                    value="4"
                  />
                  <Tab
                    sx={{
                      fontSize: "14px",
                      color: "white",
                      textTransform: "none",
                    }}
                    className="TabColor"
                    icon={<SettingsOutlinedIcon fontSize={"small"} />}
                    iconPosition="start"
                    label="Setting"
                    value="5"
                  />
                  <Tab
                    sx={{
                      fontSize: "14px",
                      color: "white",
                      textTransform: "none",
                    }}
                    className="TabColor"
                    icon={<NotificationsIcon fontSize={"small"} />}
                    value="6"
                  />
                </TabList>
              </div>
            </TabList>
            <div className="ms-auto d-block d-sm-none d-lg-none">
              <TabList centered onChange={handleChange}>
                <Tab
                  sx={{
                    fontSize: "14px",
                    color: "white",
                    textTransform: "none",
                  }}
                  className="TabColor"
                  icon={<ArticleOutlinedIcon fontSize={"small"} />}
                  iconPosition="start"
                  label="Order"
                  value="4"
                />
                <Tab
                  sx={{
                    fontSize: "14px",
                    color: "white",
                    textTransform: "none",
                  }}
                  className="TabColor"
                  icon={<SettingsOutlinedIcon fontSize={"small"} />}
                  iconPosition="start"
                  label="Setting"
                  value="5"
                />
                <Tab
                  sx={{
                    fontSize: "14px",
                    color: "white",
                    textTransform: "none",
                  }}
                  className="TabColor"
                  icon={<NotificationsIcon fontSize={"small"} />}
                  value="6"
                />
              </TabList>
            </div>
          </Box>
          {/*P2P Markets*/}
          <TabPanel value="1">
            <P2PMarkets />
          </TabPanel>
          {/*Credit/Debit Card*/}
          <TabPanel value="2"><Cards/></TabPanel>
          {/* PUSH */}
          <TabPanel value="3">
            {pushBtn === false ? (
              <>
                <Grid item xs={12} lg={12} md={12}>
                  <Card
                    sx={{
                      minWidth: 100,
                      background: "var(--card-bg-color)",
                    }}
                  >
                    <CardContent>
                      <Box sx={{ width: "100%", typography: "body1" }}>
                        <div className="d-flex justify-content-between">
                          <div>
                            <Typography
                              sx={{ color: "var(--profile-textClr)" }}
                              fontWeight={"bold"}
                            >
                              PUSH
                            </Typography>
                          </div>
                          <div>
                            <button
                              className="btn btn-sm"
                              style={{ background: "#1a94ae", color: "white" }}
                              onClick={() => {
                                setPushBtn(!pushBtn);
                              }}
                            >
                              PUSH Transcation
                            </button>
                          </div>
                        </div>
                      </Box>
                      <Typography
                        className="my-lg-4"
                        component="div"
                        sx={{ color: "var(--profile-textClr)" }}
                      >
                        {" "}
                        <InfoOutlinedIcon
                          sx={{ color: "var(--edit-icon)" }}
                          fontSize={"small"}
                        />{" "}
                        PUSH allows users to trade directly with each other on
                        their own terms. When the PUSH button is clicked, the
                        transaction will complete with no further confirmation.
                        Please proceed with caution.
                      </Typography>
                      <div className="d-flex justify-content-center">
                        {" "}
                        <img src={NODATA} />{" "}
                      </div>
                    </CardContent>
                  </Card>
                </Grid>{" "}
              </>
            ) : (
              <>
                <Grid item xs={12} lg={12} md={12}>
                  <Card
                    sx={{
                      minWidth: 100,
                      background: "var(--card-bg-color)",
                    }}
                  >
                    <CardContent>
                      <Box sx={{ width: "100%", typography: "body1" }}>
                        <div className="d-flex justify-content-between">
                          <div>
                            <Typography
                              sx={{ color: "var(--profile-textClr)" }}
                              fontWeight={"bold"}
                            >
                              PUSH Record
                            </Typography>
                          </div>
                          <div>
                            <button
                              className="btn btn-sm"
                              style={{ background: "#1a94ae", color: "white" }}
                              onClick={() => {
                                setPushBtn(!pushBtn);
                              }}
                            >
                              Back
                            </button>
                          </div>
                        </div>
                      </Box>
                      <Box>
                        <TabContext value={pushValue}>
                          <TabList onChange={pushHandleChange}>
                            <Tab
                              sx={{
                                fontSize: "14px",
                                color: "var(--profile-textClr)",
                                textTransform: "none",
                              }}
                              label="PUSH Purchases Made"
                              value="0001"
                            />
                            <Tab
                              sx={{
                                fontSize: "14px",
                                color: "var(--profile-textClr)",
                                textTransform: "none",
                              }}
                              label="PUSH Listing Created"
                              value="0002"
                            />
                          </TabList>
                          <TabPanel value="0001">
                            <>
                              <Table
                                sx={{
                                  minWidth: 650,
                                  background: "var( --card-bg-color)",
                                }}
                                aria-label="simple table"
                                className="table-border-color"
                              >
                                <TableHead className="table-head-bg">
                                  <TableRow>
                                    <TableCell
                                      className="table-head-color"
                                      align="start"
                                    >
                                      Cypto
                                    </TableCell>
                                    <TableCell
                                      className="table-head-color"
                                      align="start"
                                    >
                                      Market
                                    </TableCell>
                                    <TableCell
                                      className="table-head-color"
                                      align="start"
                                    >
                                      Price
                                    </TableCell>
                                    <TableCell
                                      className="table-head-color"
                                      align="center"
                                    >
                                      Quality
                                    </TableCell>
                                    <TableCell
                                      className="table-head-color"
                                      align="start"
                                    >
                                      Cost
                                    </TableCell>
                                    <TableCell
                                      className="table-head-color"
                                      align="center"
                                    >
                                      Time Of Transcation
                                    </TableCell>
                                  </TableRow>
                                </TableHead>
                                <TableBody>
                                  <TableRow>
                                    <TableCell align="center" colSpan={6}>
                                      <img src={NODATA} />
                                    </TableCell>
                                  </TableRow>
                                </TableBody>
                              </Table>
                            </>
                          </TabPanel>
                          <TabPanel value="0002">
                            <>
                              <Table
                                sx={{
                                  minWidth: 650,
                                  background: "var( --card-bg-color)",
                                }}
                                aria-label="simple table"
                                className="table-border-color"
                              >
                                <TableHead className="table-head-bg">
                                  <TableRow>
                                    <TableCell
                                      className="table-head-color"
                                      align="start"
                                    >
                                      Trading Partner Price
                                    </TableCell>
                                    <TableCell
                                      className="table-head-color"
                                      align="start"
                                    >
                                      Quantity
                                    </TableCell>
                                    <TableCell
                                      className="table-head-color"
                                      align="start"
                                    >
                                      Total Purchase
                                    </TableCell>
                                    <TableCell
                                      className="table-head-color"
                                      align="center"
                                    >
                                      Process
                                    </TableCell>
                                    <TableCell
                                      className="table-head-color"
                                      align="start"
                                    >
                                      Status
                                    </TableCell>
                                    <TableCell
                                      className="table-head-color"
                                      align="center"
                                    >
                                      Order Time
                                    </TableCell>
                                    <TableCell
                                      className="table-head-color"
                                      align="center"
                                    >
                                      Action
                                    </TableCell>
                                  </TableRow>
                                </TableHead>
                                <TableBody>
                                  <TableRow>
                                    <TableCell align="center" colSpan={7}>
                                      <img src={NODATA} />
                                    </TableCell>
                                  </TableRow>
                                </TableBody>
                              </Table>
                            </>
                          </TabPanel>
                        </TabContext>
                      </Box>
                    </CardContent>
                  </Card>
                </Grid>
              </>
            )}
          </TabPanel>
          <TabPanel value="4">
            <Grid item xs={12} lg={12} md={12}>
              <Card
                sx={{
                  minWidth: 100,
                  background: "var(--card-bg-color)",
                }}
              >
                <CardContent>
                  <Box>
                    <TabContext value={pushValueTab}>
                      <TabList variant='scrollable' onChange={pushHandleChangeTab}>
                        <Tab
                          className="fw-bold"
                          sx={{
                            fontSize: "14px",
                            color: "var(--profile-textClr)",
                            textTransform: "none",
                          }}
                          label="P2P Markets"
                          value="1001"
                        />
                        <Tab
                          className="fw-bold"
                          sx={{
                            fontSize: "14px",
                            color: "var(--profile-textClr)",
                            textTransform: "none",
                          }}
                          label="Credit/Debit Card"
                          value="1002"
                        />
                        <Tab
                          className="fw-bold"
                          sx={{
                            fontSize: "14px",
                            color: "var(--profile-textClr)",
                            textTransform: "none",
                          }}
                          label="Pending Order"
                          value="1003"
                        />
                      </TabList>
                      <TabPanel value="1001">
                    <P2PTab/>
                      </TabPanel>
                      <TabPanel value="1003">
                     <CreditTab/>
                      </TabPanel>
                      {/* ////CREDIT DEBIT CARD TAB */}
                      <TabPanel value="1002">
                      <PendingOrder/>
                      </TabPanel>
                    </TabContext>
                  </Box>
                </CardContent>
              </Card>
            </Grid>
          </TabPanel>
          <TabPanel value="5">
           <SettingTab/>
          </TabPanel>
        </TabContext>
      </Container>
    </div>
  );
};
export default MarketBuy;
