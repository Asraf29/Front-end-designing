import React from 'react'
import {
    Table,
    TableBody,
    TableCell,
    TableContainer,
    TableHead,
    TableRow,
  } from "@mui/material";
  import NODATA from "../../components/assets/images/nodata.png";
export default function PendingOrder() {
  return (
    <>
      <ul
                          className="nav nav-pills mb-0 credit-pills"
                          id="pills-tab"
                          role="tablist"
                        >
                          <li className="nav-item" role="presentation">
                            <button
                              className="nav-link active"
                              id="pills-home-tab"
                              data-bs-toggle="pill"
                              data-bs-target="#pills-home"
                              type="button"
                              role="tab"
                              aria-controls="pills-home"
                              aria-selected="true"
                              style={{ color: "var(--profile-textClr)" }}
                            >
                              Simplex
                            </button>
                          </li>
                          <li className="nav-item" role="presentation">
                            <button
                              className="nav-link"
                              id="pills-profile-tab"
                              data-bs-toggle="pill"
                              data-bs-target="#pills-profile"
                              type="button"
                              role="tab"
                              aria-controls="pills-profile"
                              aria-selected="false"
                              style={{ color: "var(--profile-textClr)" }}
                            >
                              Menapay
                            </button>
                          </li>
                          <li className="nav-item" role="presentation">
                            <button
                              className="nav-link"
                              id="pills-contact-tab"
                              data-bs-toggle="pill"
                              data-bs-target="#pills-contact"
                              type="button"
                              role="tab"
                              aria-controls="pills-contact"
                              aria-selected="false"
                              style={{ color: "var(--profile-textClr)" }}
                            >
                              Moonpay
                            </button>
                          </li>
                          <li className="nav-item" role="presentation">
                            <button
                              className="nav-link"
                              id="banxa"
                              data-bs-toggle="pill"
                              data-bs-target="#banxa"
                              type="button"
                              role="tab"
                              aria-selected="false"
                              style={{ color: "var(--profile-textClr)" }}
                            >
                              Banxa
                            </button>
                          </li>
                          <li className="nav-item" role="presentation">
                            <button
                              className="nav-link"
                              id="Mercuryo"
                              data-bs-toggle="pill"
                              data-bs-target="#Mercuryo"
                              type="button"
                              role="tab"
                              aria-selected="false"
                              style={{ color: "var(--profile-textClr)" }}
                            >
                              Mercuryo
                            </button>
                          </li>
                        </ul>
                        <div className="tab-content" id="pills-tabContent">
                          <div
                            className="tab-pane fade show active"
                            id="pills-home"
                            role="tabpanel"
                            aria-labelledby="pills-home-tab"
                          >
                            <div className="my-3 mb-0">
                              <Table
                                sx={{
                                  minWidth: 650,
                                  background: "var( --card-bg-color)",
                                }}
                                aria-label="simple table"
                                className="table-border-color"
                              >
                                <TableHead className="table-head-bg">
                                  <TableRow>
                                    <TableCell
                                      className="table-head-color fw-bold"
                                      align="start"
                                    >
                                      Order ID
                                    </TableCell>
                                    <TableCell
                                      className="table-head-color fw-bold"
                                      align="start"
                                    >
                                      <div className="d-flex me-2">
                                        Older Time
                                        {
                                          <div className="my-1">
                                            <i
                                              className="bi bi-caret-up d-block ms-2"
                                              style={{ fontSize: "9px" }}
                                            ></i>{" "}
                                            <i
                                              className="bi bi-caret-down ms-2"
                                              style={{ fontSize: "9px" }}
                                            ></i>{" "}
                                          </div>
                                        }{" "}
                                      </div>
                                    </TableCell>
                                    <TableCell
                                      className="table-head-color fw-bold"
                                      align="start"
                                    >
                                      Quality
                                    </TableCell>
                                    <TableCell
                                      className="table-head-color fw-bold"
                                      align="center"
                                    >
                                      Amount (including fee)
                                    </TableCell>
                                    <TableCell
                                      className="table-head-color fw-bold"
                                      align="start"
                                    >
                                      Payment method
                                    </TableCell>
                                    <TableCell
                                      className="table-head-color fw-bold"
                                      align="center"
                                    >
                                      Status
                                    </TableCell>
                                  </TableRow>
                                </TableHead>
                                <TableBody>
                                  <TableRow>
                                    <TableCell align="center" colSpan={8}>
                                      <img src={NODATA} />
                                    </TableCell>
                                  </TableRow>
                                </TableBody>
                              </Table>
                            </div>
                          </div>
                          <div
                            className="tab-pane fade"
                            id="pills-profile"
                            role="tabpanel"
                            aria-labelledby="pills-profile-tab"
                          >
                            <div className="my-3 mb-0">
                              <Table
                                sx={{
                                  minWidth: 650,
                                  background: "var( --card-bg-color)",
                                }}
                                aria-label="simple table"
                                className="table-border-color"
                              >
                                <TableHead className="table-head-bg">
                                  <TableRow>
                                    <TableCell
                                      className="table-head-color fw-bold"
                                      align="start"
                                    >
                                      Order ID
                                    </TableCell>
                                    <TableCell
                                      className="table-head-color fw-bold"
                                      align="start"
                                    >
                                      <div className="d-flex me-2">
                                        Older Time
                                        {
                                          <div className="my-1">
                                            <i
                                              className="bi bi-caret-up d-block ms-2"
                                              style={{ fontSize: "9px" }}
                                            ></i>{" "}
                                            <i
                                              className="bi bi-caret-down ms-2"
                                              style={{ fontSize: "9px" }}
                                            ></i>{" "}
                                          </div>
                                        }{" "}
                                      </div>
                                    </TableCell>
                                    <TableCell
                                      className="table-head-color fw-bold"
                                      align="start"
                                    >
                                      Quality
                                    </TableCell>
                                    <TableCell
                                      className="table-head-color fw-bold"
                                      align="center"
                                    >
                                      Amount (including fee)
                                    </TableCell>
                                    <TableCell
                                      className="table-head-color fw-bold"
                                      align="start"
                                    >
                                      Payment method
                                    </TableCell>
                                    <TableCell
                                      className="table-head-color fw-bold"
                                      align="center"
                                    >
                                      Status
                                    </TableCell>
                                  </TableRow>
                                </TableHead>
                                <TableBody>
                                  <TableRow>
                                    <TableCell align="center" colSpan={8}>
                                      <img src={NODATA} />
                                    </TableCell>
                                  </TableRow>
                                </TableBody>
                              </Table>
                            </div>
                          </div>
                          <div
                            className="tab-pane fade"
                            id="banxa"
                            role="tabpanel"
                            aria-labelledby="pills-contact-tab"
                          >
                            <div className="my-3 mb-0">
                              <Table
                                sx={{
                                  minWidth: 650,
                                  background: "var( --card-bg-color)",
                                }}
                                aria-label="simple table"
                                className="table-border-color"
                              >
                                <TableHead className="table-head-bg">
                                  <TableRow>
                                    <TableCell
                                      className="table-head-color fw-bold"
                                      align="start"
                                    >
                                      Order ID
                                    </TableCell>
                                    <TableCell
                                      className="table-head-color fw-bold"
                                      align="start"
                                    >
                                      <div className="d-flex me-2">
                                        Older Time
                                        {
                                          <div className="my-1">
                                            <i
                                              className="bi bi-caret-up d-block ms-2"
                                              style={{ fontSize: "9px" }}
                                            ></i>{" "}
                                            <i
                                              className="bi bi-caret-down ms-2"
                                              style={{ fontSize: "9px" }}
                                            ></i>{" "}
                                          </div>
                                        }{" "}
                                      </div>
                                    </TableCell>
                                    <TableCell
                                      className="table-head-color fw-bold"
                                      align="start"
                                    >
                                      Quality
                                    </TableCell>
                                    <TableCell
                                      className="table-head-color fw-bold"
                                      align="center"
                                    >
                                      Amount (including fee)
                                    </TableCell>
                                    <TableCell
                                      className="table-head-color fw-bold"
                                      align="start"
                                    >
                                      Payment method
                                    </TableCell>
                                    <TableCell
                                      className="table-head-color fw-bold"
                                      align="center"
                                    >
                                      Status
                                    </TableCell>
                                  </TableRow>
                                </TableHead>
                                <TableBody>
                                  <TableRow>
                                    <TableCell align="center" colSpan={8}>
                                      <img src={NODATA} />
                                    </TableCell>
                                  </TableRow>
                                </TableBody>
                              </Table>
                            </div>
                          </div>
                          <div
                            className="tab-pane fade"
                            id="Mercuryo"
                            role="tabpanel"
                            aria-labelledby="pills-contact-tab"
                          >
                            <div className="my-3 mb-0">
                              <Table
                                sx={{
                                  minWidth: 650,
                                  background: "var( --card-bg-color)",
                                }}
                                aria-label="simple table"
                                className="table-border-color"
                              >
                                <TableHead className="table-head-bg">
                                  <TableRow>
                                    <TableCell
                                      className="table-head-color fw-bold"
                                      align="start"
                                    >
                                      Order ID
                                    </TableCell>
                                    <TableCell
                                      className="table-head-color fw-bold"
                                      align="start"
                                    >
                                      <div className="d-flex me-2">
                                        Older Time
                                        {
                                          <div className="my-1">
                                            <i
                                              className="bi bi-caret-up d-block ms-2"
                                              style={{ fontSize: "9px" }}
                                            ></i>{" "}
                                            <i
                                              className="bi bi-caret-down ms-2"
                                              style={{ fontSize: "9px" }}
                                            ></i>{" "}
                                          </div>
                                        }{" "}
                                      </div>
                                    </TableCell>
                                    <TableCell
                                      className="table-head-color fw-bold"
                                      align="start"
                                    >
                                      Quality
                                    </TableCell>
                                    <TableCell
                                      className="table-head-color fw-bold"
                                      align="center"
                                    >
                                      Amount (including fee)
                                    </TableCell>
                                    <TableCell
                                      className="table-head-color fw-bold"
                                      align="start"
                                    >
                                      Payment method
                                    </TableCell>
                                    <TableCell
                                      className="table-head-color fw-bold"
                                      align="center"
                                    >
                                      Status
                                    </TableCell>
                                  </TableRow>
                                </TableHead>
                                <TableBody>
                                  <TableRow>
                                    <TableCell align="center" colSpan={8}>
                                      <img src={NODATA} />
                                    </TableCell>
                                  </TableRow>
                                </TableBody>
                              </Table>
                            </div>
                          </div>
                        </div>
    </>
  )
}
