import { Typography } from '@mui/material'
import React from 'react'
import {
  Table,
  TableBody,
  TableCell,
  TableContainer,
  TableHead,
  TableRow,
} from "@mui/material";
import NODATA from "../../components/assets/images/nodata.png";
export default function CreditTab() {
  return (
    <div>
      <div className="d-block d-lg-flex justify-content-between">
        <div className="d-block d-md-flex col-lg-6 mb-3 mb-sm-0">
          <div className="col-lg-3 col-sm-12 col-md-3 mb-2 mb-sm-0">
            <Typography
              sx={{ color: "var(--card-sub-text)" }}
            >
              Current Order
            </Typography>
          </div>
        </div>
        <div>
          <div className="me-2 d-grid d-md-flex">
            <Typography
              sx={{ color: "var(--profile-textClr)" }}
              className="my-2 me-2"
            >
              Crypto:
            </Typography>
            <select
              id="form-select"
              className="form-select me-2"
              aria-label="Default select example"
            >
              <option value="1" className="textClr">
                USDT
              </option>
            </select>
            <Typography
              className="my-2 me-2"
              sx={{ color: "var(--profile-textClr)" }}
            >
              Status:
            </Typography>
            <select
              id="form-select"
              className="form-select"
              aria-label="Default select example"
            >
              <option value="1" className="textClr">
                OK
              </option>
            </select>
          </div>
        </div>
      </div>
      <div>
        <div className="d-block d-sm-flex">
          <div></div>
        </div>
      </div>
      <TableContainer className="my-3 mb-0">
        <Table
          sx={{
            minWidth: 650,
            background: "var( --card-bg-color)",
          }}
          aria-label="simple table"
          className="table-border-color"
        >
          <TableHead className="table-head-bg">
            <TableRow>
              <TableCell
                className="table-head-color"
                align="start"
              >
                Published Time
              </TableCell>
              <TableCell
                className="table-head-color"
                align="start"
              >
                Type
              </TableCell>
              <TableCell
                className="table-head-color"
                align="start"
              >
                Crypco
              </TableCell>
              <TableCell
                className="table-head-color"
                align="center"
              >
                Price
              </TableCell>
              <TableCell
                className="table-head-color"
                align="start"
              >
                Quality
              </TableCell>
              <TableCell
                className="table-head-color"
                align="center"
              >
                Amount
              </TableCell>
              <TableCell
                className="table-head-color"
                align="center"
              >
                Expiration Time
              </TableCell>
              <TableCell
                className="table-head-color"
                align="center"
              >
                Collection Method
              </TableCell>
              <TableCell
                className="table-head-color"
                align="center"
              >
                Status
              </TableCell>
              <TableCell
                className="table-head-color"
                align="center"
              >
                Action
              </TableCell>
            </TableRow>
          </TableHead>
          <TableBody>
            <TableRow>
              <TableCell align="center" colSpan={10}>
                <img src={NODATA} />
              </TableCell>
            </TableRow>
          </TableBody>
        </Table>
      </TableContainer>
    </div>
  )
}
