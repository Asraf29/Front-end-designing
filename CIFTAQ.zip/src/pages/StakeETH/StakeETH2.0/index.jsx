import React, { useState } from "react";
import {
    Avatar,
    Box,
    Button,
    CardActionArea,
    CardMedia,
    Stack,
} from "@mui/material";
import Card from "@mui/material/Card";
import CardContent from "@mui/material/CardContent";
import { Container } from "@mui/system";
import {
    Grid,
    Typography,
} from "@mui/material";
import { Link } from "react-router-dom";
import banner from "../../../components/assets/images/ETH2.0.png";
import "../index.css";
import step1 from '../../../components/assets/images/step1.png';
import step2 from '../../../components/assets/images/step2.png';
import step3 from '../../../components/assets/images/step3.png';
import { makeStyles } from "@mui/styles";
// Tab Switch;
const useStyles = makeStyles({
    MUITab: {
        color: "var(--Tab-gray-text) !important",
        fontSize: "16px !important",
        fontWeight: 'bold'
    },

    ribbon: {
        backgroundColor: '#9EA1C0',
        position: "absolute",
        color: 'white',
        width: 86,
        zIndex: 3,
        paddingBottom: 4,
        textAlign: 'center',
        padding: 1,
        fontSize: 14,
        '&::before': {
            position: "absolute",
            zIndex: -1,
            content: '',
            display: 'block',
            border: '5px solid #2980b9',
        },
        '&::after': {
            position: "absolute",
            zIndex: -1,
            content: '',
            display: 'block',
            border: '5px solid #2980b9',
        },
        transform: 'rotate(-45deg)',
        top: 6,
        marginLeft: -21,
    },
    span: {

    }
});
const StakeETH = () => {

    const classes = useStyles();
    return (
        <div>
            <Container sx={{ mb: 7 }}>

                <Box className="d-md-flex justify-content-md-between align-items-center">
                    <div className="ms-4 col-xs-12 col-md-6 mt-sm-0 col-lg-6">
                        <div className="my-4 my-sm-0">

                            <Typography className="text-propty mb-2 txt-head-eth" variant="h3">
                                ETH 2.0 One-click stake
                            </Typography>
                            <Typography className="text-propty-sub mb-2 txt-head-eth-sub">
                                Stake to enjoy double profit of BETH + MX
                            </Typography>
                            <div className="d-flex">
                                <div>
                                    <Typography className="text-propty-sub txt-head-eth-sub">
                                        ETH available balance : 0 ETH
                                    </Typography>
                                </div>
                                <div>
                                    <Typography className="text-propty-sub ms-2 txt-head-eth-sub">
                                        BETH available balance : 0 BETH
                                    </Typography>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div className="col-lg-6 col-md-6 col-sm-12 my-2">
                        <Box
                            component="img"
                            alt="topbar-bg"
                            src={banner}
                            sx={{ width: '100%', height: '100%' }}
                            className="img-fluid m-day-bnr" />
                    </div>
                </Box>
                <>
                    <Grid item xs={12} sm={12} lg={12} md={12}>
                        <Card
                            sx={{
                                minWidth: 100,
                                background: "var(--card-bg-color)",
                            }}
                        >
                            <CardContent>
                                <Grid container spacing={2}>
                                    <Grid xs={12} sm={12} md={6} lg={7}>
                                        <Container sx={{ mt: 4 }}>

                                            <div className=" d-flex justify-content-between">
                                                <div>
                                                    <div className="d-flex">
                                                        <Typography className="card-text fw-bold mb-0" sx={{ fontSize: '24px' }}>Stake ETH</Typography>
                                                        <div className="bg-red-ETH my-2 ms-2 h-50">
                                                            <Typography className="fw-bold" sx={{ fontSize: '10px' }}>Please be cautioned that staked ETH is NOT redeemable.</Typography>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                            <Box sx={{ mt: 4 }}><Typography className='card-text fw-bold mb-2 ms-lg-1'>ETH available balance 0 ETH</Typography>
                                                <div className="input-group mb-1">
                                                    <input style={{ fontWeight: 600, height: '50px' }} type="text" className="form-control placeholderTxtClr inputBg" placeholder="Please enter amount to be locked" aria-label="Recipient's username" aria-describedby="button-addon2" />
                                                    <button className="btn inputBg border-none-lft" style={{ color: '#1A94AE' }} type="button" id="button-addon2">ALL</button>
                                                    <button className="btn inputBg border-none-lft" style={{ color: 'var(--txt-placeholder)' }} type="button" id="button-addon2">ETH</button>
                                                </div>

                                                <div className="d-flex justify-content-between mb-2">
                                                    <div>
                                                        <Typography className="fw-bold" sx={{ fontSize: '14px', color: "var(--txt-placeholder)" }}>Exchange BETH: 0 BETH</Typography>
                                                    </div>
                                                    <div>
                                                        <Typography className="fw-bold" sx={{ fontSize: '14px', color: "var(--txt-placeholder)" }}>Exchange rate:1:1</Typography>
                                                    </div>
                                                </div>
                                                <div className="d-grid gap-2 my-3">
                                                    <button style={{ color: "rgba(0, 0, 0, 0.5)", fontSize: '14px', background: '#E0E0E0', height: '50px' }} className="btn btn-lg fw-bold" type="button">Stake exchange</button>
                                                </div>
                                            </Box>
                                            <Box>
                                                <Typography className="fw-bold card-text mb-2">What you need to know in order to participate:</Typography>
                                                <Typography className='mb-2' sx={{ color: "var(--txt-placeholder)", fontSize: '13px' }}>
                                                    1. Based on ETH 2.0 chain rules, ETH staking is a one-way transaction and cannot be reversed.
                                                </Typography>
                                                <Typography className='mb-2' sx={{ color: "var(--txt-placeholder)", fontSize: '13px' }}>
                                                    2. The staking lock period is expected to be 1-2 years and the final ETH principal amount staked may be wholly converted into ETH 2.0 main network assets. Exact details will be determined by furthe developments in ETH 2.0. Please exercise caution in committing assets accordingly.
                                                </Typography>
                                                <Typography className='mb-4' sx={{ color: "var(--txt-placeholder)", fontSize: '13px' }}>
                                                    3. BETH has no price until the trade is entered into.
                                                </Typography>
                                            </Box>
                                        </Container>


                                    </Grid>
                                    <Grid xs={12} sm={12} md={6} lg={5}>
                                        <Grid sx={12} md={12} sm={12} lg={12}>
                                            <div className="d-flex my-3 me-4 justify-content-end">
                                      <Link to='/ethDetails' className="linkTag"><button className="btn btn-sm" style={{background:'#1a94ae', color:'white', height:'40px'}}>Stake details</button></Link>
                                            </div>
                                            <Container className='mt-md-4'>
                                                <Card className='lovely-card-bg' sx={{ maxWidth: 'auto', minWidth: 'auto' }} >
                                                    <CardContent className="p-4">
                                                        <Typography className='card-text fw-bold' sx={{ fontSize: '14px', fontWeight: 500 }}>
                                                            Stake process
                                                        </Typography>
                                                        <div className="d-block my-4">
                                                            <div className="d-flex">
                                                                <div>
                                                                    <img src={step1} className='me-2' />

                                                                </div>
                                                                <Typography className='card-text fw-bold' sx={{ fontSize: '14px', fontWeight: 500 }}>
                                                                    1. Stake exchange
                                                                </Typography>
                                                            </div>
                                                            <div className="ms-2">
                                                                <Typography className='ms-4' sx={{ color: "var(--txt-placeholder)", fontSize: '11px' }}>ETH 1:1 BETH, CIFDAQ Exchange will provide BETH assets as validation for users to participate in ETH2.0 mining</Typography>
                                                            </div>
                                                        </div>

                                                        <div className="d-block my-4">
                                                            <div className="d-flex">
                                                                <div>
                                                                    <img src={step2} className='me-2' />

                                                                </div>
                                                                <Typography className='card-text fw-bold' sx={{ fontSize: '14px', fontWeight: 500 }}>
                                                                    2. Trade BETH
                                                                </Typography>
                                                            </div>
                                                            <div className="ms-2">
                                                                <Typography className='ms-4' sx={{ color: "var(--txt-placeholder)", fontSize: '11px' }}>Trade BETH for USDT and vice versa
                                                                </Typography>
                                                                <Typography className='ms-4 fw-bold' sx={{ color: "#1A94AE", fontSize: '11px' }}>Trade
                                                                </Typography>
                                                            </div>
                                                        </div>

                                                        <div className="d-block my-4">
                                                            <div className="d-flex">
                                                                <div>
                                                                    <img src={step3} className='me-2' />

                                                                </div>
                                                                <Typography className='card-text fw-bold' sx={{ fontSize: '14px', fontWeight: 500 }}>
                                                                    3. Mining
                                                                </Typography>
                                                            </div>
                                                            <div className="ms-2">
                                                                <Typography className='ms-4' sx={{ color: "var(--txt-placeholder)", fontSize: '11px' }}>Participate in PoS to earn yields in BETH + MX
                                                                </Typography>
                                                                <Typography className='ms-4 fw-bold' sx={{ color: "#1A94AE", fontSize: '11px' }}>Mine
                                                                </Typography>
                                                            </div>
                                                        </div>
                                                    </CardContent>
                                                </Card>
                                            </Container>


                                        </Grid>

                                    </Grid>
                                </Grid>
                            </CardContent>
                        </Card>
                    </Grid>
                </>
            </Container>
        </div>
    );
};
export default StakeETH;
