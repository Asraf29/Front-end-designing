import { TableContainer, Typography } from '@mui/material';
import React, { useState } from 'react'
import CachedIcon from '@mui/icons-material/Cached';
import { Box } from '@mui/system';
import {
  Button,
  Paper,
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableRow,
} from "@mui/material";
import NODATA from "../../components/assets/images/nodata.png";
export default function TriggerOrder() {
  const [value, setValue] = React.useState("1");
  const [type, setType] = useState("text");
  const handleChange = (event, newValue) => {
    setValue(newValue);
  };
  return (
    <>
      <div className="container my-2 d-block d-lg-flex justify-content-between">
        <div className="d-block d-md-flex col-lg-6 col-md-6 mb-3 mb-sm-0">
          <div className="col-lg-7 col-sm-8 d-block d-sm-flex ms-0">
            <Typography className='my-1 me-2 trending my-2' sx={{ fontSize: 13}}>Futures trading pairs</Typography>
            <div className="col-lg-6 ms-0  mb-2 mb-sm-0">
              <select
                id="form-select"
                className="form-select"
                aria-label="Default select example"
              >
                <option value="1" className="textClr">
                  All
                </option>
              </select>
            </div>
          </div>
        </div>
        
        <div className="d-lg-flex my-2 my-lg-0">
          
          <button
            className="btn btn-sm  ms-0 ms-lg-2"
            style={{ color: "white", background: '#1a94ae' }}
          >
            <CachedIcon fontSize={'small'} /> Refresh
          </button>
        </div>
      </div>
      <Box sx={{ width: "100%", typography: "body1" }}>
        <TableContainer
          sx={{
            background: "var(--card-bg-color)",
            boxShadow: "none !important",
          }}
          component={Paper}
        >
          <Table sx={{ minWidth: 650 }} aria-label="simple table">
            <TableHead>
              <TableRow>
                <TableCell
                  sx={{
                    color: "var(--txt-placeholder)", fontSize: '13px !important',
                    borderBottom: 0,
                  }}> Time
                </TableCell>
                <TableCell
                  sx={{
                    color: "var(--txt-placeholder)", fontSize: '13px !important',
                    borderBottom: 0,
                  }}
                  align="center"
                >Futures
                </TableCell>
                <TableCell
                  sx={{
                    color: "var(--txt-placeholder)", fontSize: '13px !important',
                    borderBottom: 0,
                  }}
                  align="right"
                >Direction
                </TableCell>
                <TableCell
                  sx={{
                    color: "var(--txt-placeholder)", fontSize: '13px !important',
                    borderBottom: 0,
                  }}
                  align="right"
                >Leverage
                </TableCell>
                <TableCell
                  sx={{
                    color: "var(--txt-placeholder)", fontSize: '13px !important',
                    borderBottom: 0,
                  }}
                  align="right"
                >Order amount
                </TableCell>
                <TableCell
                  sx={{
                    color: "var(--txt-placeholder)", fontSize: '13px !important',
                    borderBottom: 0,
                  }}
                  align="right"
                >Order price
                </TableCell>
                <TableCell
                  sx={{
                    color: "var(--txt-placeholder)", fontSize: '13px !important',
                    borderBottom: 0,
                  }}
                  align="right"
                >Trigger conditions
                </TableCell>
                <TableCell
                  sx={{
                    color: "var(--txt-placeholder)", fontSize: '13px !important',
                    borderBottom: 0,
                  }}
                  align="right"
                >Term of validity
                </TableCell>
                <TableCell
                  sx={{
                    color: "var(--txt-placeholder)", fontSize: '13px !important',
                    borderBottom: 0,
                  }}
                  align="right"
                >Status
                </TableCell>
                <TableCell
                  sx={{
                    color: "var(--txt-placeholder)", fontSize: '13px !important',
                    borderBottom: 0,
                  }}
                  align="right"
                >Operating
                </TableCell>
              </TableRow>
            </TableHead>
            <TableBody>
              <TableRow
                sx={{
                  "&:last-child td, &:last-child th": {
                    border: 0,
                  },
                }}
              >
                <TableCell
                  align="center"
                  colSpan={10}
                  sx={{
                    justifyContent: "center",
                    alignItems: "center",
                  }}
                >
                  {" "}
                  <img src={NODATA} />{" "}
                </TableCell>
              </TableRow>
            </TableBody>
          </Table>
        </TableContainer>
      </Box>
    </>
  )
}
