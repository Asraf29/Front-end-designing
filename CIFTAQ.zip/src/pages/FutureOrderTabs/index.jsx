import React, { useState } from "react";
import { makeStyles } from "@mui/styles";
import {
    Button,
    Card,
    CardContent,
    Grid,
    Table,
    Tabs,
    Typography,
} from "@mui/material";
import Box from "@mui/material/Box";
import ArrowBackIosIcon from "@mui/icons-material/ArrowBackIos";
import Tab from "@mui/material/Tab";
import TabContext from "@mui/lab/TabContext";
import TabList from "@mui/lab/TabList";
import TabPanel from "@mui/lab/TabPanel";
import { Container } from "@mui/system";
import { Link } from "react-router-dom";
import OrderRecords from "./orderRecords";
import LimitOrder from "./limitOrder";
import TriggerOrder from "./triggerOrder";
import FundingFees from "./fundingFees";
import CapitalFlow from "./capitalFlow";

const useStyles = makeStyles({
    MUITab: {
        fontSize: "16px !important",
        color: "var(--txt-placeholder)"
    },
});

export default function FutureOrder() {
    const [value, setValue] = React.useState("1");
    const [type, setType] = useState("text");
    const handleChange = (event, newValue) => {
        setValue(newValue);
    };
    const classes = useStyles();
    return (
        <>
            <Container sx={{ mt: 7 }}>
                <Typography
                    className="mb-3 d-flex align-items-center verifyTitle"
                    variant="h5"
                >
                    <Link to="/mday" className="linkTag text-white">
                        <ArrowBackIosIcon className="mb-2" />
                    </Link>
                    Futures order
                </Typography>

                <Grid item xs={12} lg={12} md={12}>
                    <Card
                        sx={{
                            minWidth: 100,
                            background: "var(--card-bg-color)",
                        }}
                    >
                        <CardContent>
                            <TabContext value={value}>
                                <TabList
                                    TabIndicatorProps={{
                                        style: { display: 'none' }
                                    }}
                                    onChange={handleChange}
                                    variant="scrollable"
                                >
                                    <Tab
                                        className={classes.MUITab}
                                        label="Limit order"
                                        value="1"
                                    />
                                    <Tab
                                        className={classes.MUITab}
                                        label="Trigger order"
                                        value="2"
                                    />
                                    <Tab
                                        className={classes.MUITab}
                                        label="Order records"
                                        value="3"
                                    />
                                    <Tab
                                        className={classes.MUITab}
                                        label="Funding fees"
                                        value="4"
                                    />
                                    <Tab
                                        className={classes.MUITab}
                                        label="Capital flow"
                                        value="5"
                                    />

                                </TabList>
                                <TabPanel sx={{ padding: "4px !important" }} value="1">
                                    <LimitOrder/>
                                </TabPanel>

                                <TabPanel sx={{ padding: "4px !important" }} value="2">
                               <TriggerOrder/>
                                </TabPanel>
                                <TabPanel sx={{ padding: "4px !important" }} value="3">
                                    <Typography sx={{ color: '#1A94AE', fontSize: 13, mb: 2 }} className='d-flex justify-content-end'>Export transcation history</Typography>
                                    <OrderRecords />
                                </TabPanel>
                                <TabPanel sx={{ padding: "4px !important" }} value="4">
                                    <FundingFees/>
                                </TabPanel>
                                <TabPanel sx={{ padding: "4px !important" }} value="5">
                                    <CapitalFlow/>
                                </TabPanel>
                                
                            </TabContext>

                        </CardContent>
                    </Card>
                </Grid>
            </Container>
        </>
    );
}
