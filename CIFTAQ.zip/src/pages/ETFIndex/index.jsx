import * as React from "react";
import Box from "@mui/material/Box";
import Card from "@mui/material/Card";
import { green } from "@mui/material/colors";
import CardContent from "@mui/material/CardContent";
import NODATA from "../../components/assets/images/nodata.png";
import MarketTableJson from "../../hooks/marketTable";
import Table from "@mui/material/Table";
import TableBody from "@mui/material/TableBody";
import TableCell from "@mui/material/TableCell";
import StarIcon from "@mui/icons-material/Star";
import TableContainer from "@mui/material/TableContainer";
import TableHead from "@mui/material/TableHead";
import TableRow from "@mui/material/TableRow";
import Paper from "@mui/material/Paper";
import Button from "@mui/material/Button";
import Typography from "@mui/material/Typography";
import { Avatar, FormControl, Grid, MenuItem, Select } from "@mui/material";
import Tab from "@mui/material/Tab";
import graph from "../../components/assets/images/graph.png";
import tradeGraph from "../../components/assets/images/tradeGraph.png";
import roundChart from "../../components/assets/images/roundChart.png";
import { TabContext, TabList, TabPanel } from "@mui/lab";
import FiberManualRecordIcon from '@mui/icons-material/FiberManualRecord';
import "./index.css";
function createData(name, calories, fat, carbs, protein) {
    return { name, calories, fat, carbs, protein };
}

const ETFIndex = () => {
    const [value, setValue] = React.useState("1");
    const handleChange = (event, newValue) => {
        setValue(newValue);
    };
    ////FAV TABS///
    const [trend, setTrending] = React.useState("1");
    const trending = (event, trendingTab) => {
        setTrending(trendingTab);
    };
    ///TABLE DATA////
    const rows = [
        createData("0.067312", "2.5 M", 17.19999),
        createData("0.0025", "2.5 M", 17.19999),
        createData("0.0025", "2.5 M", 17.1952),
        createData("0.0025", "2.5 M", 17.1952),
        createData("0.0025", "2.5 M", 17.1952),
        createData("0.0025", "2.5 M", 17.1952),
        createData("0.0025", "2.5 M", 17.1952),
    ];
    /*Index Market */
    const dublicateData = ["1", "2", "3", "4", "5", "6", "7", "8", "9", "10"]
    return (
        <div>
            <div className="container-fluid my-4">
                <Grid container spacing={2}>
                    {/* Left Side Card */}
                    <Grid item xs={12} lg={3} md={3}>
                        <Card sx={{ minWidth: 100, background: "var(--market-order-card-bg-color)" }}>
                            <CardContent>
                                <Box sx={{ width: "100%", typography: "body1" }}>
                                    <Box>
                                        <Typography variant="h5" className="text-blue">Index Market</Typography>
                                    </Box>
                                    <TableContainer className="tableProperty" component={Paper}>
                                        <Table sx={{ minWidth: "auto" }} aria-label="simple table" className="tableProperty">
                                            <TableHead className="border-0">
                                                <TableRow>
                                                    <TableCell className="textClr-thead index-fontSize border-0" align="lefts">
                                                        Index
                                                    </TableCell>
                                                    <TableCell className="textClr-thead index-fontSize border-0" align="center">
                                                        Market Capitalization
                                                    </TableCell>
                                                    <TableCell className="textClr-thead index-fontSize border-0" align="center">
                                                        Change[%]
                                                    </TableCell>
                                                </TableRow>
                                            </TableHead>
                                            <TableBody>
                                                {dublicateData.map((data) => (<TableRow className="border-0">
                                                    <TableCell className="index-text border-0" align="left">
                                                        Grayscale Index
                                                    </TableCell>
                                                    <TableCell className="index-text index-fontSize border-0" align="center">
                                                        3.3536
                                                    </TableCell>
                                                    <TableCell className="index-text-green index-fontSize border-0" align="center">
                                                        +3.25
                                                    </TableCell>
                                                </TableRow>))}
                                            </TableBody>
                                        </Table>
                                    </TableContainer>
                                </Box>
                            </CardContent>
                        </Card>
                    </Grid>
                    {/* Center Card */}
                    <Grid item xs={12} md={6} lg={6}>
                        <Box sx={{ marginBottom: 2 }}>
                            <Card sx={{ overflowX: "auto", height: "60px", background: "var(--market-center-bg-card)" }}>
                                <CardContent>
                                    <div className="d-flex justify-content-between">
                                        <Grid item xs={12} md={2} lg={2}>
                                            <Typography className="fs-sm" variant="h7" sx={{ mb: 1.5, color: "white" }} >
                                                Grayscale Index
                                            </Typography>
                                        </Grid>
                                        <Grid item xs={12} md={2} lg={2}>
                                            <div className="d-flex justify-content-center">
                                                <Typography sx={{ color: "white" }}>
                                                    3.3523
                                                </Typography>
                                            </div>
                                            <Typography className="textClr-subTitle" sx={{ fontSize: "12px" }}>
                                                Market Capitalization
                                            </Typography>
                                        </Grid>
                                        <Grid item xs={12} md={2} lg={2}>
                                            <div className="d-flex justify-content-center">
                                                <Typography className="index-text-green">
                                                    +3.21%
                                                </Typography>
                                            </div>
                                            <Typography className="textClr-subTitle text-center" sx={{ fontSize: "12px" }}>
                                                Change[%]
                                            </Typography>
                                        </Grid>
                                        <Grid item xs={12} md={2} lg={2}>
                                            <div className="d-flex justify-content-center">
                                                <Typography sx={{ color: "white" }}>
                                                    3.3523
                                                </Typography>
                                            </div>
                                            <Typography className="textClr-subTitle text-center" sx={{ fontSize: "12px" }}>
                                                24h High
                                            </Typography>
                                        </Grid>
                                        <Grid item xs={12} md={2} lg={2}>
                                            <div className="d-flex justify-content-center">
                                                <Typography sx={{ color: "white" }}>
                                                    3.3523
                                                </Typography>
                                            </div>
                                            <Typography className="textClr-subTitle text-center" sx={{ fontSize: "12px" }}>
                                                24h Low
                                            </Typography>
                                        </Grid>
                                    </div>
                                </CardContent>
                            </Card>
                        </Box>
                        {/* Center Graph Card */}
                        <Card sx={{ minWidth: 275, background: "var(--market-center-bg-card)" }}>
                            <CardContent>
                                <Box sx={{ width: "100%", typography: "body1" }}>
                                    <TabContext value={value}>
                                        <div className="d-sm-flex justify-content-sm-between align-content-center">
                                            <div>
                                                <Box>
                                                    <TabList onChange={handleChange} aria-label="lab API tabs example">
                                                        <Tab sx={{ color: "white", textTransform: "none" }} label="K-Line" value="1" />
                                                        <Tab sx={{ color: "white", textTransform: "none" }} label="Token information" value="2" />
                                                    </TabList>
                                                </Box>
                                            </div>
                                            <div style={{ marginLeft: "auto" }} className="d-flex align-items-center">
                                                <Typography className="text-nowrap textClr-subTitle ps-2">Data Source:</Typography>
                                                <select style={{ fontWeight: 600 }} className="indexSelectbg form-select textClr fs-sm" aria-label="Default select example">
                                                    <option className='text-dark ' selected>Grayscale Index</option>
                                                    <option className='text-dark' value="1">0x202x0</option>
                                                    <option className='text-dark' value="2">0xx545</option>
                                                    <option className='text-dark' value="3">0x789x</option>
                                                </select>
                                            </div>
                                        </div>
                                        <div className="d-flex align-items-center">
                                            <div>
                                                <ul className="nav nav-pills pills mb-2 my-2" id="pills-tab pills-icons" role="tablist">
                                                    <li className="nav-item" role="presentation">
                                                        <button className="nav-link active btn-sm btn" style={{ color: "white" }} id="pills-basic-tab" data-bs-toggle="pill" data-bs-target="#pills-basic" role="tab">
                                                            1 min
                                                        </button>
                                                    </li>
                                                    <li className="nav-item" role="presentation">
                                                        <button className="nav-link btn-sm btn" id="pills-proffessional-tab" style={{ color: "white" }} data-bs-toggle="pill" data-bs-target="#pills-proffessional" role="tab">
                                                            5 min
                                                        </button>
                                                    </li>
                                                    <li className="nav-item" role="presentation">
                                                        <button className="nav-link btn-sm btn" id="pills-depth-tab" style={{ color: "white" }} data-bs-toggle="pill" data-bs-target="#pills-depth" role="tab">
                                                            15 min
                                                        </button>
                                                    </li>
                                                    <li className="nav-item" role="presentation">
                                                        <button className="nav-link btn-sm btn" id="pills-depth-tab" style={{ color: "white" }} data-bs-toggle="pill" data-bs-target="#pills-depth" role="tab">
                                                            30 min
                                                        </button>
                                                    </li>
                                                    <li className="nav-item" role="presentation">
                                                        <button className="nav-link btn-sm btn" id="pills-depth-tab" style={{ color: "white" }} data-bs-toggle="pill" data-bs-target="#pills-depth" role="tab">
                                                            30 min
                                                        </button>
                                                    </li>
                                                    <li className="nav-item" role="presentation">
                                                        <button className="nav-link btn-sm btn" id="pills-depth-tab" style={{ color: "white" }} data-bs-toggle="pill" data-bs-target="#pills-depth" role="tab">
                                                            1 hour
                                                        </button>
                                                    </li>
                                                    <li className="nav-item" role="presentation">
                                                        <button className="nav-link btn-sm btn" id="pills-depth-tab" style={{ color: "white" }} data-bs-toggle="pill" data-bs-target="#pills-depth" role="tab">
                                                            4 hour
                                                        </button>
                                                    </li>
                                                    <li className="nav-item" role="presentation">
                                                        <button className="nav-link btn-sm btn" id="pills-depth-tab" style={{ color: "white" }} data-bs-toggle="pill" data-bs-target="#pills-depth" role="tab">
                                                            1 day
                                                        </button>
                                                    </li>
                                                    <div className="dropdown">
                                                        <button className="btn btn-sm bg-dropdown dropdown-toggle p-0 ps-1 pe-1 my-lg-1" id="dropdownMenuButton1" data-bs-toggle="dropdown">
                                                            More
                                                        </button>
                                                        <ul className="dropdown-menu bg-dropdown" aria-labelledby="dropdownMenuButton1">
                                                            <li>
                                                                <a className="dropdown-item" href="#">
                                                                    1 min <StarIcon sx={{ fontSize: "10px", color: "#ffbf00" }} />
                                                                </a>
                                                            </li>
                                                            <li>
                                                                <a className="dropdown-item" href="#">
                                                                    1 min <StarIcon sx={{ fontSize: "10px", color: "#ffbf00" }} />
                                                                </a>
                                                            </li>
                                                            <li>
                                                                <a className="dropdown-item" href="#">
                                                                    1 min <StarIcon sx={{ fontSize: "10px", color: "#ffbf00" }} />
                                                                </a>
                                                            </li>
                                                        </ul>
                                                    </div>
                                                </ul>
                                            </div>
                                        </div>
                                        <TabPanel value="1">
                                            <div>
                                                <div className="tab-content" id="pills-tabContent">
                                                    <div className="tab-pane fade show active" id="pills-basic" role="tabpanel">
                                                        <div className=" d-flex justify-content-center">
                                                            <img src={tradeGraph} className="img-fluid" />
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                        </TabPanel>
                                        <TabPanel value="2">
                                            <div className="tab-pane fade show active" id="pills-basic" role="tabpanel">
                                                <div className=" d-flex justify-content-center">
                                                    <img src={tradeGraph} className="img-fluid" />
                                                </div>
                                            </div>
                                        </TabPanel>
                                        <TabPanel value="3">
                                            <div className=" d-flex justify-content-center">
                                                <img src={graph} className="img-fluid" />
                                            </div>
                                        </TabPanel>
                                    </TabContext>
                                </Box>
                            </CardContent>
                        </Card>

                        {/* /////////SPOT MARKET////// */}
                        <Grid item xs={12} md={12} lg={12}>
                            <Card sx={{ minWidth: 275, background: "var(--market-center-bg-card)", marginTop: 3 }}>
                                <CardContent>
                                    <Box sx={{ width: "100%", typography: "body1" }}>
                                        <div className="row ">
                                            <Typography className="text-blue mb-4">Index Trades</Typography>
                                            {/* Buy Card */}
                                            <div className="col-lg-6  my-2 col-sm-12 col-md-12">
                                                <Box className="d-flex justify-content-between mb-4">
                                                    <div><Typography sx={{ color: '#fff' }}>Asset</Typography></div>
                                                    <div><Typography sx={{ color: '#fff' }}>0 USDT--</Typography></div>
                                                </Box>
                                                <div className="mb-2 d-flex  mt-2" style={{ height: "60px" }}>
                                                    <span className="priceTag pe-2">
                                                        <b className="text-center text-muted">
                                                            Unit Price
                                                        </b>
                                                    </span>
                                                    <input type="text" className="form-control form-control-usd form-input-usd" style={{ border: "none", borderTopRightRadius: 0, borderBottomRightRadius: 0, height: "40px" }} />
                                                    <select
                                                        className="form-select form-select-sm text-muted form-control-usd selction-bg"
                                                        style={{ width: "5rem", height: "40px", fontWeight: 700, fontSize: "15px", border: "none", borderTopLeftRadius: 0, borderBottomLeftRadius: 0 }}>
                                                        <option value="1" className="selectionText">
                                                            USDT
                                                        </option>
                                                        <option value="2" className="selectionText">
                                                            USDT
                                                        </option>
                                                        <option value="3" className="selectionText">
                                                            USDT
                                                        </option>
                                                    </select>
                                                </div>
                                                <div className="d-flex justify-content-between mb-4">
                                                    <div><Typography sx={{ color: '#fff' }} className="fs-sm">Quantity</Typography></div>
                                                    <div className="d-flex">
                                                        <Typography sx={{ color: '#fff' }} className="fs-sm">Max 20000 USDT</Typography>
                                                        <Typography sx={{ color: '#fff' }} className="ps-3 fs-sm">Min 100 USDT</Typography>
                                                    </div>
                                                </div>
                                                <input type="range" style={{ width: "98%" }} id="green" className="input-green" name="vol" min="0" max="100" />
                                                <div className="d-flex justify-content-between ms-1 mt-4">
                                                    <Typography sx={{ color: "white" }}>
                                                        Subscription rate
                                                    </Typography>
                                                    <Typography sx={{ color: "white" }}>
                                                        0.20%
                                                    </Typography>
                                                </div>
                                                <div className="d-grid my-4">
                                                    <button className="btn" style={{ background: "var(--icon-color)", color: "white" }} type="button">
                                                        Buy
                                                    </button>
                                                </div>
                                            </div>
                                            {/* Buy Card End*/}
                                            {/* Sell Card */}
                                            <div className="col-lg-6 col-sm-12 col-md-12 pt-2">
                                                <Box className="d-flex justify-content-between mb-4">
                                                    <div><Typography sx={{ color: '#fff' }}>Asset</Typography></div>
                                                    <div><Typography sx={{ color: '#fff' }}>0 Part--</Typography></div>
                                                </Box>
                                                <div className="mb-2 d-flex  mt-2" style={{ height: "60px" }}>
                                                    <span className="priceTag pe-2">
                                                        <b className="text-center text-muted">
                                                            Unit Price
                                                        </b>
                                                    </span>
                                                    <input type="text" className="form-control form-control-usd form-input-usd" style={{ border: "none", borderTopRightRadius: 0, borderBottomRightRadius: 0, height: "40px" }} />

                                                    <select
                                                        className="form-select form-select-sm text-muted form-control-usd selction-bg"
                                                        style={{ width: "5rem", height: "40px", fontWeight: 700, fontSize: "15px", border: "none", borderTopLeftRadius: 0, borderBottomLeftRadius: 0 }}>
                                                        <option value="1" className="selectionText">
                                                            Part
                                                        </option>
                                                        <option value="2" className="selectionText">
                                                            Part
                                                        </option>
                                                        <option value="3" className="selectionText">
                                                            Part
                                                        </option>
                                                    </select>
                                                </div>
                                                <div className="d-flex justify-content-between mb-4">
                                                    <div><Typography sx={{ color: '#fff' }} className="fs-sm">Quantity</Typography></div>
                                                    <div className="d-flex">
                                                        <Typography sx={{ color: '#fff' }} className="fs-sm">Max 20000 USDT</Typography>
                                                        <Typography sx={{ color: '#fff' }} className="ps-3 fs-sm">Min 10 Cont</Typography>
                                                    </div>
                                                </div>
                                                <input type="range" id="red" style={{ width: "99%" }} className="input-green" name="vol" min="0" max="100" />
                                                <div className="d-flex justify-content-between ms-1 mt-4">
                                                    <Typography sx={{ color: "white" }}>
                                                        Redemption rate
                                                    </Typography>
                                                    <Typography sx={{ color: "white" }}>
                                                        0.20%
                                                    </Typography>
                                                </div>
                                                <div className="d-grid my-4">
                                                    <button className="btn" type="button" style={{ background: "#DD2942", color: "white" }}>
                                                        Sell
                                                    </button>
                                                </div>
                                            </div>
                                            {/* Sell Card End*/}
                                        </div>
                                    </Box>
                                </CardContent>
                            </Card>
                            <Box></Box>
                        </Grid>
                    </Grid>
                    {/* Right Side Card */}
                    <Grid item xs={12} md={3} lg={3}>
                        <Card sx={{ minWidth: 100, background: "var(--market-fav-card-bg-color)" }}>
                            <CardContent>
                                <Box sx={{ width: "100%", typography: "body1" }}>
                                    <Box>
                                        <Typography variant="h5" className="text-blue">Fund Allocations</Typography>
                                    </Box>
                                    <Box>
                                        <div className=" d-flex justify-content-center py-4">
                                            <img src={roundChart} className="img-fluid" />
                                        </div>
                                    </Box>
                                    <TableContainer className="tableProperty" component={Paper}>
                                        <Table sx={{ minWidth: "auto" }} aria-label="simple table" className="tableProperty">
                                            <TableHead className="border-0">
                                                <TableRow>
                                                    <TableCell className="textClr-thead index-fontSize border-0 fw-bold" align="lefts">
                                                        Token
                                                    </TableCell>
                                                    <TableCell className="textClr-thead index-fontSize border-0  fw-bold" align="center">
                                                        Percentage
                                                    </TableCell>
                                                    <TableCell className="textClr-thead index-fontSize border-0 fw-bold" align="center">
                                                        Price[USDT]
                                                    </TableCell>
                                                </TableRow>
                                            </TableHead>
                                            <TableBody>
                                                <TableRow className="border-0">
                                                    <TableCell className="index-text border-0" align="left">
                                                        <Box className="d-flex align-items-center">
                                                            <div><FiberManualRecordIcon className="dot-icon green-circle pb-1" /></div>
                                                            <div>ETH</div>
                                                        </Box>
                                                    </TableCell>
                                                    <TableCell className="index-text index-fontSize border-0" align="center">
                                                        29.37%
                                                    </TableCell>
                                                    <TableCell className="index-text index-fontSize border-0" align="center">
                                                        3248.17
                                                    </TableCell>
                                                </TableRow>
                                                <TableRow className="border-0">
                                                    <TableCell className="index-text border-0" align="left">
                                                        <Box className="d-flex align-items-center">
                                                            <div><FiberManualRecordIcon className="dot-icon blue-circle pb-1" /></div>
                                                            <div>ZEN</div>
                                                        </Box>
                                                    </TableCell>
                                                    <TableCell className="index-text index-fontSize border-0" align="center">
                                                        29.37%
                                                    </TableCell>
                                                    <TableCell className="index-text index-fontSize border-0" align="center">
                                                        3248.17
                                                    </TableCell>
                                                </TableRow>
                                                <TableRow className="border-0">
                                                    <TableCell className="index-text border-0" align="left">
                                                        <Box className="d-flex align-items-center">
                                                            <div><FiberManualRecordIcon className="dot-icon lightblue-circle pb-1" /></div>
                                                            <div>ETC</div>
                                                        </Box>
                                                    </TableCell>
                                                    <TableCell className="index-text index-fontSize border-0" align="center">
                                                        29.37%
                                                    </TableCell>
                                                    <TableCell className="index-text index-fontSize border-0" align="center">
                                                        3248.17
                                                    </TableCell>
                                                </TableRow>
                                                <TableRow className="border-0">
                                                    <TableCell className="index-text border-0" align="left">
                                                        <Box className="d-flex align-items-center">
                                                            <div><FiberManualRecordIcon className="dot-icon violet-circle pb-1" /></div>
                                                            <div>BTC</div>
                                                        </Box>
                                                    </TableCell>
                                                    <TableCell className="index-text index-fontSize border-0" align="center">
                                                        29.37%
                                                    </TableCell>
                                                    <TableCell className="index-text index-fontSize border-0" align="center">
                                                        3248.17
                                                    </TableCell>
                                                </TableRow>
                                                <TableRow className="border-0">
                                                    <TableCell className="index-text border-0" align="left">
                                                        <Box className="d-flex align-items-center">
                                                            <div><FiberManualRecordIcon className="dot-icon yellow-circle pb-1" /></div>
                                                            <div>LTC</div>
                                                        </Box>
                                                    </TableCell>
                                                    <TableCell className="index-text index-fontSize border-0" align="center">
                                                        29.37%
                                                    </TableCell>
                                                    <TableCell className="index-text index-fontSize border-0" align="center">
                                                        3248.17
                                                    </TableCell>
                                                </TableRow>
                                                <TableRow className="border-0">
                                                    <TableCell className="index-text border-0" align="left">
                                                        <Box className="d-flex align-items-center">
                                                            <div><FiberManualRecordIcon className="dot-icon orange-circle pb-1" /></div>
                                                            <div>XLM</div>
                                                        </Box>
                                                    </TableCell>
                                                    <TableCell className="index-text index-fontSize border-0" align="center">
                                                        29.37%
                                                    </TableCell>
                                                    <TableCell className="index-text index-fontSize border-0" align="center">
                                                        3248.17
                                                    </TableCell>
                                                </TableRow>
                                                <TableRow className="border-0">
                                                    <TableCell className="index-text border-0" align="left">
                                                        <Box className="d-flex align-items-center">
                                                            <div><FiberManualRecordIcon className="dot-icon pink-circle pb-1" /></div>
                                                            <div>ZEC</div>
                                                        </Box>
                                                    </TableCell>
                                                    <TableCell className="index-text index-fontSize border-0" align="center">
                                                        29.37%
                                                    </TableCell>
                                                    <TableCell className="index-text index-fontSize border-0" align="center">
                                                        3248.17
                                                    </TableCell>
                                                </TableRow>
                                                <TableRow className="border-0">
                                                    <TableCell className="index-text border-0" align="left">
                                                        <Box className="d-flex align-items-center">
                                                            <div><FiberManualRecordIcon className="dot-icon darkgray-circle pb-1" /></div>
                                                            <div>XRP</div>
                                                        </Box>
                                                    </TableCell>
                                                    <TableCell className="index-text index-fontSize border-0" align="center">
                                                        29.37%
                                                    </TableCell>
                                                    <TableCell className="index-text index-fontSize border-0" align="center">
                                                        3248.17
                                                    </TableCell>
                                                </TableRow>
                                                <TableRow className="border-0">
                                                    <TableCell className="index-text border-0" align="left">
                                                        <Box className="d-flex align-items-center">
                                                            <div><FiberManualRecordIcon className="dot-icon gray-circle pb-1" /></div>
                                                            <div>BCH</div>
                                                        </Box>
                                                    </TableCell>
                                                    <TableCell className="index-text index-fontSize border-0" align="center">
                                                        29.37%
                                                    </TableCell>
                                                    <TableCell className="index-text index-fontSize border-0" align="center">
                                                        3248.17
                                                    </TableCell>
                                                </TableRow>
                                            </TableBody>
                                        </Table>
                                    </TableContainer>
                                </Box>
                            </CardContent>
                        </Card>
                    </Grid>
                </Grid>
                {/* Bottom Table */}
                <Grid item xs={12} lg={12} md={3}>
                    <Card sx={{ background: "var(--market-center-bg-card)", my: 6 }}>
                        <CardContent>
                            <TabContext value={trend}>
                                <div className="d-sm-flex justify-content-sm-between align-items-center">
                                    <div>
                                        <Box sx={{ marginTop: "10px" }}>
                                            <TabList variant="scrollable" onChange={trending} aria-label="lab API tabs example">
                                                <Tab sx={{ fontSize: "15px", color: "#1A94AE", fontWeight: 500, textTransform: "none" }}
                                                    label="Subscription application" value="1" />
                                                <Tab sx={{ fontSize: "15px", color: "#fff", fontWeight: 500, textTransform: "none" }}
                                                    label="Subscription application" value="2" />
                                            </TabList>
                                        </Box>
                                    </div>
                                    <div>
                                        <ul className="nav nav-pills pills mb-2 my-2" id="pills-tab pills-icons" role="tablist">
                                            <li className="nav-item" role="presentation">
                                                <button className="nav-link active btn-sm btn" style={{ color: "white" }} id="pills-basic-tab" data-bs-toggle="pill" data-bs-target="#pills-basic" role="tab">
                                                    Current
                                                </button>
                                            </li>
                                            <li className="nav-item" role="presentation">
                                                <button className="nav-link btn-sm btn" id="pills-proffessional-tab" style={{ color: "white" }} data-bs-toggle="pill" data-bs-target="#pills-proffessional" role="tab">
                                                    All
                                                </button>
                                            </li>
                                        </ul>
                                    </div>
                                </div>
                                <TabPanel value="1">
                                    <TableContainer className="tableBox-shadow border-0">
                                        <Table
                                            sx={{ minWidth: 650, background: "var(--market-center-bg-card)" }} className="" aria-label="simple table">
                                            <TableHead>

                                                <TableRow className="border-line">
                                                    <TableCell className="textClr-thead index-fontSize border-0 fw-bold" align="center">
                                                        Index name
                                                    </TableCell>
                                                    <TableCell className="textClr-thead index-fontSize border-0  fw-bold" align="center">
                                                        Time
                                                    </TableCell>
                                                    <TableCell className="textClr-thead index-fontSize border-0 fw-bold" align="center">
                                                        Unit price
                                                    </TableCell>
                                                    <TableCell className="textClr-thead index-fontSize border-0  fw-bold" align="center">
                                                        Quality
                                                    </TableCell>
                                                    <TableCell className="textClr-thead index-fontSize  border-0 fw-bold" align="center">
                                                        Transcation fee
                                                    </TableCell>
                                                    <TableCell className="textClr-thead index-fontSize  border-0 fw-bold" align="center">
                                                        Net transcation value
                                                    </TableCell>
                                                    <TableCell className="textClr-thead index-fontSize border-0  fw-bold" align="center">
                                                        Status
                                                    </TableCell>
                                                    <TableCell className="textClr-thead index-fontSiz  border-0 fw-bold" align="center">
                                                        Action
                                                    </TableCell>
                                                </TableRow>
                                            </TableHead>
                                            <TableBody>
                                                <TableRow>
                                                    <TableCell align="center" colSpan={8} sx={{ justifyContent: "center", alignItems: "center"}} className="border-0">
                                                        <img src={NODATA} className="pt-5"/>
                                                    </TableCell>
                                                </TableRow>
                                            </TableBody>
                                        </Table>
                                    </TableContainer>
                                </TabPanel>
                            </TabContext>
                        </CardContent>
                    </Card>
                </Grid>
            </div>
        </div>
    );
}
export default ETFIndex;