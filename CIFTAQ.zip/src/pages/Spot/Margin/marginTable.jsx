import React, { useState } from 'react'
import NODATA from "../../../components/assets/images/nodata.png";
import TableBody from "@mui/material/TableBody";
import TableCell from "@mui/material/TableCell";
import TableContainer from "@mui/material/TableContainer";
import TableHead from "@mui/material/TableHead";
import { makeStyles } from "@mui/styles";
import TableRow from "@mui/material/TableRow";
import Paper from "@mui/material/Paper";
import { Card, CardContent, Grid, Table, Typography } from '@mui/material';
import Box from '@mui/material/Box';
import Tab from '@mui/material/Tab';
import TabContext from '@mui/lab/TabContext';
import CachedIcon from '@mui/icons-material/Cached';
import TabList from '@mui/lab/TabList';
import '../index.css';
import ExitToAppIcon from '@mui/icons-material/ExitToApp';
import TabPanel from '@mui/lab/TabPanel';
const useStyles = makeStyles({
    MUITab: {
        fontSize: "16px !important",
    },
});
const MarginTable = () => {
    const [value, setValue] = React.useState('1');
    const [type, setType] = useState("text");
    const handleChange = (event, newValue) => {
        setValue(newValue);
    };
    const classes = useStyles();
    return (
        <>
            <Grid item xs={12} lg={12} md={12}>
                <Card
                    sx={{
                        minWidth: 100,
                        background: "var(--card-bg-color)",
                    }}
                >
                    <CardContent>
                        <Box>
                            <TabContext value={value}>
                                <Box>
                                    <TabList onChange={handleChange} aria-label="lab API tabs example">
                                        <Tab className={classes.MUITab} label="Current Order" value="1" />
                                        <Tab className={classes.MUITab} label="Order History" value="2" />
                                        <Tab className={classes.MUITab} label="Transcation History" value="3" />
                                        <Tab className={classes.MUITab} label="Stop-Limit" value="4" />
                                        <Tab className={classes.MUITab} label="Loan-History" value="5" />
                                        <Tab className={classes.MUITab} label="Repayment History" value="6" />
                                    </TabList>
                                </Box>
                                {/* Currunt Order Table */}
                                <TabPanel value="1">
                                    <div className="container my-2 d-block d-lg-flex justify-content-between">
                                        <div className="d-block d-md-flex col-lg-6 mb-3 mb-sm-0">
                                            <div className="col-lg-5 d-block d-sm-flex ms-0">
                                                <Typography className='my-1 ms-2 me-2 trending'>Trading Pair:</Typography>
                                                <div className="col-lg-6 ms-0  mb-2 mb-sm-0">
                                                    <select id="form-select" className="form-select" aria-label="Default select example">
                                                        <option value="1" className="textClr">
                                                            All
                                                        </option>
                                                    </select>
                                                </div>
                                            </div>
                                            <div className="col-lg-5 d-block d-sm-flex ms-0">
                                                <Typography className='my-1 ms-2 me-2 trending'>Direction:</Typography>
                                                <div className="col-lg-6 ms-0  mb-2 mb-sm-0">
                                                    <select id="form-select" className="form-select" aria-label="Default select example">
                                                        <option value="1" className="textClr">
                                                            All
                                                        </option>
                                                    </select>
                                                </div>
                                            </div>
                                        </div>
                                        <div className="d-grid d-lg-flex">
                                            <button className="btn btn-sm  ms-0 ms-lg-2 mt-2 mt-lg-0" style={{ color: "white", background: '#1a94ae' }}
                                            >
                                                <CachedIcon fontSize={'small'} /> Refresh
                                            </button>
                                        </div>
                                    </div>
                                    <Box sx={{ width: "100%", typography: "body1", mt: 3 }}>
                                        <TableContainer className='paper-bg' sx={{ background: 'var(--card-bg-color)' }} component={Paper}>
                                            <Table sx={{ minWidth: 650 }} aria-label="simple table" className='table-color'>
                                                <TableHead className='border-color'>
                                                    <TableRow>
                                                        <TableCell className="textClr" sx={{ fontWeight: "bolder !important" }}>
                                                            Trading Pair
                                                        </TableCell>
                                                        <TableCell className="textClr" sx={{ fontWeight: "bolder !important" }} align="center">
                                                            Filled time
                                                        </TableCell>
                                                        <TableCell className="textClr" sx={{ fontWeight: "bolder !important" }} align="center">
                                                            Direction
                                                        </TableCell>
                                                        <TableCell className="textClr" sx={{ fontWeight: "bolder !important" }} align="center">
                                                            Type
                                                        </TableCell>
                                                        <TableCell className="textClr" sx={{ fontWeight: "bolder !important" }} align="center">
                                                            Price
                                                        </TableCell>
                                                        <TableCell className="textClr" sx={{ fontWeight: "bolder !important" }} align="center">
                                                            Quantity
                                                        </TableCell>
                                                        <TableCell className="textClr" sx={{ fontWeight: "bolder !important" }} align="center">
                                                            Amount
                                                        </TableCell>
                                                        <TableCell className="textClr" sx={{ fontWeight: "bolder !important" }} align="center">
                                                            Filled Quantity
                                                        </TableCell>
                                                        <TableCell className="textClr" sx={{ fontWeight: "bolder !important" }} align="center">
                                                            Action
                                                        </TableCell>
                                                    </TableRow>
                                                </TableHead>
                                                <TableBody>
                                                    <TableRow sx={{ "&:last-child td, &:last-child th": { border: 0 } }}>
                                                        <TableCell align="center" colSpan={9} sx={{ justifyContent: "center", alignItems: "center" }}>
                                                            <img className='my-4' src={NODATA} />
                                                        </TableCell>
                                                    </TableRow>
                                                </TableBody>
                                            </Table>
                                        </TableContainer>
                                    </Box>
                                </TabPanel>
                                {/* Current Order Table End */}
                                {/* Order History Table */}
                                <TabPanel value="2">
                                    <div className="container my-2 d-block d-lg-flex justify-content-between">
                                        <div className="d-block d-md-flex col-lg-6 mb-3 mb-sm-0">
                                            <div className="col-lg-5 d-block d-sm-flex ms-0">
                                                <Typography className='my-1 ms-2 me-2 trending'>Trading Pair:</Typography>
                                                <div className="col-lg-6 ms-0  mb-2 mb-sm-0">
                                                    <select id="form-select" className="form-select" aria-label="Default select example">
                                                        <option value="1" className="textClr">
                                                            All
                                                        </option>
                                                    </select>
                                                </div>
                                            </div>
                                            <div className="col-lg-5 d-block d-sm-flex ms-0">
                                                <Typography className='my-1 ms-2 me-2 trending'>Direction:</Typography>
                                                <div className="col-lg-6 ms-0  mb-2 mb-sm-0">
                                                    <select id="form-select" className="form-select" aria-label="Default select example">
                                                        <option value="1" className="textClr">
                                                            All
                                                        </option>
                                                    </select>
                                                </div>
                                            </div>
                                        </div>
                                        <div className="d-grid d-lg-flex">
                                            <button className="btn btn-sm  ms-0 ms-lg-2 mt-2 mt-lg-0" style={{ color: "white", background: '#1a94ae' }}
                                            >
                                                <CachedIcon fontSize={'small'} /> Refresh
                                            </button>
                                        </div>
                                    </div>
                                    <Box sx={{ width: "100%", typography: "body1", mt: 3 }}>
                                        <TableContainer className='paper-bg' sx={{ background: 'var(--card-bg-color)' }} component={Paper}>
                                            <Table sx={{ minWidth: 650 }} aria-label="simple table" className='table-color'>
                                                <TableHead className='border-color'>
                                                    <TableRow>
                                                        <TableCell className="textClr" sx={{ fontWeight: "bolder !important" }}>
                                                            Trading Pair
                                                        </TableCell>
                                                        <TableCell className="textClr" sx={{ fontWeight: "bolder !important" }} align="center">
                                                            Order time
                                                        </TableCell>
                                                        <TableCell className="textClr" sx={{ fontWeight: "bolder !important" }} align="center">
                                                            Direction
                                                        </TableCell>
                                                        <TableCell className="textClr" sx={{ fontWeight: "bolder !important" }} align="center">
                                                            Type
                                                        </TableCell>
                                                        <TableCell className="textClr" sx={{ fontWeight: "bolder !important" }} align="center">
                                                            Price
                                                        </TableCell>
                                                        <TableCell className="textClr" sx={{ fontWeight: "bolder !important" }} align="center">
                                                            Quantity
                                                        </TableCell>
                                                        <TableCell className="textClr" sx={{ fontWeight: "bolder !important" }} align="center">
                                                            Amount
                                                        </TableCell>
                                                        <TableCell className="textClr" sx={{ fontWeight: "bolder !important" }} align="center">
                                                            Filled Quantity
                                                        </TableCell>
                                                        <TableCell className="textClr" sx={{ fontWeight: "bolder !important" }} align="center">
                                                            Average Filled Price
                                                        </TableCell>
                                                        <TableCell className="textClr" sx={{ fontWeight: "bolder !important" }} align="center">
                                                            Action
                                                        </TableCell>
                                                    </TableRow>
                                                </TableHead>
                                                <TableBody>
                                                    <TableRow sx={{ "&:last-child td, &:last-child th": { border: 0 } }}>
                                                        <TableCell align="center" colSpan={10} sx={{ justifyContent: "center", alignItems: "center" }}>
                                                            <img className='my-4' src={NODATA} />
                                                        </TableCell>
                                                    </TableRow>
                                                </TableBody>
                                            </Table>
                                        </TableContainer>
                                    </Box>
                                </TabPanel>
                                {/* Order History Table End */}
                                {/* Transaction History Table */}
                                <TabPanel value="3">
                                    <div className="container my-2 d-block d-lg-flex justify-content-between">
                                        <div className="d-block d-md-flex col-lg-6 mb-3 mb-sm-0">
                                            <div className="col-lg-5 d-block d-sm-flex ms-0">
                                                <Typography className='my-1 ms-2 me-2 trending'>Trading Pair:</Typography>
                                                <div className="col-lg-6 ms-0  mb-2 mb-sm-0">
                                                    <select id="form-select" className="form-select" aria-label="Default select example">
                                                        <option value="1" className="textClr">
                                                            All
                                                        </option>
                                                    </select>
                                                </div>
                                            </div>
                                            <div className="col-lg-5 d-block d-sm-flex ms-0">
                                                <Typography className='my-1 ms-2 me-2 trending'>Direction:</Typography>
                                                <div className="col-lg-6 ms-0  mb-2 mb-sm-0">
                                                    <select id="form-select" className="form-select" aria-label="Default select example">
                                                        <option value="1" className="textClr">
                                                            All
                                                        </option>
                                                    </select>
                                                </div>
                                            </div>
                                        </div>
                                        <div className="d-grid d-lg-flex">
                                            <button className="btn btn-sm  ms-0 ms-lg-2 mt-2 mt-lg-0" style={{ color: "white", background: '#1a94ae' }}
                                            >
                                                <CachedIcon fontSize={'small'} /> Refresh
                                            </button>
                                        </div>
                                    </div>
                                    <Box sx={{ width: "100%", typography: "body1", mt: 3 }}>
                                        <TableContainer className='paper-bg' sx={{ background: 'var(--card-bg-color)' }} component={Paper}>
                                            <Table sx={{ minWidth: 650 }} aria-label="simple table" className='table-color'>
                                                <TableHead className='border-color'>
                                                    <TableRow>
                                                        <TableCell className="textClr" sx={{ fontWeight: "bolder !important" }}>
                                                            Trading Pair
                                                        </TableCell>
                                                        <TableCell className="textClr" sx={{ fontWeight: "bolder !important" }} align="center">
                                                            Order time
                                                        </TableCell>
                                                        <TableCell className="textClr" sx={{ fontWeight: "bolder !important" }} align="center">
                                                            Direction
                                                        </TableCell>
                                                        <TableCell className="textClr" sx={{ fontWeight: "bolder !important" }} align="center">
                                                            Average Filled Price
                                                        </TableCell>
                                                        <TableCell className="textClr" sx={{ fontWeight: "bolder !important" }} align="center">
                                                            Filled Quantity
                                                        </TableCell>
                                                        <TableCell className="textClr" sx={{ fontWeight: "bolder !important" }} align="center">
                                                            Filled Amount
                                                        </TableCell>
                                                        <TableCell className="textClr" sx={{ fontWeight: "bolder !important" }} align="center">
                                                            Fee
                                                        </TableCell>
                                                    </TableRow>
                                                </TableHead>
                                                <TableBody>
                                                    <TableRow sx={{ "&:last-child td, &:last-child th": { border: 0 } }}>
                                                        <TableCell align="center" colSpan={10} sx={{ justifyContent: "center", alignItems: "center" }}>
                                                            <img className='my-4' src={NODATA} />
                                                        </TableCell>
                                                    </TableRow>
                                                </TableBody>
                                            </Table>
                                        </TableContainer>
                                    </Box>
                                </TabPanel>
                                {/*Transaction History Table End */}
                                {/* Stop Limit Table */}
                                <TabPanel value="4">
                                    <div className="container my-2 d-block d-lg-flex justify-content-between">
                                        <div className="d-block d-md-flex col-lg-6 mb-3 mb-sm-0">
                                            <div className="col-lg-5 d-block d-sm-flex ms-0">
                                                <Typography className='my-1 ms-2 me-2 trending'>Trading Pair:</Typography>
                                                <div className="col-lg-6 ms-0  mb-2 mb-sm-0">
                                                    <select id="form-select" className="form-select" aria-label="Default select example">
                                                        <option value="1" className="textClr">
                                                            All
                                                        </option>
                                                    </select>
                                                </div>
                                            </div>
                                        </div>
                                        <div className="d-grid d-lg-flex">
                                            <button className="btn btn-sm  ms-0 ms-lg-2 mt-2 mt-lg-0" style={{ color: "white", background: '#1a94ae' }}
                                            >
                                                <CachedIcon fontSize={'small'} /> Refresh
                                            </button>
                                        </div>
                                    </div>
                                    <Box sx={{ width: "100%", typography: "body1", mt: 3 }}>
                                        <TableContainer className='paper-bg' sx={{ background: 'var(--card-bg-color)' }} component={Paper}>
                                            <Table sx={{ minWidth: 650 }} aria-label="simple table" className='table-color'>
                                                <TableHead className='border-color'>
                                                    <TableRow>
                                                        <TableCell className="textClr" sx={{ fontWeight: "bolder !important" }}>
                                                            Trading Pair
                                                        </TableCell>
                                                        <TableCell className="textClr" sx={{ fontWeight: "bolder !important" }} align="center">
                                                            Order time
                                                        </TableCell>
                                                        <TableCell className="textClr" sx={{ fontWeight: "bolder !important" }} align="center">
                                                            Direction
                                                        </TableCell>
                                                        <TableCell className="textClr" sx={{ fontWeight: "bolder !important" }} align="center">
                                                            Trigger Price
                                                        </TableCell>
                                                        <TableCell className="textClr" sx={{ fontWeight: "bolder !important" }} align="center">
                                                            Executed Price
                                                        </TableCell>
                                                        <TableCell className="textClr" sx={{ fontWeight: "bolder !important" }} align="center">
                                                            Quantity
                                                        </TableCell>
                                                        <TableCell className="textClr" sx={{ fontWeight: "bolder !important" }} align="center">
                                                            Amount
                                                        </TableCell>
                                                        <TableCell className="textClr" sx={{ fontWeight: "bolder !important" }} align="center">
                                                            Status
                                                        </TableCell>
                                                        <TableCell className="textClr" sx={{ fontWeight: "bolder !important" }} align="center">
                                                            Action
                                                        </TableCell>
                                                    </TableRow>
                                                </TableHead>
                                                <TableBody>
                                                    <TableRow sx={{ "&:last-child td, &:last-child th": { border: 0 } }}>
                                                        <TableCell align="center" colSpan={10} sx={{ justifyContent: "center", alignItems: "center" }}>
                                                            <img className='my-4' src={NODATA} />
                                                        </TableCell>
                                                    </TableRow>
                                                </TableBody>
                                            </Table>
                                        </TableContainer>
                                    </Box>
                                </TabPanel>
                                {/*Stop Limit Table End */}
                                {/*Loan-History Table */}
                                <TabPanel value="5">
                                    <div className="container my-2 d-block d-lg-flex justify-content-between">
                                        <div className="d-block d-md-flex col-lg-6 mb-3 mb-sm-0">

                                        </div>
                                        <div className="d-grid d-lg-flex">
                                            <button className="btn btn-sm  ms-0 ms-lg-2 mt-2 mt-lg-0" style={{ color: "white", background: '#1a94ae' }}
                                            >
                                                <CachedIcon fontSize={'small'} /> Refresh
                                            </button>
                                        </div>
                                    </div>
                                    <Box sx={{ width: "100%", typography: "body1", mt: 3 }}>
                                        <TableContainer className='paper-bg' sx={{ background: 'var(--card-bg-color)' }} component={Paper}>
                                            <Table sx={{ minWidth: 650 }} aria-label="simple table" className='table-color'>
                                                <TableHead className='border-color'>
                                                    <TableRow>
                                                        <TableCell className="textClr" sx={{ fontWeight: "bolder !important" }}>
                                                            Order ID
                                                        </TableCell>
                                                        <TableCell className="textClr" sx={{ fontWeight: "bolder !important" }} align="center">
                                                            Trading Pair
                                                        </TableCell>
                                                        <TableCell className="textClr" sx={{ fontWeight: "bolder !important" }} align="center">
                                                            Loan Time
                                                        </TableCell>
                                                        <TableCell className="textClr" sx={{ fontWeight: "bolder !important" }} align="center">
                                                            Crypto
                                                        </TableCell>
                                                        <TableCell className="textClr" sx={{ fontWeight: "bolder !important" }} align="center">
                                                            Loan Amount
                                                        </TableCell>
                                                        <TableCell className="textClr" sx={{ fontWeight: "bolder !important" }} align="center">
                                                            Unpaid Amount
                                                        </TableCell>
                                                        <TableCell className="textClr" sx={{ fontWeight: "bolder !important" }} align="center">
                                                            Exercise Rate
                                                        </TableCell>
                                                        <TableCell className="textClr" sx={{ fontWeight: "bolder !important" }} align="center">
                                                            Unpaid Interest
                                                        </TableCell>
                                                        <TableCell className="textClr" sx={{ fontWeight: "bolder !important" }} align="center">
                                                            Status
                                                        </TableCell>
                                                        <TableCell className="textClr" sx={{ fontWeight: "bolder !important" }} align="center">
                                                            Action
                                                        </TableCell>
                                                    </TableRow>
                                                </TableHead>
                                                <TableBody>
                                                    <TableRow sx={{ "&:last-child td, &:last-child th": { border: 0 } }}>
                                                        <TableCell align="center" colSpan={10} sx={{ justifyContent: "center", alignItems: "center" }}>
                                                            <img className='my-4' src={NODATA} />
                                                        </TableCell>
                                                    </TableRow>
                                                </TableBody>
                                            </Table>
                                        </TableContainer>
                                    </Box>
                                </TabPanel>
                                {/*Loan-HistoryTable End */}
                                {/* Repayment History Table  */}
                                <TabPanel value="6">
                                    <div className="container my-2 d-block d-lg-flex justify-content-between">
                                        <div className="d-block d-md-flex col-lg-6 mb-3 mb-sm-0">

                                        </div>
                                        <div className="d-grid d-lg-flex">
                                            <button className="btn btn-sm  ms-0 ms-lg-2 mt-2 mt-lg-0" style={{ color: "white", background: '#1a94ae' }}
                                            >
                                                <CachedIcon fontSize={'small'} /> Refresh
                                            </button>
                                        </div>
                                    </div>
                                    <Box sx={{ width: "100%", typography: "body1", mt: 3 }}>
                                        <TableContainer className='paper-bg' sx={{ background: 'var(--card-bg-color)' }} component={Paper}>
                                            <Table sx={{ minWidth: 650 }} aria-label="simple table" className='table-color'>
                                                <TableHead className='border-color'>
                                                    <TableRow>
                                                        <TableCell className="textClr" sx={{ fontWeight: "bolder !important" }}>
                                                            Order ID
                                                        </TableCell>
                                                        <TableCell className="textClr" sx={{ fontWeight: "bolder !important" }} align="center">
                                                            Trading Pair
                                                        </TableCell>
                                                        <TableCell className="textClr" sx={{ fontWeight: "bolder !important" }} align="center">
                                                        Repayment Time
                                                        </TableCell>
                                                        <TableCell className="textClr" sx={{ fontWeight: "bolder !important" }} align="center">
                                                            Crypto
                                                        </TableCell>
                                                        <TableCell className="textClr" sx={{ fontWeight: "bolder !important" }} align="center">
                                                            Loan Amount
                                                        </TableCell>
                                                        <TableCell className="textClr" sx={{ fontWeight: "bolder !important" }} align="center">
                                                        Repaid Amount
                                                        </TableCell>
                                                        <TableCell className="textClr" sx={{ fontWeight: "bolder !important" }} align="center">
                                                        Repaid Interest
                                                        </TableCell>
                                                    </TableRow>
                                                </TableHead>
                                                <TableBody>
                                                    <TableRow sx={{ "&:last-child td, &:last-child th": { border: 0 } }}>
                                                        <TableCell align="center" colSpan={10} sx={{ justifyContent: "center", alignItems: "center" }}>
                                                            <img className='my-4' src={NODATA} />
                                                        </TableCell>
                                                    </TableRow>
                                                </TableBody>
                                            </Table>
                                        </TableContainer>
                                    </Box>
                                </TabPanel>
                                {/*Repayment History End */}
                            </TabContext>

                        </Box>
                    </CardContent>
                </Card>
            </Grid>
        </>
    )
}
export default MarginTable;
