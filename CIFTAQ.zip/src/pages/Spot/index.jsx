import React, { useState } from "react";
import { Box, Container } from "@mui/system";
import Tab from "@mui/material/Tab";
import { TabPanel, TabList, TabContext } from "@mui/lab";
import { makeStyles } from "@mui/styles";
import { Tabs } from "@mui/material";
import TableSpot from './spotTable';
import MarginTable from "./Margin/marginTable";
import IndexTab from "../Spot/Index/index";
const useStyles = makeStyles({
  MUITab: {
    color: "white !important",
  },
});
export default function Spot() {
  const [value, setValue] = React.useState("1");
  const handleChange = (event, newValue) => {
    setValue(newValue);
  };
  const classes = useStyles();
  return (
    <>
      <Container sx={{ mt: 7 }}>
        <TabContext value={value}>
          <Container
          >
            <Tabs value={value} onChange={handleChange} variant="scrollable" scrollButtons="auto" aria-label="scrollable auto tabs example">
              <Tab className={classes.MUITab} label="Spot" value="1" />
              <Tab className={classes.MUITab} label="Margin" value="2" />
              <Tab className={classes.MUITab} label="Index" value="3" />
            </Tabs>
          </Container>
          <TabPanel value="1">
            <TableSpot />
          </TabPanel>
          <TabPanel value="2">
            <MarginTable />
          </TabPanel>
          <TabPanel value="3">
            <IndexTab />
          </TabPanel>
        </TabContext>
      </Container>
    </>
  )
}
