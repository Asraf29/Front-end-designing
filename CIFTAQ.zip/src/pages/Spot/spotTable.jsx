import React, { useState } from 'react'
import NODATA from "../../components/assets/images/nodata.png";
import TableBody from "@mui/material/TableBody";
import TableCell from "@mui/material/TableCell";
import TableContainer from "@mui/material/TableContainer";
import TableHead from "@mui/material/TableHead";
import { makeStyles } from "@mui/styles";
import TableRow from "@mui/material/TableRow";
import Paper from "@mui/material/Paper";
import { Card, CardContent, Grid, Table, Typography } from '@mui/material';
import Box from '@mui/material/Box';
import Tab from '@mui/material/Tab';
import TabContext from '@mui/lab/TabContext';
import CachedIcon from '@mui/icons-material/Cached';
import TabList from '@mui/lab/TabList';
import './index.css';
import ExitToAppIcon from '@mui/icons-material/ExitToApp';
import TabPanel from '@mui/lab/TabPanel';
import OrderHistory from './orderHistory';
import CurrentOrder from './currentOrder';
import StopLimit from './stopLimit';

//////THIS TABLE IS USED IN TRANSACTION HISTORY PAGE/////


const useStyles = makeStyles({
    MUITab: {
      fontSize: "16px !important",
      color:'var(--txt-placeholder) !important'
    },
  });

  
export default function TableSpot() {
    const [value, setValue] = React.useState('10001');
    const [type, setType] = useState("text");
    const handleChange = (event, newValue) => {
      setValue(newValue);
    };
    const classes = useStyles();
  return (
    <>
     <Grid item xs={12} lg={12} md={12}>
            <Card
              sx={{
                minWidth: 100,
                background: "var(--card-bg-color)",
              }}
            >
              <CardContent>
              <TabContext value={value}>
              <Box>
      
        <Box>
          <TabList variant='scrollable' onChange={handleChange} aria-label="lab API tabs example">
            <Tab  className={classes.MUITab}  label="Current Order" value="10001" />
            <Tab  className={classes.MUITab} label="Order History" value="10002" />
            <Tab  className={classes.MUITab} label="Transcation History" value="10003" />
            <Tab  className={classes.MUITab} label="Stop-Limit" value="10004" />
          </TabList>
        </Box>
<TabPanel value="10001" sx={{padding:1}}>
  <CurrentOrder/>
</TabPanel>
<TabPanel value="10002" sx={{padding:1}}>
<OrderHistory/>
     </TabPanel>
      <TabPanel value="10003" sx={{padding:1}}>
        <div className="container my-2 d-block d-lg-flex justify-content-between">
    <div className="d-block d-md-flex col-lg-6 mb-3 mb-sm-0">
      <div className="col-lg-5 d-block d-sm-flex ms-0">
      <Typography className='my-1 me-2 trending'>Trading Pair:</Typography>
       <div className="col-lg-6 ms-0  mb-2 mb-sm-0">
          <select
            id="form-select"
            className="form-select"
            aria-label="Default select example"
          >
            <option value="1" className="textClr">
              {" "}
              All{" "}
            </option>
          </select>
        </div>
      </div>
      <div className="col-lg-5 d-block d-sm-flex ms-0">
      <Typography className='my-1 ms-2 me-2 trending'>Direction:</Typography>
       <div className="col-lg-6 ms-0  mb-2 mb-sm-0">
          <select
            id="form-select"
            className="form-select"
            aria-label="Default select example"
          >
            <option value="1" className="textClr">
              {" "}
              All{" "}
            </option>
          </select>
        </div>
      </div>
      <div className="col-lg-3 col-sm-12 col-md-3 mb-2 mb-sm-0 ms-0 ms-md-3 ms-lg-3">
        <input
          style={{ height: "40px" }}
          className="input-sizes placeholder-start inputBg sizes-in"
          placeholder="Start date ~ End date"
          type={type}
          onFocus={() => setType("date")}
          onBlur={() => setType("text")}
          id="date"
        />
      </div>
    </div>
    <div className="d-lg-flex my-2 my-lg-0">
      <button
        className="btn btn-sm my-lg-0  me-0 me-lg-2 mb-2 mb-lg-0"
        style={{ border: "2px solid #1a94ae", color: "#1A94AE" }}
      >
       <ExitToAppIcon fontSize={'small'}/> Export historical transcations
      </button>
      <button
        className="btn btn-sm  ms-0 ms-lg-2"
        style={{ color: "white", background:'#1a94ae' }}
      >
       <CachedIcon fontSize={'small'}/> Refresh
      </button>
    </div>
  </div>
  <Box sx={{ width: "100%", typography: "body1", mt:3 }}>
                <TableContainer sx={{background:'var(--card-bg-color)', boxShadow:'none !important'}} component={Paper}>

        <Table sx={{ minWidth: 650 }} aria-label="simple table">
          <TableHead className='border-color'>
<div>

</div>
            <TableRow>
         <TableCell
                sx={{
                  fontWeight: "bolder !important",
                  color: "var(--txt-placeholder)",
                }}
              >
                Trading Pair{" "}
              </TableCell>
              <TableCell
                sx={{
                  fontWeight: "bolder !important",
                  color: "var(--txt-placeholder)",
                }}
                align="left"
              > Filled time
              </TableCell>
              <TableCell
                sx={{
                  fontWeight: "bolder !important",
                  color: "var(--txt-placeholder)",
                }}
                align="left"
              >
                   Direction
              </TableCell>
              <TableCell
                sx={{
                  fontWeight: "bolder !important",
                  color: "var(--txt-placeholder)",
                }}
                align="left"
              >Average Filled Price
              </TableCell>
              <TableCell
                sx={{
                  fontWeight: "bolder !important",
                  color: "var(--txt-placeholder)",
                }}
                align="left"
              >Filled Quantity
              </TableCell>
              <TableCell
                sx={{
                  fontWeight: "bolder !important",
                  color: "var(--txt-placeholder)",
                }}
                align="left"
              >Filled Amount
              </TableCell>
              <TableCell
                sx={{
                  fontWeight: "bolder !important",
                  color: "var(--txt-placeholder)",
                }}
                align="left"
              >Fee
              </TableCell>
            </TableRow>
          </TableHead>
          <TableBody>
                <TableRow
                  sx={{ "&:last-child td, &:last-child th": { border: 0 } }}
                >
                <TableCell
                  align="center"
                  colSpan={7}
                  sx={{ justifyContent: "center", alignItems: "center" }}
                > <img src={NODATA} /> </TableCell>
              </TableRow>
          </TableBody>
        </Table>
      </TableContainer>
                </Box>
        </TabPanel>
<TabPanel value="10004" sx={{padding:1}}>
  <StopLimit/>
</TabPanel>
    </Box>
           
                
                </TabContext>
              </CardContent>
            </Card>
          </Grid>


    </>
  )
}
