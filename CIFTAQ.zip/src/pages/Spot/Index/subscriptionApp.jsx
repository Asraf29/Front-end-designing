import React from "react";
import NODATA from "../../../components/assets/images/nodata.png";
import TableBody from "@mui/material/TableBody";
import TableCell from "@mui/material/TableCell";
import TableContainer from "@mui/material/TableContainer";
import TableHead from "@mui/material/TableHead";
import TableRow from "@mui/material/TableRow";
import Paper from "@mui/material/Paper";
import {Table, Typography } from "@mui/material";
import Box from "@mui/material/Box";
import CachedIcon from "@mui/icons-material/Cached";


export default function SubscriptionApplication() {
  return (
    <>
      <div className="container my-2 d-block d-lg-flex justify-content-between">
        <div className="d-block d-md-flex col-lg-6 mb-3 mb-sm-0">
          <div className="col-lg-5 d-block d-sm-flex ms-0">
            <Typography className="my-1 me-2 trending">
              Index name:
            </Typography>
            <div className="col-lg-6 ms-0  mb-2 mb-sm-0">
              <select
                id="form-select"
                className="form-select"
                aria-label="Default select example"
              >
                <option value="1" className="textClr">
                  {" "}
                  All{" "}
                </option>
              </select>
            </div>
          </div>
          <div className="col-lg-5 d-block d-sm-flex ms-0">
            <Typography className="my-1 me-1 trending">
            Order Status:
            </Typography>
            <div className="col-lg-6 ms-0  mb-2 mb-sm-0">
              <select
                id="form-select"
                className="form-select"
                aria-label="Default select example"
              >
                <option value="1" className="textClr">
                  {" "}
                  All{" "}
                </option>
              </select>
            </div>
          </div>
        </div>
        <div>
          <button
            className="btn btn-sm  ms-0 ms-lg-2"
            style={{ color: "white", background: "#1a94ae" }}
          >
            <CachedIcon fontSize={"small"} /> Refresh
          </button>
        </div>
      </div>
      <Box sx={{ width: "100%", typography: "body1", mt: 3 }}>
        <TableContainer
          sx={{
            background: "var(--card-bg-color)",
            boxShadow: "none !important",
          }}
          component={Paper}
        >
          <Table sx={{ minWidth: 650 }} aria-label="simple table">
            <TableHead className="border-color">
              <div></div>
              <TableRow>
                <TableCell
                  sx={{
                    fontWeight: "bolder !important",
                    color: "var(--txt-placeholder)",
                  }}
                >
            Index Name
                </TableCell>
                <TableCell
                  sx={{
                    fontWeight: "bolder !important",
                    color: "var(--txt-placeholder)",
                  }}
                  align="left"
                >
                  {" "}
                 Time
                </TableCell>
                <TableCell
                  sx={{
                    fontWeight: "bolder !important",
                    color: "var(--txt-placeholder)",
                  }}
                  align="left"
                >
                  <div className="d-flex me-2">
                 Unit Price{" "}
                  {
                    <div className="my-1">
                      <i
                        className="bi bi-caret-up d-block ms-2"
                        style={{ fontSize: "9px" }}
                      ></i>{" "}
                      <i
                        className="bi bi-caret-down ms-2"
                        style={{ fontSize: "9px" }}
                      ></i>{" "}
                    </div>
                  }{" "}
                </div>
                </TableCell>
                <TableCell
                  sx={{
                    fontWeight: "bolder !important",
                    color: "var(--txt-placeholder)",
                  }}
                  align="left"
                >
                 <div className="d-flex me-2">
                Quantity
                  {
                    <div className="my-1">
                      <i
                        className="bi bi-caret-up d-block ms-2"
                        style={{ fontSize: "9px" }}
                      ></i>{" "}
                      <i
                        className="bi bi-caret-down ms-2"
                        style={{ fontSize: "9px" }}
                      ></i>{" "}
                    </div>
                  }{" "}
                </div>
                </TableCell>
                <TableCell
                  sx={{
                    fontWeight: "bolder !important",
                    color: "var(--txt-placeholder)",
                  }}
                  align="left"
                >
                 <div className="d-flex me-2">
                Transaction Fee
                  {
                    <div className="my-1">
                      <i
                        className="bi bi-caret-up d-block ms-2"
                        style={{ fontSize: "9px" }}
                      ></i>{" "}
                      <i
                        className="bi bi-caret-down ms-2"
                        style={{ fontSize: "9px" }}
                      ></i>{" "}
                    </div>
                  }{" "}
                </div>
                </TableCell>
                <TableCell
                  sx={{
                    fontWeight: "bolder !important",
                    color: "var(--txt-placeholder)",
                  }}
                  align="left"
                >
                   <div className="d-flex me-2">
                   Net Transcation Value
                  {
                    <div className="my-1">
                      <i
                        className="bi bi-caret-up d-block ms-2"
                        style={{ fontSize: "9px" }}
                      ></i>{" "}
                      <i
                        className="bi bi-caret-down ms-2"
                        style={{ fontSize: "9px" }}
                      ></i>{" "}
                    </div>
                  }{" "}
                </div>
                </TableCell>
                <TableCell
                  sx={{
                    fontWeight: "bolder !important",
                    color: "var(--txt-placeholder)",
                  }}
                  align="left"
                >
                 Status
                </TableCell>
                <TableCell
                  sx={{
                    fontWeight: "bolder !important",
                    color: "var(--txt-placeholder)",
                  }}
                  align="left"
                >Action
                </TableCell>
              </TableRow>
            </TableHead>
            <TableBody>
              <TableRow
                sx={{ "&:last-child td, &:last-child th": { border: 0 } }}
              >
                <TableCell
                  align="center"
                  colSpan={8}
                  sx={{ justifyContent: "center", alignItems: "center" }}
                >
                  {" "}
                  <img src={NODATA} />{" "}
                </TableCell>
              </TableRow>
            </TableBody>
          </Table>
        </TableContainer>
      </Box>
    </>
  );
}
