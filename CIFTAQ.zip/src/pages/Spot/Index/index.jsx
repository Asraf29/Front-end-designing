import React, { useState } from "react";
import NODATA from "../../../components/assets/images/nodata.png";
import TableBody from "@mui/material/TableBody";
import TableCell from "@mui/material/TableCell";
import TableContainer from "@mui/material/TableContainer";
import TableHead from "@mui/material/TableHead";
import { makeStyles } from "@mui/styles";
import TableRow from "@mui/material/TableRow";
import Paper from "@mui/material/Paper";
import { Card, CardContent, Grid, Table, Typography } from "@mui/material";
import Box from "@mui/material/Box";
import TabContext from '@mui/lab/TabContext';
import CachedIcon from '@mui/icons-material/Cached';
import TabList from '@mui/lab/TabList';
import ExitToAppIcon from '@mui/icons-material/ExitToApp';
import TabPanel from '@mui/lab/TabPanel';
import Tab from '@mui/material/Tab';
import SubscriptionApplication from "./subscriptionApp";
const useStyles = makeStyles({
    MUITab: {
      fontSize: "16px !important",
      color:'var(--txt-placeholder) !important'
    },
  });
export default function IndexTab() {
    const [value, setValue] = React.useState('10001');
    const [type, setType] = useState("text");
    const handleChange = (event, newValue) => {
      setValue(newValue);
    };
    const classes = useStyles();
  return (
    <>
    <Grid item xs={12} lg={12} md={12}>
           <Card
             sx={{
               minWidth: 100,
               background: "var(--card-bg-color)",
             }}
           >
             <CardContent>
             <TabContext value={value}>
             <Box>
     
       <Box>
         <TabList variant='scrollable' onChange={handleChange} aria-label="lab API tabs example">
           <Tab  className={classes.MUITab}  label="Subscription Application" value="10001" />
           <Tab  className={classes.MUITab} label="Redemption Application" value="10002" />
         </TabList>
       </Box>
<TabPanel value="10001" sx={{padding:1}}>
<SubscriptionApplication/>
</TabPanel>
<TabPanel value="10002" sx={{padding:1}}>
<SubscriptionApplication/>
    </TabPanel>
   </Box>
          
               
               </TabContext>
             </CardContent>
           </Card>
         </Grid>


   </>
  );
}
