import * as React from "react";
import Box from "@mui/material/Box";
import Card from "@mui/material/Card";
import CardActions from "@mui/material/CardActions";
import CardContent from "@mui/material/CardContent";
import Tab from "@mui/material/Tab";
import { Link } from "react-router-dom";
import "./index.css";

import { TabPanel, TabList, TabContext } from "@mui/lab";
import { Button, Grid, makeStyles, Tabs, Typography } from "@mui/material";
import { Container } from "@mui/system";
export default function Login() {
  const [value, setValue] = React.useState("1");
  const handleChange = (event, newValue) => {
    setValue(newValue);
  };
  const [passwordShowned, setPasswordShowned] = React.useState(false);
  const togglePasswords = () => {
    setPasswordShowned(!passwordShowned);
  };
  return (
    <div className="cardHeight">
      <Container>
        <div className="center">
          <Typography
            varient="h4"
            textAlign={"center"}
            sx={{ fontWeight: 700, color: "white", fontSize: 30 }}
          >
            Login to MEXC
          </Typography>
          <Card
            className="logincard"
            sx={{ minWidth: 80, maxWidth: "500", marginTop: 1 }}
          >
            <CardContent className="loginCardContent">
              <TabContext value={value}>
                <Box sx={{ borderBottom: 1, borderColor: "divider" }}>
                  <TabList
                    centered
                    onChange={handleChange}
                    aria-label="lab API tabs example"
                  >
                    <Tab label="Mobile" value="1" />

                    <Tab label="Email" value="2" />
                  </TabList>
                </Box>
                <TabPanel value="1">
                  <div>
                    <label
                      htmlFor="exampleInputEmail1"
                      className="form-label labed-size"
                    >
                      Phone
                    </label>
                    <div className="mb-2 d-flex">
                      <select
                        className="form-select form-select-sm login-form-select form-border"
                        style={{
                          width: "8rem",
                          borderTopRightRadius: 0,
                          borderBottomRightRadius: 0,
                        }}
                        aria-label="Default select example"
                      >
                        <option value="1"> 🏴‍☠️ +95 </option>
                        <option value="2"> 🏳️‍🌈 +93</option>
                        <option value="3"> 🏳️‍🌈+96</option>
                      </select>

                      <input
                        type="number"
                        className="form-control login-form-control form-border"
                        style={{
                          borderTopLeftRadius: 0,
                          borderBottomLeftRadius: 0,
                        }}
                        aria-label="Text input with dropdown button"
                      />
                    </div>
                  </div>
                  <div className="mb-3 form-group">
                    <label
                      htmlFor="exampleInputEmail1"
                      className="form-label labed-size"
                    >
                      Password
                    </label>
                    <div>
                      <input
                        type={passwordShowned ? "text" : "password"}
                        className="form-control login-form-control"
                      />
                      <span className="field-icon pe-2">
                        {passwordShowned ? (
                          <i
                            onClick={togglePasswords}
                            className="bi bi-eye eyeIcon"
                          />
                        ) : (
                          <i
                            onClick={togglePasswords}
                            className="bi bi-eye-slash eyeIcon"
                          />
                        )}
                      </span>
                    </div>
                  </div>
                  <div className="d-grid gap-2">
                    <button
                      className="btn"
                      style={{
                        backgroundColor: "#1A94AE",
                        color: "white",
                        fontWeight: 700,
                      }}
                      type="button"
                    >
                      Login
                    </button>
                    <div
                      style={{
                        display: "flex",
                        justifyContent: "space-between",
                      }}
                    >
                      <Typography sx={{ fontWeight: 700, color: "#1A94AE" }}>
                        Forget Password
                      </Typography>
                      <Link style={{ textDecoration: "none" }} to="/register">
                        {" "}
                        <Typography sx={{ fontWeight: 700, color: "#1A94AE" }}>
                          Sign up
                        </Typography>{" "}
                      </Link>
                    </div>
                  </div>
                </TabPanel>
                <TabPanel value="2">
                  <>
                    <div>
                      <label
                        htmlFor="exampleInputEmail1"
                        className="form-label labed-size"
                      >
                        Email
                      </label>
                      <div className="mb-2 d-flex">
                        <input
                          type="email"
                          className="form-control form-border login-form-control"
                          aria-label="Text input with dropdown button"
                        />
                      </div>
                    </div>
                    <div className="mb-3 form-group">
                      <label
                        htmlFor="exampleInputEmail1"
                        className="form-label labed-size"
                      >
                        Password
                      </label>
                      <div>
                        <input
                          type={passwordShowned ? "text" : "password"}
                          className="form-control login-form-control"
                        />
                        <span className="field-icon pe-2">
                          {passwordShowned ? (
                            <i
                              onClick={togglePasswords}
                              className="bi bi-eye eyeIcon"
                            />
                          ) : (
                            <i
                              onClick={togglePasswords}
                              className="bi bi-eye-slash eyeIcon"
                            />
                          )}
                        </span>
                      </div>
                    </div>
                    <div className="d-grid gap-2">
                      <button
                        className="btn"
                        style={{
                          backgroundColor: "#1A94AE",
                          color: "white",
                          fontWeight: 700,
                        }}
                        type="button"
                      >
                        Login
                      </button>
                      <div
                        style={{
                          display: "flex",
                          justifyContent: "space-between",
                        }}
                      >
                        <Typography sx={{ fontWeight: 700, color: "#1A94AE" }}>
                          Forget Password
                        </Typography>
                        <Link style={{ textDecoration: "none" }} to="/register">
                          {" "}
                          <Typography
                            sx={{ fontWeight: 700, color: "#1A94AE" }}
                          >
                            Sign up
                          </Typography>{" "}
                        </Link>
                      </div>
                    </div>
                  </>
                </TabPanel>
              </TabContext>
              <Typography variant="h5" component="div"></Typography>
            </CardContent>
            <CardActions></CardActions>
          </Card>
        </div>
      </Container>
    </div>
  );
}
