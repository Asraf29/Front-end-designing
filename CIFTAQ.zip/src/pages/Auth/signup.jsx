import * as React from "react";
import Box from "@mui/material/Box";
import Card from "@mui/material/Card";
import CardActions from "@mui/material/CardActions";
import CardContent from "@mui/material/CardContent";
import Tab from "@mui/material/Tab";
import "./index.css";

import { TabPanel, TabList, TabContext } from "@mui/lab";
import { Button, Grid, makeStyles, Tabs, Typography } from "@mui/material";
import { Container } from "@mui/system";
export default function Login() {
  const [value, setValue] = React.useState("1");
  const handleChange = (event, newValue) => {
    setValue(newValue);
  };
  const [passwordShown, setPasswordShown] = React.useState(false);
  const togglePassword = () => {
    setPasswordShown(!passwordShown);
  };
  return (
    <div>
      <Container>
        <div className="my-5">
          <Typography
            varient="h4"
            className="cardTitle mb-4"
            sx={{ fontWeight: 700, color: "white", fontSize: 30 }}
          >
            Sign Up for MEXC
          </Typography>
          <Card className="logincard signupCard" sx={{ minWidth: 310, maxWidth: 500 }}>
            <CardContent>
              <TabContext value={value}>
                <Box sx={{ borderBottom: 1, borderColor: "divider" }}>
                  <TabList centered
                    onChange={handleChange} aria-label="lab API tabs example" >
                    <Tab label="Mobile" value="1" />
                    <Tab label="Email" value="2" />
                  </TabList>
                </Box>
                <TabPanel value="1">
                  <div>
                    <label
                      for="exampleInputEmail1"
                      className="form-label signupText"
                    >
                      Mobile Number
                    </label>
                    <div className="mb-2 d-flex">
                      <select
                        className="form-select login-form-select form-select-sm"
                        style={{ width: "8rem" }}
                        aria-label="Default select example"
                      >
                        <option value="1"> IN +91 </option>
                        <option value="2">+93</option>
                        <option value="3">+96</option>
                      </select>
                      <input
                        type="number"
                        className="form-control login-form-control mobilenoField"
                        aria-label="Text input with dropdown button"
                      />
                    </div>
                  </div>
                  <div className="form-group mb-3">
                    <label htmlFor="password" className="signupText">
                      Password
                    </label>
                    <div>
                      <input
                        type={passwordShown ? "text" : "password"}
                        className="form-control login-form-control"
                      />
                      <span className="field-icon pe-2">
                        {passwordShown ? (
                          <i
                            onClick={togglePassword}
                            className="bi bi-eye eyeIcon"
                          />
                        ) : (
                          <i
                            onClick={togglePassword}
                            className="bi bi-eye-slash eyeIcon"
                          />
                        )}
                      </span>
                    </div>
                  </div>
                  <div className="form-group mb-3">
                    <label htmlFor="password" className="signupText">
                      Confirm Password
                    </label>
                    <div>
                      <input
                        type={passwordShown ? "text" : "password"}
                        className="form-control login-form-control"
                      />
                      <span className="field-icon pe-2">
                        {passwordShown ? (
                          <i
                            onClick={togglePassword}
                            className="bi bi-eye eyeIcon"
                          />
                        ) : (
                          <i
                            onClick={togglePassword}
                            className="bi bi-eye-slash eyeIcon"
                          />
                        )}
                      </span>
                    </div>
                  </div>
                  <div className="form-group mb-3">
                    <label htmlFor="VerificationCode" className="signupText">
                      Verification code
                    </label>
                    <div className="d-flex">
                      <div className="w-75">
                        <input
                          type="number"
                          className="form-control login-form-control vericationNumber"
                        />
                      </div>
                      <button className="btn d-flex align-items-center getCodeBtn px-lg-3 ms-1" role="button">Get Code</button>
                    </div>
                  </div>
                  <div className="form-group mb-3">
                    <label htmlFor="ReferralCode" className="signupText">
                      Referral code
                    </label>
                    <div>
                      <input
                        type="number"
                        className="form-control login-form-control"
                      />
                    </div>
                  </div>
                  <div className="form-check pb-1">
                    <input
                      className="form-check-input"
                      type="checkbox"
                      value=""
                      id="flexCheckChecked"
                    />
                    <label className="agreeLabel" for="flexCheckChecked">
                      I have read and agree to the user Agreement and privacy
                      policy.
                    </label>
                  </div>
                  <div className="d-grid">
                    <button
                      className="btn"
                      style={{
                        backgroundColor: "#1A94AE",
                        color: "white",
                        fontWeight: 700,
                      }}
                      type="button"
                    >
                      Sign up
                    </button>
                  </div>
                </TabPanel>
                <TabPanel value="2">
                  <div className="form-group mb-3">
                    <label htmlFor="userName" className="signupText">
                      Email
                    </label>
                    <div>
                      <input
                        type="email"
                        className="form-control login-form-control"
                      />
                    </div>
                  </div>
                  <div className="form-group mb-3">
                    <label htmlFor="password" className="signupText">
                      Password
                    </label>
                    <div>
                      <input
                        type={passwordShown ? "text" : "password"}
                        className="form-control login-form-control"
                      />
                      <span className="field-icon pe-2">
                        {passwordShown ? (
                          <i
                            onClick={togglePassword}
                            className="bi bi-eye eyeIcon"
                          />
                        ) : (
                          <i
                            onClick={togglePassword}
                            className="bi bi-eye-slash eyeIcon"
                          />
                        )}
                      </span>
                    </div>
                  </div>
                  <div className="form-group mb-3">
                    <label htmlFor="password" className="signupText">
                      Confirm Password
                    </label>
                    <div>
                      <input
                        type={passwordShown ? "text" : "password"}
                        className="form-control login-form-control"
                      />
                      <span className="field-icon pe-2">
                        {passwordShown ? (
                          <i
                            onClick={togglePassword}
                            className="bi bi-eye eyeIcon"
                          />
                        ) : (
                          <i
                            onClick={togglePassword}
                            className="bi bi-eye-slash eyeIcon"
                          />
                        )}
                      </span>
                    </div>
                  </div>
                  <div className="form-group mb-3">
                    <label htmlFor="VerificationCode" className="signupText">
                      Verification code
                    </label>
                    <div className="d-flex">
                      <div className="w-75">
                        <input
                          type="number"
                          className="form-control login-form-control vericationNumber"
                        />
                      </div>
                      <button className="btn d-flex align-items-center getCodeBtn px-lg-3 ms-1" role="button">Get Code</button>
                    </div>
                  </div>
                  <div className="form-group mb-3">
                    <label htmlFor="ReferralCode" className="signupText">
                      Referral code
                    </label>
                    <div>
                      <input
                        type="number"
                        className="form-control login-form-control"
                      />
                    </div>
                  </div>
                  <div className="form-check pb-1" id="checkBox">
                    <input
                      className="form-check-input checkbox-bg"
                      type="checkbox"
                      value=""
                      id="flexCheckChecked"
                    />
                    <label className="agreeLabel" for="flexCheckChecked">
                      I have read and agree to the user Agreement and privacy
                      policy.
                    </label>
                  </div>
                  <div className="d-grid">
                    <button
                      className="btn"
                      style={{
                        backgroundColor: "#1A94AE",
                        color: "white",
                        fontWeight: 700,
                      }}
                      type="button"
                    >
                      Sign up
                    </button>
                  </div>
                </TabPanel>
              </TabContext>
            </CardContent>
          </Card>
        </div>
      </Container>
    </div>
  );
}
