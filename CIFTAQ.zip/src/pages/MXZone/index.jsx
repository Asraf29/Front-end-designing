import React, { useState } from 'react'
import Card from "@mui/material/Card";
import CardContent from "@mui/material/CardContent";
import { Box, Container } from "@mui/system";
import playButtonImage from "../../components/assets/images/playButtonImage.png"
import ChevronRightIcon from '@mui/icons-material/ChevronRight';
import NODATA from "../../components/assets/images/nodata.png";
import iconOne from '../../components/assets/images/icon1.png'
import iconTwo from '../../components/assets/images/icon2.png'
import iconThree from '../../components/assets/images/icon3.png'
import iconFour from '../../components/assets/images/icon4.png'
import iconFive from '../../components/assets/images/icon5.png'
import iconSix from '../../components/assets/images/icon6.png'
import './index.css'
import { Button, Grid, Typography } from '@mui/material';
import SnapshotModal from '../../components/SnapshotModal';
const data = ['1', '2', '3'];

const MXZone = () => {
    const [openSnapshotModal, setOpenSnapshotModal] = React.useState(false);
    const handleSnapshotClickOpen = () => {
        setOpenSnapshotModal(true);
    };

    const handleSnapshotModalClose = () => {
        setOpenSnapshotModal(false);
    };
    return (
        <div>
            <SnapshotModal openSnapshotModal={openSnapshotModal} handleSnapshotClickOpen={handleSnapshotClickOpen} handleSnapshotModalClose={handleSnapshotModalClose} />
            <Container sx={{ mb: 7 }}>
                <Container >
                    <Box className="mx-lg-5 mx-sm-3 d-md-flex justify-content-md-between align-items-center">
                        <div className='text-center mt-3 text-sm-start mt-sm-0'>
                            <Typography className='text-prop' variant="h3">MX Zone</Typography>
                            <Typography className="text-prop-sub my-2">MX is the only token of the CIFDAQ Exchange platform. The profits of trading<br />and ETF will 100% destroy MX. Currently, MX is used to realized operations<br />such as trading fee deductions, project voting and renewal, new lottery<br />bonuses, MX DeFi mining stakes, etc.</Typography>
                        </div>
                        <div>
                            <Box component="img" alt="topbar-bg" src={playButtonImage} className="playButtonBox_Size img-fluid" />
                        </div>
                    </Box>
                </Container>
                {/* MX Information Card */}
                <Card className="profile-page-card" sx={{ minWidth: "auto", maxWidth: "auto" }}>
                    <CardContent className="px-sm-4 my-3">
                        <Typography variant="h6" className="fw-bold font-color-title">MX information card</Typography>
                        <Box>
                            <Typography className="textClr py-2">MXToken (MX) is a decentralized digital asset developed by the CIFDAQ platform based on Ethereum, and MX is also the proof of the interests of CIFDAQ community. As the only platform in CIFDAQ Exchange ecological system, the MX token plays an important role in connecting communities, teams and partners.</Typography>
                            <Typography className="textClr">CIFDAQ is committed to enabling MX Token from the value aspect, including fee deduction, SpaceM innovation, M-Day special benefits, and project voting in the Assessment Zone, etc. CIFDAQ also started the "Growth Plan for Everything", by becoming the first cross-chain asset of BSC and HECO, and opening multiple operations such as on-chain lending, mining, and DEX trading, to improve MX token economy and increase MX usage scenarios.</Typography>
                        </Box>
                    </CardContent>
                </Card>
                {/* MX Token Card Grid*/}
                <Grid container className="mt-3" spacing={2}>
                    {/*MX Token Progress Section */}
                    <Grid item xs={12} sm={12} md={5} lg={5}>
                        <Card className="profile-page-card" sx={{ minWidth: "auto", maxWidth: "auto" }}>
                            <CardContent className="px-sm-4 my-3">
                                <Typography variant="h6" className="fw-bold font-color-title">MX Token</Typography>
                                <Typography className='text-blue'>Blockchain Explorer</Typography>
                                <Box className="my-4">
                                    <Box className="d-flex justify-content-between">
                                        <Typography className="font-color-title fs-small">Total MX destroyed last month</Typography>
                                        <Typography className="font-color-title fs-small">4549954.99</Typography>
                                    </Box>
                                    <div className="progress" id="progressCustomHeight">
                                        <div class="progress-bar w-25 bg-danger" role="progressbar"></div>
                                    </div>
                                </Box>
                                <Box className="mb-4">
                                    <Box className="d-flex justify-content-between">
                                        <Typography className="font-color-title fs-small">Total MX circulation</Typography>
                                        <Typography className="font-color-title fs-small">100000000</Typography>
                                    </Box>
                                    <div className="progress" id="progressCustomHeight">
                                        <div class="progress-bar w-50 bg-success" role="progressbar"></div>
                                    </div>
                                </Box>
                                <Box className="mb-3">
                                    <Box className="d-flex justify-content-between">
                                        <Typography className="font-color-title fs-small">Total MX issuance (before destruction)</Typography>
                                        <Typography className="font-color-title fs-small">1,000,000,000</Typography>
                                    </Box>
                                    <div className="progress" id="progressCustomHeight">
                                        <div class="progress-bar w-100 bg-custom-blue" role="progressbar"></div>
                                    </div>
                                </Box>
                            </CardContent>
                        </Card>
                    </Grid>
                    {/*MX position snapshot (UTC+8) */}
                    <Grid item xs={12} sm={12} md={7} lg={7}>
                        <Card className="profile-page-card" sx={{ minWidth: "auto", maxWidth: "auto" }}>
                            <CardContent className="px-sm-4 my-3">
                                <Box className="d-sm-flex justify-content-sm-between align-items-center">
                                    <Typography variant="h6" className="fw-bold font-color-title">MX position snapshot (UTC+8)</Typography>
                                    <Typography className='text-blue' role="button" onClick={()=>{handleSnapshotClickOpen()}}>Snapshot details <ChevronRightIcon className="mb-1" /></Typography>
                                </Box>
                                <Box className="text-center">
                                    <Box component="img" alt="emptyData" className="my-4 py-3" src={NODATA} />
                                </Box>
                            </CardContent>
                        </Card>
                    </Grid>
                </Grid>
                {/*MX scene application Card */}
                <Card className="profile-page-card mt-3" sx={{ minWidth: "auto", maxWidth: "auto" }}>
                    <CardContent className="px-sm-4">
                        <Typography variant="h6" className="fw-bold font-color-title py-4">MX scene application</Typography>
                        {/* First Three Pair Icons */}
                        <Grid container spacing={8} className="px-5">
                            <Grid item xs={12} sm={12} md={4} lg={4}>
                                <Card className="profile-page-card RewardCenter_card" sx={{ minWidth: "auto", maxWidth: "auto" }}>
                                    <CardContent>
                                        <Box className="my-3">
                                            <Box className="text-center py-4"><Box component="img" alt="icon1" src={iconOne} className="img-fluid" /></Box>
                                            <Typography className="fw-bold font-color-title text-center" >Trading fee deduction</Typography>
                                        </Box>
                                    </CardContent>
                                </Card>
                            </Grid>
                            <Grid item xs={12} sm={12} md={4} lg={4}>
                                <Card className="profile-page-card RewardCenter_card" sx={{ minWidth: "auto", maxWidth: "auto" }}>
                                    <CardContent>
                                        <Box className="my-3">
                                            <Box className="text-center py-4"><Box component="img" alt="icon1" src={iconTwo} className="img-fluid" /></Box>
                                            <Typography className="fw-bold font-color-title text-center" >New subscription of Launchpad</Typography>
                                        </Box>
                                    </CardContent>
                                </Card>
                            </Grid>
                            <Grid item xs={12} sm={12} md={4} lg={4}>
                                <Card className="profile-page-card RewardCenter_card" sx={{ minWidth: "auto", maxWidth: "auto" }}>
                                    <CardContent>
                                        <Box className="my-3">
                                            <Box className="text-center py-4"><Box component="img" alt="icon1" src={iconThree} className="img-fluid" /></Box>
                                            <Typography className="fw-bold font-color-title text-center" >M-Day event</Typography>
                                        </Box>
                                    </CardContent>
                                </Card>
                            </Grid>
                        </Grid>
                        {/* Second Three Pair Icons */}
                        <Grid container spacing={8} className="px-5 pt-5 pb-4">
                            <Grid item xs={12} sm={12} md={4} lg={4}>
                                <Card className="profile-page-card RewardCenter_card" sx={{ minWidth: "auto", maxWidth: "auto" }}>
                                    <CardContent>
                                        <Box className="my-3">
                                            <Box className="text-center py-4"><Box component="img" alt="icon1" src={iconFour} className="img-fluid" /></Box>
                                            <Typography className="fw-bold font-color-title text-center" >Referral Reward</Typography>
                                        </Box>
                                    </CardContent>
                                </Card>
                            </Grid>
                            <Grid item xs={12} sm={12} md={4} lg={4}>
                                <Card className="profile-page-card RewardCenter_card" sx={{ minWidth: "auto", maxWidth: "auto" }}>
                                    <CardContent>
                                        <Box className="my-3">
                                            <Box className="text-center py-4"><Box component="img" alt="icon1" src={iconFive} className="img-fluid" /></Box>
                                            <Typography className="fw-bold font-color-title text-center" >Ecological fund</Typography>
                                        </Box>
                                    </CardContent>
                                </Card>
                            </Grid>
                            <Grid item xs={12} sm={12} md={4} lg={4}>
                                <Card className="profile-page-card RewardCenter_card" sx={{ minWidth: "auto", maxWidth: "auto" }}>
                                    <CardContent>
                                        <Box className="my-3">
                                            <Box className="text-center py-4"><Box component="img" alt="icon1" src={iconSix} className="img-fluid" /></Box>
                                            <Typography className="fw-bold font-color-title text-center" >Offline consumption payment</Typography>
                                        </Box>
                                    </CardContent>
                                </Card>
                            </Grid>
                        </Grid>
                    </CardContent>
                </Card>
            </Container>
        </div>
    )
}
export default MXZone;