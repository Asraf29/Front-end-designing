import React, { useState } from "react";
import {
    Avatar,
    Box,
    Button,
} from "@mui/material";
import Card from "@mui/material/Card";
import CardContent from "@mui/material/CardContent";
import { Container } from "@mui/system";
import {
    Grid,
    Typography,
} from "@mui/material";
import Table from '@mui/material/Table';
import TableBody from '@mui/material/TableBody';
import TableCell from '@mui/material/TableCell';
import TableContainer from '@mui/material/TableContainer';
import TableHead from '@mui/material/TableHead';
import TableRow from '@mui/material/TableRow';
import Paper from '@mui/material/Paper';
import { Link } from "react-router-dom";
import banner from "../../components/assets/images/slotAuctionBg.png";
import "./index.css";
import Tab from '@mui/material/Tab';
import TabContext from '@mui/lab/TabContext';
import TabList from '@mui/lab/TabList';
import TabPanel from '@mui/lab/TabPanel';
import { makeStyles } from "@mui/styles";
import CTO from '../../components/assets/images/CTO.png'
const data = [0, 1, 2, 3, 4]

// Tab Switch;
const useStyles = makeStyles({
    MUITab: {
        color: "var(--Tab-gray-text) !important",
        fontSize: "16px !important",
        fontWeight: 'bold !important'
    },
});
const SlotAuction = () => {
    const [value, setValue] = React.useState('1');

    const handleChange = (event, newValue) => {
        setValue(newValue);
    };
    // Tab Switch;

    const classes = useStyles();
    return (
        <div>
            <Container sx={{ mb: 7 }}>

                <Box className="d-md-flex justify-content-md-between align-items-center">
                    <div className="text-center ms-4 col-md-6  mt-3 mt-sm-0 col-lg-6">
                        <Typography className="text-propty" variant="h3">
                            DOT {'&'} KSM Slot auction
                        </Typography>
                        <Typography className="text-propty-sub">
                            Vota and receive airdrops
                        </Typography>
                    </div>
                    <div className="col-lg-6 col-md-6 my-2">
                        <Box
                            component="img"
                            alt="topbar-bg"
                            src={banner}
                            className="img-fluid" />
                    </div>
                </Box>
                {/*Slot Cards*/}
                <TabContext value={value}>
                    <Card className="profile-page-card" sx={{ minWidth: "auto", maxWidth: "auto" }}>
                        <CardContent>
                            <Box>
                                <Box>
                                    <Box>
                                        <TabList variant="scrollable" onChange={handleChange} aria-label="lab API tabs example">
                                            <Tab label="Polkadot" value="1" className={classes.MUITab} />
                                            <Tab label="Kusama" value="2" className={classes.MUITab} />
                                        </TabList>
                                    </Box>
                                </Box>
                            </Box>
                        </CardContent>
                    </Card>
                    <TabPanel value="1">
                        <Box sx={{ mt: 2 }}>
                            <>
                                <Card className="profile-page-card mb-5" sx={{ minWidth: "auto", maxWidth: "auto" }}>
                                    <CardContent>

                                        <Box>
                                            <Box className="container">
                                                <Typography className="card-text mb-3" sx={{ fontWeight: 800, fontSize: 20 }}>Polkadot slot auction</Typography>
                                                <Typography className="card-text mb-3" sx={{ fontWeight: 800, fontSize: 15 }}>
                                                    DOT Slot Auction is a parachain auction for the Polkadot ecosystem. On CIFDAQ, you can use DOT to vote for a Polkadot parachain project you support. After voting you will be rewarded according to the project's official auction rules.
                                                </Typography>
                                                <Typography className="card-text" sx={{ fontWeight: 400, fontSize: 12 }}>
                                                    *Please refer to the announcement for auction rules and details
                                                </Typography>
                                            </Box>
                                        </Box>
                                    </CardContent>
                                </Card>
                                {/* -------------------- Second Card----------- */}
                                <Card
                                    className="profile-page-card"
                                    sx={{ minWidth: "auto", maxWidth: "auto" }}
                                >
                                    <CardContent>
                                        <Container className='my-2'>
                                            <Grid item xs={12} sm={12} md={12} lg={12}>
                                                <Box className="d-flex justify-content-between">
                                                    <div>
                                                        <Typography className="card-text fw-bold" sx={{ fontSize: 18 }}>Issue 7</Typography>
                                                    </div>
                                                    <div>
                                                        <Link to='/slotVote' className="linkTag"> <Typography className="card-text fw-bold" sx={{ color: '#1A94AE', fontSize: 18 }}>My Votes</Typography></Link>
                                                    </div>
                                                </Box>
                                                <Box>
                                                    <TableContainer component={Paper} className="profile-page-card">
                                                        <Table sx={{ minWidth: 650 }} className="profile-page-card" aria-label="simple table">
                                                            <TableHead>
                                                                <TableRow>
                                                                    <TableCell sx={{ borderBottom: 0 }} className="fw-bold greyTxt">Project</TableCell>
                                                                    <TableCell sx={{ borderBottom: 0 }} className="fw-bold greyTxt" align="right">Campaign index</TableCell>
                                                                    <TableCell sx={{ borderBottom: 0 }} className="fw-bold greyTxt" align="right">Votes received</TableCell>
                                                                    <TableCell sx={{ borderBottom: 0 }} className="fw-bold greyTxt" align="right">Lockup period</TableCell>
                                                                    <TableCell sx={{ borderBottom: 0 }} className="fw-bold greyTxt" align="right">Rewards</TableCell>
                                                                    <TableCell sx={{ borderBottom: 0 }} className="fw-bold greyTxt" align="right">Total supply</TableCell>
                                                                    <TableCell sx={{ borderBottom: 0 }} className="fw-bold greyTxt" align="right">Action</TableCell>
                                                                </TableRow>
                                                            </TableHead>
                                                            <TableBody>
                                                                {data.map((data) => (
                                                                    <TableRow
                                                                        key={data.name}
                                                                        sx={{ 'td,th': { border: 0 } }}
                                                                    >
                                                                        <TableCell component="th" scope="row">
                                                                            <div className="d-flex">
                                                                                <div>
                                                                                    <img src={CTO} />
                                                                                </div>
                                                                                <div className="my-2">
                                                                                    <Typography className='blck-Txt fw-bold'>CTO</Typography>
                                                                                </div>
                                                                            </div>
                                                                        </TableCell>
                                                                        <TableCell className='blck-Txt' align="center" sx={{ fontWeight: 700 }}>--</TableCell>
                                                                        <TableCell className='blck-Txt' align="right" sx={{ fontWeight: 700 }}>846 DOT</TableCell>
                                                                        <TableCell className='blck-Txt' align="right" sx={{ fontWeight: 700 }}>672 Day(s)</TableCell>
                                                                        <TableCell className='blck-Txt' align="right" sx={{ fontWeight: 700 }}>22500000 CTO</TableCell>
                                                                        <TableCell className='blck-Txt' align="right" sx={{ fontWeight: 700 }}>100000000 CTO</TableCell>
                                                                        <TableCell className='blck-Txt' align="right" sx={{ fontWeight: 700 }}><button className="btn-secondary btn btn-sm" disabled>Ended</button></TableCell>
                                                                    </TableRow>
                                                                ))}
                                                            </TableBody>
                                                        </Table>
                                                    </TableContainer>
                                                </Box>
                                            </Grid>
                                        </Container>
                                    </CardContent>
                                </Card>
                                {/* ===================THIRD CARD=================== */}
                                <Card
                                    className="profile-page-card mb-1 my-5"
                                    sx={{ minWidth: "auto", maxWidth: "auto" }}
                                >
                                    <CardContent>

                                        <Box>
                                            <Box className="container">
                                                <Typography className="mb-3 greyTxt" sx={{ fontWeight: 800, fontSize: 20 }}>Disclaimer</Typography>
                                                <Typography className="greyTxt mb-3" sx={{ fontWeight: 500, fontSize: 15 }}>
                                                    CIFDAQ will try its best to ensure the smooth progress of voting. CIFDAQ only assists users to vote on the chain, but does not guarantee that the bid will be successful. CIFDAQ is not responsible for any asset loss caused by potential risks including but not limited to suspension or termination of business, abrupt suspension or cessation of transactions, and price volatility driven by market movement. Please refer to the announcement for other details, thank you for your participation!
                                                </Typography>
                                            </Box>
                                        </Box>
                                    </CardContent>
                                </Card>
                            </>
                        </Box>
                    </TabPanel>


                    {/* ////////////////TAB2/////////////// */}
                    <TabPanel value="2">
                        <Box sx={{ mt: 2 }}>
                            <>
                                <Card
                                    className="profile-page-card mb-5"
                                    sx={{ minWidth: "auto", maxWidth: "auto" }}
                                >
                                    <CardContent>

                                        <Box>
                                            <Box className="container">
                                                <Typography className="card-text mb-3" sx={{ fontWeight: 800, fontSize: 20 }}>Polkadot slot auction</Typography>
                                                <Typography className="card-text mb-3" sx={{ fontWeight: 800, fontSize: 15 }}>
                                                    DOT Slot Auction is a parachain auction for the Polkadot ecosystem. On CIFDAQ, you can use DOT to vote for a Polkadot parachain project you support. After voting you will be rewarded according to the project's official auction rules.
                                                </Typography>
                                                <Typography className="card-text" sx={{ fontWeight: 400, fontSize: 12 }}>
                                                    *Please refer to the announcement for auction rules and details
                                                </Typography>
                                            </Box>
                                        </Box>
                                    </CardContent>
                                </Card>
                                {/* -------------------- Second Card----------- */}
                                <Card
                                    className="profile-page-card"
                                    sx={{ minWidth: "auto", maxWidth: "auto" }}
                                >
                                    <CardContent>
                                        <Container className='my-2'>
                                            <Grid item xs={12} sm={12} md={12} lg={12}>
                                                <Box className="d-flex justify-content-between">
                                                    <div>
                                                        <Typography className="card-text fw-bold" sx={{ fontSize: 18 }}>Issue 7</Typography>
                                                    </div>
                                                    <div>
                                                        <Link to='/slotVote' className="linkTag"> <Typography className="card-text fw-bold" sx={{ color: '#1A94AE', fontSize: 18 }}>My Votes</Typography></Link>
                                                    </div>
                                                </Box>
                                                <Box>
                                                    <TableContainer component={Paper} className="profile-page-card">
                                                        <Table sx={{ minWidth: 650 }} className="profile-page-card" aria-label="simple table">
                                                            <TableHead>
                                                                <TableRow>
                                                                    <TableCell sx={{ borderBottom: 0 }} className="fw-bold greyTxt">Project</TableCell>
                                                                    <TableCell sx={{ borderBottom: 0 }} className="fw-bold greyTxt" align="right">Campaign index</TableCell>
                                                                    <TableCell sx={{ borderBottom: 0 }} className="fw-bold greyTxt" align="right">Votes received</TableCell>
                                                                    <TableCell sx={{ borderBottom: 0 }} className="fw-bold greyTxt" align="right">Lockup period</TableCell>
                                                                    <TableCell sx={{ borderBottom: 0 }} className="fw-bold greyTxt" align="right">Rewards</TableCell>
                                                                    <TableCell sx={{ borderBottom: 0 }} className="fw-bold greyTxt" align="right">Total supply</TableCell>
                                                                    <TableCell sx={{ borderBottom: 0 }} className="fw-bold greyTxt" align="right">Action</TableCell>
                                                                </TableRow>
                                                            </TableHead>
                                                            <TableBody>
                                                                {data.map((data) => (
                                                                    <TableRow
                                                                        key={data.name}
                                                                        sx={{ 'td,th': { border: 0 } }}
                                                                    >
                                                                        <TableCell component="th" scope="row">
                                                                            <div className="d-flex">
                                                                                <div>
                                                                                    <img src={CTO} />
                                                                                </div>
                                                                                <div className="my-2">
                                                                                    <Typography className='blck-Txt fw-bold'>CTO</Typography>
                                                                                </div>
                                                                            </div>
                                                                        </TableCell>
                                                                        <TableCell className='blck-Txt' align="center" sx={{ fontWeight: 700 }}>--</TableCell>
                                                                        <TableCell className='blck-Txt' align="right" sx={{ fontWeight: 700 }}>846 DOT</TableCell>
                                                                        <TableCell className='blck-Txt' align="right" sx={{ fontWeight: 700 }}>672 Day(s)</TableCell>
                                                                        <TableCell className='blck-Txt' align="right" sx={{ fontWeight: 700 }}>22500000 CTO</TableCell>
                                                                        <TableCell className='blck-Txt' align="right" sx={{ fontWeight: 700 }}>100000000 CTO</TableCell>
                                                                        <TableCell className='blck-Txt' align="right" sx={{ fontWeight: 700 }}><button className="btn-secondary btn btn-sm" disabled>Ended</button></TableCell>
                                                                    </TableRow>
                                                                ))}
                                                            </TableBody>
                                                        </Table>
                                                    </TableContainer>
                                                </Box>
                                            </Grid>
                                        </Container>
                                    </CardContent>
                                </Card>
                                {/* ===================THIRD CARD=================== */}
                                <Card
                                    className="profile-page-card mb-1 my-5"
                                    sx={{ minWidth: "auto", maxWidth: "auto" }}
                                >
                                    <CardContent>

                                        <Box>
                                            <Box className="container">
                                                <Typography className="mb-3 DarkgreyTxt" sx={{ fontWeight: 800, fontSize: 20 }}>Disclaimer</Typography>
                                                <Typography className="DarkgreyTxt mb-3" sx={{ fontWeight: 500, fontSize: 15 }}>
                                                    CIFDAQ will try its best to ensure the smooth progress of voting. CIFDAQ only assists users to vote on the chain, but does not guarantee that the bid will be successful. CIFDAQ is not responsible for any asset loss caused by potential risks including but not limited to suspension or termination of business, abrupt suspension or cessation of transactions, and price volatility driven by market movement. Please refer to the announcement for other details, thank you for your participation!
                                                </Typography>
                                            </Box>
                                        </Box>
                                    </CardContent>
                                </Card>
                            </>
                        </Box>
                    </TabPanel>
                </TabContext>
            </Container>
        </div>
    );
};
export default SlotAuction;
