import React from "react";
import FiberManualRecordIcon from "@mui/icons-material/FiberManualRecord";
import { Typography } from "@mui/material";
import "./index.css";
export default function Accordion() {
  return (
    <>
      <div className="tab-content" id="v-pills-tabContent">
        <div
          className="tab-pane fade show active"
          id="v-pills-home"
          role="tabpanel"
          aria-labelledby="v-pills-home-tab"
        >
          <div className="accordion accordion-flush" id="accordionFlushExample">
            <div className="accordion-item accordtionbtn-clr">
              <h2 className="accordion-header" id="flush-headingOne">
                <button
                  className="accordion-button accordtionbtn-clr collapsed"
                  type="button"
                  data-bs-toggle="collapse"
                  data-bs-target="#flush-collapseOne"
                  aria-expanded="false"
                  aria-controls="flush-collapseOne"
                >
                  <div className="d-block">
                    <div className="d-flex">
                      <FiberManualRecordIcon
                        sx={{ fontSize: 15, color: "var(--notify-icon)" }}
                      />
                      <Typography
                        className="accordion-txts"
                        sx={{ fontSize: 14, fontWeight: 700 }}
                      >
                        <span
                          className="ms-2 fw-bold"
                          style={{ color: "#1A94AE" }}
                        >
                          #ETF# #New Listing#{" "}
                        </span>
                        DUSK3L/3S &RON3L/3S ETF Trading Event is ongoing!
                      </Typography>
                    </div>
                    <div>
                      <Typography
                        className="ms-4 accordion-txts accordion-txts"
                        sx={{ fontSize: 14, fontWeight: 700 }}
                      >
                        Trade to grab DUSK3L Token Airdrops!
                        <span
                          className="ms-2 fw-bold"
                          style={{ color: "#1A94AE" }}
                        >
                          {" "}
                          Join now {">>"}
                        </span>
                      </Typography>
                    </div>
                    <div>
                      <Typography
                        className="ms-4 accordion-txts accordion-txts"
                        sx={{ fontSize: 14, fontWeight: 700 }}
                      >
                        Today
                      </Typography>
                    </div>
                  </div>
                </button>
              </h2>
              <div
                id="flush-collapseOne"
                className="accordion-collapse collapse"
                aria-labelledby="flush-headingOne"
                data-bs-parent="#accordionFlushExample"
              >
                <div className="accordion-body accordion-txts">
                  Lorem ipsum dolor sit, amet consectetur adipisicing elit. Quos
                  id magnam magni deserunt perferendis ab exercitationem
                  praesentium. Expedita, repudiandae odio voluptatem fuga facere
                  dignissimos rerum, dolor iure natus repellendus quisquam!
                </div>
              </div>
            </div>
            {/* /////ACCORDION 2 */}
            <div className="accordion-item accordtionbtn-clr">
              <h2 className="accordion-header" id="flush-headingTwo">
                <button
                  className="accordion-button accordtionbtn-clr collapsed"
                  type="button"
                  data-bs-toggle="collapse"
                  data-bs-target="#flush-collapseTwo"
                  aria-expanded="false"
                  aria-controls="flush-collapseTwo"
                >
                  <div className="d-block">
                    <div className="d-flex">
                      <FiberManualRecordIcon
                        sx={{ fontSize: 15, color: "var(--notify-icon)" }}
                      />
                      <Typography
                        className="accordion-txts"
                        sx={{ fontSize: 14, fontWeight: 700 }}
                      >
                        <span
                          className="ms-2 fw-bold"
                          style={{ color: "#1A94AE" }}
                        >
                          #ETF# #New Listing#{" "}
                        </span>
                        DUSK3L/3S &RON3L/3S ETF Trading Event is ongoing!
                      </Typography>
                    </div>
                    <div>
                      <Typography
                        className="ms-4 accordion-txts accordion-txts"
                        sx={{ fontSize: 14, fontWeight: 700 }}
                      >
                        Trade to grab DUSK3L Token Airdrops!
                        <span
                          className="ms-2 fw-bold"
                          style={{ color: "#1A94AE" }}
                        >
                          {" "}
                          Join now {">>"}
                        </span>
                      </Typography>
                    </div>
                    <div>
                      <Typography
                        className="ms-4 accordion-txts accordion-txts"
                        sx={{ fontSize: 14, fontWeight: 700 }}
                      >
                        Today
                      </Typography>
                    </div>
                  </div>
                </button>
              </h2>
              <div
                id="flush-collapseTwo"
                className="accordion-collapse collapse"
                aria-labelledby="flush-headingTwo"
                data-bs-parent="#accordionFlushExample"
              >
                <div className="accordion-body accordion-txts">
                  Lorem ipsum dolor, sit amet consectetur adipisicing elit.
                  Possimus, dicta. Illo qui similique tempora odit dolor
                  exercitationem dolorem, voluptatem, provident, maxime vero
                  corrupti rem nam. Labore magnam nobis consequatur dicta.
                </div>
              </div>
            </div>
            {/* ACCORDION-3  */}
            <div className="accordion-item accordtionbtn-clr">
              <h2 className="accordion-header" id="flush-headingThree">
                <button
                  className="accordion-button accordtionbtn-clr collapsed"
                  type="button"
                  data-bs-toggle="collapse"
                  data-bs-target="#flush-collapseThree"
                  aria-expanded="false"
                  aria-controls="flush-collapseThree"
                >
                  <div className="d-block">
                    <div className="d-flex">
                      <FiberManualRecordIcon
                        sx={{ fontSize: 15, color: "var(--notify-icon)" }}
                      />
                      <Typography
                        className="accordion-txts"
                        sx={{ fontSize: 14, fontWeight: 700 }}
                      >
                        <span
                          className="ms-2 fw-bold"
                          style={{ color: "#1A94AE" }}
                        >
                          #ETF# #New Listing#{" "}
                        </span>
                        DUSK3L/3S &RON3L/3S ETF Trading Event is ongoing!
                      </Typography>
                    </div>
                    <div>
                      <Typography
                        className="ms-4 accordion-txts accordion-txts"
                        sx={{ fontSize: 14, fontWeight: 700 }}
                      >
                        Trade to grab DUSK3L Token Airdrops!
                        <span
                          className="ms-2 fw-bold"
                          style={{ color: "#1A94AE" }}
                        >
                          {" "}
                          Join now {">>"}
                        </span>
                      </Typography>
                    </div>
                    <div>
                      <Typography
                        className="ms-4 accordion-txts accordion-txts"
                        sx={{ fontSize: 14, fontWeight: 700 }}
                      >
                        Today
                      </Typography>
                    </div>
                  </div>
                </button>
              </h2>
              <div
                id="flush-collapseThree"
                className="accordion-collapse collapse"
                aria-labelledby="flush-headingThree"
                data-bs-parent="#accordionFlushExample"
              >
                <div className="accordion-body accordion-txts">
                  Lorem ipsum dolor, sit amet consectetur adipisicing elit.
                  Possimus, dicta. Illo qui similique tempora odit dolor
                  exercitationem dolorem, voluptatem, provident, maxime vero
                  corrupti rem nam. Labore magnam nobis consequatur dicta.
                </div>
              </div>
            </div>
            {/* ACCORDION-4  */}
            <div className="accordion-item accordtionbtn-clr">
              <h2 className="accordion-header" id="flush-heading4">
                <button
                  className="accordion-button accordtionbtn-clr collapsed"
                  type="button"
                  data-bs-toggle="collapse"
                  data-bs-target="#flush-collapse4"
                  aria-expanded="false"
                  aria-controls="flush-collapse4"
                >
                  <div className="d-block">
                    <div className="d-flex">
                      <FiberManualRecordIcon
                        sx={{ fontSize: 15, color: "#DD2942" }}
                      />
                      <Typography
                        className="accordion-txts"
                        sx={{ fontSize: 14, fontWeight: 700 }}
                      >
                        <span
                          className="ms-2 fw-bold"
                          style={{ color: "#1A94AE" }}
                        >
                          #ETF# #New Listing#{" "}
                        </span>
                        DUSK3L/3S &RON3L/3S ETF Trading Event is ongoing!
                      </Typography>
                    </div>
                    <div>
                      <Typography
                        className="ms-4 accordion-txts accordion-txts"
                        sx={{ fontSize: 14, fontWeight: 700 }}
                      >
                        Trade to grab DUSK3L Token Airdrops!
                        <span
                          className="ms-2 fw-bold"
                          style={{ color: "#1A94AE" }}
                        >
                          {" "}
                          Join now {">>"}
                        </span>
                      </Typography>
                    </div>
                    <div>
                      <Typography
                        className="ms-4 accordion-txts"
                        sx={{ fontSize: 14, fontWeight: 700 }}
                      >
                        Today
                      </Typography>
                    </div>
                  </div>
                </button>
              </h2>
              <div
                id="flush-collapse4"
                className="accordion-collapse collapse"
                data-bs-parent="#accordionFlushExample"
              >
                <div className="accordion-body accordion-txts">
                  Lorem ipsum dolor, sit amet consectetur adipisicing elit.
                  Possimus, dicta. Illo qui similique tempora odit dolor
                  exercitationem dolorem, voluptatem, provident, maxime vero
                  corrupti rem nam. Labore magnam nobis consequatur dicta.
                </div>
              </div>
            </div>

            {/* ACCORDION-5  */}
            <div className="accordion-item accordtionbtn-clr">
              <h2 className="accordion-header" id="flush-heading5">
                <button
                  className="accordion-button accordtionbtn-clr collapsed"
                  type="button"
                  data-bs-toggle="collapse"
                  data-bs-target="#flush-collapse5"
                  aria-expanded="false"
                  aria-controls="flush-collapse5"
                >
                  <div className="d-block">
                    <div className="d-flex">
                      <FiberManualRecordIcon
                        sx={{ fontSize: 15, color: "#DD2942" }}
                      />
                      <Typography
                        className="accordion-txts"
                        sx={{ fontSize: 14, fontWeight: 700 }}
                      >
                        <span
                          className="ms-2 fw-bold"
                          style={{ color: "#1A94AE" }}
                        >
                          #ETF# #New Listing#{" "}
                        </span>
                        DUSK3L/3S &RON3L/3S ETF Trading Event is ongoing!
                      </Typography>
                    </div>
                    <div>
                      <Typography
                        className="ms-4 accordion-txts"
                        sx={{ fontSize: 14, fontWeight: 700 }}
                      >
                        Trade to grab DUSK3L Token Airdrops!
                        <span
                          className="ms-2 fw-bold"
                          style={{ color: "#1A94AE" }}
                        >
                          {" "}
                          Join now {">>"}
                        </span>
                      </Typography>
                    </div>
                    <div>
                      <Typography
                        className="ms-4 accordion-txts"
                        sx={{ fontSize: 14, fontWeight: 700 }}
                      >
                        Today
                      </Typography>
                    </div>
                  </div>
                </button>
              </h2>
              <div
                id="flush-collapse5"
                className="accordion-collapse collapse"
                data-bs-parent="#accordionFlushExample"
              >
                <div className="accordion-body accordion-txts">
                  Lorem ipsum dolor, sit amet consectetur adipisicing elit.
                  Possimus, dicta. Illo qui similique tempora odit dolor
                  exercitationem dolorem, voluptatem, provident, maxime vero
                  corrupti rem nam. Labore magnam nobis consequatur dicta.
                </div>
              </div>
            </div>
            {/* ACCORDION-6  */}
            <div className="accordion-item accordtionbtn-clr">
              <h2 className="accordion-header" id="flush-heading6">
                <button
                  className="accordion-button accordtionbtn-clr collapsed"
                  type="button"
                  data-bs-toggle="collapse"
                  data-bs-target="#flush-collapse6"
                  aria-expanded="false"
                  aria-controls="flush-collapse6"
                >
                  <div className="d-block">
                    <div className="d-flex">
                      <FiberManualRecordIcon
                        sx={{ fontSize: 15, color: "#DD2942" }}
                      />
                      <Typography
                        className="accordion-txts"
                        sx={{ fontSize: 14, fontWeight: 700 }}
                      >
                        <span
                          className="ms-2 fw-bold"
                          style={{ color: "#1A94AE" }}
                        >
                          #ETF# #New Listing#{" "}
                        </span>
                        DUSK3L/3S &RON3L/3S ETF Trading Event is ongoing!
                      </Typography>
                    </div>
                    <div>
                      <Typography
                        className="ms-4 accordion-txts"
                        sx={{ fontSize: 14, fontWeight: 700 }}
                      >
                        Trade to grab DUSK3L Token Airdrops!
                        <span
                          className="ms-2 fw-bold"
                          style={{ color: "#1A94AE" }}
                        >
                          {" "}
                          Join now {">>"}
                        </span>
                      </Typography>
                    </div>
                    <div>
                      <Typography
                        className="ms-4 accordion-txts"
                        sx={{ fontSize: 14, fontWeight: 700 }}
                      >
                        Today
                      </Typography>
                    </div>
                  </div>
                </button>
              </h2>
              <div
                id="flush-collapse6"
                className="accordion-collapse collapse"
                data-bs-parent="#accordionFlushExample"
              >
                <div className="accordion-body accordion-txts">
                  Lorem ipsum dolor, sit amet consectetur adipisicing elit.
                  Possimus, dicta. Illo qui similique tempora odit dolor
                  exercitationem dolorem, voluptatem, provident, maxime vero
                  corrupti rem nam. Labore magnam nobis consequatur dicta.
                </div>
              </div>
            </div>
            {/* ACCORDION-7  */}
            <div className="accordion-item accordtionbtn-clr">
              <h2 className="accordion-header" id="flush-heading7">
                <button
                  className="accordion-button accordtionbtn-clr collapsed"
                  type="button"
                  data-bs-toggle="collapse"
                  data-bs-target="#flush-collapse7"
                  aria-expanded="false"
                  aria-controls="flush-collapse7"
                >
                  <div className="d-block">
                    <div className="d-flex">
                      <FiberManualRecordIcon
                        sx={{ fontSize: 15, color: "var(--notify-icon)" }}
                      />
                      <Typography
                        className="accordion-txts"
                        sx={{ fontSize: 14, fontWeight: 700 }}
                      >
                        <span
                          className="ms-2 fw-bold"
                          style={{ color: "#1A94AE" }}
                        >
                          #ETF# #New Listing#{" "}
                        </span>
                        DUSK3L/3S &RON3L/3S ETF Trading Event is ongoing!
                      </Typography>
                    </div>
                    <div>
                      <Typography
                        className="ms-4 accordion-txts"
                        sx={{ fontSize: 14, fontWeight: 700 }}
                      >
                        Trade to grab DUSK3L Token Airdrops!
                        <span
                          className="ms-2 fw-bold"
                          style={{ color: "#1A94AE" }}
                        >
                          {" "}
                          Join now {">>"}
                        </span>
                      </Typography>
                    </div>
                    <div>
                      <Typography
                        className="ms-4 accordion-txts"
                        sx={{ fontSize: 14, fontWeight: 700 }}
                      >
                        Today
                      </Typography>
                    </div>
                  </div>
                </button>
              </h2>
              <div
                id="flush-collapse7"
                className="accordion-collapse collapse"
                data-bs-parent="#accordionFlushExample"
              >
                <div className="accordion-body accordion-txts">
                  Lorem ipsum dolor, sit amet consectetur adipisicing elit.
                  Possimus, dicta. Illo qui similique tempora odit dolor
                  exercitationem dolorem, voluptatem, provident, maxime vero
                  corrupti rem nam. Labore magnam nobis consequatur dicta.
                </div>
              </div>
            </div>
            {/* ACCORDION-8 */}
            <div className="accordion-item accordtionbtn-clr">
              <h2 className="accordion-header" id="flush-heading8">
                <button
                  className="accordion-button accordtionbtn-clr collapsed"
                  type="button"
                  data-bs-toggle="collapse"
                  data-bs-target="#flush-collapse8"
                  aria-expanded="false"
                  aria-controls="flush-collapse8"
                >
                  <div className="d-block">
                    <div className="d-flex">
                      <FiberManualRecordIcon
                        sx={{ fontSize: 15, color: "var(--notify-icon)" }}
                      />
                      <Typography
                        className="accordion-txts"
                        sx={{ fontSize: 14, fontWeight: 700 }}
                      >
                        <span
                          className="ms-2 fw-bold"
                          style={{ color: "#1A94AE" }}
                        >
                          #ETF# #New Listing#{" "}
                        </span>
                        DUSK3L/3S &RON3L/3S ETF Trading Event is ongoing!
                      </Typography>
                    </div>
                    <div>
                      <Typography
                        className="ms-4 accordion-txts"
                        sx={{ fontSize: 14, fontWeight: 700 }}
                      >
                        Trade to grab DUSK3L Token Airdrops!
                        <span
                          className="ms-2 fw-bold"
                          style={{ color: "#1A94AE" }}
                        >
                          {" "}
                          Join now {">>"}
                        </span>
                      </Typography>
                    </div>
                    <div>
                      <Typography
                        className="ms-4 accordion-txts"
                        sx={{ fontSize: 14, fontWeight: 700 }}
                      >
                        Today
                      </Typography>
                    </div>
                  </div>
                </button>
              </h2>
              <div
                id="flush-collapse8"
                className="accordion-collapse collapse"
                data-bs-parent="#accordionFlushExample"
              >
                <div className="accordion-body accordion-txts">
                  {" "}
                  Lorem ipsum dolor, sit amet consectetur adipisicing elit.
                  Possimus, dicta. Illo qui similique tempora odit dolor
                  exercitationem dolorem, voluptatem, provident, maxime vero
                  corrupti rem nam. Labore magnam nobis consequatur dicta.
                </div>
              </div>
            </div>
            {/* ACCORDION-9 */}
            <div className="accordion-item accordtionbtn-clr">
              <h2 className="accordion-header" id="flush-heading9">
                <button
                  className="accordion-button accordtionbtn-clr collapsed"
                  type="button"
                  data-bs-toggle="collapse"
                  data-bs-target="#flush-collapse9"
                  aria-expanded="false"
                  aria-controls="flush-collapse9"
                >
                  <div className="d-block">
                    <div className="d-flex">
                      <FiberManualRecordIcon
                        sx={{ fontSize: 15, color: "var(--notify-icon)" }}
                      />
                      <Typography
                        className="accordion-txts"
                        sx={{ fontSize: 14, fontWeight: 700 }}
                      >
                        <span
                          className="ms-2 fw-bold"
                          style={{ color: "#1A94AE" }}
                        >
                          #ETF# #New Listing#{" "}
                        </span>
                        DUSK3L/3S &RON3L/3S ETF Trading Event is ongoing!
                      </Typography>
                    </div>
                    <div>
                      <Typography
                        className="ms-4 accordion-txts"
                        sx={{ fontSize: 14, fontWeight: 700 }}
                      >
                        Trade to grab DUSK3L Token Airdrops!
                        <span
                          className="ms-2 fw-bold"
                          style={{ color: "#1A94AE" }}
                        >
                          {" "}
                          Join now {">>"}
                        </span>
                      </Typography>
                    </div>
                    <div>
                      <Typography
                        className="ms-4 accordion-txts"
                        sx={{ fontSize: 14, fontWeight: 700 }}
                      >
                        Today
                      </Typography>
                    </div>
                  </div>
                </button>
              </h2>
              <div
                id="flush-collapse9"
                className="accordion-collapse collapse"
                data-bs-parent="#accordionFlushExample"
              >
                <div className="accordion-body accordion-txts">
                  Lorem ipsum dolor, sit amet consectetur adipisicing elit.
                  Possimus, dicta. Illo qui similique tempora odit dolor
                  exercitationem dolorem, voluptatem, provident, maxime vero
                  corrupti rem nam. Labore magnam nobis consequatur dicta.
                </div>
              </div>
            </div>
            {/* ACCORDION-10 */}
            <div className="accordion-item accordtionbtn-clr">
              <h2 className="accordion-header" id="flush-heading10">
                <button
                  className="accordion-button accordtionbtn-clr collapsed"
                  type="button"
                  data-bs-toggle="collapse"
                  data-bs-target="#flush-collapse10"
                  aria-expanded="false"
                  aria-controls="flush-collapse10"
                >
                  <div className="d-block">
                    <div className="d-flex">
                      <FiberManualRecordIcon
                        sx={{ fontSize: 15, color: "var(--notify-icon)" }}
                      />
                      <Typography
                        className="accordion-txts"
                        sx={{ fontSize: 14, fontWeight: 700 }}
                      >
                        <span
                          className="ms-2 fw-bold"
                          style={{ color: "#1A94AE" }}
                        >
                          #ETF# #New Listing#{" "}
                        </span>
                        DUSK3L/3S &RON3L/3S ETF Trading Event is ongoing!
                      </Typography>
                    </div>
                    <div>
                      <Typography
                        className="ms-4 accordion-txts"
                        sx={{ fontSize: 14, fontWeight: 700 }}
                      >
                        Trade to grab DUSK3L Token Airdrops!
                        <span
                          className="ms-2 fw-bold"
                          style={{ color: "#1A94AE" }}
                        >
                          {" "}
                          Join now {">>"}
                        </span>
                      </Typography>
                    </div>
                    <div>
                      <Typography
                        className="ms-4 accordion-txts"
                        sx={{ fontSize: 14, fontWeight: 700 }}
                      >
                        Today
                      </Typography>
                    </div>
                  </div>
                </button>
              </h2>
              <div
                id="flush-collapse10"
                className="accordion-collapse collapse"
                data-bs-parent="#accordionFlushExample"
              >
                <div className="accordion-body accordion-txts">
                  Lorem ipsum dolor, sit amet consectetur adipisicing elit.
                  Possimus, dicta. Illo qui similique tempora odit dolor
                  exercitationem dolorem, voluptatem, provident, maxime vero
                  corrupti rem nam. Labore magnam nobis consequatur dicta.
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </>
  );
}
