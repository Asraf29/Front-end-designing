import React, { useState } from "react";
import { Box, Button } from "@mui/material";
import Card from "@mui/material/Card";
import CardContent from "@mui/material/CardContent";
import { Container } from "@mui/system";
import { styled } from "@mui/material/styles";
import CardGiftcardOutlinedIcon from "@mui/icons-material/CardGiftcardOutlined";
import AppsIcon from "@mui/icons-material/Apps";
import PaidOutlinedIcon from "@mui/icons-material/PaidOutlined";
import MilitaryTechOutlinedIcon from "@mui/icons-material/MilitaryTechOutlined";
import NotificationsIcon from "@mui/icons-material/Notifications";
import "./index.css";
import Pagination from "@mui/material/Pagination";
import usePagination from "./pagination";
import Stack from "@mui/material/Stack";

import {
  Checkbox,
  Grid,
  ListItemButton,
  ListItemIcon,
  ListItemText,
  Typography,
} from "@mui/material";
import FormGroup from "@mui/material/FormGroup";
import FormControlLabel from "@mui/material/FormControlLabel";
import Switch from "@mui/material/Switch";
import Accordion from "./accordion";
const Android12Switch = styled(Switch)(({ theme }) => ({
  padding: 8,
  "& .MuiSwitch-track": {
    borderRadius: 22 / 2,
    "&:before, &:after": {
      content: '""',
      position: "absolute",
      top: "50%",
      transform: "translateY(-50%)",
      width: 16,
      height: 16,
    },
    "&:before": {
      backgroundImage: `url('data:image/svg+xml;utf8,<svg xmlns="http://www.w3.org/2000/svg" height="16" width="16" viewBox="0 0 24 24"><path fill="${encodeURIComponent(
        theme.palette.getContrastText(theme.palette.primary.main)
      )}" d="M21,7L9,19L3.5,13.5L4.91,12.09L9,16.17L19.59,5.59L21,7Z"/></svg>')`,
      left: 12,
    },
    "&:after": {
      backgroundImage: `url('data:image/svg+xml;utf8,<svg xmlns="http://www.w3.org/2000/svg" height="16" width="16" viewBox="0 0 24 24"><path fill="${encodeURIComponent(
        theme.palette.getContrastText(theme.palette.primary.main)
      )}" d="M19,13H5V11H19V13Z" /></svg>')`,
      right: 12,
    },
  },
  "& .MuiSwitch-thumb": {
    boxShadow: "none",
    width: 16,
    height: 16,
    margin: 2,
  },
}));
export default function NotificationExpand() {
  let [page, setPage] = useState(1);
  const PER_PAGE = 1;
  const data = ["0", "1", "2", "3", "4", "5"];
  const count = Math.ceil(data.length / PER_PAGE);
  const _DATA = usePagination(data, PER_PAGE);

  const paginationChange = (e, p) => {
    setPage(p);
    _DATA.jump(p);
  };
  return (
    <>
      <Container sx={{ my: 4 }}>
        {/*Card_One*/}
        <Card
          className="profile-page-card"
          sx={{ minWidth: "auto", maxWidth: "auto" }}
        >
          <CardContent className="px-sm-4">
            <div className="d-block d-md-flex justify-content-between">
              <div>
                <Typography
                  sx={{ fontSize: "20px" }}
                  className="text-color-black fw-bold"
                >
                  Message
                </Typography>
              </div>
              <div className="d-flex my-2 my-sm-0">
                <FormControlLabel
                  control={
                    <Android12Switch className="fw-bold" defaultChecked />
                  }
                  label="Push only important notification"
                  className="PushLabel accordion-txts"
                />
                <Typography
                  className="my-2"
                  sx={{ fontSize: "14px", color: "#1A94AE", fontWeight: 600 }}
                >
                  Mark all as read
                </Typography>
              </div>
            </div>
            <Grid container spacing={4} sx={{ mt: 1 }} className="d-flex">
              <Grid item xs={12} sm={12} md={3} lg={3}>
                <div className="d-block d-lg-flex align-items-start">
                  <div
                    className="nav flex-column color-nav nav-pills me-3"
                    id="v-pills-tab"
                    role="tablist"
                    aria-orientation="vertical"
                  >
                    <button
                      className="nav-link  text-align  color-nav-tb active"
                      id="v-pills-home-tab"
                      data-bs-toggle="pill"
                      data-bs-target="#v-pills-home"
                      type="button"
                      role="tab"
                      aria-controls="v-pills-home"
                      aria-selected="true"
                    >
                      <span className="active-clr">
                        <AppsIcon sx={{ mb: 0.2, fontSize: "20px" }} />
                      </span>{" "}
                      All
                    </button>
                    <button
                      className="nav-link  text-align  color-nav-tb"
                      id="v-pills-home-tab"
                      data-bs-toggle="pill"
                      data-bs-target="#v-pills-home"
                      type="button"
                      role="tab"
                      aria-controls="v-pills-home"
                      aria-selected="true"
                    >
                      {" "}
                      <span
                        style={{ backgroundColor: "#C4C4C4", borderRadius: 4 }}
                      >
                        <CardGiftcardOutlinedIcon
                          sx={{ mb: 0.2, fontSize: "20px", padding: "2px" }}
                        />
                      </span>{" "}
                      Activities
                    </button>
                    <button
                      className="nav-link  text-align  color-nav-tb"
                      id="v-pills-home-tab"
                      data-bs-toggle="pill"
                      data-bs-target="#v-pills-home"
                      type="button"
                      role="tab"
                      aria-controls="v-pills-home"
                      aria-selected="true"
                    >
                      {" "}
                      <span
                        className="me-1"
                        style={{ backgroundColor: "#C4C4C4", borderRadius: 4 }}
                      >
                        <PaidOutlinedIcon
                          sx={{ mb: 0.2, fontSize: "20px", padding: "2px" }}
                        />
                      </span>
                      New Listings
                    </button>
                    <button
                      className="nav-link  text-align  color-nav-tb"
                      id="v-pills-home-tab"
                      data-bs-toggle="pill"
                      data-bs-target="#v-pills-home"
                      type="button"
                      role="tab"
                      aria-controls="v-pills-home"
                      aria-selected="true"
                    >
                      {" "}
                      <span
                        className="me-1"
                        style={{ backgroundColor: "#C4C4C4", borderRadius: 4 }}
                      >
                        <MilitaryTechOutlinedIcon
                          sx={{ mb: 0.2, fontSize: "20px", padding: "2px" }}
                        />
                      </span>
                      Breaking News
                    </button>
                    <button
                      className="nav-link  text-align  color-nav-tb"
                      id="v-pills-home-tab"
                      data-bs-toggle="pill"
                      data-bs-target="#v-pills-home"
                      type="button"
                      role="tab"
                      aria-controls="v-pills-home"
                      aria-selected="true"
                    >
                      {" "}
                      <span
                        className="me-1"
                        style={{ backgroundColor: "#C4C4C4", borderRadius: 4 }}
                      >
                        <NotificationsIcon
                          sx={{ mb: 0.2, fontSize: "20px", padding: "2px" }}
                        />
                      </span>
                      System Messages
                    </button>
                  </div>
                </div>
              </Grid>
              <Grid className="p-0" item xs={12} sm={12} md={9} lg={9}>
                <Accordion />
              </Grid>
            </Grid>
            <div className="d-flex justify-content-end">
              <Stack spacing={2}>
                <Pagination
                  count={22}
                  size="large"
                  page={page}
                  variant="outlined"
                  shape="rounded"
                  onChange={paginationChange}
                />
              </Stack>
            </div>
          </CardContent>
        </Card>
      </Container>
    </>
  );
}
