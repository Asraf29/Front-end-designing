import React, { useState } from "react";
import {
  Box,
  Button,
  Paper,
  Table,
  TableBody,
  TableCell,
  TableContainer,
  TableHead,
  TableRow,
} from "@mui/material";
import ContentCopyIcon from "@mui/icons-material/ContentCopy";
import Stack from "@mui/material/Stack";
import "./index.css";
import Card from "@mui/material/Card";
import CardContent from "@mui/material/CardContent";
import QR from "../../components/assets/images/QR.png";
import { Container } from "@mui/system";
import {
  Checkbox,
  Grid,
  ListItemButton,
  ListItemIcon,
  ListItemText,
  Typography,
} from "@mui/material";
import ArrowBackIosIcon from "@mui/icons-material/ArrowBackIos";
import { Link } from "react-router-dom";
import NODATA from "../../components/assets/images/nodata.png";
import Ellipse from "../../components/assets/images/Ellipse.png";
const LoopAlliance = () => {
  return (
    <div>
      <Container sx={{ my: 7 }}>
        <Typography
          className="mb-3 d-flex align-items-center verifyTitle"
          variant="h5"
        >
          <Link to="/profile" className="linkTag text-white">
            <ArrowBackIosIcon className="mb-2" />
          </Link>
          LOOP Alliance
        </Typography>

        {/*Main Card*/}
        <Card
          className="profile-page-card mt-5 mt-sm-0"
          sx={{ minWidth: "auto", maxWidth: "auto" }}
        >
          <CardContent className=" px-sm-3 px-md-4 px-lg-5">
            <Grid container spacing={1}>
              <Grid item xs={12} sm={12} md={7} lg={6}>
                <div className="d-block">
                  <div>
                    <label className="value fw-bold">From</label>
                  </div>
                  <div>
                    <div className="pe-4 pt-2">
                      <select
                        style={{ height: "60px" }}
                        className="BTC-Select fw-bold col-lg-9 col-sm-12"
                      >
                        <option value="BTC-LOOP">BTC-LOOP</option>
                      </select>
                      <span className="BTC-icon pe-2 text-dark">
                        <img
                          src={Ellipse}
                          style={{ width: "40px", height: "40px" }}
                        />
                      </span>
                    </div>
                    <div className="pe-4 pt-4">
                      <Typography
                        sx={{ fontSize: "12px" }}
                        className="fw-bold txt-head"
                      >
                        Amount
                      </Typography>
                      <Typography
                        sx={{ fontSize: "18px" }}
                        className="fw-bold value"
                      >
                        0.00000000 MX
                      </Typography>
                    </div>
                    <div className="pe-4 pt-4">
                      <Typography
                        sx={{ fontSize: "12px" }}
                        className="fw-bold txt-head"
                      >
                        Available Balance
                      </Typography>
                      <Typography
                        sx={{ fontSize: "18px" }}
                        className="fw-bold value"
                      >
                        0.00000000 MX
                      </Typography>
                    </div>
                    <div className="pe-4 pt-4">
                      <Typography
                        sx={{ fontSize: "12px" }}
                        className="fw-bold txt-head"
                      >
                        Frozen Amount
                      </Typography>
                      <Typography
                        sx={{ fontSize: "18px" }}
                        className="fw-bold value"
                      >
                        0.00000000 MX
                      </Typography>
                    </div>
                  </div>
                </div>
              </Grid>
              <Grid item xs={12} sm={12} md={5} lg={6}>
                <Box>
                  <div className="pe-4 pt-4">
                    <Typography sx={{ fontSize: "14px" }} className="txt-head mb-1">
                    BTC-LOOP Available deposit blockchain
                    </Typography>
                    <Box>
                      <ul
                        className="nav nav-pills MAX-Coloured-Pills mb-3"
                        id="pills-tab"
                        role="tablist"
                      >
                        <li className="nav-item" role="presentation">
                          <button
                            className="nav-link active btn-sm me-2"
                            id="pills-home-tab"
                            data-bs-toggle="pill"
                            data-bs-target="#pills-home"
                            type="button"
                            role="tab"
                            aria-controls="pills-home"
                            aria-selected="true"
                          >
                           BTC-LOOP
                          </button>
                        </li>
                      </ul>
                      <div className="tab-content" id="pills-tabContent">
                        <div
                          className="tab-pane fade show active"
                          id="pills-home"
                          role="tabpanel"
                          aria-labelledby="pills-home-tab"
                        >
                          <Box>
                            <div className="pt-2">
                              <div className="d-block">
                                <div className="d-block d-md-flex justify-content-between">
                                  <div>
                                    <div className="d-flex">
                                      <Typography
                                        sx={{ fontSize: "14px" }}
                                        className="fw-bold value"
                                      >
                                        Deposit address
                                      </Typography>
                                      <Typography
                                        sx={{ fontSize: "12px" }}
                                        className="fw-bold linkTxts ms-lg-4"
                                      >
                                        Security verification of deposit address
                                      </Typography>
                                    </div>

                                    <div className="mb-3 form-group my-1">
                                      <div>
                                        <input
                                          type="text"
                                          className="form-control fw-bold inputQrBg"
                                          value="5494g1g4445x515"
                                        />
                                        <span className="copy-icon-deposit pe-2">
                                          <ContentCopyIcon
                                            sx={{ color: "#198ca5" }}
                                            fontSize={"small"}
                                          />
                                        </span>
                                      </div>
                                    </div>
                                  </div>
                                  <div>
                                    <div className="d-flex justify-content-center">
                                      <img
                                        src={QR}
                                        className="img-fluid ms-lg-2 "
                                        style={{
                                          height: "100px",
                                          width: "100px",
                                        }}
                                      />
                                    </div>
                                  </div>
                                </div>
                              </div>
                            </div>
                          </Box>
                        </div>
                        <div
                          className="tab-pane fade"
                          id="pills-profile"
                          role="tabpanel"
                          aria-labelledby="pills-profile-tab"
                        >
                          ...
                        </div>
                        <div
                          className="tab-pane fade"
                          id="pills-contact"
                          role="tabpanel"
                          aria-labelledby="pills-contact-tab"
                        >
                          ...
                        </div>
                      </div>
                    </Box>
                  </div>
                </Box>
                <Card
                  className="inputQrBg mt-3"
                  sx={{ minWidth: "auto", maxWidth: "auto", mt: 2 }}
                >
                  <CardContent>
                    <Typography className="fw-bold value">Notice</Typography>
                    <Typography className="value">
                      Please ensure that you transfer the corresponding crypto
                      to the stated address. Transferring the wrong type of
                      confirmations.
                    </Typography>
                  </CardContent>
                </Card>
              </Grid>
            </Grid>
          </CardContent>
        </Card>
        <TableContainer
          component={Paper}
          sx={{ background: "var( --card-bg-color)" }}
          className="mt-4"
        >
          <div className="d-flex justify-content-between">
            <div>
              <Typography variant="h6" className="ps-3 py-3 APITitle">
                Recent deposit records
              </Typography>
            </div>
            <div className="m-3">
              <Typography
                sx={{ color: "#1a94ae" }}
                variant="h7"
                className="APITitle"
              >
                History
              </Typography>
            </div>
          </div>

          <Table
            sx={{ minWidth: 650, background: "var( --card-bg-color)" }}
            aria-label="simple table"
          >
            <TableHead>
              <TableRow
                sx={{
                  border: "1px solid var(--input-qr-bg)",
                  borderRight: 0,
                  borderLeft: 0,
                }}
              >
                <TableCell
                  sx={{ fontWeight: "bolder !important", borderBottom:0 }}
                  className="textClr"
                  align="center"
                >
                  Status
                </TableCell>
                <TableCell
                  sx={{ fontWeight: "bolder !important", borderBottom:0 }}
                  className="textClr"
                  align="center"
                >
                  Time
                </TableCell>
                <TableCell
                  sx={{ fontWeight: "bolder !important", borderBottom:0 }}
                  className="textClr"
                  align="center"
                >
                  Crypto
                </TableCell>
                <TableCell
                  sx={{ fontWeight: "bolder !important", borderBottom:0 }}
                  className="textClr"
                  align="center"
                >
                  Amount
                </TableCell>
                <TableCell
                  sx={{ fontWeight: "bolder !important", borderBottom:0 }}
                  className="textClr"
                  align="center"
                >
                  transcation ID (Txid)
                </TableCell>
                <TableCell
                  sx={{ fontWeight: "bolder !important", borderBottom:0 }}
                  className="textClr"
                  align="center"
                >
                  Progress
                </TableCell>
              </TableRow>
            </TableHead>
            <TableBody>
              <TableRow
                sx={{ "&:last-child td, &:last-child th": { border: 0 } }}
              >
                <TableCell
                  align="center"
                  colSpan={7}
                  sx={{ justifyContent: "center", alignItems: "center" }}
                  className="my-4"
                >
                  <img src={NODATA} />
                </TableCell>
              </TableRow>
            </TableBody>
          </Table>
        </TableContainer>
      </Container>
    </div>
  );
};
export default LoopAlliance;
