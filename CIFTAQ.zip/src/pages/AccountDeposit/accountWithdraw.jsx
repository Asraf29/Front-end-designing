import React, { useState } from "react";
import {
  Box,
  Button,
  Paper,
  Table,
  TableBody,
  TableCell,
  TableContainer,
  TableHead,
  TableRow,
} from "@mui/material";
import "./index.css";
import Card from "@mui/material/Card";
import CardContent from "@mui/material/CardContent";
import { borderBottom, Container } from "@mui/system";
import { Grid, Typography } from "@mui/material";
import ArrowBackIosIcon from "@mui/icons-material/ArrowBackIos";
import { Link } from "react-router-dom";
import NODATA from "../../components/assets/images/nodata.png";
import Ellipse from "../../components/assets/images/Ellipse.png";
const AccountWithdraw = () => {
  return (
    <div>
      <Container sx={{ my: 7 }}>
        <Typography
          className="mb-3 d-flex align-items-center verifyTitle"
          variant="h5"
        >
          <Link to="/profile" className="linkTag text-white">
            <ArrowBackIosIcon className="mb-2" />
          </Link>
          Withdraw
        </Typography>

        {/*Main Card*/}
        <Card
          className="profile-page-card mt-5 mt-sm-0"
          sx={{ minWidth: "auto", maxWidth: "auto" }}
        >
          <CardContent className=" px-sm-3 px-md-4 px-lg-5">
            <Grid container spacing={1}>
              <Grid item xs={12} sm={12} md={6} lg={6}>
                <div className="d-block">
                  <div>
                    <label className="value fw-bold">From</label>
                  </div>
                  <div>
                    <div className="pe-4 pt-2">
                      <select
                        style={{ height: "60px" }}
                        className="BTC-Select fw-bold col-lg-9 col-sm-12"
                      >
                        <option value="bitcoin">BTC Bitcoin</option>
                      </select>
                      <span className="BTC-icon pe-2 text-dark">
                        <img
                          src={Ellipse}
                          style={{ width: "40px", height: "40px" }}
                        />
                      </span>
                    </div>
                    <div className="pe-4 pt-4">
                      <Typography
                        sx={{ fontSize: "12px" }}
                        className="fw-bold txt-head"
                      >
                        Amount
                      </Typography>
                      <Typography
                        sx={{ fontSize: "20px" }}
                        className="fw-bold value"
                      >
                        0.00000000 MX
                      </Typography>
                    </div>
                    <div className="pe-4 pt-4">
                      <Typography
                        sx={{ fontSize: "12px" }}
                        className="fw-bold txt-head"
                      >
                        Available Balance
                      </Typography>
                      <Typography
                        sx={{ fontSize: "20px" }}
                        className="fw-bold value"
                      >
                        0.00000000 MX
                      </Typography>
                    </div>
                    <div className="pe-4 pt-4">
                      <Typography
                        sx={{ fontSize: "12px" }}
                        className="fw-bold txt-head"
                      >
                        Frozen Amount
                      </Typography>
                      <Typography
                        sx={{ fontSize: "20px" }}
                        className="fw-bold value"
                      >
                        0.00000000 MX
                      </Typography>
                    </div>
                    <Box>
                      <Card className="inputQrBg mt-2" sx={{ mt: 2 }}>
                        <CardContent>
                          <Typography className="fw-bold value">
                            Notice
                          </Typography>
                          <Typography
                            className="value"
                            sx={{ fontSize: "12px" }}
                          >
                            Transaction speeds are increased and fees are
                            platform will be deposited quickly waived when you
                            transfer funds to your MEXC custodial wallet.{" "}
                          </Typography>
                          <Typography
                            className="value"
                            sx={{ fontSize: "12px" }}
                          >
                            Minimum withdrawal amount (per transaction): 25MX.
                            Maximum single withdrawal amount (per
                            transaction):11000000MX
                          </Typography>
                          <Typography
                            className="value"
                            sx={{ fontSize: "12px" }}
                          >
                            Please do not withdraw funds directly for the
                            purposes of crowdfunding or to an ICO address. MEXC
                            will not be responsible for distributing any future
                            tokens you might receive
                          </Typography>
                        </CardContent>
                      </Card>
                    </Box>
                  </div>
                </div>
              </Grid>
              <Grid item xs={12} sm={12} md={6} lg={6}>
                <Box>
                  <div className="pe-4 pt-4">
                    <Typography sx={{ fontSize: "14px" }} className="txt-head">
                      MX Available deposit blockchain
                    </Typography>
                    <Box>
                      <ul
                        className="nav nav-pills MAX-Coloured-Pills mb-3"
                        id="pills-tab"
                        role="tablist"
                      >
                        <li className="nav-item" role="presentation">
                          <button
                            className="nav-link active btn-sm me-2"
                            id="pills-home-tab"
                            data-bs-toggle="pill"
                            data-bs-target="#pills-home"
                            type="button"
                            role="tab"
                            aria-controls="pills-home"
                            aria-selected="true"
                          >
                            ERC-20
                          </button>
                        </li>
                        <li className="nav-item" role="presentation">
                          <button
                            className="nav-link btn-sm me-2"
                            id="pills-profile-tab"
                            data-bs-toggle="pill"
                            data-bs-target="#pills-home"
                            type="button"
                            role="tab"
                            aria-controls="pills-profile"
                            aria-selected="false"
                          >
                            HECO
                          </button>
                        </li>
                        <li className="nav-item" role="presentation">
                          <button
                            className="nav-link btn-sm me-2"
                            id="pills-contact-tab"
                            data-bs-toggle="pill"
                            data-bs-target="#pills-home"
                            type="button"
                            role="tab"
                            aria-controls="pills-contact"
                            aria-selected="false"
                          >
                            BEP20(BSC)
                          </button>
                        </li>
                        <li className="nav-item my-02" role="presentation">
                          <button
                            className="nav-link btn-sm"
                            id="pills-contact-tab"
                            data-bs-toggle="pill"
                            data-bs-target="#pills-home"
                            type="button"
                            role="tab"
                            aria-controls="pills-contact"
                            aria-selected="false"
                          >
                            MX-HECO
                          </button>
                        </li>
                      </ul>
                      <div className="tab-content" id="pills-tabContent">
                        <div
                          className="tab-pane fade show active"
                          id="pills-home"
                          role="tabpanel"
                          aria-labelledby="pills-home-tab"
                        >
                          <Box>
                            <div className="pt-4">
                              <div className="d-block">
                                <div className="col-lg-12">
                                  <div className="form-group mb-3">
                                    <label
                                      htmlFor="password"
                                      className="value fw-bold mb-2"
                                    >
                                      <b className="text-danger">*</b>Address
                                    </label>
                                    <div>
                                      <input
                                        placeholder="Please enter or select the withdrawal address"
                                        type="text"
                                        className="form-control txtClr inputBg"
                                      />
                                    </div>
                                  </div>
                                </div>
                                <div className="col-lg-12">
                                <label
                                      htmlFor="amount"
                                      className="value fw-bold"
                                    >Amount
                                    </label>
                                  <div class="input-group mb-1">
  <input type="text" class="form-control txtClr inputBg" placeholder="Minimum amount (per transaction) 25" aria-label="Recipient's username" aria-describedby="button-addon2"/>
  <button class="btn btn-outline-primary btn-hvr" style={{color:'#1A94AE'}} type="button" id="button-addon2">Select All</button>
</div>
<div className="txt-head d-flex justify-content-between mb-2">
                                    <Typography>Fee:10</Typography>
                                    <Typography>Received: --</Typography>
                                  </div>
                                  <div className="form-group mb-3">
                                    <label
                                      htmlFor="password"
                                      className="value fw-bold mb-2"
                                    >
                                      Withdrawal remarks (optional)
                                    </label>
                                    <div>
                                      <input
                                        placeholder="Please enter your remarks here e.g.purpose of withdrawal "
                                        type="text"
                                        className="form-control txtClr inputBg"
                                      />
                                    </div>
                                    <div className="d-grid my-3">
                                      <button
                                        className="btn"
                                        style={{
                                          background: "#1A94AE",
                                          color: "white",
                                        }}
                                        type="button"
                                      >
                                        Submit
                                      </button>
                                      <Typography
                                        className="txt-head m-1"
                                        sx={{ fontSize: "13px" }}
                                      >
                                        24-hour withdrwal limit; 0/5 BTC
                                      </Typography>
                                    </div>
                                  </div>
                                </div>
                              </div>
                            </div>
                          </Box>
                        </div>
                        <div
                          className="tab-pane fade"
                          id="pills-profile"
                          role="tabpanel"
                          aria-labelledby="pills-profile-tab"
                        >
                          ...
                        </div>
                        <div
                          className="tab-pane fade"
                          id="pills-contact"
                          role="tabpanel"
                          aria-labelledby="pills-contact-tab"
                        >
                          ...
                        </div>
                      </div>
                    </Box>
                  </div>
                </Box>
              </Grid>
            </Grid>
          </CardContent>
        </Card>
        <TableContainer
          component={Paper}
          sx={{ background: "var( --card-bg-color)" }}
          className="mt-4"
        >
          <div className="d-flex justify-content-between">
            <div>
              <Typography variant="h6" className="ps-3 py-3 APITitle">
                Recent Withdrawal records
              </Typography>
            </div>
            <div className="m-3">
              <Typography
                sx={{ color: "#1a94ae" }}
                variant="h7"
                className="APITitle"
              >
                History
              </Typography>
            </div>
          </div>

          <Table
            sx={{ minWidth: 650, background: "var( --card-bg-color)" }}
            aria-label="simple table"
          >
            <TableHead>
              <TableRow
                sx={{
                  border: "1px solid var(--input-qr-bg)",
                  borderRight: 0,
                  borderLeft: 0,
                }}
              >
                <TableCell
                  sx={{ fontWeight: "bolder !important", borderBottom: 0 }}
                  className="textClr"
                  align="center"
                >
                  Crypto
                </TableCell>
                <TableCell
                  sx={{ fontWeight: "bolder !important", borderBottom: 0 }}
                  className="textClr"
                  align="center"
                >
                  Time
                </TableCell>
                <TableCell
                  sx={{ fontWeight: "bolder !important", borderBottom: 0 }}
                  className="textClr"
                  align="center"
                >
                  Status
                </TableCell>
                <TableCell
                  sx={{ fontWeight: "bolder !important", borderBottom: 0 }}
                  className="textClr"
                  align="center"
                >
                  Amount
                </TableCell>
                <TableCell
                  sx={{ fontWeight: "bolder !important", borderBottom: 0 }}
                  className="textClr"
                  align="center"
                >
                  Withdraw Address
                </TableCell>
                <TableCell
                  sx={{ fontWeight: "bolder !important", borderBottom: 0 }}
                  className="textClr"
                  align="center"
                >
                  Fee
                </TableCell>
                <TableCell
                  sx={{ fontWeight: "bolder !important", borderBottom: 0 }}
                  className="textClr"
                  align="center"
                >
                  Balance
                </TableCell>
                <TableCell
                  sx={{ fontWeight: "bolder !important", borderBottom: 0 }}
                  className="textClr"
                  align="center"
                >
                  Action
                </TableCell>
              </TableRow>
            </TableHead>
            <TableBody>
              <TableRow
                sx={{ "&:last-child td, &:last-child th": { border: 0 } }}
              >
                <TableCell
                  align="center"
                  colSpan={8}
                  sx={{ justifyContent: "center", alignItems: "center" }}
                  className="my-4"
                >
                  <img src={NODATA} />
                </TableCell>
              </TableRow>
            </TableBody>
          </Table>
        </TableContainer>
      </Container>
    </div>
  );
};
export default AccountWithdraw;
