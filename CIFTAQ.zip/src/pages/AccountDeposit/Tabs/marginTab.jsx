import React, { useState } from "react";
import {
  Avatar,
  Box,
  Button,
  Paper,
  Table,
  TableBody,
  TableCell,
  TableContainer,
  TableHead,
  TableRow,
} from "@mui/material";
import Card from "@mui/material/Card";
import CardContent from "@mui/material/CardContent";
import { Container } from "@mui/system";
import {
  Checkbox,
  Grid,
  ListItemButton,
  ListItemIcon,
  ListItemText,
  Typography,
} from "@mui/material";
import VisibilityIcon from "@mui/icons-material/Visibility";
import dougnutData from "../../../components/assets/images/dougnutData.png";
import fromBlue from "../../../components/assets/images/formBlue.png";
import fromViolet from "../../../components/assets/images/formViolet.png";
import FormControlLabel from "@mui/material/FormControlLabel";
import Switch from "@mui/material/Switch";
import Tab from "@mui/material/Tab";
import { TabPanel, TabList, TabContext } from "@mui/lab";
import { styled } from "@mui/material/styles";
import { makeStyles } from "@mui/styles";
import SearchIcon from "@mui/icons-material/Search";
import { Tabs } from "@mui/material";
import CoinImage from "../../../components/assets/images/coinImage.png";
import "../index.css";
import ExchageModal from "../../../components/AssetExchangeModal/indx";
import LoanModel from "../../../components/LoanModel/loan";
import AssetTransferModel from "../../../components/AssetTransferModel/assetTransfer";
import RepaymentModel from "../../../components/RepaymentModel/repaymentModel";
export default function MarginTab() {
  const data = ["1", "2", "3"];
  //Loan Modal
  const [openLoanModal, setOpenLoanModal] = React.useState(false);

  const handleLoanClickOpen = () => {
    setOpenLoanModal(true);
  };

  const handleLoanClose = () => {
    setOpenLoanModal(false);
  };
  //ASSET TRANSFER MODEL
  const [openAssetTransferModal, setOpenAssetTransferModal] = React.useState(false);
  const handleAssetsClickOpen = () => {
    setOpenAssetTransferModal(true);
  };

  const handleAssetsClose = () => {
    setOpenAssetTransferModal(false);
  };
  //Repayment Model
  const [openRepaymentModal, setOpenRepaymentModal] =
    React.useState(false);

  const handleRepaymentOpen = () => {
    setOpenRepaymentModal(true);
  };
  const handleRepaymentClose = () => {
    setOpenRepaymentModal(false);
  };
  return (
    <>
      <RepaymentModel
        openRepaymentModal={openRepaymentModal}
        handleRepaymentOpen={handleRepaymentOpen}
        handleRepaymentClose={handleRepaymentClose}
      />
      <AssetTransferModel openAssetTransferModal={openAssetTransferModal} handleAssetsClickOpen={handleAssetsClickOpen} handleAssetsClose={handleAssetsClose}/>
      <LoanModel
        openLoanModal={openLoanModal}
        handleClickOpen={handleLoanClickOpen}
        handleClose={handleLoanClose}
      />
      <div className="d-sm-flex justify-content-sm-between">
        <ul
          className="nav nav-pills mb-3 d-flex"
          id="depositTableTab"
          role="tablist"
        >
          <li className="nav-item" role="presentation">
            <button
              className="nav-link greenTab active"
              data-bs-toggle="pill"
              data-bs-target="#MarginAssetTab"
              type="button"
              role="tab"
            >
              Margin asset
            </button>
          </li>
          <li className="nav-item pe-2" role="presentation">
            <button
              className="nav-link greenTab"
              data-bs-toggle="pill"
              data-bs-target="#TransferDetailTab"
              type="button"
              role="tab"
            >
              Transfer details
            </button>
          </li>
        </ul>
        <div className="mb-2 mb-sm-0">
          <input
            type="text"
            id="searchBar"
            className="form-control input-typing-space seachbar-bg"
            placeholder="Search Token"
          />
          <span className="search-iconProp pe-2 text-dark">
            <SearchIcon className="search-icon-color" />
          </span>
        </div>
      </div>
      <div class="tab-content">
        <div
          class="tab-pane fade show active"
          id="MarginAssetTab"
          role="tabpanel"
          aria-labelledby="pills-home-tab"
          tabindex="0"
        >
          <TableContainer>
            <Table
              sx={{ minWidth: 650 }}
              aria-label="simple table"
              className="table-color px-3"
            >
              <TableHead className="headerbg">
                <TableRow
                  sx={{
                    border: "1px solid grey",
                    borderTop: 0,
                    borderRight: 0,
                    borderLeft: 0,
                  }}
                >
                  <TableCell
                    sx={{ fontWeight: "bolder !important" }}
                    align="start"
                    className="tableHead"
                  >
                    Token
                  </TableCell>
                  <TableCell
                    sx={{ fontWeight: "bolder !important" }}
                    align="center"
                    className="tableHead"
                  >
                    Amount
                  </TableCell>
                  <TableCell
                    sx={{ fontWeight: "bolder !important" }}
                    align="center"
                    className="tableHead"
                  >
                    Available Balance
                  </TableCell>
                  <TableCell
                    sx={{ fontWeight: "bolder !important" }}
                    align="center"
                    className="tableHead"
                  >
                    Frozen Amount
                  </TableCell>
                  <TableCell
                    sx={{ fontWeight: "bolder !important" }}
                    align="center"
                    className="tableHead"
                  >
                    Loaned
                  </TableCell>
                  <TableCell
                    sx={{ fontWeight: "bolder !important" }}
                    align="center"
                    className="tableHead"
                  >
                    Risk rate
                  </TableCell>
                  <TableCell
                    sx={{ fontWeight: "bolder !important" }}
                    align="center"
                    className="tableHead"
                  >
                    Liquidation Price
                  </TableCell>
                  <TableCell
                    sx={{ fontWeight: "bolder !important" }}
                    align="center"
                    className="tableHead"
                  >
                    Action
                  </TableCell>
                </TableRow>
              </TableHead>
              <TableBody>
                {data.map((data) => (
                  <TableRow
                    sx={{ "&:last-child td, &:last-child th": { border: 0 } }}
                  >
                    <TableCell className="text-color-account" align="center">
                      CEEK/USDT
                    </TableCell>
                    <TableCell
                      sx={{ fontWeight: "bolder !important" }}
                      align="center"
                      className="text-color-account"
                    >
                      <div>
                        <Typography className="sizeText">
                          0.00000000 CEEK
                        </Typography>
                        <Typography className="sizeText">
                          0.00000000 USDT
                        </Typography>
                      </div>
                    </TableCell>
                    <TableCell
                      sx={{ fontWeight: "bolder !important" }}
                      align="center"
                      className="text-color-account"
                    >
                      <div>
                        <Typography className="sizeText">
                          0.00000000 CEEK
                        </Typography>
                        <Typography className="sizeText">
                          0.00000000 USDT
                        </Typography>
                      </div>
                    </TableCell>
                    <TableCell
                      sx={{ fontWeight: "bolder !important" }}
                      align="center"
                      className="text-color-account"
                    >
                      <div>
                        <Typography className="sizeText">
                          0.00000000 CEEK
                        </Typography>
                        <Typography className="sizeText">
                          0.00000000 USDT
                        </Typography>
                      </div>
                    </TableCell>
                    <TableCell
                      sx={{ fontWeight: "bolder !important" }}
                      align="center"
                      className="text-color-account"
                    >
                      <div>
                        <Typography className="sizeText">
                          0.00000000 CEEK
                        </Typography>
                        <Typography className="sizeText">
                          0.00000000 USDT
                        </Typography>
                      </div>
                    </TableCell>
                    <TableCell
                      sx={{ fontWeight: "bolder !important" }}
                      align="center"
                      className="text-color-account sizeText"
                    >
                      0.00%
                    </TableCell>
                    <TableCell
                      sx={{ fontWeight: "bolder !important" }}
                      align="center"
                      className="text-color-account sizeText"
                    >
                      0
                    </TableCell>
                    <TableCell
                      sx={{ fontWeight: "bolder !important" }}
                      align="center"
                      className="tableHead"
                    >
                      <Box className="d-flex justify-content-center">
                        <Typography
                          onClick={() => {
                            handleAssetsClickOpen();
                          }}
                          className="text-blue tablelastData sizeText"
                        role="button">
                          Transfer
                        </Typography>
                        <Typography
                          onClick={() => {
                            handleLoanClickOpen();
                          }}
                          className="text-blue tablelastData sizeText"
                          role="button"
                        >
                          Loan 
                        </Typography>
                        <Typography   onClick={() => {
                            handleRepaymentOpen();
                          }} className="text-blue paddingStart sizeText text-nowrap"  role="button">
                          Repayment Trade
                        </Typography>
                      </Box>
                    </TableCell>
                  </TableRow>
                ))}
              </TableBody>
            </Table>
          </TableContainer>
        </div>
        <div
          class="tab-pane"
          id="TransferDetailTab"
          role="tabpanel"
          aria-labelledby="pills-home-tab"
          tabindex="0"
        ></div>
      </div>
    </>
  );
}
