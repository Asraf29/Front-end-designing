import React, { useState } from 'react'
import { Avatar, Box, Button, Paper, Table, TableBody, TableCell, TableContainer, TableHead, TableRow } from "@mui/material";
import Card from "@mui/material/Card";
import CardContent from "@mui/material/CardContent";
import { Container } from "@mui/system";
import { Checkbox, Grid, ListItemButton, ListItemIcon, ListItemText, Typography } from '@mui/material';
import VisibilityIcon from '@mui/icons-material/Visibility';
import dougnutData from "../../../components/assets/images/dougnutData.png"
import fromBlue from "../../../components/assets/images/formBlue.png"
import fromViolet from "../../../components/assets/images/formViolet.png"
import FormControlLabel from "@mui/material/FormControlLabel";
import Switch from "@mui/material/Switch";
import Tab from "@mui/material/Tab";
import { TabPanel, TabList, TabContext } from "@mui/lab";
import { styled } from "@mui/material/styles";
import { makeStyles } from "@mui/styles";
import SearchIcon from "@mui/icons-material/Search";
import { Tabs } from "@mui/material";
import CoinImage from "../../../components/assets/images/coinImage.png"
import '../index.css'
import ExchageModal from '../../../components/AssetExchangeModal/indx';
import NODATA from "../../../components/assets/images/nodata.png";
export default function FuturesTab() {
    const data = ['1', '2', '3'];
  return (
    <>
        <div className="d-sm-flex justify-content-sm-between">
                  <ul
                    className="nav nav-pills mb-3 d-flex"
                    id="depositTableTab"
                    role="tablist"
                  >
                    <li className="nav-item" role="presentation">
                      <button
                        className="nav-link greenTab active"
                        data-bs-toggle="pill"
                        data-bs-target="#FuturesAssetTab"
                        type="button"
                        role="tab"
                      >
                        Futures asset
                      </button>
                    </li>
                    <li className="nav-item pe-2" role="presentation">
                      <button
                        className="nav-link greenTab"
                        data-bs-toggle="pill"
                        data-bs-target="#TransferTab"
                        type="button"
                        role="tab"
                      >
                        Transfer details
                      </button>
                    </li>
                  </ul>
                  <div className="mb-2 mb-sm-0">
                    <input
                      type="text"
                      id="searchBar"
                      className="form-control input-typing-space seachbar-bg"
                      placeholder="Search Token"
                    />
                    <span className="search-iconProp pe-2 text-dark">
                      <SearchIcon className="search-icon-color" />
                    </span>
                  </div>
                </div>
                <div class="tab-content">
                  <div
                    class="tab-pane fade show active"
                    id="FuturesAssetTab"
                    role="tabpanel"
                    aria-labelledby="pills-home-tab"
                    tabindex="0"
                  >
                    <TableContainer>
                      <Table
                        sx={{ minWidth: 650 }}
                        aria-label="simple table"
                        className="table-color px-3"
                      >
                        <TableHead className="headerbg">
                          <TableRow
                            sx={{
                              border: "1px solid grey",
                              borderTop: 0,
                              borderRight: 0,
                              borderLeft: 0,
                            }}
                          >
                            <TableCell
                              sx={{ fontWeight: "bolder !important" }}
                              align="start"
                              className="tableHead"
                            >
                              Token
                            </TableCell>
                            <TableCell
                              sx={{ fontWeight: "bolder !important" }}
                              align="center"
                              className="tableHead"
                            >
                              Total equity
                            </TableCell>
                            <TableCell
                              sx={{ fontWeight: "bolder !important" }}
                              align="center"
                              className="tableHead"
                            >
                              Wallet balance
                            </TableCell>
                            <TableCell
                              sx={{ fontWeight: "bolder !important" }}
                              align="center"
                              className="tableHead"
                            >
                              unrealized Profit/Loss
                            </TableCell>
                            <TableCell
                              sx={{ fontWeight: "bolder !important" }}
                              align="center"
                              className="tableHead"
                            >
                              Position margin
                            </TableCell>
                            <TableCell
                              sx={{ fontWeight: "bolder !important" }}
                              align="center"
                              className="tableHead"
                            >
                              Order margin
                            </TableCell>
                            <TableCell
                              sx={{ fontWeight: "bolder !important" }}
                              align="center"
                              className="tableHead"
                            >
                              Available balance
                            </TableCell>
                            <TableCell
                              sx={{ fontWeight: "bolder !important" }}
                              align="center"
                              className="tableHead"
                            >
                              Net-asset balance
                            </TableCell>
                            <TableCell
                              sx={{ fontWeight: "bolder !important" }}
                              align="center"
                              className="tableHead"
                            >
                              Trial fund
                            </TableCell>
                            <TableCell
                              sx={{ fontWeight: "bolder !important" }}
                              align="center"
                              className="tableHead"
                            >
                              Action
                            </TableCell>
                          </TableRow>
                        </TableHead>
                        <TableBody>
                          {data.map((data) => (
                            <TableRow
                              sx={{
                                "&:last-child td, &:last-child th": {
                                  border: 0,
                                },
                              }}
                            >
                              <TableCell
                                className="text-color-account"
                                align="center"
                              >
                                USDT
                              </TableCell>
                              <TableCell
                                sx={{ fontWeight: "bolder !important" }}
                                align="center"
                                className="text-color-account"
                              >
                                0.00000000
                              </TableCell>
                              <TableCell
                                sx={{ fontWeight: "bolder !important" }}
                                align="center"
                                className="text-color-account"
                              >
                                0.00000000
                              </TableCell>
                              <TableCell
                                sx={{ fontWeight: "bolder !important" }}
                                align="center"
                                className="text-color-account"
                              >
                                0.00000000
                              </TableCell>
                              <TableCell
                                sx={{ fontWeight: "bolder !important" }}
                                align="center"
                                className="text-color-account"
                              >
                                0.00000000
                              </TableCell>
                              <TableCell
                                sx={{ fontWeight: "bolder !important" }}
                                align="center"
                                className="text-color-account sizeText"
                              >
                                0.00000000
                              </TableCell>
                              <TableCell
                                sx={{ fontWeight: "bolder !important" }}
                                align="center"
                                className="text-color-account sizeText"
                              >
                                0.00000000
                              </TableCell>
                              <TableCell
                                sx={{ fontWeight: "bolder !important" }}
                                align="center"
                                className="text-color-account sizeText"
                              >
                                0.00000000
                              </TableCell>
                              <TableCell
                                sx={{ fontWeight: "bolder !important" }}
                                align="center"
                                className="text-color-account sizeText"
                              >
                                0.00000000
                              </TableCell>
                              <TableCell
                                sx={{ fontWeight: "bolder !important" }}
                                align="center"
                                className="tableHead"
                              >
                                <Box className="d-flex justify-content-center">
                                  <Typography className="text-blue tablelastData sizeText">
                                    Transfer
                                  </Typography>
                                  <Typography className="text-blue paddingStart sizeText text-nowrap">
                                    Trade
                                  </Typography>
                                </Box>
                              </TableCell>
                            </TableRow>
                          ))}
                        </TableBody>
                      </Table>
                    </TableContainer>
                  </div>
                  <div
                    class="tab-pane"
                    id="TransferTab"
                    role="tabpanel"
                    aria-labelledby="pills-home-tab"
                    tabindex="0"
                  ></div>
                </div>
    </>
  )
}
