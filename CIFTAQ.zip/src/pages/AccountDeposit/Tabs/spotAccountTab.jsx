import React, { useState } from 'react'
import { Avatar, Box, Button, Paper, Table, TableBody, TableCell, TableContainer, TableHead, TableRow } from "@mui/material";
import Card from "@mui/material/Card";
import CardContent from "@mui/material/CardContent";
import { Container } from "@mui/system";
import { Checkbox, Grid, ListItemButton, ListItemIcon, ListItemText, Typography } from '@mui/material';
import VisibilityIcon from '@mui/icons-material/Visibility';
import dougnutData from "../../../components/assets/images/dougnutData.png"
import fromBlue from "../../../components/assets/images/formBlue.png"
import fromViolet from "../../../components/assets/images/formViolet.png"
import FormControlLabel from "@mui/material/FormControlLabel";
import Switch from "@mui/material/Switch";
import Tab from "@mui/material/Tab";
import { TabPanel, TabList, TabContext } from "@mui/lab";
import { styled } from "@mui/material/styles";
import { makeStyles } from "@mui/styles";
import SearchIcon from "@mui/icons-material/Search";
import { Tabs } from "@mui/material";
import CoinImage from "../../../components/assets/images/coinImage.png"
import '../index.css'
import ExchageModal from '../../../components/AssetExchangeModal/indx';
import NODATA from "../../../components/assets/images/nodata.png";
//Exchange Modal 
const data = ['1', '2', '3'];
export default function SpotAccountTab() {
    //Exchange Modal
    const [openExchangeModal, setOpenExchangeModal] = React.useState(false);

    const handleClickOpen = () => {
        setOpenExchangeModal(true);
    };

    const handleClose = () => {
        setOpenExchangeModal(false);
    };

    return (
        <>
            <ExchageModal openExchangeModal={openExchangeModal} handleClickOpen={handleClickOpen} handleClose={handleClose} />
            <div className="d-lg-flex justify-content-lg-between">
                <ul className="nav nav-pills my-3 d-flex" id="depositTableTab" role="tablist">
                    <li className="nav-item" role="presentation">
                        <button className="nav-link greenTab active" data-bs-toggle="pill" data-bs-target="#AllTab" type="button" role="tab">All</button>
                    </li>
                    <li className="nav-item" role="presentation">
                        <button className="nav-link greenTab" data-bs-toggle="pill" data-bs-target="#MainTab" type="button" role="tab">Main</button>
                    </li>
                    <li className="nav-item" role="presentation">
                        <button className="nav-link greenTab" data-bs-toggle="pill" data-bs-target="#InnovationTab" type="button" role="tab">Innovation</button>
                    </li>
                    <li className="nav-item" role="presentation">
                        <button className="nav-link greenTab" data-bs-toggle="pill" data-bs-target="#AssessmentTab" type="button" role="tab">Assessment</button>
                    </li>
                    <li className="nav-item" role="presentation">
                        <button className="nav-link greenTab" data-bs-toggle="pill" data-bs-target="#FIATTab" type="button" role="tab">FIAT</button>
                    </li>
                    <li className="nav-item pe-2" role="presentation">
                        <button className="nav-link greenTab" data-bs-toggle="pill" data-bs-target="#Off-shelfTab" type="button" role="tab">Off-shelf</button>
                    </li>
                    <div>
                        <input
                            type="text"
                            id="searchBar"
                            className="form-control input-typing-space seachbar-bg"
                            placeholder="Search Token"
                        />
                        <span className="search-iconProp pe-2 text-dark">
                            <SearchIcon className="search-icon-color" />
                        </span>
                    </div>
                </ul>
                <div className='d-flex align-items-center' >
                    <div>
                        <ListItemButton className="listBtn">
                            <ListItemIcon className="margin-right0 mb-1">
                                <Checkbox edge="start" tabIndex={-1} disableRipple />
                            </ListItemIcon>
                            <ListItemText className="textClr" primary={'Hide small assets'} />
                        </ListItemButton>
                    </div>
                    <div><Typography className="text-blue fontSize-14px" role="button" onClick={() => { handleClickOpen() }}>Exchange your Crypto for MX</Typography></div>
                </div>
            </div>
            <div class="tab-content">
                <div class="tab-pane fade show active" id="AllTab" role="tabpanel" aria-labelledby="pills-home-tab" tabindex="0">
                    <TableContainer>
                        <Table sx={{ minWidth: 650 }} aria-label="simple table" className='table-color px-3'>
                            <TableHead className="headerbg">
                                <TableRow sx={{ border: "1px solid grey", borderTop: 0, borderRight: 0, borderLeft: 0 }}>
                                    <TableCell sx={{ fontWeight: "bolder !important" }} align="start" className="tableHead">
                                        Token
                                    </TableCell>
                                    <TableCell sx={{ fontWeight: "bolder !important" }} align="center" className="tableHead">
                                        Available Balance
                                    </TableCell>
                                    <TableCell sx={{ fontWeight: "bolder !important" }} align="center" className="tableHead">
                                        Frozen Amount
                                    </TableCell>
                                    <TableCell sx={{ fontWeight: "bolder !important" }} align="start" className="tableHead">
                                        USDT
                                    </TableCell>
                                    <TableCell sx={{ fontWeight: "bolder !important" }} align="right" className="tableHead">
                                        Action
                                    </TableCell>
                                </TableRow>
                            </TableHead>
                            <TableBody>
                                {data.map((data) => (<TableRow sx={{ "&:last-child td, &:last-child th": { border: 0 } }}>
                                    <TableCell className='text-color-account' align="center">
                                        <Box className="d-flex">
                                            <Avatar alt="Coin-Image" src={CoinImage} />
                                            <div>
                                                <Typography className='text-color-account'>BTC</Typography>
                                                <Typography className="textClr ps-3">Bitcoin</Typography>
                                            </div>
                                        </Box>
                                    </TableCell>
                                    <TableCell sx={{ fontWeight: "bolder !important" }} align="center" className="text-color-account">
                                        0.00000000
                                    </TableCell>
                                    <TableCell sx={{ fontWeight: "bolder !important" }} align="center" className="text-color-account">
                                        0.00000000
                                    </TableCell>
                                    <TableCell sx={{ fontWeight: "bolder !important" }} align="start" className="text-color-account">
                                        0.00000000
                                    </TableCell>
                                    <TableCell sx={{ fontWeight: "bolder !important" }} align="right" className="tableHead">
                                        <Box className="d-flex justify-content-end">
                                            <Typography className="text-blue tablelastData">POS</Typography>
                                            <Typography className="text-blue tablelastData">Exchange</Typography>
                                            <Typography className="text-blue tablelastData">Deposit</Typography>
                                            <Typography className="text-blue tablelastData">Withdraw</Typography>
                                            <Typography className="text-blue paddingStart">Trade</Typography>
                                        </Box>
                                    </TableCell>
                                </TableRow>))}
                            </TableBody>
                        </Table>
                    </TableContainer>
                </div>
                <div class="tab-pane" id="MainTab" role="tabpanel" aria-labelledby="pills-home-tab" tabindex="0"></div>
            </div>
        </>
    )
}
