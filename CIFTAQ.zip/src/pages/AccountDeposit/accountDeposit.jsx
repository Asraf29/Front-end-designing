import React, { useState } from "react";
import {
  Avatar,
  Box,
  Button,
  Paper,
  Table,
  TableBody,
  TableCell,
  TableContainer,
  TableHead,
  TableRow,
} from "@mui/material";
import Card from "@mui/material/Card";
import CardContent from "@mui/material/CardContent";
import { Container } from "@mui/system";
import {
  Checkbox,
  Grid,
  ListItemButton,
  ListItemIcon,
  ListItemText,
  Typography,
} from "@mui/material";
import VisibilityIcon from "@mui/icons-material/Visibility";
import dougnutData from "../../components/assets/images/dougnutData.png";
import fromBlue from "../../components/assets/images/formBlue.png";
import fromViolet from "../../components/assets/images/formViolet.png";
import FormControlLabel from "@mui/material/FormControlLabel";
import Switch from "@mui/material/Switch";
import Tab from "@mui/material/Tab";
import { TabPanel, TabList, TabContext } from "@mui/lab";
import { styled } from "@mui/material/styles";
import { makeStyles } from "@mui/styles";
import SearchIcon from "@mui/icons-material/Search";
import { Tabs } from "@mui/material";
import CoinImage from "../../components/assets/images/coinImage.png";
import "./index.css";
import ExchageModal from "../../components/AssetExchangeModal/indx";
import NODATA from "../../components/assets/images/nodata.png";
import SpotAccountTab from "./Tabs/spotAccountTab";
import FiatTab from "./Tabs/fiatTab";
import MarginTab from "./Tabs/marginTab";
import FuturesTab from "./Tabs/futuresTab";
const data = ["1", "2", "3"];

const Android12Switch = styled(Switch)(({ theme }) => ({
  padding: 8,
  "& .MuiSwitch-track": {
    borderRadius: 22 / 2,
    "&:before, &:after": {
      content: '""',
      position: "absolute",
      top: "50%",
      transform: "translateY(-50%)",
      width: 16,
      height: 16,
    },
    "&:before": {
      backgroundImage: `url('data:image/svg+xml;utf8,<svg xmlns="http://www.w3.org/2000/svg" height="16" width="16" viewBox="0 0 24 24"><path fill="${encodeURIComponent(
        theme.palette.getContrastText(theme.palette.primary.main)
      )}" d="M21,7L9,19L3.5,13.5L4.91,12.09L9,16.17L19.59,5.59L21,7Z"/></svg>')`,
      center: 12,
    },
    "&:after": {
      backgroundImage: `url('data:image/svg+xml;utf8,<svg xmlns="http://www.w3.org/2000/svg" height="16" width="16" viewBox="0 0 24 24"><path fill="${encodeURIComponent(
        theme.palette.getContrastText(theme.palette.primary.main)
      )}" d="M19,13H5V11H19V13Z" /></svg>')`,
      right: 12,
    },
  },
  "& .MuiSwitch-thumb": {
    boxShadow: "none",
    width: 16,
    height: 16,
    margin: 2,
  },
}));
// Tab Switch;
const useStyles = makeStyles({
  MUITab: {
    color: "var(--Tab-gray-text) !important",
    fontSize: "18px !important",
  },
});
const AccountDeposit = () => {
  const [value, setValue] = React.useState("1");
  const handleChange = (event, newValue) => {
    setValue(newValue);
  };
  const classes = useStyles();

  return (
    <div>
      <Container sx={{ mb: 7 }}>
        {/* Referral History common  Card*/}
        <Card className="profile-page-card" sx={{ mt: 3 }}>
          <Box className="px-4">
            <Box className="py-3 d-block d-lg-flex justify-content-lg-between align-items-lg-center">
              <div>
                <Typography className="textClr px-2 px-sm-3 px-lg-0 mb-2 mb-lg-0">
                  Total Balance
                  <VisibilityIcon className="textClr  mb-2 ms-" />
                </Typography>
                <Box className="d-flex align-items-center">
                  <Typography
                    className="text-color-account fw-bold ps-sm-3 ps-lg-0"
                    variant="h5"
                  >
                    0.00000000 BTC
                  </Typography>
                  <Typography className="ms-2 grayText">--USD</Typography>
                </Box>
              </div>
              <div className=" d-block d-sm-flex align-items-sm-center px-lg-2 mt-2 mt-md-3 mt-lg-0 px-md-3 px-lg-0 px-lg-0">
                <ul
                  className="nav nav-pills mb-3"
                  id="depositeTab"
                  role="tablist"
                >
                  <li className="nav-item me-2  me-lg-3" role="presentation">
                    <button
                      className="textColors nav-link active"
                      data-bs-toggle="pill"
                      data-bs-target="#depositTab"
                      type="button"
                      role="tab"
                    >
                      Deposit
                    </button>
                  </li>
                  <li className="nav-item me-2 me-lg-3" role="presentation">
                    <button
                      className="textColors nav-link"
                      data-bs-toggle="pill"
                      data-bs-target="#depositTab"
                      type="button"
                      role="tab"
                    >
                      Withdraw
                    </button>
                  </li>
                  <li className="nav-item me-2 me-lg-3" role="presentation">
                    <button
                      className="textColors  nav-link marginTop-1"
                      data-bs-toggle="pill"
                      data-bs-target="#depositTab"
                      type="button"
                      role="tab"
                    >
                      Transfer
                    </button>
                  </li>
                  <li className="nav-item " role="presentation">
                    <button
                      className="textColors nav-link marginTop-1 margin-top-1-sm"
                      data-bs-toggle="pill"
                      data-bs-target="#depositTab"
                      type="button"
                      role="tab"
                    >
                      Loop Alliance
                    </button>
                  </li>
                </ul>
              </div>
            </Box>
            <div className="tab-content" id="pills-tabContent">
              <div
                className="tab-pane fade"
                id="todayTab"
                role="tabpanel"
              ></div>
              <div
                className="tab-pane fade"
                id="thisWeekTab"
                role="tabpanel"
              ></div>
              <div
                className="tab-pane fade show active"
                id="depositTab"
                role="tabpanel"
              >
                {/* Account Deposit Graph Card*/}
                <Grid container sx={{ my: 3 }}>
                  <Grid
                    item
                    xs={12}
                    sm={12}
                    md={2}
                    lg={2}
                    className="d-flex justify-content-center justify-content-lg-start"
                  >
                    <Box
                      component="img"
                      alt="graph"
                      src={dougnutData}
                      className="img-fluid dougnutSize"
                    />
                  </Grid>
                  <Grid item xs={12} sm={12} md={10} lg={10}>
                    <Grid container>
                      <Grid
                        item
                        xs={6}
                        sm={12}
                        md={12}
                        lg={12}
                        className="mt-3 mt-lg-0  d-lg-flex  justify-content-lg-around"
                      >
                        <Card
                          className="card-bg-green card-graphs"
                          sx={{ minWidth: "auto", maxWidth: "auto" }}
                        >
                          <CardContent className="text-center text-lg-start ">
                            <ul className="pl-1rem list-style">
                              <li className="card-title greenBullet">
                                Spot account
                              </li>
                            </ul>
                            <Typography variant="h5" className="fw-bold">
                              0.00000000 BTC
                            </Typography>
                            <Typography className="cardGrayText">
                              --USD
                            </Typography>
                          </CardContent>
                        </Card>
                        <Card
                          className="card-bg-green  card-graphs mt-2 mt-lg-0"
                          sx={{ minWidth: "auto", maxWidth: "auto" }}
                        >
                          <CardContent className="text-center text-lg-start">
                            <ul className="pl-1rem list-style">
                              <li className="card-title yellowBullet">
                                Fiat account
                              </li>
                            </ul>
                            <Typography variant="h5" className="fw-bold">
                              0.00000000 BTC
                            </Typography>
                            <Typography className="cardGrayText">
                              --USD
                            </Typography>
                          </CardContent>
                        </Card>
                        <Card
                          className="card-bg-green  card-graphs mt-2 mt-lg-0"
                          sx={{ minWidth: "auto", maxWidth: "auto" }}
                        >
                          <CardContent className="text-center text-lg-start">
                            <ul className="pl-1rem list-style">
                              <li className="card-title skyblueBullet">
                                Fiat account
                              </li>
                            </ul>
                            <Typography variant="h5" className="fw-bold">
                              0.00000000 BTC
                            </Typography>
                            <Typography className="cardGrayText">
                              --USD
                            </Typography>
                          </CardContent>
                        </Card>
                        <Card
                          className="card-bg-green  card-graphs mt-2 mt-lg-0"
                          sx={{ minWidth: "auto", maxWidth: "auto" }}
                        >
                          <CardContent className="text-center text-lg-start">
                            <ul className="pl-1rem list-style">
                              <li className="card-title blueBullet">
                                Fiat account
                              </li>
                            </ul>
                            <Typography variant="h5" className="fw-bold">
                              0.00000000 BTC
                            </Typography>
                            <Typography className="cardGrayText">
                              --USD
                            </Typography>
                          </CardContent>
                        </Card>
                      </Grid>
                    </Grid>
                  </Grid>
                </Grid>
                <hr className="border-bottom-divider" />
              </div>
            </div>
          </Box>
          <Box className="d-lg-flex justify-content-lg-between px-4">
            <div className="d-flex">
              <Typography className="mb-3 text-color-account fw-bold">
                Your spot trading fee rate
              </Typography>
              <Typography className="ms-5 text-color-account">
                <img alt="form" src={fromBlue} className="pe-2" />
                Maker: 0.200%
              </Typography>
              <Typography className=" ms-2 text-color-account">
                <img alt="form" src={fromViolet} className="pe-2" />
                Maker: 0.200%
              </Typography>
            </div>
            <div className="d-flex align-items-center">
              <Typography className="mb-3 text-color-account fw-bold pe-3">
                Available MX 0.00000000
              </Typography>
              <div className="mb-3">
                <FormControlLabel
                  control={
                    <Android12Switch className="fw-bold" defaultChecked />
                  }
                  className="PushLabel accordion-txts"
                />
              </div>
            </div>
          </Box>
        </Card>
        {/* Tables */}
        <Card
          className="profile-page-card mt-3"
          sx={{ minWidth: "auto", maxWidth: "auto" }}
        >
          <CardContent>
            <TabContext value={value}>
              <Container className="paddingZero">
                <Box className="container-fluid d-lg-flex justify-content-lg-between mb-0">
                  <Tabs
                    value={value}
                    onChange={handleChange}
                    variant="scrollable"
                    scrollButtons="auto"
                    aria-label="scrollable auto tabs example"
                  >
                    <Tab
                      className={classes.MUITab}
                      label="Spot account"
                      value="1"
                    />
                    <Tab
                      className={classes.MUITab}
                      label="Fiat account"
                      value="2"
                    />
                    <Tab
                      className={classes.MUITab}
                      label="Margin account"
                      value="3"
                    />
                    <Tab
                      className={classes.MUITab}
                      label="Futures account"
                      value="4"
                    />
                  </Tabs>
                  <div className="d-flex align-items-center">
                    <div>
                      <ListItemButton className="listBtn">
                        <ListItemIcon className="margin-right0 mb-1">
                          <Checkbox edge="start" tabIndex={-1} disableRipple />
                        </ListItemIcon>
                        <ListItemText
                          className="textClr"
                          primary={"Hide small assets"}
                        />
                      </ListItemButton>
                    </div>
                    <div>
                      <Typography className="text-blue">Records</Typography>
                    </div>
                  </div>
                </Box>
              </Container>
              {/* All Tab Table */}
              {/* Spot Account */}
              <TabPanel value="1" className="py-0">
                <SpotAccountTab />
              </TabPanel>
              {/* Flat Account */}
              <TabPanel value="2" className="py-0">
                <FiatTab />
              </TabPanel>
              {/* Margin Account */}
              <TabPanel value="3">
                <MarginTab />
              </TabPanel>
              {/* Futures Account */}
              <TabPanel value="4">
            <FuturesTab/>
              </TabPanel>
            </TabContext>
          </CardContent>
        </Card>
      </Container>
    </div>
  );
};
export default AccountDeposit;
