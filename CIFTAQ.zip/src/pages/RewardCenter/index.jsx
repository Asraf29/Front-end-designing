import React, { useState } from 'react'
import Card from "@mui/material/Card";
import CardContent from "@mui/material/CardContent";
import { Box, Container } from "@mui/system";
import rewardBox from "../../components/assets/images/rewardBox.png"
import LockIcon from '@mui/icons-material/Lock';
import StarsIcon from '@mui/icons-material/Stars';
import LogoutIcon from '@mui/icons-material/Logout';
import './index.css'
import { Button, Typography } from '@mui/material';
const data = ['1', '2', '3'];


const RewardCenter = () => {
    return (
        <div>
            <Container sx={{ mb: 7 }}>
                <Box className="d-md-flex justify-content-md-between align-items-center">
                    <div className='text-center mt-3 text-sm-start mt-sm-0'>
                        <Typography className='text-prop' variant="h3">MEXC beginner tasks</Typography>
                        <Typography className="text-prop-sub my-2">Complete assigned tasks and receive<span className="textYellow ps-1">free bonuses for futures trading</span> </Typography>
                    </div>
                    <div>
                        <Box component="img" alt="topbar-bg" src={rewardBox} className="reawrdBox_Size img-fluid" />
                    </div>
                </Box>
                {/*Reward Center Main Card */}
                <Card className="profile-page-card mt-3 mt-sm-0" sx={{ minWidth: "auto", maxWidth: "auto" }}>
                    <CardContent className="px-sm-4 my-3">
                        <Card className="profile-page-card RewardCenter_card" sx={{ minWidth: "auto", maxWidth: "auto" }}>
                            <CardContent>
                                <Box className="d-sm-flex justify-content-sm-between my-3">
                                    <Box className="d-flex">
                                        <LockIcon className="icons" />
                                        <div className='ms-2'>
                                            <Typography variant="h6" className="fw-bold font-color-title">Complete the security verification</Typography>
                                            <div className="textClr">Verify using your <span className="text-blue">Phone Number or MEXC/Google Aunthenticator</span> </div>
                                        </div>
                                    </Box>
                                    <div className='d-grid mt-3 mt-sm-0'><Button variant="contained" className='button-accept'>Completed</Button></div>
                                </Box>
                            </CardContent>
                        </Card>
                        <Card className="profile-page-card RewardCenter_card my-4" sx={{ minWidth: "auto", maxWidth: "auto" }}>
                            <CardContent>
                                <Box className="d-sm-flex justify-content-sm-between my-3">
                                    <Box className="d-flex">
                                        <StarsIcon className="icons" />
                                        <div className='ms-2'>
                                            <Typography variant="h6" className="fw-bold font-color-title">KYC Checks</Typography>
                                            <div className="textClr">Complete your  <span className="text-blue">KYC checks</span> </div>
                                        </div>
                                    </Box>
                                    <div className='d-grid mt-3 mt-sm-0'><Button variant="contained" className='button-reject'>Incomplete</Button></div>
                                </Box>
                            </CardContent>
                        </Card>
                        <Card className="profile-page-card RewardCenter_card my-4" sx={{ minWidth: "auto", maxWidth: "auto" }}>
                            <CardContent>
                                <Box className="d-sm-flex justify-content-sm-between my-3">
                                    <Box className="d-flex">
                                        <LogoutIcon className="icons" />
                                        <div className='ms-2'>
                                            <Typography variant="h6" className="fw-bold font-color-title">Deposit</Typography>
                                            <div className="textClr">Now<span className="text-blue px-2">Buy</span>or<span className="text-blue px-2">Deposit</span>atleast 200 USD worth of tokens of single trading  </div>
                                        </div>
                                    </Box>
                                    <div className='d-grid mt-3 mt-sm-0'><Button variant="contained" className='button-reject'>Incomplete</Button></div>
                                </Box>
                            </CardContent>
                        </Card>
                        <div className="d-flex justify-content-center"><Button variant="contained" className="px-5 py-2 backgroundGray">Get it now</Button></div>
                        <Box>
                            <Box>
                                <Typography variant='h6' className="font-color-title fw-bold mt-2">Frequently asked question (FAQ)</Typography>
                                <Typography className="font-color-title fw-bold my-3">How does one get new user rewards?</Typography>
                                <Typography className="font-color-title fw-bold">Answer:<span className="textClr fw-normal ps-2">After completing the above assigned tasks, please click on ‘Receive Your Rewards’. You will receive your new user rewards for futures trading shortly after our internal verification.</span></Typography>
                            </Box>
                            <Box>
                                <Typography className="font-color-title fw-bold my-3"> How do I know if I qualify as a New User?</Typography>
                                <Typography className="font-color-title fw-bold">Answer:<span className="textClr fw-normal ps-2"> This reward is given only to MEXC Users who registers after the ‘MEXC New User Rewards’ program is started and have completed all the assigned tasks above.</span></Typography>
                            </Box>
                            <Box>
                                <Typography className="font-color-title fw-bold my-3">  How do I use these new user rewards for futures trading?</Typography>
                                <Typography className="font-color-title fw-bold">Answer:<span className="textClr fw-normal ps-2"> Before receiving the rewards for futures trading, you must first open a futures account on MEXC. You can then use these rewards in your futures trades.</span></Typography>
                            </Box>
                            <Box>
                                <Typography className="font-color-title fw-bold my-3"> Why was my new user rewards forfeited?</Typography>
                                <Typography className="font-color-title fw-bold">Answer:<span className="textClr fw-normal ps-2">Any remaining balance in the new user rewards will be forfeited on the 30th day from the date of issue, if unused.</span></Typography>
                            </Box>
                        </Box>
                        <Box>
                            <Typography variant='h6' className="font-color-title fw-bold mt-5 mb-3">Notes to the New User</Typography>
                            <ol className='pl-1rem'>
                                <li className="textClr">The new user rewards will be paid to your futures account which can be accessed and viewed in ‘Futures Transaction’ {'->'} ‘Futures Order’ {'->'} ‘Capital Flow’</li>
                                <li className="textClr">The new user rewards can only be used for futures trade. The profits can be withdrawn but the rewards itself cannot be withdrawn.</li>
                                <li className="textClr">The new user rewards can be used as deposit for futures trading, and can also be used to offset trading fees, losses and costs.</li>
                                <li className="textClr">The new user rewards will be forfeited when any assets are transferred out of the futures account.</li>
                                <li className="textClr">The new user rewards must be used within 30 days from the date of issue. Any remaining balance unused will be forfeited after 30 days. We draw your attention to the risk of liquidation that may occur if the new user rewards are forfeited.</li>
                            </ol>
                        </Box>
                        <Typography className='font-color-title fw-bold mt-5'> MEXC Exchange reserves the right of final interpretation of the event and the right to amend the terms of the event.</Typography>
                    </CardContent>
                </Card>
            </Container>
        </div>
    )
}
export default RewardCenter;