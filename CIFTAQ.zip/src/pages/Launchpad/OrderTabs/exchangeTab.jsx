import React, { useState } from "react";
import NODATA from "../../../components/assets/images/nodata.png";
import TableBody from "@mui/material/TableBody";
import TableCell from "@mui/material/TableCell";
import TableContainer from "@mui/material/TableContainer";
import TableHead from "@mui/material/TableHead";
import { makeStyles } from "@mui/styles";
import TableRow from "@mui/material/TableRow";
import Paper from "@mui/material/Paper";
import CachedIcon from "@mui/icons-material/Cached";
import { Button, Table, Typography } from "@mui/material";
import Box from "@mui/material/Box";

//////THIS TABLE IS USED IN EXCHANGE PAGE/////

const useStyles = makeStyles({
  MUITab: {
    fontSize: "16px !important",
    color: "var(--txt-placeholder) !important",
  },
});

export default function ExchangeTab() {
  const [value, setValue] = React.useState("10001");
  const [type, setType] = useState("text");
  const handleChange = (event, newValue) => {
    setValue(newValue);
  };
  return (
    <>
      <div className=" my-2 d-block d-sm-flex  justify-content-between">
        <div className="d-block d-sm-flex  col-lg-6 mb-3 mb-sm-0">
          <div className="col-lg-5 d-sm-flex ms-0">
            <Typography className="my-1 m-1 ms-2 me-2 trending fw-bold">
              Time:
            </Typography>
            <div className="col-lg-10  ms-0  mb-2 mb-sm-0">
              <input
                style={{ height: "40px" }}
                className="input-sizes placeholder-start inputBg sizes-in"
                placeholder="Start date ~ End date"
                type={type}
                onFocus={() => setType("date")}
                onBlur={() => setType("text")}
                id="date"
              />
            </div>
          </div>
        </div>

        <div>
          <button
            className="btn ms-0 ms-lg-2"
            style={{ color: "white", background: "#1a94ae" }}
          >
            Search
          </button>
        </div>
      </div>
      <Box sx={{ width: "100%", typography: "body1", mt: 3 }}>
        <TableContainer
          sx={{
            background: "var(--card-bg-color)",
            boxShadow: "none !important",
          }}
          component={Paper}
        >
          <Table sx={{ minWidth: 650 }} aria-label="simple table">
            <TableHead>
              <TableRow>
                <TableCell
                  sx={{
                    color: "var(--txt-placeholder)",
                    borderBottom: 0,
                  }}
                >
                  Project
                </TableCell>
                <TableCell
                  sx={{
                    color: "var(--txt-placeholder)",
                    borderBottom: 0,
                  }}
                  align="left"
                >
                  Total input
                </TableCell>
                <TableCell
                  sx={{
                    color: "var(--txt-placeholder)",
                    borderBottom: 0,
                  }}
                  align="left"
                >
                  Deducted amount
                </TableCell>
                <TableCell
                  sx={{
                    color: "var(--txt-placeholder)",
                    borderBottom: 0,
                  }}
                  align="left"
                >
                  Exchange price
                </TableCell>
                <TableCell
                  sx={{
                    color: "var(--txt-placeholder)",
                    borderBottom: 0,
                  }}
                  align="left"
                >
                  Exchange quantity
                </TableCell>
                <TableCell
                  sx={{
                    color: "var(--txt-placeholder)",
                    borderBottom: 0,
                  }}
                  align="left"
                >
                  Exchange time
                </TableCell>
              </TableRow>
            </TableHead>
            <TableBody>
              <TableRow
                sx={{
                  "&:last-child td, &:last-child th": {
                    border: 0,
                  },
                }}
              >
                <TableCell
                  align="center"
                  colSpan={6}
                  sx={{
                    justifyContent: "center",
                    alignItems: "center",
                  }}
                >
                  {" "}
                  <img src={NODATA} />{" "}
                </TableCell>
              </TableRow>
            </TableBody>
          </Table>
        </TableContainer>
      </Box>
    </>
  );
}
