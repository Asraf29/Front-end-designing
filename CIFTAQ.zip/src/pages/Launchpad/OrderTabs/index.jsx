import React, { useState } from "react";
import NODATA from "../../../components/assets/images/nodata.png";
import TableBody from "@mui/material/TableBody";
import TableCell from "@mui/material/TableCell";
import TableContainer from "@mui/material/TableContainer";
import TableHead from "@mui/material/TableHead";
import { makeStyles } from "@mui/styles";
import TableRow from "@mui/material/TableRow";
import Paper from "@mui/material/Paper";
import {
  Button,
  Card,
  CardContent,
  Grid,
  Table,
  Tabs,
  Typography,
} from "@mui/material";
import Box from "@mui/material/Box";
import ArrowBackIosIcon from "@mui/icons-material/ArrowBackIos";
import Tab from "@mui/material/Tab";
import TabContext from "@mui/lab/TabContext";
import CachedIcon from "@mui/icons-material/Cached";
import TabList from "@mui/lab/TabList";
import TabPanel from "@mui/lab/TabPanel";
import { Container } from "@mui/system";
import { Link } from "react-router-dom";
import MyOrderTabs from "./myOrder";
import ExchangeTab from "./exchangeTab";

//////THIS TABLE IS USED IN TRANSACTION HISTORY PAGE/////

const useStyles = makeStyles({
  MUITab: {
    fontSize: "16px !important",
    color: "var(--txt-placeholder) !important",
  },
});

export default function OrderMainTab() {
  const [value, setValue] = React.useState("10001");
  const [type, setType] = useState("text");
  const handleChange = (event, newValue) => {
    setValue(newValue);
  };
  const classes = useStyles();
  return (
    <>
      <Container sx={{ mt: 7 }}>
        <Typography
          className="mb-3 d-flex align-items-center verifyTitle"
          variant="h5"
        >
          <Link to="/launchpad" className="linkTag text-white">
            <ArrowBackIosIcon className="mb-2" />
          </Link>
         My Orders
        </Typography>
        <Grid item xs={12} lg={12} md={12}>
          <Card
            sx={{
              minWidth: 100,
              background: "var(--card-bg-color)",
            }}
          >
            <CardContent>
              <TabContext value={value}>
                <Box>
                  <Box>
                    <TabList
                      variant="scrollable"
                      onChange={handleChange}
                      aria-label="lab API tabs example"
                    >
                      <Tab
                        className={classes.MUITab}
                        label="Participation record"
                        value="10001"
                      />
                      <Tab
                        className={classes.MUITab}
                        label="Exchange record"
                        value="10002"
                      />
                    </TabList>
                  </Box>
                  <TabPanel value="10001" sx={{ padding: 1 }}>
                    <MyOrderTabs />
                  </TabPanel>
                  <TabPanel value="10002" sx={{ padding: 1 }}>
                      <ExchangeTab/>
                  </TabPanel>
                </Box>
              </TabContext>
            </CardContent>
          </Card>
        </Grid>
      </Container>
    </>
  );
}
