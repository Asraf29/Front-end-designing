import React, { useState } from "react";
import {
  Avatar,
  Box,
  Button,
  Paper,
  Table,
  TableBody,
  TableCell,
  TableContainer,
  TableHead,
  TableRow,
} from "@mui/material";
import Card from "@mui/material/Card";
import CardContent from "@mui/material/CardContent";
import { Container } from "@mui/system";
import {
  Checkbox,
  Grid,
  ListItemButton,
  ListItemIcon,
  ListItemText,
  Typography,
} from "@mui/material";
import ArrowBackIosIcon from "@mui/icons-material/ArrowBackIos";
import { Link } from "react-router-dom";
import SearchIcon from "@mui/icons-material/Search";
import topBg from "../../components/assets/images/top-bg.png";
import NODATA from "../../components/assets/images/nodata.png";
import productImg from "../../components/assets/images/productImg.png";
import reload from "../../components/assets/images/reloadimg.png";
import share from "../../components/assets/images/shareimg.png";
import "./index.css";
const data = ["1", "2", "3"];

const LaunchpadViewProduct = () => {
  return (
    <div>
      <Container sx={{ mb: 7, mt: 4 }}>
        <Typography
          className="mb-3 d-flex align-items-center verifyTitle"
          variant="h5"
        >
          <Link to="/launchpad" className="linkTag text-white">
            <ArrowBackIosIcon className="mb-2" />
          </Link>
          CIFDAQ Launchpad
        </Typography>
        {/*Invite Link Cards*/}
        <Card className="profile-page-card">
          <CardContent>
            <div>
              <div className="d-flex  justify-content-between">
                <div className="my-auto d-flex">
                  <Box
                    component="img"
                    alt="graph"
                    src={productImg}
                    sx={{ width: "70px", height: "70px" }}
                    className="img-fluid"
                  />
                  <div className="my-auto">
                    <Typography className="card-text ms-lg-1" sx={{ fontSize: 20, fontWeight: 600 }}>
                      Colony
                    </Typography>

                    <Typography
                      className="textClr ms-lg-1"
                      sx={{ fontSize: 14, fontWeight: 400 }}
                    >
                      Colony is a community driven Accelerator, evolving into a
                      DAO, to boost Avalanche’s ecosystem growth.
                    </Typography>
                  </div>
                </div>
                <div className="my-auto">
                  <div>
                    <Typography
                      sx={{ fontSize: 16, fontWeight: 600, color: "#1A94AE" }}
                    >
                      View more details {">"}
                    </Typography>
                  </div>
                </div>
              </div>
            </div>
          </CardContent>
        </Card>
        {/* hold card */}
        <Card className="profile-page-card pb-4" sx={{ mt: 3 }}>
          <Box className="px-3">
            <Box className="my-4 ms-2 d-block d-sm-flex justify-content-between">
              <div>
                <Typography
                  className="fontsize-card mb-2 mb-sm-0 card-text px-2 px-sm-3 px-lg-0 mb-2 mb-lg-0 "
                  variant="h7"
                  sx={{ textDecoration: "underline", color: "#1A94AE" }}
                >
                  MX Round
                </Typography>
              </div>
              <div>
                <Typography
                  sx={{ color: "#1A94AE" }}
                  className="fontsize-card card-text px-2 px-sm-3 px-lg-0 mb-2 mb-lg-0 "
                  variant="h7"
                >
                  Mx position details {">"}
                </Typography>
              </div>
            </Box>
            <>
              <>
                {/* Project Card*/}
                <Grid container spacing={2}>
                  <Grid item xs={12} sm={12} md={12} lg={8}>
                    <Card
                      className="pb-3"
                      sx={{
                        minWidth: "auto",
                        maxWidth: "auto",
                        background: "var(--bg-sale)",
                      }}
                    >
                      <CardContent>
                        <Grid container>
                          <div className="d-md-flex">
                            <Grid
                              item
                              xs={12}
                              sm={12}
                              md={12}
                              lg={12}
                              className="d-flex my-2 my-sm-0"
                            >
                              <img
                                src={reload}
                                style={{ width: "50px", height: "50px" }}
                                className="img-fluid"
                              />
                              <Box className="text-center text-md-start ms-md-0  ms-5 ms-lg-2 text-lg-start">
                                <Typography className="graph-text fw-bold text-nowrap">
                                  Sale price:
                                </Typography>
                                <Typography className="text-nowrap" sx={{ fontWeight: "bold" }}>
                                  0.132465 MX
                                </Typography>
                              </Box>
                            </Grid>
                            <Grid
                              item
                              xs={12}
                              sm={12}
                              md={12}
                              lg={9}
                              className="d-flex"
                            >
                              <img
                                src={reload}
                                style={{ width: "50px", height: "50px" }}
                                className="img-fluid"
                              />
                              <Box className="text-center text-md-start  text-lg-start">
                                <Typography className="graph-text fw-bold">
                                  Registration time
                                </Typography>
                                <Typography className='date-product' sx={{ fontWeight: "bold" }}>
                                  2021-12-07 17:00:01 - 2021-12-08 17:00:00
                                </Typography>
                              </Box>
                            </Grid>
                          </div>
                          <Grid
                            item
                            xs={12}
                            sm={4}
                            md={4}
                            lg={4}
                            className="d-flex my-4"
                          >
                            <Box className="text-center ms-4 ms-lg-2 text-lg-start">
                              <Typography
                                sx={{ fontSize: "14px" }}
                                className="graph-text fw-bold"
                              >
                                Total supply:
                              </Typography>
                              <Typography sx={{ fontWeight: "bold" }}>
                                150,000,000 CLY
                              </Typography>
                            </Box>
                          </Grid>
                          <Grid
                            item
                            xs={12}
                            sm={4}
                            md={4}
                            lg={4}
                            className="d-flex my-4"
                          >
                            <Box className="text-center ms-2 text-lg-start">
                              <Typography
                                sx={{ fontSize: "14px" }}
                                className="graph-text fw-bold"
                              >
                                Current Launchpad Offered
                              </Typography>
                              <Typography sx={{ fontWeight: "bold" }}>
                                150,000,000 CLY
                              </Typography>
                            </Box>
                          </Grid>
                          <Grid
                            item
                            xs={12}
                            sm={4}
                            md={4}
                            lg={4}
                            className="d-flex my-4"
                          >
                            <Box className="text-center ms-2 text-lg-start">
                              <Typography
                                sx={{ fontSize: "14px" }}
                                className="graph-text fw-bold"
                              >
                                Estimated listing time
                              </Typography>
                              <Typography sx={{ fontWeight: "bold" }}>
                                2021-12-08 18:30:00
                              </Typography>
                            </Box>
                          </Grid>
                        </Grid>
                      </CardContent>
                    </Card>
                  </Grid>
                  <Grid item xs={12} sm={12} md={12} lg={4}>
                    <Card sx={{ minWidth: "auto", maxWidth: "auto" }} className='profile-page-card'>
                      <CardContent className="text-center text-lg-start">
                        <Typography sx={{ fontWeight: 600 }} className="pb-2 card-text">
                          Holding Calculation
                        </Typography>
                        <div className="d-flex justify-content-between card-text">
                          <Typography className="pb-2">
                            MXAvailable limit:
                          </Typography>
                          <Typography sx={{ fontWeight: 600 }} className="pb-2">
                            0 MX
                          </Typography>
                        </div>
                        <div className="d-flex justify-content-between card-text">
                          <Typography className="pb-2">
                            MX Average daily position:
                          </Typography>
                          <Typography sx={{ fontWeight: 600 }} className="pb-2 card-text">
                            --MX
                          </Typography>
                        </div>
                        <div className="d-flex justify-content-between card-text">
                          <Typography>
                            Participation limit for this event:
                          </Typography>
                          <Typography sx={{ fontWeight: 600 }}>--MX</Typography>
                        </div>
                        <div class="d-grid py-2 pb-0">
                          <button class="btn btn-secondary" type="button">
                            FINISHED
                          </button>
                        </div>
                      </CardContent>
                    </Card>
                  </Grid>
                </Grid>
              </>
            </>
          </Box>
        </Card>
        {/* Referral Event Reward Rules */}
        <Card className="mt-3" sx={{ minWidth: "auto", maxWidth: "auto", background: 'var(--crd-bg-lauch)' }}>
          <CardContent className="px-4">
            <Grid container spacing={8}>
              <Grid item  xs={12} md={6} lg={6}>
                <Box className="d-flex justify-content-between my-3">
                  <div>
                    <Typography
                      variant="h6"
                      className="fontsize-card card-text"
                    >
                      Colony [CLY] is Launching
                    </Typography>
                  </div>
                </Box>
                <Box className="pb-3">
                  <Typography className="textClr my-3">
                    Colony is a community driven Accelerator, evolving into a
                    DAO, to boost Avalanche's ecosystem growth. Powered by a
                    governance token: $CLY. Colony will deploy capital within
                    Avalanche on early stages projects, provide liquidity to
                    DeFi protocols, maintain an Index on top Avalanche projects,
                    and validate networks through stacking capabilities. Our
                    open governance mechanism ensures capital is allocated
                    across the Avalanche ecosystem for its sole benefit. The
                    true sustenance and value generated by Colony's investments
                    is routed back to the Community through airdrops, a buyback
                    mechanism, and staking rewards.
                  </Typography>
                </Box>
              </Grid>
              <Grid item xs={12} md={6} lg={6}>
                <Grid item xs={12} md={12} lg={12}>
                  <Card sx={{ minWidth: "100%", maxWidth: "auto" }}>
                    <CardContent className="text-center text-lg-start">
                      <Typography sx={{ fontWeight: 600 }} className="pb-2">
                        Token Allocation
                      </Typography>
                      <TableContainer
                        component={Paper}
                        sx={{ background: "var( --card-bg-color)" }}
                        className="mt-4"
                      >
                        <Table
                          sx={{
                            background: "var( --card-bg-color)",
                          }}
                          aria-label="simple table"
                        >
                          <TableHead>
                            <TableRow
                              sx={{
                                border: "1px solid var(--input-qr-bg)",
                                borderRight: 0,
                                borderLeft: 0,
                              }}
                            >
                              <TableCell
                                sx={{ fontWeight: "bolder !important" }}
                                className="textClr"
                                align="left"
                              >
                                Type
                              </TableCell>
                              <TableCell
                                sx={{ fontWeight: "bolder !important" }}
                                className="textClr"
                                align="center"
                              >
                                Percentage
                              </TableCell>
                              <TableCell
                                sx={{ fontWeight: "bolder !important" }}
                                className="textClr"
                                align="center"
                              >
                                Amount
                              </TableCell>
                            </TableRow>
                          </TableHead>
                          <TableBody>
                            <TableRow
                              sx={{
                                "&:last-child td, &:last-child th": { border: 0 },
                              }}
                            >
                              <TableCell>
                                <Typography>Team</Typography>
                              </TableCell>
                              <TableCell>
                                <Typography
                                  sx={{ fontWeight: 700 }}
                                  align={"center"}
                                >
                                  10%
                                </Typography>
                              </TableCell>
                              <TableCell>
                                <Typography
                                  sx={{ fontWeight: 700 }}
                                  align={"center"}
                                >
                                  15000
                                </Typography>
                              </TableCell>
                            </TableRow>
                            <TableRow
                              sx={{
                                "&:last-child td, &:last-child th": { border: 0 },
                                background: "#c4c4c4",
                              }}
                            >
                              <TableCell>
                                <Typography>Team</Typography>
                              </TableCell>
                              <TableCell>
                                <Typography
                                  sx={{ fontWeight: 700 }}
                                  align={"center"}
                                >
                                  10%
                                </Typography>
                              </TableCell>
                              <TableCell>
                                <Typography
                                  sx={{ fontWeight: 700 }}
                                  align={"center"}
                                >
                                  15000
                                </Typography>
                              </TableCell>
                            </TableRow>
                            <TableRow
                              sx={{
                                "&:last-child td, &:last-child th": { border: 0 },
                              }}
                            >
                              <TableCell>
                                <Typography>Team</Typography>
                              </TableCell>
                              <TableCell>
                                <Typography
                                  sx={{ fontWeight: 700 }}
                                  align={"center"}
                                >
                                  10%
                                </Typography>
                              </TableCell>
                              <TableCell>
                                <Typography
                                  sx={{ fontWeight: 700 }}
                                  align={"center"}
                                >
                                  15000
                                </Typography>
                              </TableCell>
                            </TableRow>
                          </TableBody>
                        </Table>
                      </TableContainer>
                    </CardContent>
                  </Card>
                </Grid>
                {/* ////////SECOND CARD//// */}
                <Card sx={{ minWidth: "auto", maxWidth: "auto", mt: 3 }}>
                  <CardContent className="text-center text-lg-start d-block">
                    <Typography sx={{ fontWeight: 600 }} className="pb-2">
                      Project Highlights
                    </Typography>
                    <Typography>
                      Colony delivers an incentivized foundation for novel
                      applications on the Avalanche platform with a first of its
                      kind funding mechanism. It combines traditional venture
                      capital and the power of blockchain-based community with
                      open governance, support, and inclusion. Colony's
                      Governance allows the community to leverage its knowledge,
                      actions and will In other words, traditional Venture
                      Capital firms are highly centralized and only benefit
                      their LPs and are not fully aligned with the long-term
                      growth of the ecosystem due to a mismatch between the fund
                      lifespan and the one of the ecosystem. Colony shifts this
                      paradigm upside down: from the start, governance is given
                      to the community with strong incentives aligned with the
                      long-term growth of the ecosystem.
                    </Typography>
                    <div className="d-block my-2">
                      <Typography>
                        The Community leads: <br />
                        Voting: <br />
                        Influence: <br />
                        • Sharing Deal Flow with the Fund Analyst Team. <br />
                        • Providing Analysis on projects. <br />• Providing
                        ideas to increase the fund's participation in the
                        ecosystem.
                      </Typography>
                      <div>
                        <Typography>
                          Colony delivers an incentivized foundation for novel
                          applications on the Avalanche platform with a first of
                          its kind funding mechanism. It combines traditional
                          venture capital and the power of blockchain-based
                          community with open governance, support, and
                          inclusion. Colony's Governance allows the community to
                          leverage its knowledge, actions and will In other
                          words, traditional Venture Capital firms are highly
                          centralized and only benefit their LPs and are not
                          fully aligned with the long-term growth of the
                          ecosystem due to a mismatch between the fund lifespan
                          and the one of the ecosystem. Colony shifts this
                          paradigm upside down: from the start, governance is
                          given to the community with strong incentives aligned
                          with the long-term growth of the ecosystem.
                        </Typography>
                      </div>
                    </div>
                  </CardContent>
                </Card>
              </Grid>
            </Grid>
          </CardContent>
        </Card>
      </Container>
    </div>
  );
};
export default LaunchpadViewProduct;
