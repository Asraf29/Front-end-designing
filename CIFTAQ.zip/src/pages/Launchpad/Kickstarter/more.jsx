import React, { useState } from "react";
import { makeStyles } from "@mui/styles";
import {
    Avatar,
    Button,
    Card,
    CardContent,
    Grid,
    ListItemButton,
    ListItemIcon,
    ListItemText,
    Stack,
    Table,
    Tabs,
    Typography,
} from "@mui/material";
import AccessTimeIcon from '@mui/icons-material/AccessTime';
import broken from '../../../components/assets/images/broken.png'
import Box from "@mui/material/Box";
import ArrowBackIosIcon from "@mui/icons-material/ArrowBackIos";
import Tab from "@mui/material/Tab";
import TabContext from "@mui/lab/TabContext";
import TabList from "@mui/lab/TabList";
import TabPanel from "@mui/lab/TabPanel";
import { Container } from "@mui/system";
import { Link } from "react-router-dom";
import '../index.css'

const useStyles = makeStyles({
    MUITab: {
        fontSize: "16px !important",
        color: "var(--txt-placeholder) !important",
    },
});

export default function KickstartMore() {
    const [value, setValue] = React.useState("10001");
    const [type, setType] = useState("text");
    const handleChange = (event, newValue) => {
        setValue(newValue);
    };
    const classes = useStyles();
    return (
        <>
            <Container sx={{ mt: 7 }}>
                <Typography
                    className="mb-3 d-flex align-items-center verifyTitle"
                    variant="h5"
                >
                    <Link to="/kickstart" className="linkTag text-white">
                        <ArrowBackIosIcon className="mb-2" />
                    </Link>
                    Kickstarter
                </Typography>
                <Grid item xs={12} sm={12} lg={12} md={6}>
                    <Card
                        sx={{
                            minWidth: 100,
                            background: "var(--card-bg-color)",
                        }}
                    >
                        <CardContent>
                            <Grid container spacing={2}>
                                <Grid xs={12} sm={12} md={6} lg={6}>
                                    <Container>
                                        <Box sx={{ mt: 4 }}>
                                            <div className="d-flex justify-content-between mb-2">
                                                <div>
                                                    <Typography sx={{ fontSize: '13px', color: "var(--txt-placeholder)" }}>Number of votes</Typography>
                                                </div>
                                                <div>
                                                    <Typography sx={{ fontSize: '13px', color: "var(--txt-placeholder)" }}>Available balance: --MX</Typography>
                                                </div>
                                            </div>
                                            <div className="input-group mb-3">
                                                <input type="text" className="form-control placeholderTxtClr inputBg" placeholder="Number of available votes:0" aria-label="Recipient's username" aria-describedby="button-addon2" />
                                                <button className="btn inputBg" style={{ color: '#1A94AE' }} type="button" id="button-addon2">ALL</button>
                                            </div>
                                            <div>
                                                <div className="form-check">
                                                    <input className="form-check-input" type="checkbox" value="" id="flexCheckDefault" />
                                                    <label className="form-check-label card-text mb-2 fw-bold" for="flexCheckDefault">
                                                        I agreed to the terms and conditions <span style={{ color: '#1A94AE' }}>{"<CIFDAQ’s Risk Notice>"}</span>
                                                    </label>
                                                </div>
                                                <div className="d-grid gap-2">
                                                    <button style={{ background: 'rgba(0, 0, 0, 0.4)', color: 'white', fontSize: '14px' }} className="btn btn-lg fw-bold" type="button">Vote</button>
                                                </div>
                                            </div>
                                            <div className="my-2 bg-red">
                                                <Typography sx={{ fontSize: '12px' }}>
                                                    Note: Voting Participation Rate = Total Voting Value / Total Reward Token Value (value units will be converted to USDT). If the current voting participation rate reaches the target, the token reward can be splitted. Otherwise, CIFDAQ Global will cancel the listed project tokens and unlock the voting tokens.
                                                </Typography>
                                            </div>
                                        </Box>
                                    </Container>


                                </Grid>
                                <Grid xs={12} sm={12} md={6} lg={6}>
                                    <Grid sx={12} md={12} sm={12} lg={12}>
                                        <Container className='marginTop' sx={{mt:3}}>
                                            <Card className='lovely-card-bg' sx={{ maxWidth: 'auto' , minWidth:'auto'}} >
                                                <CardContent>
                                                    <Stack direction="row" className="d-block d-sm-flex justify-content-between fntSz">
                                                        <div className="d-block d-sm-flex">
                                                            <Avatar className="my-1" alt="Remy Sharp" src={broken} />
                                                            <div className="d-block">
                                                                <div>
                                                                    <Typography className="card-text ms-1" sx={{ fontWeight: 700, fontSize: 24 }}>
                                                                        Lovely
                                                                    </Typography>
                                                                    <Typography className="textClr ms-1" sx={{ fontWeight: 700, fontSize: 15 }}>
                                                                        Lovely Inu
                                                                    </Typography>
                                                                </div>
                                                            </div>
                                                        </div>
                                                        <div className="d-block">
                                                            <Typography className="card-text ms-1" sx={{ fontWeight: 700, fontSize: 24 }}>
                                                                300
                                                            </Typography>
                                                            <Typography className="textClr ms-1" sx={{ fontWeight: 700, fontSize: 10 }}>
                                                                Reward Pool (REAL)
                                                            </Typography>
                                                        </div>
                                                    </Stack>
                                                    <div className="d-block d-sm-flex justify-content-between my-4">
                                                        <div className="d-block">
                                                            <Typography className="textClr">
                                                                Total vote[MX]:
                                                            </Typography>
                                                            <Typography className="card-text fw-bold">
                                                                6006374.70045709
                                                            </Typography>
                                                        </div>
                                                        <div className="d-block">
                                                            <Typography className="textClr">
                                                                Target voting rate
                                                            </Typography>
                                                            <Typography className="card-text fw-bold">
                                                                500.00%
                                                            </Typography>
                                                        </div>
                                                    </div>
                                                    <div className="d-block d-sm-flex justify-content-between">
                                                        <div className="d-block">
                                                            <Typography className="textClr">
                                                                Total vote[MX]:
                                                            </Typography>
                                                            <Typography className="card-text fw-bold">
                                                                6006374.70045709
                                                            </Typography>
                                                        </div>
                                                        <div className="d-block">
                                                            <Typography className="textClr">
                                                                Target voting rate
                                                            </Typography>
                                                            <Typography className="card-text fw-bold">
                                                                500.00%
                                                            </Typography>
                                                        </div>
                                                    </div>
                                                  
                                                    <div className="d-flex my-2 mb-0 justify-content-center">
                                                        <Typography sx={{fontSize:12, color:'#1A94AE'}}>
                                                        <AccessTimeIcon fontSize={'small'} className="mb-0"/> Voting time:2022-01-16 08:30 - 2022-01-16 16:20
                                                        </Typography>
                                                    </div>
                                                </CardContent>
                                            </Card>

                                        </Container>

                                        {/* <Container sx={{mt:4}}>
                                        <Card sx={{ minWidth: '100%', maxWidth: '100%' }}>
                                        <div className="container my-4">
                                            
                                            </div>
                                        </Card>
                                    </Container> */}
                                    </Grid>

                                </Grid>
                            </Grid>
                        </CardContent>
                    </Card>
                </Grid>
            </Container>
        </>
    );
}
