import React, { useState } from "react";
import {
    Avatar,
    Box,
    Button,
    Paper,
    Table,
    TableBody,
    TableCell,
    TableContainer,
    TableHead,
    TableRow,
} from "@mui/material";
import Stack from '@mui/material/Stack';
import Card from "@mui/material/Card";
import CardContent from "@mui/material/CardContent";
import { Container } from "@mui/system";
import {
    Checkbox,
    Grid,
    ListItemButton,
    ListItemIcon,
    ListItemText,
    Typography,
} from "@mui/material";
import ArrowBackIosIcon from "@mui/icons-material/ArrowBackIos";
import { Link } from "react-router-dom";
import cardImg from "../../../components/assets/images/cardImg.png";
import banner from "../../../components/assets/images/kickstart.png";
import "../index.css";
import broken from '../../../components/assets/images/broken.png'
const data = ["1", "2", "3"];

const Kickstarter = () => {
    return (
        <div>
            <Container sx={{ mb: 7 }}>
                <Box className="d-md-flex justify-content-md-between align-items-center">
                    <div className="text-center ms-4  mt-3 mt-sm-0 col-lg-3">
                        <Typography className="text-propty" variant="h3">
                            Kickstarter
                        </Typography>
                        <Typography className="text-propty-sub">
                            Vote and receive Airdrods
                        </Typography>
                    </div>
                    <div className="col-lg-9">
                        <Box
                            component="img"
                            alt="topbar-bg"
                            src={banner}
                            className="imgSizePad img-fluid"

                        />
                    </div>
                </Box>
                {/*EVENT  Cards*/}
                <Card
                    className="profile-page-card"
                    sx={{ minWidth: "auto", maxWidth: "auto" }}
                >
                    <CardContent>
                        <Box className="d-flex justify-content-between mb-2">
                            <div>
                                <Typography variant="h6" className="fontsize-card card-text">
                                    What is the “kickstarter” event?
                                </Typography>
                            </div>
                        </Box>
                        <Grid item xs={12} sm={12} md={12} lg={12}>
                            <Typography className="textClr" sx={{ fontSize: "14px" }}>
                                The ‘Kickstarter’ event is an activity during the pre-launch stage of a project in which the project initiates voting for the launch on CIFDAQ, and then airdrops its tokens for free to all successful voting users. If the set goals are not met, CIFDAQ will cancel the listed project and unlock the voting token. This event is design to attract more premium projects to list on CIFDAQ and provide free airdrops to CIFDAQ users.
                            </Typography>
                            <Typography className="py-2 pb-0" sx={{ color: '#1A94AE', fontSize: '14px' }}>Please click here for more information</Typography>
                        </Grid>
                    </CardContent>
                </Card>
                {/* VOTE */}
                <Box sx={{ mt: 2 }}>
                    <div class="container">
                        <div className="d-flex justify-content-between mb-2">
                            <div>
                                <Typography className="text-heading">Vote and receive rewards</Typography>
                            </div>
                            <div>
                                <Link to='/myOrder' className="linkTag"><Typography className="text-heading2">Reward records</Typography> </Link>
                            </div>
                        </div>
                        {/* -------------------- LOVELY CARDS----------- */}
                        <Card
                            className="profile-page-card"
                            sx={{ minWidth: "auto", maxWidth: "auto" }}
                        >
                            <CardContent>
                                <Grid item xs={12} sm={12} md={12} lg={12}>
                                    <Stack direction="row" spacing={2} className="d-block d-sm-flex justify-content-between fntSz">
                                        <div className="d-flex">   <Avatar alt="Remy Sharp" src={broken} />
                                            <div className="d-flex">
                                                <div style={{ paddingTop: 6 }}>
                                                    <Typography className="card-text fntSz ms-1" sx={{ fontWeight: 700 }}>
                                                        Lovely( <span className="textClr">Lovely Inu</span>)
                                                    </Typography>
                                                    <Typography className="ftSz" sx={{ fontWeight: 700, color: '#1A94AE' }}>
                                                        Voting start time: 01-13 08:30 - 01 - 13 16:20
                                                    </Typography>
                                                </div>
                                            </div>
                                        </div>
                                        <div className="d-flex" style={{ paddingTop: 6 }}>
                                            <Typography className="card-text textClr fntSz" sx={{ fontWeight: 700 }}>
                                                Reward Pool: <b className="card-text">36500000000</b>
                                            </Typography>
                                        </div>
                                        <div className="d-block d-sm-flex" style={{ paddingTop: 6 }}>
                                            <div>
                                                <Typography className="card-text textClr fntSz me-lg-1" sx={{ fontWeight: 700 }}>
                                                    Time remaining until event ends </Typography>
                                            </div>
                                            <div>
                                                <Typography className="card-text textClr fntSz" sx={{ fontWeight: 700 }}> <span className="bg-count me-1 count-txt">00</span> D <span className="bg-count me-1 count-txt">03</span> H <span className="bg-count ms-1 count-txt">01</span> M <span className="bg-count ms-1 count-txt">02</span> S
                                                </Typography>
                                            </div>
                                        </div>
                                    </Stack>
                                </Grid>
                                <Card
                                    className="sub-card-bg-kick  my-3 mb-0"
                                    sx={{ minWidth: "auto", maxWidth: "auto" }}>
                                    <CardContent>
                                        <Grid container>
                                            <Grid item xs={12} sm={12} md={12} lg={12}>
                                                <Stack direction="row" spacing={2} className="d-block d-sm-flex justify-content-between fntSz m-4 m-sm-0">
                                                    <div className="d-block ms-3 ms-sm-0">
                                                        <div>
                                                            <Typography className="card-text textClr" sx={{ fontWeight: 600, fontSize: 13 }}>
                                                                Total vote[MX]:
                                                            </Typography>
                                                        </div>
                                                        <div>
                                                            <Typography className="card-text" sx={{ fontWeight: 600, fontSize: 16 }}>
                                                                6006374.70045709
                                                            </Typography>
                                                        </div>
                                                    </div>

                                                    <div className="d-block my-4 my-sm-0">
                                                        <div>
                                                            <Typography className="card-text textClr" sx={{ fontWeight: 600, fontSize: 13 }}>
                                                                Target voting rate
                                                            </Typography>
                                                        </div>
                                                        <div>
                                                            <Typography className="card-text" sx={{ fontWeight: 600, fontSize: 16 }}>
                                                                500.00%
                                                            </Typography>
                                                        </div>
                                                    </div>
                                                    <div className="d-block my-4 my-sm-0">
                                                        <div>
                                                            <Typography className="card-text textClr" sx={{ fontWeight: 600, fontSize: 13 }}>
                                                                Participation rate
                                                            </Typography>
                                                        </div>
                                                        <div>
                                                            <Typography className="card-text" sx={{ fontWeight: 600, fontSize: 16 }}>
                                                                24686.26%
                                                            </Typography>
                                                        </div>
                                                    </div>
                                                    <div className="d-block">
                                                        <div>
                                                            <Typography className="card-text textClr" sx={{ fontWeight: 600, fontSize: 13 }}>
                                                                Listing time
                                                            </Typography>
                                                        </div>
                                                        <div>
                                                            <Typography className="card-text" sx={{ fontWeight: 600, fontSize: 16 }}>
                                                                01-14 09:30
                                                            </Typography>
                                                        </div>
                                                    </div>
                                                    <div>
                                                        <div className="py-lg-2">
                                                        <Button variant="contained" sx={{background:'#1A94AE', textTransform:'none'}}>Vote</Button>
                                                        </div>
                                                    </div>
                                                </Stack>
                                            </Grid>
                                        </Grid>

                                    </CardContent>
                                </Card>
                            </CardContent>
                        </Card>
                          {/* -------------------- LOVELY CARDS 2----------- */}
                          <Card
                            className="profile-page-card my-4"
                            sx={{ minWidth: "auto", maxWidth: "auto" }}
                        >
                            <CardContent>
                                <Grid item xs={12} sm={12} md={12} lg={12}>
                                    <Stack direction="row" spacing={2} className="d-block d-sm-flex justify-content-between fntSz">
                                        <div className="d-flex">   <Avatar alt="Remy Sharp" src={broken} />
                                            <div className="d-flex">
                                                <div style={{ paddingTop: 6 }}>
                                                    <Typography className="card-text fntSz ms-1" sx={{ fontWeight: 700 }}>
                                                        Lovely( <span className="textClr">Lovely Inu</span>)
                                                    </Typography>
                                                    <Typography className="ftSz" sx={{ fontWeight: 700, color: '#1A94AE' }}>
                                                        Voting start time: 01-13 08:30 - 01 - 13 16:20
                                                    </Typography>
                                                </div>
                                            </div>
                                        </div>
                                        <div className="d-flex" style={{ paddingTop: 6 }}>
                                            <Typography className="card-text textClr fntSz" sx={{ fontWeight: 700 }}>
                                                Reward Pool: <b className="card-text">36500000000</b>
                                            </Typography>
                                        </div>
                                        <div className="d-block d-sm-flex" style={{ paddingTop: 6 }}>
                                            <div>
                                                <Typography className="card-text textClr fntSz me-lg-1" sx={{ fontWeight: 700 }}>
                                                    Time remaining until event ends </Typography>
                                            </div>
                                            <div>
                                                <Typography className="card-text textClr fntSz" sx={{ fontWeight: 700 }}> <span className="bg-count me-1 count-txt">00</span> D <span className="bg-count me-1 count-txt">03</span> H <span className="bg-count ms-1 count-txt">01</span> M <span className="bg-count ms-1 count-txt">02</span> S
                                                </Typography>
                                            </div>
                                        </div>
                                    </Stack>
                                </Grid>
                                <Card
                                    className="sub-card-bg-kick my-3 mb-0"
                                    sx={{ minWidth: "auto", maxWidth: "auto" }}>
                                    <CardContent>
                                        <Grid container>
                                            <Grid item xs={12} sm={12} md={12} lg={12}>
                                                <Stack direction="row" spacing={2} className="d-block d-sm-flex justify-content-between fntSz m-4 m-sm-0">
                                                    <div className="d-block ms-3 ms-sm-0">
                                                        <div>
                                                            <Typography className="card-text textClr" sx={{ fontWeight: 600, fontSize: 13 }}>
                                                                Total vote[MX]:
                                                            </Typography>
                                                        </div>
                                                        <div>
                                                            <Typography className="card-text" sx={{ fontWeight: 600, fontSize: 16 }}>
                                                                6006374.70045709
                                                            </Typography>
                                                        </div>
                                                    </div>

                                                    <div className="d-block my-4 my-sm-0">
                                                        <div>
                                                            <Typography className="card-text textClr" sx={{ fontWeight: 600, fontSize: 13 }}>
                                                                Target voting rate
                                                            </Typography>
                                                        </div>
                                                        <div>
                                                            <Typography className="card-text" sx={{ fontWeight: 600, fontSize: 16 }}>
                                                                500.00%
                                                            </Typography>
                                                        </div>
                                                    </div>
                                                    <div className="d-block my-4 my-sm-0">
                                                        <div>
                                                            <Typography className="card-text textClr" sx={{ fontWeight: 600, fontSize: 13 }}>
                                                                Participation rate
                                                            </Typography>
                                                        </div>
                                                        <div>
                                                            <Typography className="card-text" sx={{ fontWeight: 600, fontSize: 16 }}>
                                                                24686.26%
                                                            </Typography>
                                                        </div>
                                                    </div>
                                                    <div className="d-block">
                                                        <div>
                                                            <Typography className="card-text textClr" sx={{ fontWeight: 600, fontSize: 13 }}>
                                                                Listing time
                                                            </Typography>
                                                        </div>
                                                        <div>
                                                            <Typography className="card-text" sx={{ fontWeight: 600, fontSize: 16 }}>
                                                                01-14 09:30
                                                            </Typography>
                                                        </div>
                                                    </div>
                                                    <div>
                                                        <div className="py-lg-2">
                                                        <Button variant="contained" sx={{background:'#1A94AE', textTransform:'none'}}>Trade</Button>
                                                        </div>
                                                    </div>
                                                </Stack>
                                            </Grid>
                                        </Grid>

                                    </CardContent>
                                </Card>
                            </CardContent>
                        </Card>
                        {/* -------------------- LOVELY CARDS 3----------- */}
                        <Card
                            className="profile-page-card my-4"
                            sx={{ minWidth: "auto", maxWidth: "auto" }}
                        >
                            <CardContent>
                                <Grid item xs={12} sm={12} md={12} lg={12}>
                                    <Stack direction="row" spacing={2} className="d-block d-sm-flex justify-content-between fntSz">
                                        <div className="d-flex">   <Avatar alt="Remy Sharp" src={broken} />
                                            <div className="d-flex">
                                                <div style={{ paddingTop: 6 }}>
                                                    <Typography className="card-text fntSz ms-1" sx={{ fontWeight: 700 }}>
                                                        Lovely( <span className="textClr">Lovely Inu</span>)
                                                    </Typography>
                                                    <Typography className="ftSz" sx={{ fontWeight: 700, color: '#1A94AE' }}>
                                                        Voting start time: 01-13 08:30 - 01 - 13 16:20
                                                    </Typography>
                                                </div>
                                            </div>
                                        </div>
                                        <div className="d-flex" style={{ paddingTop: 6 }}>
                                            <Typography className="card-text textClr fntSz" sx={{ fontWeight: 700 }}>
                                                Reward Pool: <b className="card-text">36500000000</b>
                                            </Typography>
                                        </div>
                                        <div className="d-block d-sm-flex" style={{ paddingTop: 6 }}>
                                            <div>
                                                <Typography className="card-text textClr fntSz me-lg-1" sx={{ fontWeight: 700 }}>
                                                    Time remaining until event ends </Typography>
                                            </div>
                                            <div>
                                                <Typography className="card-text textClr fntSz" sx={{ fontWeight: 700 }}> <span className="bg-count me-1 count-txt">00</span> D <span className="bg-count me-1 count-txt">03</span> H <span className="bg-count ms-1 count-txt">01</span> M <span className="bg-count ms-1 count-txt">02</span> S
                                                </Typography>
                                            </div>
                                        </div>
                                    </Stack>
                                </Grid>
                                <Card
                                    className="sub-card-bg-kick my-3 mb-0"
                                    sx={{ minWidth: "auto", maxWidth: "auto" }}>
                                    <CardContent>
                                        <Grid container>
                                            <Grid item xs={12} sm={12} md={12} lg={12}>
                                                <Stack direction="row" spacing={2} className="d-block d-sm-flex justify-content-between fntSz m-4 m-sm-0">
                                                    <div className="d-block ms-3 ms-sm-0">
                                                        <div>
                                                            <Typography className="card-text textClr" sx={{ fontWeight: 600, fontSize: 13 }}>
                                                                Total vote[MX]:
                                                            </Typography>
                                                        </div>
                                                        <div>
                                                            <Typography className="card-text" sx={{ fontWeight: 600, fontSize: 16 }}>
                                                                6006374.70045709
                                                            </Typography>
                                                        </div>
                                                    </div>

                                                    <div className="d-block my-4 my-sm-0">
                                                        <div>
                                                            <Typography className="card-text textClr" sx={{ fontWeight: 600, fontSize: 13 }}>
                                                                Target voting rate
                                                            </Typography>
                                                        </div>
                                                        <div>
                                                            <Typography className="card-text" sx={{ fontWeight: 600, fontSize: 16 }}>
                                                                500.00%
                                                            </Typography>
                                                        </div>
                                                    </div>
                                                    <div className="d-block my-4 my-sm-0">
                                                        <div>
                                                            <Typography className="card-text textClr" sx={{ fontWeight: 600, fontSize: 13 }}>
                                                                Participation rate
                                                            </Typography>
                                                        </div>
                                                        <div>
                                                            <Typography className="card-text" sx={{ fontWeight: 600, fontSize: 16 }}>
                                                                24686.26%
                                                            </Typography>
                                                        </div>
                                                    </div>
                                                    <div className="d-block">
                                                        <div>
                                                            <Typography className="card-text textClr" sx={{ fontWeight: 600, fontSize: 13 }}>
                                                                Listing time
                                                            </Typography>
                                                        </div>
                                                        <div>
                                                            <Typography className="card-text" sx={{ fontWeight: 600, fontSize: 16 }}>
                                                                01-14 09:30
                                                            </Typography>
                                                        </div>
                                                    </div>
                                                    <div>
                                                        <div className="py-lg-2">
                                                        <Button variant="contained" disabled sx={{textTransform:'none'}}>Trading soon to be available</Button>
                                                        </div>
                                                    </div>
                                                </Stack>
                                            </Grid>
                                        </Grid>

                                    </CardContent>
                                </Card>
                            </CardContent>
                        </Card>
                    </div>
                </Box>
            </Container>
        </div>
    );
};
export default Kickstarter;
