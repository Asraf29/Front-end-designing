import React, { useState } from "react";
import {
  Avatar,
  Box,
  Button,
  Paper,
  Table,
  TableBody,
  TableCell,
  TableContainer,
  TableHead,
  TableRow,
} from "@mui/material";
import Card from "@mui/material/Card";
import CardContent from "@mui/material/CardContent";
import { Container } from "@mui/system";
import {
  Checkbox,
  Grid,
  ListItemButton,
  ListItemIcon,
  ListItemText,
  Typography,
} from "@mui/material";
import ArrowBackIosIcon from "@mui/icons-material/ArrowBackIos";
import { Link } from "react-router-dom";
import cardImg from "../../components/assets/images/cardImg.png";
import banner from "../../components/assets/images/launchpadbanner.png";
import "./index.css";
import CardMedia from "@mui/material/CardMedia";
import { CardActionArea } from "@mui/material";
const data = ["1", "2", "3"];

const LaunchPad = () => {
  return (
    <div>
      <Container sx={{ mb: 7 }}>
        <Box className="d-md-flex justify-content-md-between align-items-center">
          <div className="text-center ms-4  mt-3 mt-sm-0 col-lg-6">
            <Typography className="text-propty text-no-wraps" variant="h3">
              MEXC Launchpad
            </Typography>
            <Typography className="text-propty-sub">
              Exclusively for MX Holders
            </Typography>
          </div>
          <div className="col-lg-6">
            <Box
              component="img"
              alt="topbar-bg"
              src={banner}
              className="imgSizePadding"
            />
          </div>
        </Box>
        {/*Invite Link Cards*/}
        <Card
          className="profile-page-card"
          sx={{ minWidth: "auto", maxWidth: "auto" }}
        >
          <CardContent>
            <Box className="d-flex justify-content-between mb-2">
              <div>
                <Typography variant="h6" className="fontsize-card card-text">
                  Launchpad
                </Typography>
              </div>
            </Box>
            <Grid item xs={12} sm={12} md={12} lg={12}>
              <Typography className="textClr" sx={{ fontSize: "14px" }}>
                MEXC Launchpad provides users worldwide with a low-cost
                opportunity to invest early in project tokens. MEXC Launchpad,
                exclusively for MX Holders.
              </Typography>
            </Grid>
          </CardContent>
        </Card>
        {/* Referral History common  Card*/}
        <Box sx={{ mt: 3 }}>
          <div class="container">
            <div className="d-flex justify-content-between mb-2">
              <div>
                <Typography className="text-heading">Past Events</Typography>
              </div>
              <div>
              <Link to='/myOrder' className="linkTag"><Typography className="text-heading2">My orders</Typography> </Link>
              </div>
            </div>
            <div class="row row-md-cols-4">
              <div class="col-sm-12 col-md-6 col-lg-3">
                <div>
                  <Card className="profile-page-card" sx={{ maxWidth: 345 }}>
                    <CardActionArea>
                      <CardMedia
                        component="img"
                        height="140"
                        image={cardImg}
                        alt="green iguana"
                      />
                      <CardContent>
                        <div className="d-flex justify-content-between mb-1 bordr-Clr">
                          <div>
                            <Typography
                              className="card-text mb-2"
                              gutterBottom
                              sx={{ fontSize: "16px", fontWeight: 600 }}
                            >
                              Colony
                            </Typography>
                          </div>
                          <div className="bg-txt">
                            <Typography
                              sx={{ fontSize: "12px", fontWeight: 600, mb: 0 }}
                            >
                              FINISHED
                            </Typography>
                          </div>
                        </div>
                        <div className="d-flex justify-content-between">
                          <div>
                            <Typography
                              className="textClr"
                              sx={{ fontSize: "14px", fontWeight: 500 }}
                            >
                              Total supply
                            </Typography>
                          </div>
                          <div>
                            <Typography
                              className="textClr"
                              sx={{ fontSize: "14px", fontWeight: 500 }}
                            >
                              150,000,000 CLY
                            </Typography>
                          </div>
                        </div>
                        <div className="d-flex justify-content-between">
                          <div>
                            <Typography
                              className="textClr"
                              sx={{ fontSize: "14px", fontWeight: 500 }}
                            >
                              Start time
                            </Typography>
                          </div>
                          <div>
                            <Typography
                              className="textClr"
                              sx={{ fontSize: "14px", fontWeight: 500 }}
                            >
                              2021-12-07 17:00:01
                            </Typography>
                          </div>
                        </div>
                        <div className="d-flex justify-content-between">
                          <div>
                            <Typography
                              className="textClr"
                              sx={{ fontSize: "14px", fontWeight: 500 }}
                            >
                              Estimated listing
                            </Typography>
                          </div>
                          <div>
                            <Typography
                              className="textClr"
                              sx={{ fontSize: "14px", fontWeight: 500 }}
                            >
                              2021-12-08
                            </Typography>
                          </div>
                        </div>
                        <div className="d-flex justify-content-between">
                          <div>
                            <Typography
                              className="textClr"
                              sx={{ fontSize: "14px", fontWeight: 500 }}
                            >
                              Time
                            </Typography>
                          </div>
                          <div>
                            <Typography
                              className="textClr"
                              sx={{ fontSize: "14px", fontWeight: 500 }}
                            >
                              18:30:00
                            </Typography>
                          </div>
                        </div>
                      </CardContent>
                    </CardActionArea>
                  </Card>
                </div>
              </div>
              <div class="col-sm-12 col-md-6 col-lg-3 my-3 my-md-0">
                <div>
                  <Card className="profile-page-card" sx={{ maxWidth: 345 }}>
                    <CardActionArea>
                      <CardMedia
                        component="img"
                        height="140"
                        image={cardImg}
                        alt="green iguana"
                      />
                      <CardContent>
                        <div className="d-flex justify-content-between mb-1 bordr-Clr">
                          <div>
                            <Typography
                              className="card-text mb-2"
                              gutterBottom
                              sx={{ fontSize: "16px", fontWeight: 600 }}
                            >
                              Colony
                            </Typography>
                          </div>
                          <div className="bg-txt">
                            <Typography
                              sx={{ fontSize: "12px", fontWeight: 600, mb: 0 }}
                            >
                              FINISHED
                            </Typography>
                          </div>
                        </div>
                        <div className="d-flex justify-content-between">
                          <div>
                            <Typography
                              className="textClr"
                              sx={{ fontSize: "14px", fontWeight: 500 }}
                            >
                              Total supply
                            </Typography>
                          </div>
                          <div>
                            <Typography
                              className="textClr"
                              sx={{ fontSize: "14px", fontWeight: 500 }}
                            >
                              150,000,000 CLY
                            </Typography>
                          </div>
                        </div>
                        <div className="d-flex justify-content-between">
                          <div>
                            <Typography
                              className="textClr"
                              sx={{ fontSize: "14px", fontWeight: 500 }}
                            >
                              Start time
                            </Typography>
                          </div>
                          <div>
                            <Typography
                              className="textClr"
                              sx={{ fontSize: "14px", fontWeight: 500 }}
                            >
                              2021-12-07 17:00:01
                            </Typography>
                          </div>
                        </div>
                        <div className="d-flex justify-content-between">
                          <div>
                            <Typography
                              className="textClr"
                              sx={{ fontSize: "14px", fontWeight: 500 }}
                            >
                              Estimated listing
                            </Typography>
                          </div>
                          <div>
                            <Typography
                              className="textClr"
                              sx={{ fontSize: "14px", fontWeight: 500 }}
                            >
                              2021-12-08
                            </Typography>
                          </div>
                        </div>
                        <div className="d-flex justify-content-between">
                          <div>
                            <Typography
                              className="textClr"
                              sx={{ fontSize: "14px", fontWeight: 500 }}
                            >
                              Time
                            </Typography>
                          </div>
                          <div>
                            <Typography
                              className="textClr"
                              sx={{ fontSize: "14px", fontWeight: 500 }}
                            >
                              18:30:00
                            </Typography>
                          </div>
                        </div>
                      </CardContent>
                    </CardActionArea>
                  </Card>
                </div>
              </div>
              <div class="col-sm-12 col-md-6 col-lg-3 my-3 my-lg-0">
                <div>
                  <Card className="profile-page-card" sx={{ maxWidth: 345 }}>
                    <CardActionArea>
                      <CardMedia
                        component="img"
                        height="140"
                        image={cardImg}
                        alt="green iguana"
                      />
                      <CardContent>
                        <div className="d-flex justify-content-between mb-1 bordr-Clr">
                          <div>
                            <Typography
                              className="card-text mb-2"
                              gutterBottom
                              sx={{ fontSize: "16px", fontWeight: 600 }}
                            >
                              Colony
                            </Typography>
                          </div>
                          <div className="bg-txt">
                            <Typography
                              sx={{ fontSize: "12px", fontWeight: 600, mb: 0 }}
                            >
                              FINISHED
                            </Typography>
                          </div>
                        </div>
                        <div className="d-flex justify-content-between">
                          <div>
                            <Typography
                              className="textClr"
                              sx={{ fontSize: "14px", fontWeight: 500 }}
                            >
                              Total supply
                            </Typography>
                          </div>
                          <div>
                            <Typography
                              className="textClr"
                              sx={{ fontSize: "14px", fontWeight: 500 }}
                            >
                              150,000,000 CLY
                            </Typography>
                          </div>
                        </div>
                        <div className="d-flex justify-content-between">
                          <div>
                            <Typography
                              className="textClr"
                              sx={{ fontSize: "14px", fontWeight: 500 }}
                            >
                              Start time
                            </Typography>
                          </div>
                          <div>
                            <Typography
                              className="textClr"
                              sx={{ fontSize: "14px", fontWeight: 500 }}
                            >
                              2021-12-07 17:00:01
                            </Typography>
                          </div>
                        </div>
                        <div className="d-flex justify-content-between">
                          <div>
                            <Typography
                              className="textClr"
                              sx={{ fontSize: "14px", fontWeight: 500 }}
                            >
                              Estimated listing
                            </Typography>
                          </div>
                          <div>
                            <Typography
                              className="textClr"
                              sx={{ fontSize: "14px", fontWeight: 500 }}
                            >
                              2021-12-08
                            </Typography>
                          </div>
                        </div>
                        <div className="d-flex justify-content-between">
                          <div>
                            <Typography
                              className="textClr"
                              sx={{ fontSize: "14px", fontWeight: 500 }}
                            >
                              Time
                            </Typography>
                          </div>
                          <div>
                            <Typography
                              className="textClr"
                              sx={{ fontSize: "14px", fontWeight: 500 }}
                            >
                              18:30:00
                            </Typography>
                          </div>
                        </div>
                      </CardContent>
                    </CardActionArea>
                  </Card>
                </div>
              </div>
              <div class="col-sm-12 col-md-6 col-lg-3 my-3 my-lg-0">
                <div>
                  <Card className="profile-page-card" sx={{ maxWidth: 345 }}>
                    <CardActionArea>
                      <CardMedia
                        component="img"
                        height="140"
                        image={cardImg}
                        alt="green iguana"
                      />
                      <CardContent>
                        <div className="d-flex justify-content-between mb-1 bordr-Clr">
                          <div>
                            <Typography
                              className="card-text mb-2"
                              gutterBottom
                              sx={{ fontSize: "16px", fontWeight: 600 }}
                            >
                              Colony
                            </Typography>
                          </div>
                          <div className="bg-txt">
                            <Typography
                              sx={{ fontSize: "12px", fontWeight: 600, mb: 0 }}
                            >
                              FINISHED
                            </Typography>
                          </div>
                        </div>
                        <div className="d-flex justify-content-between">
                          <div>
                            <Typography
                              className="textClr"
                              sx={{ fontSize: "14px", fontWeight: 500 }}
                            >
                              Total supply
                            </Typography>
                          </div>
                          <div>
                            <Typography
                              className="textClr"
                              sx={{ fontSize: "14px", fontWeight: 500 }}
                            >
                              150,000,000 CLY
                            </Typography>
                          </div>
                        </div>
                        <div className="d-flex justify-content-between">
                          <div>
                            <Typography
                              className="textClr"
                              sx={{ fontSize: "14px", fontWeight: 500 }}
                            >
                              Start time
                            </Typography>
                          </div>
                          <div>
                            <Typography
                              className="textClr"
                              sx={{ fontSize: "14px", fontWeight: 500 }}
                            >
                              2021-12-07 17:00:01
                            </Typography>
                          </div>
                        </div>
                        <div className="d-flex justify-content-between">
                          <div>
                            <Typography
                              className="textClr"
                              sx={{ fontSize: "14px", fontWeight: 500 }}
                            >
                              Estimated listing
                            </Typography>
                          </div>
                          <div>
                            <Typography
                              className="textClr"
                              sx={{ fontSize: "14px", fontWeight: 500 }}
                            >
                              2021-12-08
                            </Typography>
                          </div>
                        </div>
                        <div className="d-flex justify-content-between">
                          <div>
                            <Typography
                              className="textClr"
                              sx={{ fontSize: "14px", fontWeight: 500 }}
                            >
                              Time
                            </Typography>
                          </div>
                          <div>
                            <Typography
                              className="textClr"
                              sx={{ fontSize: "14px", fontWeight: 500 }}
                            >
                              18:30:00
                            </Typography>
                          </div>
                        </div>
                      </CardContent>
                    </CardActionArea>
                  </Card>
                </div>
              </div>
            </div>
          </div>
        </Box>
      </Container>
    </div>
  );
};
export default LaunchPad;
