import React, { useState } from "react";
import { makeStyles } from "@mui/styles";
import {
    Avatar,
    Button,
    Card,
    CardContent,
    Grid,
    ListItemButton,
    ListItemIcon,
    ListItemText,
    Stack,
    Table,
    Tabs,
    Typography,
} from "@mui/material";
import mxlogo from '../../../components/assets/images/mxlogo.png';
import Box from "@mui/material/Box";
import ArrowBackIosIcon from "@mui/icons-material/ArrowBackIos";
import { styled } from "@mui/material/styles";
import Stepper from "@mui/material/Stepper";
import Step from "@mui/material/Step";
import StepLabel from "@mui/material/StepLabel";
import Check from "@mui/icons-material/Check";
import StepConnector, {
  stepConnectorClasses
} from "@mui/material/StepConnector";
import { Container } from "@mui/system";
import { Link } from "react-router-dom";
import '../index.css'
////STEPPER////
const QontoConnector = styled(StepConnector)(({ theme }) => ({
    [`&.${stepConnectorClasses.alternativeLabel}`]: {
      top: 10,
      left: "calc(-50% + 16px)",
      right: "calc(50% + 16px)"
    },
    [`&.${stepConnectorClasses.active}`]: {
      [`& .${stepConnectorClasses.line}`]: {
        borderColor: "#1A94AE"
      }
    },
    [`&.${stepConnectorClasses.completed}`]: {
      [`& .${stepConnectorClasses.line}`]: {
        borderColor: "#784af4"
      }
    },
    [`& .${stepConnectorClasses.line}`]: {
      borderColor:
        theme.palette.mode === "dark" ? "#36a1b8" : "#eaeaf0",
      borderTopWidth: 3,
      borderRadius: 1
    }
  }));
 
  
  const QontoStepIconRoot = styled("div")(({ theme, ownerState }) => ({
    color: theme.palette.mode === "dark" ? "#1A94AE" : "#1A94AE",
    display: "flex",
    height: 22,
    alignItems: "center",
    ...(ownerState.active && {
      color: "#1A94AE"
    }),
    "& .QontoStepIcon-completedIcon": {
      color: "#1A94AE",
      zIndex: 1,
      fontSize: 18
    },
    "& .QontoStepIcon-circle": {
      width: 8,
      height: 8,
      borderRadius: "50%",
      backgroundColor: "#1A94AE"
    }
  }));

  function QontoStepIcon(props) {
    const { active, completed, className } = props;
  
    return (
      <QontoStepIconRoot ownerState={{ active }} className={className}>
        {completed ? (
          <Check className="QontoStepIcon-completedIcon" />
        ) : (
          <div className="QontoStepIcon-circle" />
        )}
      </QontoStepIconRoot>
    );
  }

  const steps = [
    "Locking Start time",
    "Unlock time",
    "Release of principal"
  ];
  
  
////STEPPR END///
const useStyles = makeStyles({
    MUITab: {
        fontSize: "16px !important",
        color: "var(--txt-placeholder) !important",
    },
});

export default function NewToken() {
    const [value, setValue] = React.useState("10001");
    const handleChange = (event, newValue) => {
        setValue(newValue);
    };
    const classes = useStyles();
    return (
        <>
            <Container sx={{ mt: 7 }}>
                <Typography
                    className="mb-3 d-flex align-items-center verifyTitle"
                    variant="h5"
                >
                    <Link to="/defi" className="linkTag text-white">
                        <ArrowBackIosIcon className="mb-2" />
                    </Link>
                    MX DeFi - New token mining
                </Typography>
                <Grid item xs={12} sm={12} lg={12} md={12}>
                    <Card
                        sx={{
                            minWidth: 100,
                            background: "var(--card-bg-color)",
                        }}
                    >
                        <CardContent>
                            <Grid container spacing={2}>
                                <Grid xs={12} sm={12} md={6} lg={7}>
                                    <Container sx={{mt:4}}>

                                        <div className=" d-flex justify-content-between">
                                            <div>
                                                <div className="d-flex">
                                                    <img alt="logo" style={{ width: '30px', height: '30px' }} src={mxlogo} className='me-2' />
                                                    <Typography className="card-text fw-bold mb-0" sx={{ fontSize: '24px' }}>MX </Typography></div>
                                                <div>
                                                    <Typography className="ms-4 fw-bold my-0" sx={{ fontSize: 12, color: "var(--txt-placeholder)" }}>MX Token</Typography></div>
                                            </div>
                                            <div className="d-flex">
                                                <Typography className="fw-bold text-center me-2" sx={{ color: '#7f7f7f', fontSize: '16px' }}>EST.APY</Typography>
                                                <Typography className="fw-bold text-center" sx={{ fontSize: '30px', color: '#1A94AE' }}>45.40%</Typography>
                                            </div>
                                        </div>
                                        <Box>
                                        <Stack sx={{ width: "100%" }} spacing={4}>
      <Stepper alternativeLabel activeStep={1} connector={<QontoConnector />}>
        {steps.map((label) => (
          <Step key={label}>
            <StepLabel className="card-text act-txt" StepIconComponent={QontoStepIcon}>{label}</StepLabel>
            <Typography className='text-center textClr'>2022-01-13</Typography>
            
          </Step>
        ))}
      </Stepper>
    </Stack>
                                        </Box>
                                        <Box sx={{ mt: 4 }}>
                                            <div className="d-flex justify-content-between mb-2">
                                                <div>
                                                    <Typography sx={{ fontSize: '14px', color: "var(--txt-placeholder)" }}>Locked Quantity</Typography>
                                                </div>
                                                <div>
                                                    <Typography sx={{ fontSize: '14px', color: "var(--txt-placeholder)" }}>Available balance: --MX</Typography>
                                                </div>
                                            </div>
                                            <div className="input-group mb-1">
                                                <input style={{fontWeight:600}} type="text" className="form-control placeholderTxtClr inputBg" placeholder="Please enter amount to be locked" aria-label="Recipient's username" aria-describedby="button-addon2" />
                                                <button className="btn inputBg" style={{ color: '#1A94AE' }} type="button" id="button-addon2">ALL</button>
                                            </div>
                                            <Typography className="ms-3 text-danger fw-bold">Maximum locked amount 10MX</Typography>
                                            <div className="d-grid gap-2 my-3">
                                                <button style={{ color: "rgba(0, 0, 0, 0.5)", fontSize: '14px', background:'rgba(26, 148, 174, 0.5)' }} className="btn btn-lg fw-bold" type="button">Mining gains BOT</button>
                                            </div>
                                        </Box>
                                    </Container>


                                </Grid>
                                <Grid xs={12} sm={12} md={6} lg={5}>
                                    <Grid sx={12} md={12} sm={12} lg={12}>
                                        <Container sx={{ mt: 3 }}>
                                            <Card className='lovely-card-bg' sx={{ maxWidth: 'auto', minWidth: 'auto' }} >
                                                <CardContent>
                                                    <Typography sx={{ fontSize: '13px', color: "var(--txt-placeholder)", fontWeight: 500 }}>
                                                        Attention
                                                    </Typography>
                                                    <Typography className="mb-1" sx={{ fontSize: '13px', color: "var(--txt-placeholder)", fontWeight: 500 }}>
                                                        (1) Entry standard: 10 MX; minimum locking period: 1 day, maximum locking period:3 days
                                                    </Typography>
                                                    <Typography className="mb-1" sx={{ fontSize: '13px', color: "var(--txt-placeholder)", fontWeight: 500 }}>
                                                        (2) Yield will be generated on 2022-01-13
                                                    </Typography>
                                                    <Typography className="mb-1" sx={{ fontSize: '13px', color: "var(--txt-placeholder)", fontWeight: 500 }}>
                                                        (3) Trading/withdrawal is unavailable during the locking period.
                                                    </Typography>
                                                    <Typography className="mb-1" sx={{ fontSize: '13px', color: "var(--txt-placeholder)", fontWeight: 500 }}>
                                                        (4) The assets can be unlocked at any time after maturity.
                                                    </Typography>
                                                    <Typography className="mb-1" sx={{ fontSize: '13px', color: "var(--txt-placeholder)", fontWeight: 500 }}>
                                                        (5) Yield will be calculated daily and will be distributed to your account on the next day.
                                                    </Typography>
                                                    <Typography sx={{ fontSize: '13px', color: "var(--txt-placeholder)", fontWeight: 500 }}>
                                                        (6) The principal will be released within 2 hours after unlocking.
                                                    </Typography>
                                                </CardContent>
                                            </Card>
                                            <div className="form-check my-2 mb-2">
                                                <input className="form-check-input" type="checkbox" value="" id="flexCheckDefault" />
                                                <label className="form-check-label card-text fw-bold my-1" for="flexCheckDefault" style={{ fontSize: '12px' }}>
                                                    I agreed to the terms and conditions <span style={{ color: '#1A94AE' }}>{"<CIFDAQ’s Risk Notice>"}</span>
                                                </label>
                                            </div>
                                            <div className="d-grid gap-2">
                                                <button style={{ color: "var(--txt-placeholder)", fontSize: '14px' }} className="btn btn-lg lovely-card-bg" type="button">Iam fully aware of the project risks and agree to participate</button>
                                            </div>
                                        </Container>


                                    </Grid>

                                </Grid>
                            </Grid>
                        </CardContent>
                    </Card>
                </Grid>
            </Container>
        </>
    );
}
