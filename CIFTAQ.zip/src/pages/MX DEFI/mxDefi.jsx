import React, { useState } from "react";
import {
    Avatar,
    Box,
    Button,
} from "@mui/material";
import Card from "@mui/material/Card";
import CardContent from "@mui/material/CardContent";
import { Container } from "@mui/system";
import {
    Grid,
    Typography,
} from "@mui/material";
import one from '../../components/assets/images/one.png'
import { Link } from "react-router-dom";
import banner from "../../components/assets/images/defibanner.png";
import "./index.css";
import mxlogo from '../../components/assets/images/mxlogo.png';
import Tab from '@mui/material/Tab';
import TabContext from '@mui/lab/TabContext';
import TabList from '@mui/lab/TabList';
import TabPanel from '@mui/lab/TabPanel';
import { makeStyles } from "@mui/styles";
import BOT from '../../components/assets/images/BOT.png'


// Tab Switch;
const useStyles = makeStyles({
    MUITab: {
        color: "var(--Tab-gray-text) !important",
        fontSize: "16px !important",
        fontWeight: 'bold'
    },
});
const Defi = () => {
    const [value, setValue] = React.useState('1');

    const handleChange = (event, newValue) => {
        setValue(newValue);
    };
    // Tab Switch;

    const classes = useStyles();
    return (
        <div>
            <Container sx={{ mb: 7 }}>

                <Box className="d-md-flex justify-content-md-between align-items-center">
                    <div className="text-center ms-4  mt-3 mt-sm-0 col-lg-5">
                        <Typography className="text-propty" variant="h3">
                            MX DeFi
                        </Typography>
                        <Typography className="text-propty-sub">
                            Enjoy mining rewards, store and use anytime with flexibility
                        </Typography>
                    </div>
                    <div className="col-lg-7 my-2">
                        <Box
                            component="img"
                            alt="topbar-bg"
                            src={banner}
                            className="img-fluid" />
                    </div>
                </Box>
                {/*EVENT  Cards*/}
                <TabContext value={value}>
                    <Card
                        className="profile-page-card"
                        sx={{ minWidth: "auto", maxWidth: "auto" }}
                    >
                        <CardContent>

                            <Box className="d-flex justify-content-between">
                                <Box>

                                    <Box>
                                        <TabList variant="scrollable" onChange={handleChange} aria-label="lab API tabs example">
                                            <Tab label="New token mining" value="1" className={classes.MUITab} />
                                            <Tab label="Staking" value="2" className={classes.MUITab} />
                                        </TabList>
                                    </Box>
                                </Box>
                                <div className="py-2">
                                  <Link to='/stakingRecords' className='linkTag'> <Typography sx={{ fontWeight: 600, color: '#1A94AE', fontSize: '15px' }}>
                                   Staking records
                                    </Typography> </Link>
                                </div>

                            </Box>
                        </CardContent>
                    </Card>
                    {/* VOTE */}

                    <TabPanel value="1">
                        <Box sx={{ mt: 2 }}>
                            <div class="container">
                                <div className="d-flex justify-content-between mb-2">
                                    <div>
                                        <Typography className="text-heading"><img alt="Travis Howard" src={one} className='me-2' style={{ width: '18px', height: '21px' }} />Mining gains BOT</Typography>
                                    </div>
                                </div>
                                {/* -------------------- Mining gains BOT----------- */}
                                <Card
                                    className="profile-page-card"
                                    sx={{ minWidth: "auto", maxWidth: "auto" }}
                                >
                                    <CardContent>
                                        <Container className='my-5'>
                                            <Grid item xs={12} sm={12} md={12} lg={12}>
                                                <Grid item spacing={4} container>
                                                    <Grid item xs={12} sm={12} md={12} lg={6}>
                                                        <Card className='lovely-card-bg bradius-0' sx={{ maxWidth: 'auto', minWidth: 'auto' }}>
                                                            <CardContent>
                                                                <Typography className="card-text mb-0 text-center" sx={{ fontWeight: 600, fontSize: 40 }}>80000</Typography>
                                                                <Typography className="text-center" sx={{ color: '#7f7f7f', fontWeight: 600, fontSize: 16 }}>Today’s mining pool[BOT]</Typography>
                                                            </CardContent>
                                                        </Card>
                                                    </Grid>
                                                    <Grid item xs={12} sm={12} md={12} lg={6}>
                                                        <Card className='lovely-card-bg bradius-0'>
                                                            <CardContent>
                                                                <Typography className="card-text mb-0 text-center" sx={{ fontWeight: 600, fontSize: 40 }}>0.2738</Typography>
                                                                <Typography className="text-center" sx={{ color: '#7f7f7f', fontWeight: 600, fontSize: 16 }}>Last Price[BOT/USDT]</Typography>
                                                            </CardContent>
                                                        </Card>
                                                    </Grid>
                                                    <Grid item xs={12} sm={12} md={12} lg={6}>
                                                        <Card className='lovely-card-bg bradius-0'>
                                                            <CardContent>
                                                                <Typography className="card-text mb-0 text-center" sx={{ fontWeight: 600, fontSize: 40 }}>240000</Typography>
                                                                <Typography className="text-center" sx={{ color: '#7f7f7f', fontWeight: 600, fontSize: 16 }}>Total Supply[BOT]</Typography>
                                                            </CardContent>
                                                        </Card>
                                                    </Grid>
                                                    <Grid item xs={12} sm={12} md={12} lg={6}>
                                                        <Card className='lovely-card-bg bradius-0'>
                                                            <CardContent>
                                                                <Typography className="card-text mb-0 text-center" sx={{ fontWeight: 600, fontSize: 40 }}>13458.79</Typography>
                                                                <Typography className="text-center" sx={{ color: '#7f7f7f', fontWeight: 600, fontSize: 16 }}>Total Value locked[USDT]</Typography>
                                                            </CardContent>
                                                        </Card>
                                                    </Grid>
                                                </Grid>
                                            </Grid>
                                        </Container>
                                    </CardContent>
                                </Card>
                                <Grid item spacing={2} container sx={{ my: 4 }}>
                                    <Grid item xs={12} sm={12} md={6} lg={4}>
                                        <Card className="profile-page-card" sx={{ minWidth: 'auto', maxWidth: 'auto' }} >
                                            <CardContent>
                                                <div>
                                                    <Typography className="card-text fw-bold" sx={{ fontSize: '24px' }}><img alt="logo" style={{ width: '30px', height: '30px' }} src={mxlogo} className='me-2' />MX <span style={{ fontSize: '16px' }}>MX Token</span></Typography>
                                                </div>
                                                <div className="my-3 d-block justify-content-center">
                                                    <Typography className="fw-bold text-center" sx={{ fontSize: '30px', color: '#1A94AE' }}>45.40%</Typography>
                                                    <Typography className="fw-bold text-center" sx={{ color: '#7f7f7f', fontSize: '16px' }}>EST.APY</Typography>
                                                </div>
                                                 <Link to='/newtoken' className="linkTag d-grid">   <button className="btn fw-bold" style={{ background: '#1A94AE', color: 'white' }}>Stake now</button></Link>
                                            </CardContent>
                                        </Card>
                                    </Grid>
                                    <Grid item xs={12} sm={12} md={6} lg={4}>
                                        <Card className="profile-page-card" sx={{ minWidth: 'auto', maxWidth: 'auto' }} >
                                            <CardContent>
                                                <div>
                                                    <Typography className="card-text fw-bold" sx={{ fontSize: '24px' }}><img alt="logo" style={{ width: '30px', height: '30px' }} src={BOT} className='me-2' />BOT <span style={{ fontSize: '16px' }}>Starbots Token</span></Typography>
                                                </div>
                                                <div className="my-3 d-block justify-content-center">
                                                    <Typography className="fw-bold text-center" sx={{ fontSize: '30px', color: '#1A94AE' }}>7398.87%</Typography>
                                                    <Typography className="fw-bold text-center" sx={{ color: '#7f7f7f', fontSize: '16px' }}>EST.APY</Typography>
                                                </div>
                                                 <Link to='/newtoken' className="linkTag d-grid">   <button className="btn fw-bold" style={{ background: '#1A94AE', color: 'white' }}>Stake now</button></Link>
                                            </CardContent>
                                        </Card>
                                    </Grid>
                                </Grid>
                            </div>
                        </Box>
                        {/* ==============================VEET=========== */}
                        <Box sx={{ mt: 2 }}>
                            <div class="container">
                                <div className="d-flex justify-content-between mb-2">
                                    <div>
                                        <Typography className="text-heading"><img alt="Travis Howard" src={one} className='me-2' style={{ width: '18px', height: '21px' }} />Mining gains VEET</Typography>
                                    </div>
                                </div>
                                {/* -------------------- MINING GAINS BOTS----------- */}
                                <Card
                                    className="profile-page-card"
                                    sx={{ minWidth: "auto", maxWidth: "auto" }}
                                >
                                    <CardContent>
                                        <Container className='my-5'>
                                            <Grid item xs={12} sm={12} md={12} lg={12}>
                                                <Grid item spacing={4} container>
                                                    <Grid item xs={12} sm={12} md={12} lg={6}>
                                                        <Card className='lovely-card-bg bradius-0' sx={{ maxWidth: 'auto', minWidth: 'auto' }}>
                                                            <CardContent>
                                                                <Typography className="card-text mb-0 text-center" sx={{ fontWeight: 600, fontSize: 40 }}>80000</Typography>
                                                                <Typography className="text-center" sx={{ color: '#7f7f7f', fontWeight: 600, fontSize: 16 }}>Today’s mining pool[BOT]</Typography>
                                                            </CardContent>
                                                        </Card>
                                                    </Grid>
                                                    <Grid item xs={12} sm={12} md={12} lg={6}>
                                                        <Card className='lovely-card-bg bradius-0'>
                                                            <CardContent>
                                                                <Typography className="card-text mb-0 text-center" sx={{ fontWeight: 600, fontSize: 40 }}>0.2738</Typography>
                                                                <Typography className="text-center" sx={{ color: '#7f7f7f', fontWeight: 600, fontSize: 16 }}>Last Price[BOT/USDT]</Typography>
                                                            </CardContent>
                                                        </Card>
                                                    </Grid>
                                                    <Grid item xs={12} sm={12} md={12} lg={6}>
                                                        <Card className='lovely-card-bg bradius-0'>
                                                            <CardContent>
                                                                <Typography className="card-text mb-0 text-center" sx={{ fontWeight: 600, fontSize: 40 }}>240000</Typography>
                                                                <Typography className="text-center" sx={{ color: '#7f7f7f', fontWeight: 600, fontSize: 16 }}>Total Supply[BOT]</Typography>
                                                            </CardContent>
                                                        </Card>
                                                    </Grid>
                                                    <Grid item xs={12} sm={12} md={12} lg={6}>
                                                        <Card className='lovely-card-bg bradius-0'>
                                                            <CardContent>
                                                                <Typography className="card-text mb-0 text-center" sx={{ fontWeight: 600, fontSize: 40 }}>13458.79</Typography>
                                                                <Typography className="text-center" sx={{ color: '#7f7f7f', fontWeight: 600, fontSize: 16 }}>Total Value locked[USDT]</Typography>
                                                            </CardContent>
                                                        </Card>
                                                    </Grid>
                                                </Grid>
                                            </Grid>
                                        </Container>
                                    </CardContent>
                                </Card>
                                <Grid item spacing={2} container sx={{ my: 4 }}>
                                    <Grid item xs={12} sm={12} md={6} lg={4}>
                                        <Card className="profile-page-card" sx={{ minWidth: 'auto', maxWidth: 'auto' }} >
                                            <CardContent>
                                                <div>
                                                    <Typography className="card-text fw-bold" sx={{ fontSize: '24px' }}><img alt="logo" style={{ width: '30px', height: '30px' }} src={mxlogo} className='me-2' />MX <span style={{ fontSize: '16px' }}>MX Token</span></Typography>
                                                </div>
                                                <div className="my-3 d-block justify-content-center">
                                                    <Typography className="fw-bold text-center" sx={{ fontSize: '30px', color: '#1A94AE' }}>45.40%</Typography>
                                                    <Typography className="fw-bold text-center" sx={{ color: '#7f7f7f', fontSize: '16px' }}>EST.APY</Typography>
                                                </div>
                                                 <Link to='/newtoken' className="linkTag d-grid">   <button className="btn fw-bold" style={{ background: '#1A94AE', color: 'white' }}>Stake now</button></Link>
                                            </CardContent>
                                        </Card>
                                    </Grid>
                                    <Grid item xs={12} sm={12} md={6} lg={4}>
                                        <Card className="profile-page-card" sx={{ minWidth: 'auto', maxWidth: 'auto' }} >
                                            <CardContent>
                                                <div>
                                                    <Typography className="card-text fw-bold" sx={{ fontSize: '24px' }}><img alt="logo" style={{ width: '30px', height: '30px' }} src={BOT} className='me-2' />BOT <span style={{ fontSize: '16px' }}>Starbots Token</span></Typography>
                                                </div>
                                                <div className="my-3 d-block justify-content-center">
                                                    <Typography className="fw-bold text-center" sx={{ fontSize: '30px', color: '#1A94AE' }}>7398.87%</Typography>
                                                    <Typography className="fw-bold text-center" sx={{ color: '#7f7f7f', fontSize: '16px' }}>EST.APY</Typography>
                                                </div>
                                                 <Link to='/newtoken' className="linkTag d-grid">   <button className="btn fw-bold" style={{ background: '#1A94AE', color: 'white' }}>Stake now</button></Link>
                                            </CardContent>
                                        </Card>
                                    </Grid>
                                </Grid>
                            </div>
                        </Box>
                        {/* ==============================MCRT=========== */}
                        <Box sx={{ mt: 2 }}>
                            <div class="container">
                                <div className="d-flex justify-content-between mb-2">
                                    <div>
                                        <Typography className="text-heading"><img alt="Travis Howard" src={one} className='me-2' style={{ width: '18px', height: '21px' }} />Mining gains MCRT</Typography>
                                    </div>
                                </div>
                                {/* -------------------- MINING GAINS BOTS----------- */}
                                <Card
                                    className="profile-page-card"
                                    sx={{ minWidth: "auto", maxWidth: "auto" }}
                                >
                                    <CardContent>
                                        <Container className='my-5'>
                                            <Grid item xs={12} sm={12} md={12} lg={12}>
                                                <Grid item spacing={4} container>
                                                    <Grid item xs={12} sm={12} md={12} lg={6}>
                                                        <Card className='lovely-card-bg bradius-0' sx={{ maxWidth: 'auto', minWidth: 'auto' }}>
                                                            <CardContent>
                                                                <Typography className="card-text mb-0 text-center" sx={{ fontWeight: 600, fontSize: 40 }}>80000</Typography>
                                                                <Typography className="text-center" sx={{ color: '#7f7f7f', fontWeight: 600, fontSize: 16 }}>Today’s mining pool[BOT]</Typography>
                                                            </CardContent>
                                                        </Card>
                                                    </Grid>
                                                    <Grid item xs={12} sm={12} md={12} lg={6}>
                                                        <Card className='lovely-card-bg bradius-0'>
                                                            <CardContent>
                                                                <Typography className="card-text mb-0 text-center" sx={{ fontWeight: 600, fontSize: 40 }}>0.2738</Typography>
                                                                <Typography className="text-center" sx={{ color: '#7f7f7f', fontWeight: 600, fontSize: 16 }}>Last Price[BOT/USDT]</Typography>
                                                            </CardContent>
                                                        </Card>
                                                    </Grid>
                                                    <Grid item xs={12} sm={12} md={12} lg={6}>
                                                        <Card className='lovely-card-bg bradius-0'>
                                                            <CardContent>
                                                                <Typography className="card-text mb-0 text-center" sx={{ fontWeight: 600, fontSize: 40 }}>240000</Typography>
                                                                <Typography className="text-center" sx={{ color: '#7f7f7f', fontWeight: 600, fontSize: 16 }}>Total Supply[BOT]</Typography>
                                                            </CardContent>
                                                        </Card>
                                                    </Grid>
                                                    <Grid item xs={12} sm={12} md={12} lg={6}>
                                                        <Card className='lovely-card-bg bradius-0'>
                                                            <CardContent>
                                                                <Typography className="card-text mb-0 text-center" sx={{ fontWeight: 600, fontSize: 40 }}>1347.79</Typography>
                                                                <Typography className="text-center" sx={{ color: '#7f7f7f', fontWeight: 600, fontSize: 16 }}>Total Value locked[USDT]</Typography>
                                                            </CardContent>
                                                        </Card>
                                                    </Grid>
                                                </Grid>
                                            </Grid>
                                        </Container>
                                    </CardContent>
                                </Card>
                                <Grid item spacing={2} container sx={{ my: 3 }}>
                                    <Grid item xs={12} sm={12} md={6} lg={4}>
                                        <Card className="profile-page-card" sx={{ minWidth: 'auto', maxWidth: 'auto' }} >
                                            <CardContent>
                                                <div>
                                                    <Typography className="card-text fw-bold" sx={{ fontSize: '24px' }}><img alt="logo" style={{ width: '30px', height: '30px' }} src={mxlogo} className='me-2' />MX <span style={{ fontSize: '16px' }}>MX Token</span></Typography>
                                                </div>
                                                <div className="my-3 d-block justify-content-center">
                                                    <Typography className="fw-bold text-center" sx={{ fontSize: '30px', color: '#1A94AE' }}>45.40%</Typography>
                                                    <Typography className="fw-bold text-center" sx={{ color: '#7f7f7f', fontSize: '16px' }}>EST.APY</Typography>
                                                </div>
                                                 <Link to='/newtoken' className="linkTag d-grid">   <button className="btn fw-bold" style={{ background: '#1A94AE', color: 'white' }}>Stake now</button></Link>
                                            </CardContent>
                                        </Card>
                                    </Grid>
                                    <Grid item xs={12} sm={12} md={6} lg={4}>
                                        <Card className="profile-page-card" sx={{ minWidth: 'auto', maxWidth: 'auto' }} >
                                            <CardContent>
                                                <div>
                                                    <Typography className="card-text fw-bold" sx={{ fontSize: '24px' }}><img alt="logo" style={{ width: '30px', height: '30px' }} src={BOT} className='me-2' />BOT <span style={{ fontSize: '16px' }}>Starbots Token</span></Typography>
                                                </div>
                                                <div className="my-3 d-block justify-content-center">
                                                    <Typography className="fw-bold text-center" sx={{ fontSize: '30px', color: '#1A94AE' }}>7398.87%</Typography>
                                                    <Typography className="fw-bold text-center" sx={{ color: '#7f7f7f', fontSize: '16px' }}>EST.APY</Typography>
                                                </div>
                                                 <Link to='/newtoken' className="linkTag d-grid">   <button className="btn fw-bold" style={{ background: '#1A94AE', color: 'white' }}>Stake now</button></Link>
                                            </CardContent>
                                        </Card>
                                    </Grid>
                                </Grid>
                                {/* /////////////////////////////////STARKING CARDS//////////// */}
                              
                              
                                   {/* /////////////////////////////////STARKING CARDS//////////// */}
                                  
                                   <div>
                                    <Typography className="text-heading mb-0"><img alt="Travis Howard" src={one} className='me-2' style={{ width: '18px', height: '21px' }} />Staking</Typography>
                                </div>
                                <Grid item spacing={2} container sx={{ my: 0 }}>
                                <Grid item xs={12} sm={12} md={6} lg={4}>
                                        <Card className="profile-page-card" sx={{ minWidth: 'auto', maxWidth: 'auto' }} >
                                            <CardContent>
                                            <div className="d-flex justify-content-between">
                                                    <div>
                                                        <Typography className="card-text fw-bold" sx={{ fontSize: '24px' }}><img alt="logo" style={{ width: '30px', height: '30px' }} src={mxlogo} className='me-2' />MX <span style={{ fontSize: '16px' }}>MX Token</span></Typography>
                                                    </div>
                                                    <div>
                                                        <Typography className="fw-bold" sx={{ fontSize: '10px', color: '#1777F2' }}>MX Staking2</Typography>
                                                    </div>
                                                </div>
                                                <div className="d-flex justify-content-between">
                                                <div className="my-3 d-block justify-content-center">
                                                    <Typography className="fw-bold text-center" sx={{ fontSize: '30px', color: '#1A94AE' }}>55.65%</Typography>
                                                    <Typography className="fw-bold text-center" sx={{ color: '#7f7f7f', fontSize: '14px' }}>EST.APY</Typography>
                                                </div>
                                                <div className="my-3 mb-5 d-block justify-content-center">
                                                    <Typography className="fw-bold card-text" sx={{ fontSize: '30px'}}>1 day[s]</Typography>
                                                    <Typography className="fw-bold" sx={{ color: '#7f7f7f', fontSize: '14px' }}>Min.Term[Days]</Typography>
                                                </div>
                                                </div>
                                                <div className="d-grid"> 
                                                    <button className="btn fw-bold" style={{ background: 'rgba(0, 0, 0, 0.4)', color: 'white' }}>Ended</button>
                                                </div>
                                            </CardContent>
                                        </Card>
                                    </Grid>
                                    <Grid item xs={12} sm={12} md={6} lg={4}>
                                        <Card className="profile-page-card" sx={{ minWidth: 'auto', maxWidth: 'auto' }} >
                                            <CardContent>
                                            <div className="d-flex justify-content-between">
                                                <div>
                                                    <Typography className="card-text fw-bold" sx={{ fontSize: '24px' }}><img alt="logo" style={{ width: '30px', height: '30px' }} src={BOT} className='me-2' />BOT <span style={{ fontSize: '16px' }}>Starbots Token</span></Typography>
                                                </div>
                                                    <div>
                                                        <Typography className="fw-bold" sx={{ fontSize: '10px', color: '#1777F2' }}>BOT Staking2</Typography>
                                                    </div>
                                                </div>
                                                <div className="d-flex justify-content-between">
                                                <div className="my-3 d-block justify-content-center">
                                                    <Typography className="fw-bold text-center" sx={{ fontSize: '30px', color: '#1A94AE' }}>60.00%</Typography>
                                                    <Typography className="fw-bold text-center" sx={{ color: '#7f7f7f', fontSize: '14px' }}>EST.APY</Typography>
                                                </div>
                                                <div className="my-3 d-block justify-content-center">
                                                    <Typography className="fw-bold card-text" sx={{ fontSize: '30px'}}>1 day[s]</Typography>
                                                    <Typography className="fw-bold" sx={{ color: '#7f7f7f', fontSize: '14px' }}>Min.Term[Days]</Typography>
                                                </div>
                                                </div>
                                                <div>
                                                    <Typography className="mb-3 fw-bold"sx={{fontSize: '14px' }}><span className="text-muted">Staking amount:</span> <span className="txt-blue">Unlimited</span></Typography>
                                                </div>
                                                 <Link to='/newtoken' className="linkTag d-grid">   <button className="btn fw-bold" style={{ background: '#1A94AE', color: 'white' }}>Stake now</button></Link>
                                            </CardContent>
                                        </Card>
                                    </Grid>
                                    <Grid item xs={12} sm={12} md={6} lg={4}>
                                        <Card className="profile-page-card" sx={{ minWidth: 'auto', maxWidth: 'auto' }} >
                                            <CardContent>
                                            <div className="d-flex justify-content-between">
                                                    <div>
                                                        <Typography className="card-text fw-bold" sx={{ fontSize: '24px' }}><img alt="logo" style={{ width: '30px', height: '30px' }} src={mxlogo} className='me-2' />MX <span style={{ fontSize: '16px' }}>MX Token</span></Typography>
                                                    </div>
                                                    <div>
                                                        <Typography className="fw-bold" sx={{ fontSize: '10px', color: '#1777F2' }}>MX Staking2</Typography>
                                                    </div>
                                                </div>
                                                <div className="d-flex justify-content-between">
                                                <div className="my-3 d-block justify-content-center">
                                                    <Typography className="fw-bold text-center" sx={{ fontSize: '30px', color: '#1A94AE' }}>80.00%</Typography>
                                                    <Typography className="fw-bold text-center" sx={{ color: '#7f7f7f', fontSize: '14px' }}>EST.APY</Typography>
                                                </div>
                                                <div className="my-3 d-block justify-content-center mb-5">
                                                    <Typography className="fw-bold card-text" sx={{ fontSize: '30px'}}>1 day[s]</Typography>
                                                    <Typography className="fw-bold" sx={{ color: '#7f7f7f', fontSize: '14px' }}>Min.Term[Days]</Typography>
                                                </div>
                                                </div>
                                                <div className="d-grid"> 
                                                    <button className="btn fw-bold" style={{ background: 'rgba(0, 0, 0, 0.4)', color: 'white' }}>Ended</button>
                                                </div>
                                            </CardContent>
                                        </Card>
                                    </Grid>
                                    </Grid>
                            </div>
                        </Box>
                    </TabPanel>


                    {/* ////////////////TAB2/////////////// */}
                    <TabPanel value="2">
                        <Box sx={{ mt: 2 }}>
                            <div class="container">
                                <div className="d-flex justify-content-between mb-2">
                                    <div>
                                        <Typography className="text-heading"><img alt="Travis Howard" src={one} className='me-2' style={{ width: '18px', height: '21px' }} />Mining gains BOT</Typography>
                                    </div>
                                </div>
                                {/* -------------------- Mining gains BOT----------- */}
                                <Card
                                    className="profile-page-card"
                                    sx={{ minWidth: "auto", maxWidth: "auto" }}
                                >
                                    <CardContent>
                                        <Container className='my-5'>
                                            <Grid item xs={12} sm={12} md={12} lg={12}>
                                                <Grid item spacing={4} container>
                                                    <Grid item xs={12} sm={12} md={12} lg={6}>
                                                        <Card className='lovely-card-bg bradius-0' sx={{ maxWidth: 'auto', minWidth: 'auto' }}>
                                                            <CardContent>
                                                                <Typography className="card-text mb-0 text-center" sx={{ fontWeight: 600, fontSize: 40 }}>80000</Typography>
                                                                <Typography className="text-center" sx={{ color: '#7f7f7f', fontWeight: 600, fontSize: 16 }}>Today’s mining pool[BOT]</Typography>
                                                            </CardContent>
                                                        </Card>
                                                    </Grid>
                                                    <Grid item xs={12} sm={12} md={12} lg={6}>
                                                        <Card className='lovely-card-bg bradius-0'>
                                                            <CardContent>
                                                                <Typography className="card-text mb-0 text-center" sx={{ fontWeight: 600, fontSize: 40 }}>0.2738</Typography>
                                                                <Typography className="text-center" sx={{ color: '#7f7f7f', fontWeight: 600, fontSize: 16 }}>Last Price[BOT/USDT]</Typography>
                                                            </CardContent>
                                                        </Card>
                                                    </Grid>
                                                    <Grid item xs={12} sm={12} md={12} lg={6}>
                                                        <Card className='lovely-card-bg bradius-0'>
                                                            <CardContent>
                                                                <Typography className="card-text mb-0 text-center" sx={{ fontWeight: 600, fontSize: 40 }}>240000</Typography>
                                                                <Typography className="text-center" sx={{ color: '#7f7f7f', fontWeight: 600, fontSize: 16 }}>Total Supply[BOT]</Typography>
                                                            </CardContent>
                                                        </Card>
                                                    </Grid>
                                                    <Grid item xs={12} sm={12} md={12} lg={6}>
                                                        <Card className='lovely-card-bg bradius-0'>
                                                            <CardContent>
                                                                <Typography className="card-text mb-0 text-center" sx={{ fontWeight: 600, fontSize: 40 }}>13478.79</Typography>
                                                                <Typography className="text-center" sx={{ color: '#7f7f7f', fontWeight: 600, fontSize: 16 }}>Total Value locked[USDT]</Typography>
                                                            </CardContent>
                                                        </Card>
                                                    </Grid>
                                                </Grid>
                                            </Grid>
                                        </Container>
                                    </CardContent>
                                </Card>
                                <Grid item spacing={2} container sx={{ my: 4 }}>
                                    <Grid item xs={12} sm={12} md={6} lg={4}>
                                        <Card className="profile-page-card" sx={{ minWidth: 'auto', maxWidth: 'auto' }} >
                                            <CardContent>
                                                <div>
                                                    <Typography className="card-text fw-bold" sx={{ fontSize: '24px' }}><img alt="logo" style={{ width: '30px', height: '30px' }} src={mxlogo} className='me-2' />MX <span style={{ fontSize: '16px' }}>MX Token</span></Typography>
                                                </div>
                                                <div className="my-3 d-block justify-content-center">
                                                    <Typography className="fw-bold text-center" sx={{ fontSize: '30px', color: '#1A94AE' }}>45.40%</Typography>
                                                    <Typography className="fw-bold text-center" sx={{ color: '#7f7f7f', fontSize: '16px' }}>EST.APY</Typography>
                                                </div>
                                                 <Link to='/newtoken' className="linkTag d-grid">   <button className="btn fw-bold" style={{ background: '#1A94AE', color: 'white' }}>Stake now</button></Link>
                                            </CardContent>
                                        </Card>
                                    </Grid>
                                    <Grid item xs={12} sm={12} md={6} lg={4}>
                                        <Card className="profile-page-card" sx={{ minWidth: 'auto', maxWidth: 'auto' }} >
                                            <CardContent>
                                                <div>
                                                    <Typography className="card-text fw-bold" sx={{ fontSize: '24px' }}><img alt="logo" style={{ width: '30px', height: '30px' }} src={BOT} className='me-2' />BOT <span style={{ fontSize: '16px' }}>Starbots Token</span></Typography>
                                                </div>
                                                <div className="my-3 d-block justify-content-center">
                                                    <Typography className="fw-bold text-center" sx={{ fontSize: '30px', color: '#1A94AE' }}>7398.87%</Typography>
                                                    <Typography className="fw-bold text-center" sx={{ color: '#7f7f7f', fontSize: '16px' }}>EST.APY</Typography>
                                                </div>
                                                 <Link to='/newtoken' className="linkTag d-grid">   <button className="btn fw-bold" style={{ background: '#1A94AE', color: 'white' }}>Stake now</button></Link>
                                            </CardContent>
                                        </Card>
                                    </Grid>
                                </Grid>
                            </div>
                        </Box>
                        {/* ==============================VEET=========== */}
                        <Box sx={{ mt: 2 }}>
                            <div class="container">
                                <div className="d-flex justify-content-between mb-2">
                                    <div>
                                        <Typography className="text-heading"><img alt="Travis Howard" src={one} className='me-2' style={{ width: '18px', height: '21px' }} />Mining gains VEET</Typography>
                                    </div>
                                </div>
                                {/* -------------------- MINING GAINS BOTS----------- */}
                                <Card
                                    className="profile-page-card"
                                    sx={{ minWidth: "auto", maxWidth: "auto" }}
                                >
                                    <CardContent>
                                        <Container className='my-5'>
                                            <Grid item xs={12} sm={12} md={12} lg={12}>
                                                <Grid item spacing={4} container>
                                                    <Grid item xs={12} sm={12} md={12} lg={6}>
                                                        <Card className='lovely-card-bg bradius-0' sx={{ maxWidth: 'auto', minWidth: 'auto' }}>
                                                            <CardContent>
                                                                <Typography className="card-text mb-0 text-center" sx={{ fontWeight: 600, fontSize: 40 }}>80000</Typography>
                                                                <Typography className="text-center" sx={{ color: '#7f7f7f', fontWeight: 600, fontSize: 16 }}>Today’s mining pool[BOT]</Typography>
                                                            </CardContent>
                                                        </Card>
                                                    </Grid>
                                                    <Grid item xs={12} sm={12} md={12} lg={6}>
                                                        <Card className='lovely-card-bg bradius-0'>
                                                            <CardContent>
                                                                <Typography className="card-text mb-0 text-center" sx={{ fontWeight: 600, fontSize: 40 }}>0.2738</Typography>
                                                                <Typography className="text-center" sx={{ color: '#7f7f7f', fontWeight: 600, fontSize: 16 }}>Last Price[BOT/USDT]</Typography>
                                                            </CardContent>
                                                        </Card>
                                                    </Grid>
                                                    <Grid item xs={12} sm={12} md={12} lg={6}>
                                                        <Card className='lovely-card-bg bradius-0'>
                                                            <CardContent>
                                                                <Typography className="card-text mb-0 text-center" sx={{ fontWeight: 600, fontSize: 40 }}>240000</Typography>
                                                                <Typography className="text-center" sx={{ color: '#7f7f7f', fontWeight: 600, fontSize: 16 }}>Total Supply[BOT]</Typography>
                                                            </CardContent>
                                                        </Card>
                                                    </Grid>
                                                    <Grid item xs={12} sm={12} md={12} lg={6}>
                                                        <Card className='lovely-card-bg bradius-0'>
                                                            <CardContent>
                                                                <Typography className="card-text mb-0 text-center" sx={{ fontWeight: 600, fontSize: 40 }}>1347.79</Typography>
                                                                <Typography className="text-center" sx={{ color: '#7f7f7f', fontWeight: 600, fontSize: 16 }}>Total Value locked[USDT]</Typography>
                                                            </CardContent>
                                                        </Card>
                                                    </Grid>
                                                </Grid>
                                            </Grid>
                                        </Container>
                                    </CardContent>
                                </Card>
                                <Grid item spacing={2} container sx={{ my: 4 }}>
                                    <Grid item xs={12} sm={12} md={6} lg={4}>
                                        <Card className="profile-page-card" sx={{ minWidth: 'auto', maxWidth: 'auto' }} >
                                            <CardContent>
                                                <div>
                                                    <Typography className="card-text fw-bold" sx={{ fontSize: '24px' }}><img alt="logo" style={{ width: '30px', height: '30px' }} src={mxlogo} className='me-2' />MX <span style={{ fontSize: '16px' }}>MX Token</span></Typography>
                                                </div>
                                                <div className="my-3 d-block justify-content-center">
                                                    <Typography className="fw-bold text-center" sx={{ fontSize: '30px', color: '#1A94AE' }}>45.40%</Typography>
                                                    <Typography className="fw-bold text-center" sx={{ color: '#7f7f7f', fontSize: '16px' }}>EST.APY</Typography>
                                                </div>
                                                 <Link to='/newtoken' className="linkTag d-grid">   <button className="btn fw-bold" style={{ background: '#1A94AE', color: 'white' }}>Stake now</button></Link>
                                            </CardContent>
                                        </Card>
                                    </Grid>
                                    <Grid item xs={12} sm={12} md={6} lg={4}>
                                        <Card className="profile-page-card" sx={{ minWidth: 'auto', maxWidth: 'auto' }} >
                                            <CardContent>
                                                <div>
                                                    <Typography className="card-text fw-bold" sx={{ fontSize: '24px' }}><img alt="logo" style={{ width: '30px', height: '30px' }} src={BOT} className='me-2' />BOT <span style={{ fontSize: '16px' }}>Starbots Token</span></Typography>
                                                </div>
                                                <div className="my-3 d-block justify-content-center">
                                                    <Typography className="fw-bold text-center" sx={{ fontSize: '30px', color: '#1A94AE' }}>7398.87%</Typography>
                                                    <Typography className="fw-bold text-center" sx={{ color: '#7f7f7f', fontSize: '16px' }}>EST.APY</Typography>
                                                </div>
                                                 <Link to='/newtoken' className="linkTag d-grid">   <button className="btn fw-bold" style={{ background: '#1A94AE', color: 'white' }}>Stake now</button></Link>
                                            </CardContent>
                                        </Card>
                                    </Grid>
                                </Grid>
                            </div>
                        </Box>
                        {/* ==============================MCRT=========== */}
                        <Box sx={{ mt: 2 }}>
                            <div class="container">
                                <div className="d-flex justify-content-between mb-2">
                                    <div>
                                        <Typography className="text-heading"><img alt="Travis Howard" src={one} className='me-2' style={{ width: '18px', height: '21px' }} />Mining gains MCRT</Typography>
                                    </div>
                                </div>
                                {/* -------------------- MINING GAINS BOTS----------- */}
                                <Card
                                    className="profile-page-card"
                                    sx={{ minWidth: "auto", maxWidth: "auto" }}
                                >
                                    <CardContent>
                                        <Container className='my-5'>
                                            <Grid item xs={12} sm={12} md={12} lg={12}>
                                                <Grid item spacing={4} container>
                                                    <Grid item xs={12} sm={12} md={12} lg={6}>
                                                        <Card className='lovely-card-bg bradius-0' sx={{ maxWidth: 'auto', minWidth: 'auto' }}>
                                                            <CardContent>
                                                                <Typography className="card-text mb-0 text-center" sx={{ fontWeight: 600, fontSize: 40 }}>80000</Typography>
                                                                <Typography className="text-center" sx={{ color: '#7f7f7f', fontWeight: 600, fontSize: 16 }}>Today’s mining pool[BOT]</Typography>
                                                            </CardContent>
                                                        </Card>
                                                    </Grid>
                                                    <Grid item xs={12} sm={12} md={12} lg={6}>
                                                        <Card className='lovely-card-bg bradius-0'>
                                                            <CardContent>
                                                                <Typography className="card-text mb-0 text-center" sx={{ fontWeight: 600, fontSize: 40 }}>0.2738</Typography>
                                                                <Typography className="text-center" sx={{ color: '#7f7f7f', fontWeight: 600, fontSize: 16 }}>Last Price[BOT/USDT]</Typography>
                                                            </CardContent>
                                                        </Card>
                                                    </Grid>
                                                    <Grid item xs={12} sm={12} md={12} lg={6}>
                                                        <Card className='lovely-card-bg bradius-0'>
                                                            <CardContent>
                                                                <Typography className="card-text mb-0 text-center" sx={{ fontWeight: 600, fontSize: 40 }}>240000</Typography>
                                                                <Typography className="text-center" sx={{ color: '#7f7f7f', fontWeight: 600, fontSize: 16 }}>Total Supply[BOT]</Typography>
                                                            </CardContent>
                                                        </Card>
                                                    </Grid>
                                                    <Grid item xs={12} sm={12} md={12} lg={6}>
                                                        <Card className='lovely-card-bg bradius-0'>
                                                            <CardContent>
                                                                <Typography className="card-text mb-0 text-center" sx={{ fontWeight: 600, fontSize: 40 }}>13458.79</Typography>
                                                                <Typography className="text-center" sx={{ color: '#7f7f7f', fontWeight: 600, fontSize: 16 }}>Total Value locked[USDT]</Typography>
                                                            </CardContent>
                                                        </Card>
                                                    </Grid>
                                                </Grid>
                                            </Grid>
                                        </Container>
                                    </CardContent>
                                </Card>
                                <Grid item spacing={2} container sx={{ my: 3 }}>
                                    <Grid item xs={12} sm={12} md={6} lg={4}>
                                        <Card className="profile-page-card" sx={{ minWidth: 'auto', maxWidth: 'auto' }} >
                                            <CardContent>
                                                <div>
                                                    <Typography className="card-text fw-bold" sx={{ fontSize: '24px' }}><img alt="logo" style={{ width: '30px', height: '30px' }} src={mxlogo} className='me-2' />MX <span style={{ fontSize: '16px' }}>MX Token</span></Typography>
                                                </div>
                                                <div className="my-3 d-block justify-content-center">
                                                    <Typography className="fw-bold text-center" sx={{ fontSize: '30px', color: '#1A94AE' }}>45.40%</Typography>
                                                    <Typography className="fw-bold text-center" sx={{ color: '#7f7f7f', fontSize: '16px' }}>EST.APY</Typography>
                                                </div>
                                                 <Link to='/newtoken' className="linkTag d-grid">   <button className="btn fw-bold" style={{ background: '#1A94AE', color: 'white' }}>Stake now</button></Link>
                                            </CardContent>
                                        </Card>
                                    </Grid>
                                    <Grid item xs={12} sm={12} md={6} lg={4}>
                                        <Card className="profile-page-card" sx={{ minWidth: 'auto', maxWidth: 'auto' }} >
                                            <CardContent>
                                                <div>
                                                    <Typography className="card-text fw-bold" sx={{ fontSize: '24px' }}><img alt="logo" style={{ width: '30px', height: '30px' }} src={BOT} className='me-2' />BOT <span style={{ fontSize: '16px' }}>Starbots Token</span></Typography>
                                                </div>
                                                <div className="my-3 d-block justify-content-center">
                                                    <Typography className="fw-bold text-center" sx={{ fontSize: '30px', color: '#1A94AE' }}>7398.87%</Typography>
                                                    <Typography className="fw-bold text-center" sx={{ color: '#7f7f7f', fontSize: '16px' }}>EST.APY</Typography>
                                                </div>
                                                 <Link to='/newtoken' className="linkTag d-grid">   <button className="btn fw-bold" style={{ background: '#1A94AE', color: 'white' }}>Stake now</button></Link>
                                            </CardContent>
                                        </Card>
                                    </Grid>
                                </Grid>
                                   {/* /////////////////////////////////STARKING CARDS//////////// */}
                                   <div>
                                    <Typography className="text-heading mb-0"><img alt="Travis Howard" src={one} className='me-2' style={{ width: '18px', height: '21px' }} />Staking</Typography>
                                </div>
                                <Grid item spacing={2} container sx={{ my: 0 }}>
                                <Grid item xs={12} sm={12} md={6} lg={4}>
                                        <Card className="profile-page-card" sx={{ minWidth: 'auto', maxWidth: 'auto' }} >
                                            <CardContent>
                                            <div className="d-flex justify-content-between">
                                                    <div>
                                                        <Typography className="card-text fw-bold" sx={{ fontSize: '24px' }}><img alt="logo" style={{ width: '30px', height: '30px' }} src={mxlogo} className='me-2' />MX <span style={{ fontSize: '16px' }}>MX Token</span></Typography>
                                                    </div>
                                                    <div>
                                                        <Typography className="fw-bold" sx={{ fontSize: '10px', color: '#1777F2' }}>MX Staking2</Typography>
                                                    </div>
                                                </div>
                                                <div className="d-flex justify-content-between">
                                                <div className="my-3 d-block justify-content-center">
                                                    <Typography className="fw-bold text-center" sx={{ fontSize: '30px', color: '#1A94AE' }}>55.65%</Typography>
                                                    <Typography className="fw-bold text-center" sx={{ color: '#7f7f7f', fontSize: '14px' }}>EST.APY</Typography>
                                                </div>
                                                <div className="my-3 mb-5 d-block justify-content-center">
                                                    <Typography className="fw-bold card-text" sx={{ fontSize: '30px'}}>1 day[s]</Typography>
                                                    <Typography className="fw-bold" sx={{ color: '#7f7f7f', fontSize: '14px' }}>Min.Term[Days]</Typography>
                                                </div>
                                                </div>
                                                <div className="d-grid"> 
                                                    <button className="btn fw-bold" style={{ background: 'rgba(0, 0, 0, 0.4)', color: 'white' }}>Ended</button>
                                                </div>
                                            </CardContent>
                                        </Card>
                                    </Grid>
                                    <Grid item xs={12} sm={12} md={6} lg={4}>
                                        <Card className="profile-page-card" sx={{ minWidth: 'auto', maxWidth: 'auto' }} >
                                            <CardContent>
                                            <div className="d-flex justify-content-between">
                                                <div>
                                                    <Typography className="card-text fw-bold" sx={{ fontSize: '24px' }}><img alt="logo" style={{ width: '30px', height: '30px' }} src={BOT} className='me-2' />BOT <span style={{ fontSize: '16px' }}>Starbots Token</span></Typography>
                                                </div>
                                                    <div>
                                                        <Typography className="fw-bold" sx={{ fontSize: '10px', color: '#1777F2' }}>BOT Staking2</Typography>
                                                    </div>
                                                </div>
                                                <div className="d-flex justify-content-between">
                                                <div className="my-3 d-block justify-content-center">
                                                    <Typography className="fw-bold text-center" sx={{ fontSize: '30px', color: '#1A94AE' }}>60.00%</Typography>
                                                    <Typography className="fw-bold text-center" sx={{ color: '#7f7f7f', fontSize: '14px' }}>EST.APY</Typography>
                                                </div>
                                                <div className="my-3 d-block justify-content-center">
                                                    <Typography className="fw-bold card-text" sx={{ fontSize: '30px'}}>1 day[s]</Typography>
                                                    <Typography className="fw-bold" sx={{ color: '#7f7f7f', fontSize: '14px' }}>Min.Term[Days]</Typography>
                                                </div>
                                                </div>
                                                <div>
                                                    <Typography className="mb-3 fw-bold"sx={{fontSize: '14px' }}><span className="text-muted">Staking amount:</span> <span className="txt-blue">Unlimited</span></Typography>
                                                </div>
                                                 <Link to='/newtoken' className="linkTag d-grid">   <button className="btn fw-bold" style={{ background: '#1A94AE', color: 'white' }}>Stake now</button></Link>
                                            </CardContent>
                                        </Card>
                                    </Grid>
                                    <Grid item xs={12} sm={12} md={6} lg={4}>
                                        <Card className="profile-page-card" sx={{ minWidth: 'auto', maxWidth: 'auto' }} >
                                            <CardContent>
                                            <div className="d-flex justify-content-between">
                                                    <div>
                                                        <Typography className="card-text fw-bold" sx={{ fontSize: '24px' }}><img alt="logo" style={{ width: '30px', height: '30px' }} src={mxlogo} className='me-2' />MX <span style={{ fontSize: '16px' }}>MX Token</span></Typography>
                                                    </div>
                                                    <div>
                                                        <Typography className="fw-bold" sx={{ fontSize: '10px', color: '#1777F2' }}>MX Staking2</Typography>
                                                    </div>
                                                </div>
                                                <div className="d-flex justify-content-between">
                                                <div className="my-3 d-block justify-content-center">
                                                    <Typography className="fw-bold text-center" sx={{ fontSize: '30px', color: '#1A94AE' }}>80.00%</Typography>
                                                    <Typography className="fw-bold text-center" sx={{ color: '#7f7f7f', fontSize: '14px' }}>EST.APY</Typography>
                                                </div>
                                                <div className="my-3 d-block justify-content-center mb-5">
                                                    <Typography className="fw-bold card-text" sx={{ fontSize: '30px'}}>1 day[s]</Typography>
                                                    <Typography className="fw-bold" sx={{ color: '#7f7f7f', fontSize: '14px' }}>Min.Term[Days]</Typography>
                                                </div>
                                                </div>
                                                <div className="d-grid"> 
                                                    <button className="btn fw-bold" style={{ background: 'rgba(0, 0, 0, 0.4)', color: 'white' }}>Ended</button>
                                                </div>
                                            </CardContent>
                                        </Card>
                                    </Grid>
                                </Grid>
                            </div>
                        </Box>
                    </TabPanel>
                </TabContext>
            </Container>
        </div>
    );
};
export default Defi;
