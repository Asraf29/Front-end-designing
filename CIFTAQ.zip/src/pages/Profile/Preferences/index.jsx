import React from 'react';
import ArrowBackIosIcon from "@mui/icons-material/ArrowBackIos";
import { Container } from "@mui/system";
import { Checkbox, Grid, ListItemButton, ListItemIcon, ListItemText, Typography, Box, Button, CardContent } from '@mui/material';
import Card from "@mui/material/Card";
import { styled } from '@mui/material/styles';
import FormGroup from '@mui/material/FormGroup';
import FormControlLabel from '@mui/material/FormControlLabel';
import Switch from '@mui/material/Switch';
import Stack from '@mui/material/Stack';
import { Link } from 'react-router-dom';
import red from '../../../components/assets/images/red.png';
import green from '../../../components/assets/images/green.png';
import standard from '../../../components/assets/images/standard.png'
import '../index.css';
const Android12Switch = styled(Switch)(({ theme }) => ({
  padding: 8,
  '& .MuiSwitch-track': {
    borderRadius: 22 / 2,
    '&:before, &:after': {
      content: '""',
      position: 'absolute',
      top: '50%',
      transform: 'translateY(-50%)',
      width: 16,
      height: 16,
    },
    '&:before': {
      backgroundImage: `url('data:image/svg+xml;utf8,<svg xmlns="http://www.w3.org/2000/svg" height="16" width="16" viewBox="0 0 24 24"><path fill="${encodeURIComponent(
        theme.palette.getContrastText(theme.palette.primary.main),
      )}" d="M21,7L9,19L3.5,13.5L4.91,12.09L9,16.17L19.59,5.59L21,7Z"/></svg>')`,
      left: 12,
    },
    '&:after': {
      backgroundImage: `url('data:image/svg+xml;utf8,<svg xmlns="http://www.w3.org/2000/svg" height="16" width="16" viewBox="0 0 24 24"><path fill="${encodeURIComponent(
        theme.palette.getContrastText(theme.palette.primary.main),
      )}" d="M19,13H5V11H19V13Z" /></svg>')`,
      right: 12,
    },
  },
  '& .MuiSwitch-thumb': {
    boxShadow: 'none',
    width: 16,
    height: 16,
  },
}));
export default function Preference() {
  return (
    <div>
      <Container sx={{ my: 7 }}>
        <Link to="/profile" className="linkTag"><Typography className="mb-3 d-flex align-items-center verifyTitle" variant="h5"><ArrowBackIosIcon className="mb-2" />API</Typography></Link>
        {/*Main Card*/}
        <Grid item xs={12} sm={12} md={12} lg={12}>
          <Card className="profile-page-card mt-5 mt-sm-0"
            sx={{ minWidth: 'auto', maxWidth: "auto" }}>
            <CardContent>
              <Grid item xs={12} sm={12} md={12} lg={12}>

                {/* Toggle Rise/Fall */}
                <div className='d-block d-md-flex justify-content-between block-sm  '>
                  <Typography className="APITitle ps-3 ps-md-5 pt-5">Display Mode</Typography>
                  <div className='d-flex block-sm  col-xs-12'> <ListItemButton className="my-4">
                    <ListItemIcon className="mb-1">
                      <Checkbox edge="start" tabIndex={-1} disableRipple />
                    </ListItemIcon>
                    <ListItemText className="checkbox-text APILabelSize" primary={'Light'} />
                  </ListItemButton>
                    <ListItemButton className="my-4">
                      <ListItemIcon className="mb-1">
                        <Checkbox edge="start" tabIndex={-1} disableRipple />
                      </ListItemIcon>
                      <ListItemText className="checkbox-text APILabelSize" primary={'Dark'} />
                    </ListItemButton>
                  </div>
                </div>
                {/* Toggle Rise/Fall */}
                <div className='d-block d-md-flex  justify-content-between'>
                  <Typography className="APITitle ps-3 ps-md-5 pt-5">Toggle Rise/Fall</Typography>
                  <div className='d-flex block-sm '> <ListItemButton className="my-4">
                    <ListItemIcon className=" mb-1">
                      <Checkbox edge="start" tabIndex={-1} disableRipple />
                    </ListItemIcon>
                    <ListItemText className="checkbox-text APILabelSize" primary={'Green-Up'} />
                    <ListItemText className="checkbox-text APILabelSize ms-2"><img src={green} style={{ width: '19px', height: '20px' }} /></ListItemText>
                  </ListItemButton>
                    <ListItemButton className="my-4">
                      <ListItemIcon className="mb-1">
                        <Checkbox edge="start" tabIndex={-1} disableRipple />
                      </ListItemIcon>
                      <ListItemText className="checkbox-text APILabelSize" primary={'Red-Up'} />

                      <ListItemText className="checkbox-text APILabelSize ms-2"><img src={red} style={{ width: '19px', height: '20px' }} /></ListItemText>
                    </ListItemButton>
                  </div>
                </div>
                {/* Trading Interface */}
                <div className='d-block d-md-flex justify-content-between'>
                  <Typography className="APITitle ps-3 ps-md-5 pt-5">Trading Interface</Typography>
                  <div className='d-block d-md-flex'> <ListItemButton className="my-4 border-check me-2">
                    <ListItemIcon className=" mb-1">
                      <Checkbox edge="start" tabIndex={-1} disableRipple />
                    </ListItemIcon>
                    <ListItemText className="checkbox-text APILabelSize" primary={'Standard'} />
                    <ListItemText className="checkbox-text APILabelSize ms-2 img-size"><img src={standard} style={{ width: '72px', height: '46px' }} /></ListItemText>
                  </ListItemButton>
                    <ListItemButton className="my-4 border-check me-2">
                      <ListItemIcon className="mb-1">
                        <Checkbox edge="start" tabIndex={-1} disableRipple />
                      </ListItemIcon>
                      <ListItemText className="checkbox-text APILabelSize" primary={'Horizontal'} />
                      <ListItemText className="checkbox-text APILabelSize ms-2 img-size"><img src={standard} style={{ width: '72px', height: '46px' }} /></ListItemText>
                    </ListItemButton>
                    <ListItemButton className="my-4 border-check me-2">
                      <ListItemIcon className="mb-1">
                        <Checkbox edge="start" tabIndex={-1} disableRipple />
                      </ListItemIcon>
                      <ListItemText className="checkbox-text APILabelSize" primary={'Vertical'} />
                      <ListItemText className="checkbox-text APILabelSize ms-2 img-size"><img src={standard} style={{ width: '72px', height: '46px' }} /></ListItemText>
                    </ListItemButton>
                  </div>
                </div>
                {/* Order book display */}
                <div className='d-block d-md-flex block-sm  justify-content-between'>
                  <Typography className="APITitle ps-3 ps-md-5 pt-5">Order book display</Typography>
                  <div className='d-block d-md-flex'> <ListItemButton className="my-4">
                    <ListItemIcon className=" mb-1">
                      <Checkbox edge="start" tabIndex={-1} disableRipple />
                    </ListItemIcon>
                    <ListItemText className="checkbox-text APILabelSize" primary={'cum.Quantity/Amount'} />
                  </ListItemButton>
                    <ListItemButton className="my-4">
                      <ListItemIcon className="mb-1">
                        <Checkbox edge="start" tabIndex={-1} disableRipple />
                      </ListItemIcon>
                      <ListItemText className="checkbox-text APILabelSize" primary={'Quantity/Amount'} />
                    </ListItemButton>
                  </div>
                </div>
                {/* Third Column of the currency listing */}
                <div className='d-block d-md-flex  justify-content-between'>
                  <Typography className="APITitle ps-3 ps-md-5 pt-5">Third Column of the currency listing</Typography>
                  <div className='d-block d-md-flex'> <ListItemButton className="my-4">
                    <ListItemIcon className=" mb-1">
                      <Checkbox edge="start" tabIndex={-1} disableRipple />
                    </ListItemIcon>
                    <ListItemText className="checkbox-text APILabelSize" primary={'Price Change Priority'} />
                  </ListItemButton>
                    <ListItemButton className="my-4">
                      <ListItemIcon className="mb-1">
                        <Checkbox edge="start" tabIndex={-1} disableRipple />
                      </ListItemIcon>
                      <ListItemText className="checkbox-text APILabelSize" primary={'Trading Volume Priority'} />
                    </ListItemButton>
                  </div>

                </div>
                <div className='d-block d-md-flex  justify-content-between'>
                  <div>
                    <Typography className="APITitle ps-3 ps-md-5 pt-5">Message</Typography>
                    <Typography className="ps-3 ps-md-5 pt-1 checkbox-text">Push only important notification [if you don’t want to be disturbed when trading, please turn off this function]</Typography>
                  </div>
                  <div className='d-block d-md-flex ms-3 ms-sm-0'>
                    <FormControlLabel
                      control={<Android12Switch defaultChecked />}
                    />
                  </div>

                </div>
                <div className='d-block d-md-flex justify-content-between'>
                  <div>
                    <Typography className="APITitle ps-3 ps-md-5 pt-5">Default Currency</Typography>
                  </div>
                  <div className='d-block d-md-flex me-4 pt-5 pb-4'>
                    <select className="form-select blue-select text-white" style={{ height: '40px', fontWeight: 600, background: 'rgba(26, 148, 174, 0.5)' }} aria-label="Default select example">
                      <option className='textClr' selected>  &#36; USD</option>
                      <option className='textClr' value="1">BTC</option>
                      <option className='textClr' value="2">USDT</option>
                      <option className='textClr' value="3">USD</option>
                    </select>

                  </div>

                </div>

              </Grid>
            </CardContent>
          </Card>
        </Grid>
      </Container>
    </div>
  )
}
