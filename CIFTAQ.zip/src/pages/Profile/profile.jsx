import React, { useState } from 'react'
import Box from "@mui/material/Box";
import Card from "@mui/material/Card";
import CardContent from "@mui/material/CardContent";
import { Button, Grid, makeStyles, Table, TableBody, TableCell, TableContainer, TableHead, TableRow, Tabs, Typography } from "@mui/material";
import Avatar from '@mui/material/Avatar';
import { Container } from "@mui/system";
import { lightBlue } from '@mui/material/colors';
import cardBg from '../../components/assets/images/cardBg.png';
import KeyboardArrowRightIcon from '@mui/icons-material/KeyboardArrowRight';
import identity from '../../components/assets/images/identity.png'
import APIWindow from '../../components/assets/images/api-window.png'
import settingIcon from '../../components/assets/images/setting.png'
import tradeGrowth from '../../components/assets/images/trade-growth.png'
import securityIcon from '../../components/assets/images/security.png'
import withdrawIcon from '../../components/assets/images/withdraw.png'
import {Link} from 'react-router-dom'
import "./index.css";
import NicknameModal from '../../components/Nickname';
const data = ['1', '2', '3', '4', '5', '6'];
const Profile = () => {
  const [openNickName, setOpenNickName] = useState(false);

  const handleClickOpen = () => {
    setOpenNickName(true);
  };
  const handleClose = () => {
    setOpenNickName(false);
  };
  return (
    <div>
      <NicknameModal openNickName={openNickName} handleClickOpen={handleClickOpen} handleClose={handleClose} />
      <div className="profile-bg"></div>
      <div className="relativePart">
        <Container className="absolutePart">
          {/* Banner */}
          <Card className="profile-page-card mt-5 mt-sm-0"
            sx={{ minWidth: 'auto', maxWidth: "auto" }}>
            <CardContent className='flexOption'>
              <div className='d-flex align-items-center'>
                <Grid container sx={{ display: 'flex', alignItems: 'center' }} spacing={6}>
                  <Grid item xs={12} sm={2} md={2} lg={2} className="d-flex justify-content-center justify-content-sm-start">
                    <Avatar sx={{ bgcolor: lightBlue[500], width: 56, height: 56 }} >Md</Avatar>
                    <Grid />
                  </Grid>
                  <Grid item xs={12} sm={10} md={10} lg={10}>
                    <Box className="d-flex justify-content-center justify-content-sm-start mb-3 my-sm-0 mb-md-2"><Typography variant="h5" className='ps-2 fontSizeProp' role="button" sx={{ fontWeight: 600 }}>Set nickname <i onClick={() => { handleClickOpen() }} class="bi bi-pencil-square editIcon ms-1" /><button className='btn vipBtn ms-4'> <span class="iconify vipIcon mb-1" data-icon="quill:vip"></span>MEXC VIP</button></Typography></Box>
                    <div className="d-flex justify-content-center justify-content-sm-start mb-3">
                      <input type="email" className="form-control bannerInputOne" id="exampleFormControlInput1" placeholder="Account: Exa***mple@gmail.com" />
                      <input type="email" className="form-control bannerInputTwo ms-2 ps-1" id="exampleFormControlInput2" placeholder="UID : 27606905 " />
                    </div>
                  </Grid>
                </Grid>
              </div>
              <div>
                <Grid container>
                  <Grid item xs={12} sm={3} md={3} lg={3}>
                    <p className='text-center'> <Box component="img"
                      alt="card-bg"
                      src={cardBg} /></p>
                  </Grid>
                </Grid>
              </div>
            </CardContent>
          </Card>
        </Container>
      </div>
      <Container>
        <Box>
          {/*First pair Cards */}
          <Grid container sx={{ mt: 2 }} spacing={2}>
            <Grid item xs={12} sm={6} md={6} lg={6}>
              <Card className="profile-page-card"
                sx={{ minWidth: "auto", maxWidth: "auto" }}>
                <CardContent>
                  <Box className='d-flex justify-content-between mb-3'>
                    <div><Typography variant="h6" className="fontsize-card card-text">Verify Your Identity</Typography></div>
                    <div><Box component="img" src={identity} alt="icon1"></Box></div>
                  </Box>
                  <Box className='card-border'>
                    <Typography className='mb-1 card-sub-text'>Current withdrawal Limit 5BTC in 24 hours</Typography>
                    <Typography className="mb-3 card-sub-text">Complete the verification process to increase your with drawal limit</Typography>
                  </Box>
                  <Link to="/verifyIdentity" className='linkTag d-flex align-items-center'><Typography className='mt-1 primarykyc-color'>Primary KYC<KeyboardArrowRightIcon className='mb-2 arrow-icon-color' /></Typography></Link>
                </CardContent>
              </Card>
              <Grid />
            </Grid>
            <Grid item xs={12} sm={6} md={6} lg={6}>
              <Card className="profile-page-card"
                sx={{ minWidth: "auto", maxWidth: "auto" }}>
                <CardContent>
                  <Box className='d-flex justify-content-between mb-3'>
                    <div><Typography variant="h6" className="fontsize-card card-text">Security Center</Typography></div>
                    <div><Box component="img" src={securityIcon} alt="icon1"></Box></div>
                  </Box>
                  <Box className='card-border'>
                    <Typography className='mb-4 pb-3 card-text'>Account risk level:</Typography>
                  </Box>
                  <Link to="/securityCenter" className=' d-flex align-items-center linkTag'><Typography className='mt-1 primarykyc-color'>Security Recommendations<KeyboardArrowRightIcon className='mb-2 arrow-icon-color' /></Typography></Link>
                </CardContent>
              </Card>
            </Grid>
          </Grid>
          {/* second pair cards */}
          <Grid container sx={{ mt: 2 }} spacing={2}>
            <Grid item xs={12} sm={6} md={6} lg={6}>
              <Card className="profile-page-card"
                sx={{ minWidth: "auto", maxWidth: "auto" }}>
                <CardContent>
                  <Box className='d-flex justify-content-between mb-3'>
                    <div><Typography variant="h6" className="fontsize-card card-text">API</Typography></div>
                    <div><Box component="img" src={APIWindow} alt="icon1"></Box></div>
                  </Box>
                  <Box className="card-border">
                    <Typography className='mb-4 pb-2 card-sub-text'>Create an API Key </Typography>
                  </Box>
                  <Link to="/api" className="linkTag"><Typography className='mt-1 manage-color'>Manage</Typography></Link>
                </CardContent>
              </Card>
              <Grid />
            </Grid>
            <Grid item xs={12} sm={6} md={6} lg={6}>
              <Card className="profile-page-card"
                sx={{ minWidth: "auto", maxWidth: "auto" }}>
                <CardContent>
                  <Box className='d-flex justify-content-between mb-3'>
                    <div><Typography variant="h6" className="fontsize-card card-text">Withdrawal Settings</Typography></div>
                    <div><Box component="img" src={withdrawIcon} alt="icon1"></Box></div>
                  </Box>
                  <Box className='card-border'>
                    <Typography className='mb-4 pb-1 card-sub-text'>Add/Edit Withdrawal Address</Typography>
                  </Box>
                  <Link to="/withdrawsetting" className="linkTag"><Typography className='mt-1 manage-color'>Manage</Typography></Link>
                </CardContent>
              </Card>
            </Grid>
          </Grid>
          {/* third pair cards */}
          <Grid container sx={{ mt: 2 }} spacing={2}>
            <Grid item xs={12} sm={6} md={6} lg={6}>
              <Card className="profile-page-card"
                sx={{ minWidth: "auto", maxWidth: "auto" }}>
                <CardContent>
                  <Box className='d-flex justify-content-between mb-3'>
                    <div><Typography variant="h6" className="fontsize-card card-text">Preferences</Typography></div>
                    <div><Box component="img" src={settingIcon} alt="icon1"></Box></div>
                  </Box>
                  <Box className="card-border">
                    <Typography className='mb-4 pb-2 card-sub-text'>Customize you UI </Typography>
                  </Box>
                <Link to='/preference' className='linkTag'>  <div><Typography className='mt-1 manage-color'>set</Typography></div></Link>
                </CardContent>
              </Card>
              <Grid />
            </Grid>
            <Grid item xs={12} sm={6} md={6} lg={6}>
              <Card className="profile-page-card"
                sx={{ minWidth: "auto", maxWidth: "auto" }}>
                <CardContent>
                  <Box className='d-flex justify-content-between mb-3'>
                    <div><Typography variant="h6" className="fontsize-card card-text">Trading Fee</Typography></div>
                    <div><Box component="img" src={tradeGrowth} alt="icon1"></Box></div>
                  </Box>
                  <Box className='card-border'>
                    <Typography className='mb-4 pb-1 card-sub-text'>Check your current trading fee</Typography>
                  </Box>
                  <Link to="/tradingFee" className="linkTag"><Typography className='mt-1 manage-color'>More</Typography></Link>
                </CardContent>
              </Card>
            </Grid>
          </Grid>
          {/* Recent Login */}
          <TableContainer>
          <Table  className='my-5 pb-5 table-color'>
            <TableHead sx={{ border: 0 }}>
            <Typography variant="h6" className='fontsize-card ms-3 mt-3  card-text'>Recent Login</Typography>
              <TableRow >
                <TableCell className="theadColor" align="start" sx={{  borderBottom: "none" }}>Time</TableCell>
                <TableCell className="theadColor" align="center" sx={{ borderBottom: "none" }}>IP</TableCell>
                <TableCell className="theadColor" align="right" sx={{ borderBottom: "none" }}>Locatoion</TableCell>
              </TableRow>
            </TableHead>
            {data.map((tableData,index)=>(<TableBody key={index}>
            <TableCell className="table-text" align="start" sx={{  borderBottom: "none" }}>2022-01-04 10:26:02</TableCell>
            <TableCell className="table-text" align="center" sx={{  borderBottom: "none", }}>49.37.212.20</TableCell>
            <TableCell className="table-text" align="right" sx={{  borderBottom: "none" }}>India-Tamil Nadu-Chennai</TableCell>
            </TableBody>))}
          </Table>
          </TableContainer>
        </Box>
      </Container>
    </div >
  )
}
export default Profile;