import {
  Button,
  Grid,
  Paper,
  Table,
  TableBody,
  TableCell,
  TableContainer,
  TableHead,
  TableRow,
  Typography,
} from "@mui/material";
import ArrowBackIosIcon from "@mui/icons-material/ArrowBackIos";
import { Box, Container } from "@mui/system";
import React, { useState } from "react";
import NODATA from "../../../components/assets/images/nodata.png";
import { Link } from "react-router-dom";
import WithdrawModal from '../../../components/WithdrawModal/index'
import "../index.css";
const WithdrawSetting = () => {
  const [openWithdrawModal, setOpenWithdrawModal] = useState(false);
  const WithdrawhandleOpen = () => {
    setOpenWithdrawModal(true);
  };
  const WithdrawhandleClose = () => {
    setOpenWithdrawModal(false);
  };

  return (
    <div>
      <WithdrawModal
        openWithdrawModal={openWithdrawModal}
        WithdrawhandleOpen={WithdrawhandleOpen}
        WithdrawhandleClose={WithdrawhandleClose}
      />
      <Grid item xs={12} lg={12} md={3}>
        <Container>
          <Box className="my-5 py-5">
            <Link to="/profile" className="linkTag"><Typography className="mb-3 d-flex align-items-center verifyTitle" variant="h5"><ArrowBackIosIcon className="mb-2" />Withdrawal Setting</Typography></Link>
            <TableContainer
              component={Paper} sx={{ background: "var( --card-bg-color)" }}>
              <div className="d-flex justify-content-between">
                <div className="m-3" style={{ color: "var(--profile-textClr)" }}>
                  <b>Withdrawal Settings</b>
                </div>
                <div className="d-block  my-2 d-sm-block d-md-flex">
                  <div className='my-1 me-2'>
                    <select style={{ fontWeight: 600 }} className="inputbg form-select textClr" aria-label="Default select example">
                      <option className='textClr' selected>Select Token</option>
                      <option className='textClr' value="1">0x202x0</option>
                      <option className='textClr' value="2">0xx545</option>
                      <option className='textClr' value="3">0x789x</option>
                    </select>
                  </div>
                  <Button className="btn btn-sm   my-lg-1 me-2 mb-2 mb-lg-0" style={{ background: "#1a94ae", color: "white" }}>
                    Add withdrawal address
                  </Button>
                </div>
              </div>
              <Table sx={{ minWidth: 650, background: "var( --card-bg-color)" }} aria-label="simple table">
                <TableHead>
                  <TableRow sx={{ border: "1px solid grey",borderRight: 0,borderLeft: 0}}>
                    <TableCell sx={{fontWeight: "bolder !important",color: "grey !important"}} align="center">
                      Crypto
                    </TableCell>
                    <TableCell sx={{fontWeight: "bolder !important",color: "grey !important"}}align="left">
                      <div className="d-flex me-2">Chaintype</div>
                    </TableCell>
                    <TableCell sx={{fontWeight: "bolder !important",color: "grey !important"}} align="left">
                      <div className="d-flex me-2">Address labels</div>
                    </TableCell>
                    <TableCell sx={{fontWeight: "bolder !important",color: "grey !important"}} align="left">
                      <div className="d-flex me-2">Price</div>
                    </TableCell>
                    <TableCell sx={{ fontWeight: "bolder !important",color: "grey !important"}}align="left">
                      <div className="d-flex me-2">Withdrawal address</div>
                    </TableCell>
                    <TableCell sx={{fontWeight: "bolder !important",color: "grey !important"}} align="left">
                      <div className="d-flex me-2">Memo</div>
                    </TableCell>
                    <TableCell sx={{fontWeight: "bolder !important",color: "grey !important"}}align="left">
                      Action
                    </TableCell>
                  </TableRow>
                </TableHead>
                <TableBody>
                  <TableRow sx={{ "&:last-child td, &:last-child th": { border: 0 } }}>
                    <TableCell align="center" colSpan={7} sx={{ justifyContent: "center", alignItems: "center" }}S>
                      <img src={NODATA} />
                    </TableCell>
                  </TableRow>
                </TableBody>
              </Table>
            </TableContainer>
          </Box>
        </Container>
      </Grid>
    </div>
  );
};
export default WithdrawSetting;
