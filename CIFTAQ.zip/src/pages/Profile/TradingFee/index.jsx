import React, { useState } from 'react'
import { Avatar, Box, Button, Paper, Table, TableBody, TableCell, TableContainer, TableHead, TableRow } from "@mui/material";
import Card from "@mui/material/Card";
import CardContent from "@mui/material/CardContent";
import { Container } from "@mui/system";
import { Checkbox, Grid, ListItemButton, ListItemIcon, ListItemText, Typography } from '@mui/material';
import ArrowBackIosIcon from '@mui/icons-material/ArrowBackIos';
import { Link } from 'react-router-dom';
import avatar1 from '../../../components/assets/images/horseAvatar.png';
import avatar2 from '../../../components/assets/images/checkedAvatar.png';
import SearchIcon from "@mui/icons-material/Search";
import MoreHorizIcon from '@mui/icons-material/MoreHoriz';
import card1Image from "../../../components/assets/images/trading-fee.png"
import card2Image from "../../../components/assets/images/Deposit-fee.png"
import card3Image from "../../../components/assets/images/withdraw-fee.png"
import "../index.css";
const data = ['1', '2', '3'];
const TradingFee = () => {
    return (
        <div>
            <Container sx={{ my: 7 }}>
                <Link to="/profile" className="linkTag"><Typography className=" d-flex align-items-center verifyTitle" variant="h5"><ArrowBackIosIcon className="mb-2" />Trading Fee</Typography></Link>
                <Typography className='textProperties my-4' variant="h4">Understanding CIFDAQ Global Fees</Typography>
                {/*Gradient Cards*/}
                <Grid container spacing={2} className="px-lg-4">
                    {/* Card-One */}
                    <Grid item xs={12} sm={6} md={4} lg={4}>
                        <Card className="gradientCard mt-2 mt-sm-0 py-2"
                            sx={{ minWidth: 'auto', maxWidth: "auto" }}>
                            <CardContent>
                                <Grid container className="d-flex align-items-center" spacing={3}>
                                    <Grid item xs={2} sm={2} md={2} lg={2}>
                                        <Box component="img"
                                            alt="Card_one_img"
                                            src={card1Image} />
                                    </Grid>
                                    <Grid item xs={10} sm={10} md={10} lg={10}>
                                        <Box className="d-flex justify-content-between ps-2 ps-sm-0">
                                            <Typography className='tradeCardText fw-bold'>Trading Fees</Typography>
                                            <Typography className='tradeCardText'>Makers 0.200%</Typography>
                                        </Box>
                                        <Box className="d-flex justify-content-between ps-2 ps-sm-0 ">
                                            <Typography className='tradeCardText'>Deducted from traded asset</Typography>
                                            <Typography className='tradeCardText'>Taker 0.200%</Typography>
                                        </Box>
                                    </Grid>
                                </Grid>
                            </CardContent>
                        </Card>
                    </Grid>
                    {/* card-Two */}
                    <Grid item xs={12} sm={6} md={4} lg={4}>
                        <Card className="gradientCard mt-2 mt-sm-0 py-2"
                            sx={{ minWidth: 'auto', maxWidth: "auto" }}>
                            <CardContent>
                                <Grid container className="d-flex align-items-center" spacing={3}>
                                    <Grid item xs={2} sm={2} md={2} lg={2}>
                                        <Box component="img"
                                            alt="Card_one_img"
                                            src={card2Image} />
                                    </Grid>
                                    <Grid item xs={10} sm={10} md={10} lg={10}>
                                        <Box className="d-flex justify-content-between align-items-center ps-2 ps-sm-0">
                                            <div>
                                                <Typography className='tradeCardText fw-bold'>Deposit Fees</Typography>
                                                <Typography className='tradeCardText'>Deposit is free of charge</Typography>
                                            </div>
                                            <div>
                                                <Typography className='tradeCardText fw-bold'>Free</Typography>
                                            </div>
                                        </Box>
                                    </Grid>
                                </Grid>
                            </CardContent>
                        </Card>
                    </Grid>
                    {/* card-Three */}
                    <Grid item xs={12} sm={6} md={4} lg={4}>
                        <Card className="gradientCard mt-2 mt-sm-0"
                            sx={{ minWidth: 'auto', maxWidth: "auto" }}>
                            <CardContent>
                                <Grid container className="d-flex align-items-center" spacing={3}>
                                    <Grid item xs={2} sm={2} md={2} lg={2}>
                                        <Box component="img"
                                            alt="Card_one_img"
                                            src={card3Image} />
                                    </Grid>
                                    <Grid item xs={10} sm={10} md={10} lg={10}>
                                        <Box className="d-flex justify-content-between align-items-center ps-2 ps-sm-0">
                                            <div>
                                                <Typography className='tradeCardText fw-bold'>Withdrawal Fees</Typography>
                                            </div>
                                            <div><MoreHorizIcon className="moreIconColor"/></div>
                                        </Box>
                                        <Typography className="tradeCardText ps-2 ps-sm-0">Withdrawal Fees is dynamically calculated based on networks demand and traffic</Typography>
                                    </Grid>
                                </Grid>
                            </CardContent>
                        </Card>
                    </Grid>
                </Grid>
                {/* Recent Login */}
                <TableContainer component={Paper} className="mt-5 pb-5 table-bg-color" sx={{ background: "var(--profile-table-bg)" }}>
                    <Box className="d-flex justify-content-between my-4 px-2">
                        <div className='mb-3'><Typography variant="h6" className='fontsize-card ms-3 mt-3  card-text '>Crypto fee rate</Typography></div>
                        <div className='pe-4 pt-2'>
                            <input
                                type="text"
                                className="form-control input-typing-space col-sm-5 search-bar-bg"
                            />
                            <span className="search-icon pe-2 text-dark">
                                <SearchIcon className="search-icon-clr" />
                            </span>
                        </div>
                    </Box>
                    <Table className='table-color'>
                        <TableHead sx={{ border: 0 }}>
                            <TableRow >
                                <TableCell className="theadColor" align="start" sx={{ borderBottom: "none" }}>Token</TableCell>
                                <TableCell className="theadColor" align="center" sx={{ borderBottom: "none" }}>Minimum withdrawal amount</TableCell>
                                <TableCell className="theadColor" align="center" sx={{ borderBottom: "none" }}>Withdrawal fee</TableCell>
                            </TableRow>
                        </TableHead>
                        <TableBody>
                            {data.map((tableData) => (<>
                                <TableRow>
                                    <TableCell className="table-text d-flex align-items-center" align="start" sx={{ borderBottom: "none" }}><Avatar alt="Travis Howard" src={avatar1} /><span className="ms-3">1 INCH</span><span className="ms-2 theadColor">1 INCH</span></TableCell>
                                    <TableCell className="table-text" align="center" sx={{ borderBottom: "none", }}>5</TableCell>
                                    <TableCell className="table-text" align="center" sx={{ borderBottom: "none" }}>7.29</TableCell>
                                </TableRow>
                                <TableRow>
                                    <TableCell className="table-text d-flex align-items-center" align="start" sx={{ borderBottom: "none" }}><Avatar alt="Travis Howard" src={avatar2} /><span className="ms-3">1 INCH</span><span className="ms-2 theadColor">1 INCH</span></TableCell>
                                    <TableCell className="table-text" align="center" sx={{ borderBottom: "none", }}>100</TableCell>
                                    <TableCell className="table-text" align="center" sx={{ borderBottom: "none" }}>79</TableCell>
                                </TableRow>
                            </>))}
                        </TableBody>
                    </Table>
                </TableContainer>
            </Container>
        </div >
    )
}
export default TradingFee;