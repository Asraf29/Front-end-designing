import React from 'react';
import './index.css';
import Logo from '../../../components/assets/images/logoimg.png'
import { Box, Container } from '@mui/system';
import { Typography } from '@mui/material';
import SearchIcon from '@mui/icons-material/Search';


export default function OfficialVerification() {
  return (
    <div className='offlbg'>
<Container className='container-fluid-size' sx={{padding:'100px'}}>
    <div className='d-block d-sm-flex justify-content-center'>
   <div className='me-0 me-sm-2 d-flex justify-content-center'>
   <img src={Logo}/>
       </div>
       <div className='borderRight-Offl d-flex justify-content-center'>
           <Typography className='ms-0 ms-sm-2 fntSize-Offl headTxt'  sx={{fontWeight:500}}>Official Verification Channel</Typography>
       </div>
    </div>
    <Box className='d-block d-sm-flex justify-content-center'>
    <div className="col-lg-8 col-sm-12 col-md-12 my-4 ms-0 ms-sm-4">
    <div className="input-group mb-3 d-flex">
  <input type="text" style={{height:'50px', background:'var(--login-input-bg)'}} className="form-control border-0" placeholder="Please enter the content" aria-label="Recipient's username" aria-describedby="basic-addon2"/>
  <div className="input-group-append">
    <button style={{height:'50px', background:'#1A94AE', color:'white'}} className="btn border-0" type="button"><SearchIcon sx={{color:'white'}}/></button>
  </div>
</div>
    </div>
    </Box>
    <div style={{textAlign:'center'}} className='headTxt'>
        <Typography>
        For the safety of our traders and to prevent fraud done in the name of MEXC, Twitter and Facebook
        </Typography>
    </div>
    <div style={{textAlign:'center'}} className='headTxt'>
        <Typography>
        we created a tool to verify if the said social media channel is an official MEXC channel or not.
        </Typography>
    </div>
    <div style={{textAlign:'center'}} className='headTxt'>
        <Typography>
        You can do that by simply entering the name of the social media channel you follow and wait for the result. 
        </Typography>
    </div>
    <div className='my-5 linkTxts' style={{textAlign:'center'}}>
        <Typography>
        A must-Know for all MEXC uses: Fraud Prevention Manual.Beware of escalation of fraud!
        </Typography>
    </div>
</Container>
    </div>
  )
}
