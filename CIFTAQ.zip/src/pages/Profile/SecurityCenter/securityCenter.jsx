import React, { useState } from "react";
import {
  Box,
  Button,
  Paper,
  Table,
  TableBody,
  TableCell,
  TableContainer,
  TableHead,
  TableRow,
} from "@mui/material";
import Card from "@mui/material/Card";
import CardContent from "@mui/material/CardContent";
import { Container } from "@mui/system";
import {
  Checkbox,
  Grid,
  ListItemButton,
  ListItemIcon,
  ListItemText,
  Typography,
} from "@mui/material";
import ArrowBackIosIcon from "@mui/icons-material/ArrowBackIos";
import { Link } from "react-router-dom";
import InfoOutlinedIcon from "@mui/icons-material/InfoOutlined";
import LockIcon from "@mui/icons-material/Lock";
import EmailIcon from "@mui/icons-material/Email";
import PhoneIphoneIcon from "@mui/icons-material/PhoneIphone";
import KeyIcon from "@mui/icons-material/Key";
import SecurityIcon from "@mui/icons-material/Security";
import DoNotDisturbAltIcon from "@mui/icons-material/DoNotDisturbAlt";
import ShieldIcon from "@mui/icons-material/Shield";
import ChangePassword from "../../../components/changePasswordModal/index";
import "../index.css";
import VerifyMobileModel from "../../../components/VerifyMobileModel/verifyMobile";
import EmailVerification from "../../../components/emailVerificationModal";

const SecurityCenter = () => {
  //////MOBILE NUMBER VERIFY MODAL/////
  const [verifyMobileModel, setVerifyMobileModel] = React.useState(false);
  const openVerifyModel = () => {
    setVerifyMobileModel(true);
  };
  const closeVerifyModel = () => {
    setVerifyMobileModel(false);
  };
////END MOBILE NUMBER VERIFICATION////
const [openChangePasswordModal, setOpenChangePasswordModal] = React.useState(false);
/*Change Password Modal*/
const handleClickOpen = () => {
    setOpenChangePasswordModal(true);
};

const handleClose  = () => {
    setOpenChangePasswordModal(false);
};
/*Email Verification*/
const [openEmailVerificationModal, setEmailVerificationModal] = React.useState(false);
const handleClickOpenVerification = () => {
    setEmailVerificationModal(true);
};

const handleCloseVerification = () => {
    setEmailVerificationModal(false);
};
  return (
    <div>
      <EmailVerification openEmailVerification={openEmailVerificationModal} handleClickOpen={handleClickOpenVerification} handleClose={handleCloseVerification} />
      <ChangePassword openChangePasswordModal={openChangePasswordModal} handleClickOpen={handleClickOpen} handleClose={handleClose} />
      <VerifyMobileModel verifyMobileModel={verifyMobileModel} openModel={openVerifyModel}closeModel={closeVerifyModel}/>
      <ChangePassword openChangePasswordModal={openChangePasswordModal} handleClickOpen={handleClickOpen} handleClose={handleClose}/>
      <Container sx={{ my: 7 }}>
        <Link to="/profile" className="linkTag">
          <Typography
            className="mb-3 d-flex align-items-center verifyTitle"
            variant="h5"
          >
            <ArrowBackIosIcon className="mb-2 me-1" />
            Security Center
          </Typography>
        </Link>
        {/*Card_One*/}
        <Card
          className="profile-page-card"
          sx={{ minWidth: "auto", maxWidth: "auto" }}
        >
          <div className="d-flex px-2 px-lg-4 bg-yellow py-3">
            <InfoOutlinedIcon className="iconProperty fs-1" />
            <div>
              <ListItemText
                className="ps-2 text-yellow secondaryText"
                primary={"Account risk level:  Medium"}
                secondary={
                  "It is recommended to enable SMS verification to ensure the security of your assets."
                }
              />
            </div>
          </div>
          <CardContent className="px-sm-4">
            <div className="d-sm-flex align-items-center justify-content-sm-between">
              <div className="d-flex py-3 px-2">
                <LockIcon className="iconColor" />
                <div>
                  <ListItemText
                    className="ps-2 securityTitle secondaryText"
                    primary={"Password Settings"}
                    secondary={
                      "Increase your password strength to enhance account security"
                    }
                  />
                </div>
              </div>
              <div className="d-flex justify-content-center d-sm-inline">
                <Button
                  variant="outlined"
                  className="button-outline-color"
                  onClick={() => {
                    handleClickOpen();
                  }}
                >
                  Change
                </Button>
              </div>
            </div>
            <div className="d-sm-flex align-items-center justify-content-sm-between">
              <div className="d-flex py-3 px-2">
                <EmailIcon className="iconColor" />
                <div>
                  <ListItemText
                    className="ps-2 securityTitle secondaryText"
                    primary={"Email verification"}
                    secondary={
                      "Link your email address to your account for password recovery and withdrawal confirmation."
                    }
                  />
                </div>
              </div>
              <div className="d-flex justify-content-center d-sm-inline">
                <Button variant="outlined" className="button-outline-color" onClick={()=>{handleClickOpenVerification()}}>
                  Change
                </Button>
              </div>
            </div>
            <div className="d-sm-flex align-items-center justify-content-sm-between">
              <div className="d-flex py-3 px-2">
                <PhoneIphoneIcon className="iconColor" />
                <div>
                  <ListItemText
                    className="ps-2 securityTitle secondaryText"
                    primary={"Mobile Verification"}
                    secondary={
                      "Link your mobile number to your account to receive verification codes via SMS"
                    }
                  />
                </div>
              </div>
              <div className="d-flex justify-content-center d-sm-inline">
                <Button variant="outlined" className="button-outline-color" onClick={() => {
                    openVerifyModel();
                  }}>
                  Verification
                </Button>
              </div>
            </div>
            <div className="d-sm-flex align-items-center justify-content-sm-between">
              <div className="d-flex py-3 px-2">
                <KeyIcon className="iconColor" />
                <div>
                  <ListItemText
                    className="ps-2 securityTitle secondaryText"
                    primary={"Google Authenticator"}
                    secondary={
                      "Set up your Google Authenticator to provide an extra layer of security when withdrawing funds or configuring your security settings"
                    }
                  />
                </div>
              </div>
              <div className="d-flex justify-content-center d-sm-inline">
                <Link to="/authentication" className="linkTag"><Button variant="outlined" className="button-outline-color-red">
                  Close
                </Button></Link>
              </div>
            </div>
            <div className="d-sm-flex align-items-center justify-content-sm-between">
              <div className="d-flex py-3 px-2">
                <SecurityIcon className="iconColor" />
                <div>
                  <ListItemText
                    className="ps-2 securityTitle secondaryText"
                    primary={"Anti-Phishing Code"}
                    secondary={
                      "Emails sent will contains your anti-phishing code to protect against phishing attacks"
                    }
                  />
                </div>
              </div>
              <div className="d-flex justify-content-center d-sm-inline">
                <Link to="/setAntiPishing" className="linkTag"><Button variant="outlined" className="button-outline-color">
                  Setup
                </Button></Link>
              </div>
            </div>
          </CardContent>
        </Card>
        <Card
          className="profile-page-card mt-4"
          sx={{ minWidth: "auto", maxWidth: "auto" }}
        >
          <CardContent className=" px-sm-3">
            <div className="d-sm-flex align-items-center justify-content-sm-between">
              <div className="d-flex py-3 px-2">
                <DoNotDisturbAltIcon className="iconColor" />
                <div>
                  <ListItemText
                    className="ps-2 securityTitle secondaryText"
                    primary={"Disable Account"}
                    secondary={"Disable your account immediately"}
                  />
                </div>
              </div>
              <div className="d-flex justify-content-center d-sm-inline">
                <Link to="/disableAccount" className="linkTag"><Button variant="outlined" className="button-outline-color-red">
                  Close
                </Button></Link>
              </div>
            </div>
            <div className="d-sm-flex align-items-center justify-content-sm-between">
              <div className="d-flex py-3 px-2">
                <ShieldIcon className="iconColor" />
                <div>
                  <ListItemText
                    className="ps-2 securityTitle secondaryText"
                    primary={"Official Verification channels "}
                    secondary={
                      "In order to prevent fraud in the name of MEXC Global sites, you can confirm whether your phone number，Twitter，Instagram, Facebook, Telegram or Wechat are used as MEXC official channels through this page."
                    }
                  />
                </div>
              </div>
              <div className="d-flex justify-content-center d-sm-inline">
               <Link to="/officialVerification" className="linkTag"><Button variant="outlined" className="button-outline-color">
                  Verification
                </Button></Link> 
              </div>
            </div>
          </CardContent>
        </Card>
      </Container>
    </div>
  );
};
export default SecurityCenter;
