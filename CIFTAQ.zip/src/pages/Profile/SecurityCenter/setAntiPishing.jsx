import React, { useState } from 'react'
import { Box, Button, Paper, Table, TableBody, TableCell, TableContainer, TableHead, TableRow } from "@mui/material";
import Card from "@mui/material/Card";
import CardContent from "@mui/material/CardContent";
import { Container } from "@mui/system";
import { Checkbox, Grid, ListItemButton, ListItemIcon, ListItemText, Typography } from '@mui/material';
import ArrowBackIosIcon from '@mui/icons-material/ArrowBackIos';
import { Link } from 'react-router-dom';
import InfoOutlinedIcon from '@mui/icons-material/InfoOutlined';
import Logo from '../../../components/assets/images/Logo.png'
import ButtonGroup from '@mui/material/ButtonGroup';
import Success from '../../../components/assets/images/right.png'
import Denied from '../../../components/assets/images/wrong.png'
import "../index.css";



const SetAntiPishing = () => {
    return (
        <div>
            <Container sx={{ my: 7 }}>
                <Link to="/securityCenter" className="linkTag"><Typography className="mb-3 d-flex align-items-center verifyTitle" variant="h5"><ArrowBackIosIcon className="mb-2 me-1" />Set anti-phishing code</Typography></Link>
                {/*Card_One*/}
                <Card className="profile-page-card" sx={{ minWidth: 'auto', maxWidth: "auto" }}>
                    <div className="d-flex justify-content-center py-3 bg-yellow">
                        <InfoOutlinedIcon className="iconProperty" />
                        <div><ListItemText className="ps-2 text-color-black" primary={'Please don’t tell anyone your password, Google or SMS verification code, uncluding the MEXC Customer Service.'} /></div>
                    </div>
                    <CardContent className="px-sm-4">
                        <Grid container sx={{ mt: 2 }} spacing={2}>
                            <Grid item xs={12} sm={6} md={6} lg={6}>
                                <Typography className='text-color-black fw-bold'>Curreny anti-phishing Code</Typography>
                                <Typography className='text-color-black fw-bold my-3'>1998</Typography>
                                <Box className="form-group mb-3">
                                    <label htmlFor="VerificationCode" className="text-color-black fw-bold mb-2">
                                        Set anti-phishing Code
                                    </label>
                                    <div className="d-flex">
                                        <input type="number" className="form-control inputProperty vericationNumber" />
                                    </div>
                                    <Typography className="text-color-black  pt-2">Please enter 1 to 6 characters without special characters, and do not set a commonly used password as the anti-phishing code</Typography>
                                </Box>
                                <Box className="d-grid">
                                    <Button className="phisingBtn py-2">Confirm</Button>
                                </Box>
                                <Box>
                                    <Typography className="text-color-black fw-bold my-3">What is the anti-phishing code?</Typography>
                                    <Typography className="textClr">The anti-phishing code is a string of characters set by you, to help you identify whether the websites or email addresses that are impersonating MEXC.</Typography>
                                </Box>
                                <Box>
                                    <Typography className="text-color-black fw-bold my-3">What is the anti-phishing code?</Typography>
                                    <Typography className="textClr">After the anti-phishing code is set successfully, you will receive from MEXC an email attached with the logo of the anti-phishing code.</Typography>
                                    <Typography className="textClr my-3">If it is not displayed or displayed incorrectly, you may have received a phishing email from the fraudster.</Typography>
                                </Box>
                            </Grid>
                            <Grid item xs={12} sm={6} md={6} lg={6}>

                            </Grid>
                        </Grid>
                    </CardContent>
                </Card>
                <div className="my-4 color-text"><span className="color-text">*</span>As shown in the figure below</div>
                <Grid container spacing={4}>
                    <Grid item xs={12} sm={6} md={6} lg={6}>
                        <Card className="Success-card" sx={{ minWidth: 'auto', maxWidth: "auto" }}>
                            <p className="text-center card-bg-green"><Box component="img" alt="icon" src={Logo} className="cardLogoSize my-4" /></p>
                            <CardContent>
                                <Box className="d-flex justify-content-end">
                                    <ButtonGroup variant="outlined" aria-label="outlined button group">
                                        <Button className="phisingBtn-outline">Anti-Phishing Code</Button>
                                        <Button variant="contained" className="phisingBtn-contained">123456</Button>
                                    </ButtonGroup>
                                </Box>
                            </CardContent>
                        </Card>
                        <p className="text-center mt-4"><Box component="img" alt="RightIcon" src={Success} className="img-fluid"/></p>
                    </Grid>
                    <Grid item xs={12} sm={6} md={6} lg={6}>
                        <Card className="warning-card" sx={{ minWidth: 'auto', maxWidth: "auto" }}>
                            <p className="text-center card-bg-gray"><Box component="img" alt="icon" src={Logo} className="cardLogoSize my-4" /></p>
                            <CardContent>
                                <Box className="d-flex justify-content-end">
                                    <Button className="phisingBtn-dashed px-5"><spam className="px-5">?</spam></Button>
                                </Box>
                            </CardContent>
                        </Card>
                        <p className="text-center mt-4"><Box component="img" alt="WrongIcon" src={Denied} className="img-fluid"/></p>
                    </Grid>
                </Grid>
            </Container>
        </div >
    )
}
export default SetAntiPishing;