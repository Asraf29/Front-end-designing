import React from "react";
import { Box, Button } from "@mui/material";
import Card from "@mui/material/Card";
import CardContent from "@mui/material/CardContent";
import { Container } from "@mui/system";
import { Checkbox, Grid, ListItemButton, ListItemIcon, ListItemText, Typography } from "@mui/material";
import ArrowBackIosIcon from "@mui/icons-material/ArrowBackIos";
import { Link } from "react-router-dom";
import InfoOutlinedIcon from "@mui/icons-material/InfoOutlined";
import "../index.css";

const DisableAccount = () => {
    return (
        <div>
            <Container sx={{ my: 7 }}>
                <Link to="/securityCenter" className="linkTag">
                    <Typography
                        className="mb-3 d-flex align-items-center verifyTitle"
                        variant="h5"
                    >
                        <ArrowBackIosIcon className="mb-2 me-1" />
                        Disable Account
                    </Typography>
                </Link>
                {/*Card_One*/}
                <Card className="profile-page-card" sx={{ minWidth: "auto", maxWidth: "auto" }}>
                    <CardContent className="px-sm-4">
                        <Typography className="text-yellow my-3">Are you sure you want to disable your account?</Typography>
                        <div className="d-flex px-2 px-lg-4 bg-yellow borderRadius py-3">
                            <InfoOutlinedIcon className="iconProperty fs-1" />
                            <div>
                                <ListItemText className="ps-2 securityTitle" primary={"Consequences:"} />
                                <Box className="ps-2">
                                    <Typography className="textClr">① You will not be able to login until you contact Customer Service to reactivate your account.</Typography>
                                    <Typography className="textClr">② All trading capabilities for your account will be disabled. </Typography>
                                    <Typography className="textClr">③ All API keys connected to your account will be disabled.</Typography>
                                    <Typography className="textClr">④ You will need to contact Customer Service to reactive your account. </Typography>
                                </Box>
                            </div>
                        </div>
                        <Grid container spacing={4} sx={{ mt: 1 }} className="d-flex align-items-center">
                            <Grid item xs={12} sm={4} md={4} lg={4}>
                                <Typography className="text-color-black TitleText mb-md-3 pb-md-5"><span className="text-danger">*</span>Please select  your reason for disabling your account:</Typography>
                            </Grid>
                            <Grid item xs={12} sm={8} md={8} lg={8}>
                                <Box className="d-block d-sm-flex">
                                    <ListItemButton className="listBtn">
                                        <ListItemIcon className="margin-right0 mb-1">
                                            <Checkbox edge="start" tabIndex={-1} disableRipple />
                                        </ListItemIcon>
                                        <ListItemText className="checkBox-text" primary={'Suspicious Logins'} />
                                    </ListItemButton>
                                    <ListItemButton className="listBtn">
                                        <ListItemIcon className="margin-right0 mb-1">
                                            <Checkbox edge="start" tabIndex={-1} disableRipple />
                                        </ListItemIcon>
                                        <ListItemText className="checkBox-text" primary={'Unauthorised Transactions'} />
                                    </ListItemButton>
                                    <ListItemButton className="listBtn">
                                        <ListItemIcon className="margin-right0 mb-1">
                                            <Checkbox edge="start" tabIndex={-1} disableRipple />
                                        </ListItemIcon>
                                        <ListItemText className="checkBox-text" primary={'Unauthorised Withdrawals'} />
                                    </ListItemButton>
                                </Box>
                                <Box className="d-block d-sm-flex">
                                    <ListItemButton className="listBtn">
                                        <ListItemIcon className="margin-right0 mb-1">
                                            <Checkbox edge="start" tabIndex={-1} disableRipple />
                                        </ListItemIcon>
                                        <ListItemText className="checkBox-text" primary={'Unauthorised Transactions'} />
                                    </ListItemButton>
                                    <ListItemButton className="listBtn">
                                        <ListItemIcon className="margin-right0 mb-1">
                                            <Checkbox edge="start" tabIndex={-1} disableRipple />
                                        </ListItemIcon>
                                        <ListItemText className="checkBox-text" primary={'Unauthorised Withdrawals'} />
                                    </ListItemButton>
                                </Box>
                            </Grid>
                        </Grid>
                        <ListItemButton className="listBtn">
                            <ListItemIcon className="margin-right0 mb-1">
                                <Checkbox edge="start" tabIndex={-1} disableRipple />
                            </ListItemIcon>
                            <ListItemText className="checkBox-text" primary={'I understand What will happen if the account is disabled'} />
                        </ListItemButton>
                        <Button className="ms-3 mt-2 confirmationButton" variant="contained">Confirm to deactivate this account</Button>
                    </CardContent>
                </Card>
            </Container>
        </div>
    );
};
export default DisableAccount;
