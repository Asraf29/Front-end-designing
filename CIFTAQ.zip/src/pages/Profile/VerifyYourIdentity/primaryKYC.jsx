import React, { useState } from 'react'
import Box from "@mui/material/Box";
import Card from "@mui/material/Card";
import CardContent from "@mui/material/CardContent";
import { Container } from "@mui/system";
import "../index.css";
import { Button, Grid, Typography } from '@mui/material';
import ArrowBackIosIcon from '@mui/icons-material/ArrowBackIos';
import { Link } from 'react-router-dom';
const PrimaryKYC = () => {
    return (
        <div>
            <Container sx={{ my: 7 }}>
                <Link to="/verifyIdentity" className="linkTag"><Typography className="mb-3 d-flex align-items-center verifyTitle" variant="h5"><ArrowBackIosIcon className="mb-2" />Primary KYC</Typography></Link>
                {/* Banner */}
                <Card className="profile-page-card mt-5 mt-sm-0  px-sm-3 px-md-4 px-lg-5"
                    sx={{ minWidth: 'auto', maxWidth: "auto" }}>
                    <CardContent>
                        {/* first pair input */}
                        <Grid container sx={{ mt: 1 }} spacing={4}>
                            <Grid item xs={12} sm={6} md={6} lg={6}>
                                <label className='mb-2  select-title'><b className='require-clr pe-1'>*</b>Nationality</label>
                                <select
                                    id="form-select"
                                    className="form-select "
                                    aria-label="Default select example">
                                    <option value="1" className='textClr'> India </option>
                                    <option value="2" className='textClr' >United States</option>
                                    <option value="3" className='textClr'>United Kingdom</option>
                                </select>
                            </Grid>
                            <Grid item xs={12} sm={6} md={6} lg={6}>
                                <label className='mb-2  select-title'><b className='require-clr pe-1'>*</b>ID Type:</label>
                                <select
                                    id="form-select"
                                    className="form-select "
                                    aria-label="Default select example">
                                    <option value="1" className='textClr'> Please select ID Type </option>
                                    <option value="2" className='textClr' >1</option>
                                    <option value="3" className='textClr'>2</option>
                                </select>
                            </Grid>
                        </Grid>
                        {/* second pair input */}
                        <Grid container spacing={4} className="pt-3">
                            <Grid item xs={12} sm={6} md={6} lg={6}>
                                <label className='mb-2  select-title'><b className='require-clr pe-1'>*</b>First name:</label>
                                <input type="text" id="PlaceHolderClr" className="form-control input-field" placeholder="Please Enter First name" />
                            </Grid>
                            <Grid item xs={12} sm={6} md={6} lg={6}>
                                <label className='mb-2  select-title'><b className='require-clr pe-1'>*</b>Last name:</label>
                                <input type="text" id="PlaceHolderClr" className="form-control input-field" placeholder="Please Enter last name" />
                            </Grid>
                        </Grid>
                        {/* third  pair input */}
                        <Grid container spacing={4} className="pt-3">
                            <Grid item xs={12} sm={6} md={6} lg={6}>
                                <label className='mb-2  select-title'><b className='require-clr pe-1'>*</b>ID number:</label>
                                <input type="text" id="PlaceHolderClr" className="form-control input-field" placeholder="Please Enter ID number" />
                            </Grid>
                            <Grid item xs={12} sm={6} md={6} lg={6}>
                                <label className='mb-2  select-title'><b className='require-clr pe-1'>*</b>Date of birth:</label>
                                <input type="date" id="date-placeholder" className="form-control input-field" placeholder="Please Select Date of birth" />
                            </Grid>
                        </Grid>
                        {/* File Upload */}
                        <Grid container className=" pt-4 pb-4" spacing={2}>
                            <Grid item xs={12} sm={6} md={2} lg={2}>
                                <label className='mb-2  select-title'><b className='require-clr pe-1'>*</b>ID photo:</label>
                                <Typography className="select-title">
                                    Please make sure the content of the photo is complete and clearly visible Only supports JPG, JPEG, PNG, image formats Image size cannot exceed 5M
                                </Typography>
                            </Grid>
                            <Grid item xs={12} sm={4} md={6} lg={6} className="pt-4">
                                <div className='upload upload-bg d-flex justify-content-center align-items-center'>
                                    <label for="file-input" role="button">
                                        <div className="text-center"><i className="bi bi-plus-lg icon-plus-color"></i></div>
                                        <div className="upload-text">Please upload your ID photo</div>
                                    </label>
                                    <input type="file" id="file-input" />
                                </div>
                            </Grid>
                        </Grid>
                        <Box textAlign='center' className="px-5 mx-5 py-3 "><Button variant='contained' className="submitBtnProperty px-5">Submit for review</Button></Box>
                    </CardContent>
                </Card>
            </Container>
        </div >
    )
}
export default PrimaryKYC;