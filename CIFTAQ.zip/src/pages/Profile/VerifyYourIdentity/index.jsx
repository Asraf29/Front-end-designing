import React, { useState } from 'react'
import Box from "@mui/material/Box";
import Card from "@mui/material/Card";
import CardContent from "@mui/material/CardContent";
import { Button, Typography } from "@mui/material";
import { Container } from "@mui/system";
import ArrowBackIosIcon from '@mui/icons-material/ArrowBackIos';
import AdvancedKycModal from '../../../components/AdvancedKycModal';
import {Link} from 'react-router-dom'
import '../index.css'
const VerifyIdentity = () => {
    const [openKycModal, setOpenKycModal] = React.useState(false);

    const handleClickOpen = () => {
        setOpenKycModal(true);
    };

    const handleClose = () => {
        setOpenKycModal(false);
    };
    return (
        <div>
            <AdvancedKycModal openKycModal={openKycModal} handleClickOpen={handleClickOpen} handleClose={handleClose} />
            <Container className="mt-5">
            <Link to="/profile" className="linkTag"><Typography className="mb-3 d-flex align-items-center verifyTitle" variant="h5"><ArrowBackIosIcon className="mb-2" />Verify your identify</Typography></Link>
                 {/* Banner_One*/}
                <Card className="identityCard"
                    sx={{ minWidth: "auto", maxWidth: "auto",mt:2}}>
                    <CardContent>
                        <Box>
                            <Box className="d-flex justify-content-between">
                                <Typography variant="h6" className="fontsize-card card-text">Advanced KYC</Typography>
                                <Button variant="contained" className="buttonColor"  onClick={() => { handleClickOpen() }}>Verify</Button>
                            </Box>
                            <Typography className="card-sub-text mb-3 mt-2">Increase your 24-hours withdrawal limit up to 100 BTC</Typography>
                        </Box>
                        <Box>
                            <ul className="card-sub-text mt-2 padding-1">
                                <li className="list-text-size">Basic verification information</li>
                                <li className="list-text-size">Basic verification information</li>
                            </ul>
                        </Box>
                    </CardContent>
                </Card>
                {/* Banner_Two*/}
                <Card className="identityCard" sx={{ minWidth: "auto", maxWidth: "auto",mt:4,mb:5}}>
                    <CardContent>
                        <Box className=" mb-2">
                            <Box className="d-flex justify-content-between">
                                <Typography variant="h6" className="fontsize-card card-text">Primary KYC</Typography>
                                <Link to="/primaryKYC" className="linkTag"><Button variant="contained" className="buttonColor">Verify</Button></Link>
                            </Box>
                            <Typography className="card-sub-text mb-3 mt-2">Increase your 24-hours withdrawal limit up to 40 BTC</Typography>
                        </Box>
                        <Box>
                            <ul className="card-sub-text mt-2 padding-1">
                                <li className="list-text-size">Personal information</li>
                            </ul>
                        </Box>
                    </CardContent>
                </Card>
            </Container>
        </div >
    )
}
export default VerifyIdentity;