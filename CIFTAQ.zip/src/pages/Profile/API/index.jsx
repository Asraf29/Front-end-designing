import React, { useState } from 'react'
import { Box, Button, Paper, Table, TableBody, TableCell, TableContainer, TableHead, TableRow } from "@mui/material";
import Card from "@mui/material/Card";
import CardContent from "@mui/material/CardContent";
import { Container } from "@mui/system";
import { Checkbox, Grid, ListItemButton, ListItemIcon, ListItemText, Typography } from '@mui/material';
import ArrowBackIosIcon from '@mui/icons-material/ArrowBackIos';
import { Link } from 'react-router-dom';
import NODATA from "../../../components/assets/images/nodata.png";
import "../index.css";

const API = () => {
    return (
        <div>
            <Container sx={{ my: 7 }}>
                <Link to="/profile" className="linkTag"><Typography className="mb-3 d-flex align-items-center verifyTitle" variant="h5"><ArrowBackIosIcon className="mb-2" />API</Typography></Link>
                {/*Main Card*/}
                <Card className="profile-page-card mt-5 mt-sm-0"
                    sx={{ minWidth: 'auto', maxWidth: "auto" }}>
                    <Typography className="APITitle ps-3 ps-md-5 pt-5">API’s management / Create New API Key</Typography>
                    <CardContent className=" px-sm-3 px-md-4 px-lg-5">
                        <Grid container spacing={1}>
                            <Grid item xs={12} sm={12} md={7} lg={7}>
                                <div className='mb-2  textClr labelSize'>Spot</div>
                                {/*Spot first pair input */}
                                <div className="d-inline-flex align-items-center">
                                    <div className='textClr labelSize'>Account:</div>
                                    <div> <ListItemButton className="listBtn padddingLeft-12px ms-1 ps-3 ms-md-3 ps-md-1 ms-lg-3 ps-lg-1">
                                        <ListItemIcon className="margin-right0 mb-1">
                                            <Checkbox edge="start" tabIndex={-1} disableRipple />
                                        </ListItemIcon>
                                        <ListItemText className="checkbox-text" primary={'Read account Information'} />
                                    </ListItemButton>
                                    </div>
                                </div>
                                {/* second pair input */}
                                <div className='d-flex justify-content-between'>
                                    <div className="d-inline-flex align-items-center">
                                        <div className='textClr labelSize'>Trade:</div>
                                        <div> <ListItemButton className="listBtn ms-3 ps-3 ms-md-3 ps-md-4 ms-lg-3 ps-lg-4">
                                            <ListItemIcon className="margin-right0 mb-1">
                                                <Checkbox edge="start" tabIndex={-1} disableRipple />
                                            </ListItemIcon>
                                            <ListItemText className="checkbox-text" primary={'Read account Information'} />
                                        </ListItemButton>
                                        </div>
                                    </div>
                                    <div>
                                        <ListItemButton className="listBtn me-3 pe-3 me-md-4 ps-md-5 me-lg-4 pe-lg-3">
                                            <ListItemIcon className="margin-right0 mb-1">
                                                <Checkbox edge="start" tabIndex={-1} disableRipple />
                                            </ListItemIcon>
                                            <ListItemText className="checkbox-text" primary={'Trade'} />
                                        </ListItemButton>
                                    </div>
                                </div>
                                {/* Third pair input */}
                                <div className='d-flex justify-content-between'>
                                    <div className="d-inline-flex align-items-center">
                                        <div className='textClr labelSize'>Withdraw:</div>
                                        <div> <ListItemButton className="listBtn paddingLeft-6px paddingRight-0 ps-3 ps-md-2 ms-md-1 ms-lg-2 ps-lg-1">
                                            <ListItemIcon className="margin-right0 mb-1">
                                                <Checkbox edge="start" tabIndex={-1} disableRipple />
                                            </ListItemIcon>
                                            <ListItemText className="checkbox-text" primary={'Read the desposit/withdrawal information'} />
                                        </ListItemButton>
                                        </div>
                                    </div>
                                    <div>
                                        <ListItemButton className="listBtn">
                                            <ListItemIcon className="margin-right0 mb-1">
                                                <Checkbox edge="start" tabIndex={-1} disableRipple />
                                            </ListItemIcon>
                                            <ListItemText className="checkbox-text withdraw-sm me-sm-0" primary={'Withdraw'} />
                                        </ListItemButton>
                                    </div>
                                </div>
                                {/* Fourth pair input */}
                                <div className='d-flex justify-content-between'>
                                    <div className="d-inline-flex align-items-center">
                                        <div className='textClr labelSize'>Transfer:</div>
                                        <div> <ListItemButton className="listBtn paddingLeft-12px ms-1 ps-3 ps-md-1 ms-md-3 ms-lg-3 ps-lg-1">
                                            <ListItemIcon className="margin-right0 mb-1">
                                                <Checkbox edge="start" tabIndex={-1} disableRipple />
                                            </ListItemIcon>
                                            <ListItemText className="checkbox-text" primary={'Read transfer information'} />
                                        </ListItemButton>
                                        </div>
                                    </div>
                                    <div>
                                        <ListItemButton className="listBtn me-1 pe-3">
                                            <ListItemIcon className="margin-right0 mb-1 me-lg-1">
                                                <Checkbox edge="start" tabIndex={-1} disableRipple />
                                            </ListItemIcon>
                                            <ListItemText className="checkbox-text" primary={'Transfer'} />
                                        </ListItemButton>
                                    </div>
                                </div>
                                <div className='mb-2  textClr labelSize'>Futures</div>
                                {/*Futures first pair input */}
                                <div className="d-inline-flex align-items-center">
                                    <div className='textClr labelSize'>Account:</div>
                                    <div> <ListItemButton className="listBtn padddingLeft-12px ms-1 ps-3 ps-md-1 ms-md-3 ms-lg-3 ps-lg-1">
                                        <ListItemIcon className="margin-right0 mb-1">
                                            <Checkbox edge="start" tabIndex={-1} disableRipple />
                                        </ListItemIcon>
                                        <ListItemText className="checkbox-text" primary={'Read account Information'} />
                                    </ListItemButton>
                                    </div>
                                </div>
                                {/* second pair input */}
                                <div className='d-flex justify-content-between'>
                                    <div className="d-inline-flex align-items-center">
                                        <div className='textClr labelSize'>Trade:</div>
                                        <div> <ListItemButton className="listBtn ms-3 ps-3 ps-md-3 ms-md-4 ms-lg-4 ps-lg-3">
                                            <ListItemIcon className="margin-right0 mb-1">
                                                <Checkbox edge="start" tabIndex={-1} disableRipple />
                                            </ListItemIcon>
                                            <ListItemText className="checkbox-text" primary={'Read account Information'} />
                                        </ListItemButton>
                                        </div>
                                    </div>
                                    <div>
                                        <ListItemButton className="listBtn me-3">
                                            <ListItemIcon className="margin-right0 mb-1 me-lg-1 pe-lg-2">
                                                <Checkbox edge="start" tabIndex={-1} disableRipple />
                                            </ListItemIcon>
                                            <ListItemText className="checkbox-text" primary={'Trade'} />
                                        </ListItemButton>
                                    </div>
                                </div>
                                {/*input Field */}
                                <Box>
                                    <label className="mb-2  textClr"><b className='require-clr pe-1'>*</b>Notes(required)</label>
                                    <input type="text" id="PlaceHolderClr" className="form-control input-field" placeholder="Please Enter ID number" />
                                    <Typography className="textClr my-2">Bind IP address (optional)<span className="require-clr">The validity period of the key for an unbound IP address is 90 days (not recommended)</span></Typography>
                                    <input type="text" id="PlaceHolderClr" className="form-control input-field" />
                                    <Button variant="contained" className="my-5 buttonColor py-2" fullWidth>Create</Button>
                                </Box>
                            </Grid>
                            <Grid item xs={12} sm={12} md={5} lg={5}>
                                <Card className="noticeBoard" sx={{ minWidth: "auto", maxWidth: "auto", mt: 2 }}>
                                    <Typography className="noticeTitle ps-3 pt-3">Notice</Typography>
                                    <CardContent>
                                        <Typography className="noticeText">
                                            MEXC’s API allows users to make market inquiries, trade automatically and perform various other tasks. You may find out more here

                                            Each user may create up to 5 groups of API keys. The platform currently supports most mainstream currencies. For a full list of supported currencies, click here.

                                            Please keep your API key confidential to protect your account. For security reasons, we recommend you link your IP address with your API key. To link your API Key with multiple addresses, you may separate each of them with a comma such as 192.168.1.1, 192.168.1.2, 192.168.1.3. Each API key can be linked with up to 4 IP addresses.
                                        </Typography>
                                    </CardContent>
                                </Card>
                                <Card className="noticeBoard mt-3" sx={{ minWidth: "auto", maxWidth: "auto", mt: 2 }}>
                                    <CardContent>
                                        <Typography className="noticeText">
                                            To further increase the liquidity of the platform and enhance the trading experience, MEXC has created a special platform market plan with lucrative rewards. Click here if you would like to be a part of an elite group of market makers!
                                        </Typography>
                                    </CardContent>
                                </Card>
                            </Grid>
                        </Grid>
                    </CardContent>
                </Card>
                <TableContainer component={Paper} sx={{ background: "var( --card-bg-color)" }} className="mt-4">
                    <Typography variant="h6" className="ps-3 py-3 APITitle">My API Key</Typography>
                    <Table sx={{ minWidth: 650, background: "var( --card-bg-color)" }} aria-label="simple table">
                        <TableHead>
                            <TableRow sx={{ border: "1px solid grey",borderRight: 0,borderLeft: 0}}>
                                <TableCell sx={{fontWeight: "bolder !important"}} className="textClr" align="center">Order time</TableCell>
                                <TableCell sx={{fontWeight: "bolder !important"}} className="textClr" align="center">Notes</TableCell>
                                <TableCell sx={{fontWeight: "bolder !important"}} className="textClr" align="center">Access Key</TableCell>
                                <TableCell sx={{fontWeight: "bolder !important"}} className="textClr" align="center">Bind IP address</TableCell>
                                <TableCell sx={{fontWeight: "bolder !important"}} className="textClr" align="center">Remaining validity(days)</TableCell>
                                <TableCell sx={{fontWeight: "bolder !important"}} className="textClr" align="center">Status</TableCell>
                                <TableCell sx={{fontWeight: "bolder !important"}} className="textClr" align="center">Action</TableCell>                                   
                            </TableRow>
                        </TableHead>
                        <TableBody>
                            <TableRow sx={{ "&:last-child td, &:last-child th": { border: 0 } }}>
                                <TableCell align="center" colSpan={7} sx={{ justifyContent: "center", alignItems: "center" }} className="my-4">
                                    <img src={NODATA} />
                                </TableCell>
                            </TableRow>
                        </TableBody>
                    </Table>
                </TableContainer>
            </Container>
        </div >
    )
}
export default API;