import React from "react";
import { Box, Container } from "@mui/system";
import { Typography } from "@mui/material";
import './auth.css'
export default function GoogleStepTwo() {
  return (
    <div>
      <Box>
        <Typography
          className="text-center my-4 me-4"
          sx={{ fontWeight: 700, fontSize: 20 }}
        >
          - Step 2 -
        </Typography>
        <Container className="d-flex justify-content-center my-4">
          <div className="col-lg-5">
            <div className="form-group mb-3">
              <label htmlFor="password" className="txtClr mb-2">
                Email address:
              </label>
              <div className="d-block d-sm-flex justify-content-between">
              <div>
               <b>Prab***2@gmail.com</b>
              </div>
              <div className="my-2 my-sm-0 ms-md-2 ms-lg-0">
              <button className="btn btn-sm" style={{border:'2px solid #44a7bd' ,color:'#44a7bd'}}>Get it now</button>
              </div>
              </div>
            </div>
            <div className="form-group mb-3">
              <label htmlFor="password" className="txtClr mb-2">
                <b className="text-danger">*</b> Email verification code
              </label>
              <div>
                <input
                  placeholder="Please enter the email verification code"
                  type="text"
                  className="form-control txtClr inputBg"
                />
              </div>
            </div>
            <div className="form-group mb-3">
              <label htmlFor="password" className="txtClr mb-2">
                <b className="text-danger">*</b> Google Aunthenticator
              </label>
              <div>
                <input
                  placeholder="Please enter the Google Authenticator verification code"
                  type="text"
                  className="form-control txtClr inputBg"
                />
                <div class="d-grid my-md-2 col-sm-6 col-md-12 col-lg-6 my-4 mx-auto d-block d-lg-flex">
  <button className="btn-blk btn mb-2 mb-lg-0" style={{ background: "#C4C4C4", color: "white"}}  type="button" disabled>Back</button>
  <button className="btn-blk btn ms-lg-4" style={{ background: "#1A94AE", color: "white"}}  type="button">Unbind</button>
</div>
              </div>
            </div>
          </div>
        </Container>
      </Box>
    </div>
  );
}
