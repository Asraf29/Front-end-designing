import React from 'react'
import {
    ListItemText,
  } from "@mui/material";
  import ArrowBackIosIcon from "@mui/icons-material/ArrowBackIos";
import Typography from '@mui/material/Typography';
import Box from '@mui/material/Box';
import Stepper from '@mui/material/Stepper';
import Step from '@mui/material/Step';
import StepLabel from '@mui/material/StepLabel';
import Card from "@mui/material/Card";
import CardContent from "@mui/material/CardContent";
import { Container, fontWeight } from "@mui/system";
import InfoOutlinedIcon from "@mui/icons-material/InfoOutlined";
import { makeStyles } from '@mui/styles';
import GoogleStepTwo from './GoogleStepTwo';
import { Link } from 'react-router-dom';
///STEPPER BOX///
const steps = [
    'Enter your login password',
    'Enter the 6-digit verification code in Google Authenticator'
  ];
  const useStyles = makeStyles({
    customLabelStyle: {
      fontSize: "18px !important",
      fontWeight:'bold !important',
    }
  });

export default function GoogleAuth() {
    const classes = useStyles();
    const [activeStep, setActiveStep] = React.useState(0)
    ////PASWORD
const [passwordShown, setPasswordShown] = React.useState(false);
const togglePassword = () => {
  setPasswordShown(!passwordShown);
};
////BUTTON CONTENT CHANGE////
const [nxtBtn , setNxtBtn] = React.useState(true)

  return (
    <div>
            <Container sx={{ my: 7 }}>
            <Link to="/securityCenter" className="linkTag"><Typography className="mb-3 d-flex align-items-center verifyTitle" variant="h5"><ArrowBackIosIcon className="mb-2" />Google Aunthenticator</Typography></Link>
           <Card
          className="profile-page-card"
          sx={{ minWidth: "auto", maxWidth: "auto" }}
        >
          <div className="d-flex px-2 px-lg-4 bg-yellow justify-content-center">
           <span className='my-2'> <InfoOutlinedIcon className="iconProperty fs-2"/> </span> 
            <div>
              <ListItemText
              sx={{ color: "var(--profile-textClr)" }}
                className="ps-2 my-3"
                primary={"The withdrawal and FiAT trading will be paused for 24h after unbinding"}
              />
            </div>
          </div>
          <CardContent className="px-sm-4">
              <Container sx={{ my: 4 }}>
          <Box sx={{ width: '100%'}}>
      <Stepper className={classes.StepperSize} sx={{fontSize:'xx-large', fontWeight:800}} activeStep={activeStep} alternativeLabel>
        {steps.map((label) => (
          <Step key={label}>
            <StepLabel classes={{label: classes.customLabelStyle}}>{label}</StepLabel>
          </Step>
        ))}
      </Stepper>
    </Box>
   {nxtBtn === true ? <Box>
<Typography className='text-center my-4 me-4' sx={{fontWeight:700, fontSize:20}}>- Step 1 -</Typography>
    <Container className="d-flex justify-content-center my-4">
        <div className='col-lg-5'>
    <div className="form-group mb-3">
                    <label htmlFor="password" className="txtClr mb-2">
                   <b className='text-danger'>*</b> password Settings:
                    </label>
                    <div>
                      <input
                      placeholder='Please Login password'
                        type={passwordShown ? "text" : "password"}
                        className="form-control txtClr inputBg"
                        
                      />
                      <span className="field-icon pe-2">
                        {passwordShown ? (
                          <i
                            onClick={togglePassword}
                            className="bi bi-eye eyeIcon"
                          />
                        ) : (
                          <i
                            onClick={togglePassword}
                            className="bi bi-eye-slash eyeIcon"
                          />
                        )}
                      </span>
                      <div class="d-grid my-3">
  <button class="btn" style={{background:'#1A94AE', color:'white'}} type="button" onClick={()=>{setNxtBtn(false);setActiveStep(2)}}>Next Step</button>
</div>
                    </div>
                  </div>
                  </div>
                  </Container>
                  </Box> :
                  <GoogleStepTwo/>}
                  </Container>
          </CardContent>
        </Card>
        </Container>
    </div>
  )
}
