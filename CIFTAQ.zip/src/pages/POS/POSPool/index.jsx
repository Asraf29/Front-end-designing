import React, { useState } from "react";
import {
    Avatar,
    Box,
    Button,
    ListItemText,
} from "@mui/material";
import Card from "@mui/material/Card";
import CardContent from "@mui/material/CardContent";
import { Container } from "@mui/system";
import {
    Grid,
    Typography,
} from "@mui/material";
import Table from '@mui/material/Table';
import TableBody from '@mui/material/TableBody';
import TableCell from '@mui/material/TableCell';
import TableContainer from '@mui/material/TableContainer';
import TableHead from '@mui/material/TableHead';
import TableRow from '@mui/material/TableRow';
import Paper from '@mui/material/Paper';
import { Link } from "react-router-dom";
import PosPool from "../../../components/assets/images/PosPool.png";
import "./index.css";
import Tab from '@mui/material/Tab';
import TabContext from '@mui/lab/TabContext';
import TabList from '@mui/lab/TabList';
import TabPanel from '@mui/lab/TabPanel';
import { makeStyles } from "@mui/styles";
import CTO from '../../../components/assets/images/CTO.png'
import FormGroup from '@mui/material/FormGroup';
import FormControlLabel from '@mui/material/FormControlLabel';
import Checkbox from '@mui/material/Checkbox'
import SearchIcon from "@mui/icons-material/Search";
import PalkadotToken from "../../../components/assets/images/PalkadotToken.png"
import PosGrid from "../../../components/assets/images/POSGrid.png"
const data = [1, 2, 3]

// Tab Switch;
const useStyles = makeStyles({
    MUITab: {
        color: "var(--Tab-gray-text) !important",
        fontSize: "16px !important",
        fontWeight: 'bold !important'
    },
});
const POSPool = () => {
    const [value, setValue] = React.useState('1');

    const handleChange = (event, newValue) => {
        setValue(newValue);
    };
    // Tab Switch;

    const classes = useStyles();
    return (
        <div>
            <Container sx={{ mb: 7 }}>
                <Container >
                    <Box className="mx-lg-5 mx-sm-3 d-md-flex justify-content-md-between align-items-center">
                        <div className='text-center mt-3 text-sm-start mt-sm-0'>
                            <Typography className='text-prop' variant="h3">PoS Pool</Typography>
                            <Typography className="text-prop-sub my-2">Simple secure and way to earn Crypto</Typography>
                        </div>
                        <div className="d-flex justify-content-center">
                            <Box component="img" alt="topbar-bg" src={PosPool} className="posPool_Size img-fluid" />
                        </div>
                    </Box>
                </Container>

                {/*Slot Cards*/}
                <TabContext value={value}>
                    <Card className="profile-page-card" sx={{ minWidth: "auto", maxWidth: "auto" }}>
                        <CardContent>
                            <Box>
                                <Box>
                                    <Box className="d-lg-flex align-items-center justify-content-lg-between">
                                        <div>
                                            <TabList variant="scrollable" onChange={handleChange} aria-label="lab API tabs example">
                                                <Tab label="Fixed" value="1" className={classes.MUITab} />
                                                <Tab label="Flexible" value="2" className={classes.MUITab} />
                                            </TabList>
                                        </div>
                                        <div className="d-sm-flex align-items-center justify-content-sm-between my-2 my-sm-0">
                                            <FormGroup>
                                                <FormControlLabel className="labeColorCheckbox" control={<Checkbox defaultChecked />} label="Show available only." />
                                            </FormGroup>
                                            <div className="text-blue pe-lg-3">Staking records</div>
                                            <div className="my-2 my-sm-0">
                                                <input type="text" className="form-control input-typing-space  searchTokenInsideText" placeholder="Search Token" />
                                                <span className="searchbar-icon pe-2 text-dark">
                                                    <SearchIcon className="searchbar-icon-clr" />
                                                </span>
                                            </div>
                                        </div>
                                    </Box>
                                </Box>
                            </Box>
                        </CardContent>
                    </Card>
                    <TabPanel value="1">
                        <Box sx={{ mt: 1 }}>
                            {/* -----------------Table----------- */}
                            <Card className="profile-page-card" sx={{ minWidth: "auto", maxWidth: "auto" }}>
                                <CardContent>
                                    <Container className='my-2'>
                                        <Grid item xs={12} sm={12} md={12} lg={12}>
                                            <Box>
                                                <TableContainer component={Paper} className="profile-page-card">
                                                    <Table sx={{ minWidth: 650 }} className="profile-page-card" aria-label="simple table">
                                                        <TableHead>
                                                            <TableRow>
                                                                <TableCell sx={{ borderBottom: 0 }} className="fw-bold greyTxt" align="left">Token</TableCell>
                                                                <TableCell sx={{ borderBottom: 0 }} className="fw-bold greyTxt" align="left">Min.Term[days]</TableCell>
                                                                <TableCell sx={{ borderBottom: 0 }} className="fw-bold greyTxt" align="left">Est.APY</TableCell>
                                                                <TableCell sx={{ borderBottom: 0 }} className="fw-bold greyTxt" align="center">Action</TableCell>
                                                            </TableRow>
                                                        </TableHead>
                                                        <TableBody>
                                                            {data.map((data) => (<>                                                                    <TableRow key={data.name} sx={{ 'td,th': { border: 0 } }}>
                                                                <TableCell component="th" scope="row">
                                                                    <div className="d-flex align-items-center">
                                                                        <div>
                                                                            <img src={PalkadotToken} />
                                                                        </div>
                                                                        <div className="my-2 ms-2">
                                                                            <ListItemText className="blck-Txt listSecondary" primary={'DOT'} secondary={'Polkadot'} />
                                                                        </div>
                                                                    </div>
                                                                </TableCell>
                                                                <TableCell className='blck-Txt' align="left" sx={{ fontWeight: 700 }}>30</TableCell>
                                                                <TableCell className='blck-Txt' align="left" sx={{ fontWeight: 700 }}>10.00%-12.00%</TableCell>
                                                                <TableCell className='blck-Txt' align="center" sx={{ fontWeight: 700 }}><Link to="/stakingRecords" className="linkTag"><button className="btn-green btn btn-sm px-5">Stake now</button></Link></TableCell>
                                                            </TableRow>
                                                                <TableRow key={data.name} sx={{ 'td,th': { border: 0 } }}>
                                                                    <TableCell component="th" scope="row">
                                                                        <div className="d-flex align-items-center">
                                                                            <div>
                                                                                <img src={PalkadotToken} />
                                                                            </div>
                                                                            <div className="my-2 ms-2">
                                                                                <ListItemText className="blck-Txt listSecondary" primary={'DOT'} secondary={'Polkadot'} />
                                                                            </div>
                                                                        </div>
                                                                    </TableCell>
                                                                    <TableCell className='blck-Txt' align="left" sx={{ fontWeight: 700 }}>30</TableCell>
                                                                    <TableCell className='blck-Txt' align="left" sx={{ fontWeight: 700 }}>10.00%-12.00%</TableCell>
                                                                    <TableCell className='blck-Txt' align="center" sx={{ fontWeight: 700 }}><button className="btn-secondary btn btn-sm px-5" disabled>Sold Out</button></TableCell>
                                                                </TableRow>
                                                            </>))}
                                                        </TableBody>
                                                    </Table>
                                                </TableContainer>
                                            </Box>
                                        </Grid>
                                    </Container>
                                </CardContent>
                            </Card>
                            {/* ===================THIRD CARD=================== */}
                            <Card
                                className="profile-page-card mb-1 my-5" sx={{ minWidth: "auto", maxWidth: "auto" }}>
                                <CardContent>
                                    <Grid container className=" px-3 py-5" spacing={2}>
                                        <Grid item xs={12} sm={12} md={6} lg={6} className="d-flex justify-content-center justify-content-lg-start">
                                           <div className="pb-3"><Box component="img" className="img-fluid" alt="gridImage" src={PosGrid}/></div>
                                        </Grid>
                                        <Grid item xs={12} sm={12} md={6} lg={6}>
                                            <Box className="container">
                                                <Typography className="mb-3 blck-Txt" sx={{ fontWeight: 800, fontSize: 20 }}>What is CIFDAQ's PoS Pool?</Typography>
                                                <Typography className="greyTxt mb-3" sx={{ fontWeight: 500, fontSize: 15 }}>
                                                    Users can participate in CIFDAQ Exchange PoS mining pool by staking their tokens and earning an interest yield on the tokens staked.
                                                </Typography>
                                                <Typography className="greyTxt mb-3" sx={{ fontWeight: 500, fontSize: 15 }}>
                                                    CIFDAQ Exchange PoS mining pool offers ‘Fixed’ and ‘Flexible’ staking. For ‘Fixed’ staking, the tokens staked will be locked for a specified period and the user will not be able to perform any transactions on the staked tokens during the lock period. For ‘Flexible’ staking, the user can transact using the staked tokens at any time. Due to the lock period for ‘Fixed’ staking, we would like to remind users to understand all risks involved before committing assets to the pool.
                                                </Typography>
                                                <Typography className="greyTxt mb-3" sx={{ fontWeight: 500, fontSize: 15 }}>
                                                    "PoS holdings" service does not lock the digital tokens of the user, and can be traded or deposited or withdrawn at any time; for the service of "locked POS", the tokens will be locked for a certain period according to the relevant rules shown. The user cannot conduct trade or full operation during the lock period. The "locked POS" requires the user to have an accurate and specific understanding and evaluation of the risks of the relevant tokens. Please be careful when participating.
                                                </Typography>
                                                <Typography className="greyTxt mb-3" sx={{ fontWeight: 500, fontSize: 15 }}>
                                                    CIFDAQ PoS pool is committed in making it easy to participate in the PoS ecology, by providing users with the best trading experience, promoting the development of PoS ecology and promoting the progress of the industry.
                                                </Typography>
                                            </Box>
                                        </Grid>
                                    </Grid>
                                </CardContent>
                            </Card>
                        </Box>
                    </TabPanel>


                    {/* ////////////////TAB2/////////////// */}
                    <TabPanel value="2">
                   
                    </TabPanel>
                </TabContext>
            </Container>
        </div>
    );
};
export default POSPool;
