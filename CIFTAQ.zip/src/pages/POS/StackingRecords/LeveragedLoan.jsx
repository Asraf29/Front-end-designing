import React ,{useState}from 'react';
import NODATA from "../../../components/assets/images/nodata.png";
import TableBody from "@mui/material/TableBody";
import TableCell from "@mui/material/TableCell";
import TableContainer from "@mui/material/TableContainer";
import TableHead from "@mui/material/TableHead";
import { makeStyles } from "@mui/styles";
import TableRow from "@mui/material/TableRow";
import Paper from "@mui/material/Paper";
import CachedIcon from '@mui/icons-material/Cached';
import { Table, Typography } from '@mui/material';
import { Box } from '@mui/system';
export default function LeveragedLoan() {
    const [value, setValue] = React.useState("1");
    const [type, setType] = useState("text");
    const handleChange = (event, newValue) => {
        setValue(newValue);
    };
  return (
    <div>
           <>
                                <div className="d-block d-sm-flex  justify-content-between">
                                    <div className="d-block d-sm-flex  col-lg-6 mb-sm-0">
                                        <div className="col-lg-5 d-sm-flex ms-0">
                                            <Typography className="my-1 m-1 ms-2 me-2 trending fw-bold">
                                                Time:
                                            </Typography>
                                            <div className="col-lg-10  ms-0  mb-2 mb-sm-0">
                                                <input
                                                    style={{ height: "40px" }}
                                                    className="input-sizes placeholder-start inputBg sizes-in"
                                                    placeholder="Start date ~ End date"
                                                    type={type}
                                                    onFocus={() => setType("date")}
                                                    onBlur={() => setType("text")}
                                                    id="date"
                                                />
                                            </div>
                                        </div>
                                    </div>

                                    <div>
                                        <button
                                            className="btn ms-0 ms-lg-2 btn-sm"
                                            style={{ color: "white", background: "#1a94ae" }}
                                        >
                                           <CachedIcon fontSize='small'/> Refresh
                                        </button>
                                    </div>
                                </div>
                                <Box sx={{ width: "100%", typography: "body1", mt: 1 }}>
                                    <TableContainer
                                        sx={{
                                            background: "var(--card-bg-color)",
                                            boxShadow: "none !important",
                                        }}
                                        component={Paper}
                                    >
                                        <Table sx={{ minWidth: 650 }} aria-label="simple table">
                                            <TableHead>
                                                <TableRow>
                                                    <TableCell
                                                        sx={{
                                                            color: "var(--txt-placeholder)" ,fontSize:'11px !important',
                                                            borderBottom: 0,
                                                        }}> Tokens
                                                    </TableCell>
                                                    <TableCell
                                                        sx={{
                                                            color: "var(--txt-placeholder)" ,fontSize:'11px !important',
                                                            borderBottom: 0,
                                                        }}
                                                        align="center"
                                                    >Locking start time
                                                    </TableCell>
                                                    <TableCell
                                                        sx={{
                                                            color: "var(--txt-placeholder)" ,fontSize:'11px !important',
                                                            borderBottom: 0,
                                                        }}
                                                        align="right"
                                                    >Unlocking start time
                                                    </TableCell>
                                                    <TableCell
                                                        sx={{
                                                            color: "var(--txt-placeholder)" ,fontSize:'11px !important',
                                                            borderBottom: 0,
                                                        }}
                                                        align="right"
                                                    >Est. principal-return time
                                                    </TableCell>
                                                    <TableCell
                                                        sx={{
                                                            color: "var(--txt-placeholder)" ,fontSize:'11px !important',
                                                            borderBottom: 0,
                                                        }}
                                                        align="right"
                                                    >Locked quantity
                                                    </TableCell>
                                                    <TableCell
                                                        sx={{
                                                            color: "var(--txt-placeholder)" ,fontSize:'11px !important',
                                                            borderBottom: 0,
                                                        }}
                                                        align="right"
                                                    >	Est. APY
                                                    </TableCell>
                                                    <TableCell
                                                        sx={{
                                                            color: "var(--txt-placeholder)" ,fontSize:'11px !important',
                                                            borderBottom: 0,
                                                        }}
                                                        align="right"
                                                    >Locking progress
                                                    </TableCell>
                                                    <TableCell
                                                        sx={{
                                                            color: "var(--txt-placeholder)" ,fontSize:'11px !important',
                                                            borderBottom: 0,
                                                        }}
                                                        align="right"
                                                    >Current Stakings yield
                                                    </TableCell>
                                                    <TableCell
                                                        sx={{
                                                            color: "var(--txt-placeholder)" ,fontSize:'11px !important',
                                                            borderBottom: 0,
                                                        }}
                                                        align="right"
                                                    >Status
                                                    </TableCell>
                                                    <TableCell
                                                        sx={{
                                                            color: "var(--txt-placeholder)" ,fontSize:'11px !important',
                                                            borderBottom: 0,
                                                        }}
                                                        align="right"
                                                    >Action
                                                    </TableCell>
                                                </TableRow>
                                            </TableHead>
                                            <TableBody>
                                                <TableRow
                                                    sx={{
                                                        "&:last-child td, &:last-child th": {
                                                            border: 0,
                                                        },
                                                    }}
                                                >
                                                    <TableCell
                                                        align="center"
                                                        colSpan={10}
                                                        sx={{
                                                            justifyContent: "center",
                                                            alignItems: "center",
                                                        }}
                                                    >
                                                        {" "}
                                                        <img src={NODATA} />{" "}
                                                    </TableCell>
                                                </TableRow>
                                            </TableBody>
                                        </Table>
                                    </TableContainer>
                                </Box>
                            </>
    </div>
  )
}
