import React, { useState } from "react";
import { makeStyles } from "@mui/styles";
import {
    Button,
    Card,
    CardContent,
    Grid,
    Table,
    Tabs,
    Typography,
} from "@mui/material";
import Box from "@mui/material/Box";
import ArrowBackIosIcon from "@mui/icons-material/ArrowBackIos";
import Tab from "@mui/material/Tab";
import TabContext from "@mui/lab/TabContext";
import TabList from "@mui/lab/TabList";
import TabPanel from "@mui/lab/TabPanel";
import { Container } from "@mui/system";
import { Link } from "react-router-dom";
import LeveragedLoan from "./LeveragedLoan";
import Flexible from "./flexible";
import CachedIcon from '@mui/icons-material/Cached';

const useStyles = makeStyles({
    MUITab: {
        fontSize: "16px !important",
        color: "var(--txt-placeholder)"
    },
});

export default function StakingRecords() {
    const [value, setValue] = React.useState("1");
    const [type, setType] = useState("text");
    const handleChange = (event, newValue) => {
        setValue(newValue);
    };
    const classes = useStyles();
    return (
        <>
            <Container sx={{ mt: 7 }}>
                <Typography
                    className="mb-3 d-flex align-items-center verifyTitle"
                    variant="h5"
                >
                    <Link to="/posPool" className="linkTag text-white">
                        <ArrowBackIosIcon className="mb-2" />
                    </Link>
                    PoS
                </Typography>
                
                <Grid item xs={12} lg={12} md={12}>
                    <Card
                        sx={{
                            minWidth: 100,
                            background: "var(--card-bg-color)",
                        }}
                    >
                        <CardContent>
                            <TabContext value={value}>
                        <TabList
                         TabIndicatorProps={{
                            style: {display: 'none'}
                          }}
                    onChange={handleChange}
                    variant="scrollable"
                  >
                    <Tab
                      className={classes.MUITab}
                      label="Leveraged loan"
                      value="1"
                    />
                    <Tab
                      className={classes.MUITab}
                      label="Fixed"
                      value="2"
                    />
                    <Tab
                      className={classes.MUITab}
                      label="Flexible"
                      value="3"
                    />
                  </TabList>
                  <TabPanel sx={{padding:"4px !important"}} value="1">
                         <LeveragedLoan/>
                            </TabPanel>
                            <TabPanel sx={{padding:"4px !important"}} value="2">
                         <LeveragedLoan/>
                            </TabPanel>
                            <TabPanel sx={{padding:"4px !important"}} value="3">
                         <Flexible/>
                            </TabPanel>
                            </TabContext>
                        
                        </CardContent>
                    </Card>
                </Grid>
            </Container>
        </>
    );
}
