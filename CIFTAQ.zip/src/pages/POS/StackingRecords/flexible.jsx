import React ,{useState}from 'react';
import NODATA from "../../../components/assets/images/nodata.png";
import TableBody from "@mui/material/TableBody";
import TableCell from "@mui/material/TableCell";
import TableContainer from "@mui/material/TableContainer";
import TableHead from "@mui/material/TableHead";
import { makeStyles } from "@mui/styles";
import TableRow from "@mui/material/TableRow";
import Paper from "@mui/material/Paper";
import CachedIcon from '@mui/icons-material/Cached';
import { Table, Typography } from '@mui/material';
import { Box } from '@mui/system';


export default function Flexible() {
    const [value, setValue] = React.useState("1");
    const [type, setType] = useState("text");
    const handleChange = (event, newValue) => {
        setValue(newValue);
    };
  return (
    <div>
           <>
           <div className='d-flex justify-content-end'>
                                        <button
                                            className="btn ms-0 ms-lg-2 btn-sm"
                                            style={{ color: "white", background: "#1a94ae" }}
                                        >
                                           <CachedIcon fontSize='small'/> Refresh
                                        </button>
                                    </div>
                                <Box sx={{ width: "100%", typography: "body1" }}>
                                    <TableContainer
                                        sx={{
                                            background: "var(--card-bg-color)",
                                            boxShadow: "none !important",
                                        }}
                                        component={Paper}
                                    >
                                        <Table sx={{ minWidth: 650 }} aria-label="simple table">
                                            <TableHead>
                                                <TableRow>
                                                    <TableCell
                                                        sx={{
                                                            color: "var(--txt-placeholder)" ,fontSize:'11px !important',
                                                            borderBottom: 0,
                                                        }}> Tokens
                                                    </TableCell>
                                                    <TableCell
                                                        sx={{
                                                            color: "var(--txt-placeholder)" ,fontSize:'11px !important',
                                                            borderBottom: 0,
                                                        }}
                                                        align="center"
                                                    >Date of Agreement
                                                    </TableCell>
                                                    <TableCell
                                                        sx={{
                                                            color: "var(--txt-placeholder)" ,fontSize:'11px !important',
                                                            borderBottom: 0,
                                                        }}
                                                        align="right"
                                                    >PoS exit time
                                                    </TableCell>
                                                    <TableCell
                                                        sx={{
                                                            color: "var(--txt-placeholder)" ,fontSize:'11px !important',
                                                            borderBottom: 0,
                                                        }}
                                                        align="right"
                                                    >	Principal
                                                    </TableCell>
                                                    <TableCell
                                                        sx={{
                                                            color: "var(--txt-placeholder)" ,fontSize:'11px !important',
                                                            borderBottom: 0,
                                                        }}
                                                        align="right"
                                                    >Latest annualized yield
                                                    </TableCell>
                                                    <TableCell
                                                        sx={{
                                                            color: "var(--txt-placeholder)" ,fontSize:'11px !important',
                                                            borderBottom: 0,
                                                        }}
                                                        align="right"
                                                    >Yield amount
                                                    </TableCell>
                                                    <TableCell
                                                        sx={{
                                                            color: "var(--txt-placeholder)" ,fontSize:'11px !important',
                                                            borderBottom: 0,
                                                        }}
                                                        align="right"
                                                    >Status
                                                    </TableCell>
                                                    <TableCell
                                                        sx={{
                                                            color: "var(--txt-placeholder)" ,fontSize:'11px !important',
                                                            borderBottom: 0,
                                                        }}
                                                        align="right"
                                                    >Action
                                                    </TableCell>
                                                </TableRow>
                                            </TableHead>
                                            <TableBody>
                                                <TableRow
                                                    sx={{
                                                        "&:last-child td, &:last-child th": {
                                                            border: 0,
                                                        },
                                                    }}
                                                >
                                                    <TableCell
                                                        align="center"
                                                        colSpan={8}
                                                        sx={{
                                                            justifyContent: "center",
                                                            alignItems: "center",
                                                        }}
                                                    >
                                                        {" "}
                                                        <img src={NODATA} />{" "}
                                                    </TableCell>
                                                </TableRow>
                                            </TableBody>
                                        </Table>
                                    </TableContainer>
                                </Box>
                            </>
    </div>
  )
}
