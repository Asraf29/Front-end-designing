import React, { useState } from "react";
import {
    Avatar,
    Box,
    Button,
    CardActionArea,
    CardMedia,
} from "@mui/material";
import Card from "@mui/material/Card";
import CardContent from "@mui/material/CardContent";
import { Container } from "@mui/system";
import {
    Grid,
    Typography,
} from "@mui/material";
import one from '../../components/assets/images/one.png'
import { Link } from "react-router-dom";
import banner from "../../components/assets/images/mdayBanner.png";
import "./index.css";
import mxlogo from '../../components/assets/images/mxlogo.png';
import Tab from '@mui/material/Tab';
import TabContext from '@mui/lab/TabContext';
import TabList from '@mui/lab/TabList';
import TabPanel from '@mui/lab/TabPanel';
import { makeStyles } from "@mui/styles";
import BOT from '../../components/assets/images/BOT.png'
import tooltip from '../../components/assets/images/tooltip.png';
import cardImg from '../../components/assets/images/mdayCard.png'
// Tab Switch;
const useStyles = makeStyles({
    MUITab: {
        color: "var(--Tab-gray-text) !important",
        fontSize: "16px !important",
        fontWeight: 'bold'
    },
    
ribbon: {
    backgroundColor: '#9EA1C0',
    position: "absolute",
    color: 'white',
    width: 86,
    zIndex: 3,
    paddingBottom:4,
    textAlign: 'center',
    padding: 1,
    fontSize:14,
    '&::before': {
        position: "absolute",
        zIndex: -1,
        content: '',
        display: 'block',
        border: '5px solid #2980b9',
    },
    '&::after': {
        position: "absolute",
        zIndex: -1,
        content: '',
        display: 'block',
        border: '5px solid #2980b9',
    },
    transform: 'rotate(-45deg)',
    top: 6,
    marginLeft: -21,
},
span: {

}
});
const Mday = () => {

    const classes = useStyles();
    return (
        <div>
            <Container sx={{ mb: 7 }}>

                <Box className="d-md-flex justify-content-md-between align-items-center">
                    <div className="ms-4 col-xs-12 mt-sm-0 col-lg-6">
                        <div className="my-4 my-sm-0">
                            <Box
                                component="img"
                                alt="topbar-bg"
                                src={tooltip}

                                sx={{ maxWidth: 180, maxHeight: 91 }}
                                className="img-fluid tooltp-img" />
                            <Typography className="text-propty" variant="h3">
                                MX DeFi
                            </Typography>
                            <Typography className="text-propty-sub">
                                Enjoy mining rewards, store and use anytime with flexibility
                            </Typography>
                        </div>
                    </div>
                    <div className="col-lg-6 col-md-6 col-sm-12 my-2">
                        <Box
                            component="img"
                            alt="topbar-bg"
                            src={banner}
                            sx={{ width: '100%', height: '100%' }}
                            className="img-fluid m-day-bnr" />
                    </div>
                </Box>
                {/*EVENT  Cards*/}

                <Card
                    className="profile-page-card"
                    sx={{ minWidth: "auto", maxWidth: "auto" }}>
                    <CardContent>
                        <Container>
                        <Typography sx={{ fontWeight:600, color: '#1A94AE', fontSize: 20 , mb:4 }}>Past events</Typography>

                        <div class="row row-md-cols-4 mb-4">

                            <div class="col-sm-12 col-md-6 col-lg-3">
                                <div className='card-one'>
                                    <div className={classes.ribbon} style={{clipPath:'polygon(12% 1px, 81% 0px, 94% 77%, 1% 77%)'}}><span className={classes.span}>Ended</span>
                                    </div>
                                    <Card className="profile-page-card rbnCard" sx={{ maxWidth: 345, boxShadow:6, borderRadius:'6px !important' }}>
                                        <CardActionArea>
                                            <CardMedia
                                                component="img"
                                                height="140"
                                                image={cardImg}
                                                alt="green iguana"
                                            />
                                            <CardContent>
                                                <div className="d-flex justify-content-between mb-1 bordr-Clr">
                                                    <div>
                                                        <Typography
                                                            className="card-text mb-2"
                                                            gutterBottom
                                                            sx={{ fontSize: "16px", fontWeight: 600 }}
                                                        >
                                                           SVT-MX Round
                                                        </Typography>
                                                    </div>
                                                </div>
                                                <div className="d-flex justify-content-between mb-2">
                                                    <div>
                                                        <Typography
                                                            className="textClr"
                                                            sx={{ fontSize: "14px", fontWeight: 600 }}
                                                        >
                                                            Total supply
                                                        </Typography>
                                                    </div>
                                                    <div>
                                                        <Typography
                                                            className="textClr"
                                                            sx={{ fontSize: "14px", fontWeight: 600 }}
                                                        >
                                                            150,000,000 SVT
                                                        </Typography>
                                                    </div>
                                                </div>
                                                <div className="d-flex justify-content-between">
                                                    <div>
                                                        <Typography
                                                            className="textClr"
                                                            sx={{ fontSize: "14px", fontWeight: 600 }}
                                                        >
                                                            Start time
                                                        </Typography>
                                                    </div>
                                                    <div>
                                                        <Typography
                                                            className="textClr"
                                                            sx={{ fontSize: "14px", fontWeight: 600 }}
                                                        >
                                                            2021-12-07 17:00:01
                                                        </Typography>
                                                    </div>
                                                </div>
                                            </CardContent>
                                        </CardActionArea>
                                    </Card>
                                </div>
                            </div>
                            <div class="col-sm-12 col-md-6 col-lg-3 my-3 my-md-0">
                            <div className='card-one'>
                                    <div className={classes.ribbon} style={{clipPath:'polygon(12% 1px, 81% 0px, 94% 77%, 1% 77%)'}}><span className={classes.span}>Ended</span>
                                    </div>
                                    <Card className="profile-page-card rbnCard" sx={{ maxWidth: 345, boxShadow:6, borderRadius:'6px !important' }}>
                                        <CardActionArea>
                                            <CardMedia
                                                component="img"
                                                height="140"
                                                image={cardImg}
                                                alt="green iguana"
                                            />
                                            <CardContent>
                                                <div className="d-flex justify-content-between mb-1 bordr-Clr">
                                                    <div>
                                                        <Typography
                                                            className="card-text mb-2"
                                                            gutterBottom
                                                            sx={{ fontSize: "16px", fontWeight: 600 }}
                                                        >
                                                          SVT-Trading Round
                                                        </Typography>
                                                    </div>
                                                </div>
                                                <div className="d-flex justify-content-between mb-2">
                                                    <div>
                                                        <Typography
                                                            className="textClr"
                                                            sx={{ fontSize: "14px", fontWeight: 600 }}
                                                        >
                                                            Total supply
                                                        </Typography>
                                                    </div>
                                                    <div>
                                                        <Typography
                                                            className="textClr"
                                                            sx={{ fontSize: "14px", fontWeight: 600 }}
                                                        >
                                                            150,000,000 SVT
                                                        </Typography>
                                                    </div>
                                                </div>
                                                <div className="d-flex justify-content-between">
                                                    <div>
                                                        <Typography
                                                            className="textClr"
                                                            sx={{ fontSize: "14px", fontWeight: 600 }}
                                                        >
                                                            Start time
                                                        </Typography>
                                                    </div>
                                                    <div>
                                                        <Typography
                                                            className="textClr"
                                                            sx={{ fontSize: "14px", fontWeight: 600 }}
                                                        >
                                                            2021-12-07 17:00:01
                                                        </Typography>
                                                    </div>
                                                </div>
                                            </CardContent>
                                        </CardActionArea>
                                    </Card>
                                </div>
                            </div>
                        </div>
                        </Container>
                    </CardContent>
                </Card>


            </Container>
        </div>
    );
};
export default Mday;
