import React, { useState } from "react";
import {
    Avatar,
    Box,
    Button,
    Paper,
    Table,
    TableBody,
    TableCell,
    TableContainer,
    TableHead,
    TableRow,
} from "@mui/material";
import Card from "@mui/material/Card";
import CardContent from "@mui/material/CardContent";
import { Container } from "@mui/system";
import { Checkbox, Grid, ListItemButton, ListItemIcon, ListItemText, Typography, } from "@mui/material";
import CloseIcon from '@mui/icons-material/Close';
import SVTIcon from '../../../components/assets/images/SVTicon.png'
import MXDefiIcon from '../../../components/assets/images/MXdefiIcon.png'
import { Link } from 'react-router-dom'
import "../index.css";
const data = ["1", "2", "3"];

const MdayPastEvent = () => {
    return (
        <div>
            <Container sx={{ mb: 7, mt: 4 }}>
                <Typography className="mb-3 text-white" variant="h4">
                    SVT--MX Round
                </Typography>
                <Button variant="contained" className="endBtnClr mb-4">Ended</Button>
                {/* Countdown */}
                <Grid container>
                    <Grid item xs={12} md={12} lg={12} className="pb-3">
                        <Grid item xs={12} md={6} lg={6} className="d-flex justify-content-center justify-content-sm-start">
                            <Box>
                                <Card sx={{ minWidth: "auto", maxWidth: "auto" }} className="countCardBg me-sm-4 marginEnd">
                                    <CardContent className="d-flex justify-content-center align-items-center">
                                        <Typography variant="h4" className="countNumber">00</Typography>
                                    </CardContent>
                                </Card>
                                <Typography className="textClr ps-4 ms-2 pt-2">D</Typography>
                            </Box><Typography className="text-white pe-lg-4 paddingEndPoin" variant="h4">:</Typography>
                            <Box>
                                <Card sx={{ minWidth: "auto", maxWidth: "auto" }} className="countCardBg me-sm-4 marginEnd">
                                    <CardContent className="d-flex justify-content-center align-items-center">
                                        <Typography variant="h4" className="countNumber">00</Typography>
                                    </CardContent>
                                </Card>
                                <Typography className="textClr ps-4 ms-2 pt-2">H</Typography>
                            </Box><Typography className="text-white pe-lg-4 paddingEndPoin" variant="h4">:</Typography>
                            <Box>
                                <Card sx={{ minWidth: "auto", maxWidth: "auto" }} className="countCardBg me-sm-4 marginEnd">
                                    <CardContent className="d-flex justify-content-center align-items-center">
                                        <Typography variant="h4" className="countNumber ">00</Typography>
                                    </CardContent>
                                </Card>
                                <Typography className="textClr ps-4 ms-2 pt-2">M</Typography>
                            </Box><Typography className="text-white pe-lg-4 paddingEndPoin" variant="h4">:</Typography>
                            <Box>
                                <Card sx={{ minWidth: "auto", maxWidth: "auto" }} className="countCardBg">
                                    <CardContent className="d-flex justify-content-center align-items-center">
                                        <Typography variant="h4" className="countNumber">00</Typography>
                                    </CardContent>
                                </Card>
                                <Typography className="textClr ps-4 ms-2 pt-2">S</Typography>
                            </Box>
                        </Grid>
                        <Box className="pt-4 pb-3 d-sm-flex justify-content-sm-around">
                            <Typography className="textClrGreen">Registration time:<span className="text-white ps-1">2022-01-11 17:30:00 - 2022-01-12 17:00:00</span></Typography>
                            <Typography className="textClrGreen py-2 py-sm-0">Total supply:<span className="text-white ps-1"> 100,000,000 SVT </span></Typography>
                            <Typography className="textClrGreen">Total amount of this round of drawing:<span className="text-white ps-1"> 180,000 SVT </span></Typography>
                        </Box>
                    </Grid>
                </Grid>
                {/*Top Card*/}
                <Card className="profile-page-card">
                    <CardContent className="px-4 my-3">
                        <Box className="d-sm-flex justify-content-sm-between">
                            <Typography variant="h5" className="SVTTitle fw-bold">MXPosition details</Typography>
                            <Box className="d-grid pt-2 pt-sm-0"><Button variant="contained" className="topcard-EndBtn px-5">Ended</Button></Box>
                        </Box>
                        <Box className="d-flex justify-content-between align-items-center py-3">
                            <Typography className="textClrGreen pt-2 pt-sm-0">Available limit:<span className="ps-1 svt-subText fw-bold">0MX</span> </Typography>
                            <Link to="/mdayOrder" className="linkTag"><Typography className="text-blue pe-sm-4 me-1">My orders</Typography></Link>
                        </Box>
                    </CardContent>
                </Card>
                {/*SVT Launching Card*/}
                <Card className="mt-4 SVTCardBg" sx={{ minWidth: "auto", maxWidth: "auto" }}>
                    <CardContent className="px-4">
                        <Grid container spacing={4}>
                            <Grid item xs={12} md={6} lg={6}>
                                <Box className="d-flex align-items-center justify-content-center justify-content-sm-start my-3">
                                    <Avatar alt="Token_one" src={SVTIcon} sx={{ width: 80, height: 80 }} />
                                    <CloseIcon className="textClrGreen fs-2" />
                                    <Avatar alt="Token_two" src={MXDefiIcon} sx={{ width: 80, height: 80 }} />
                                </Box>
                                <Box>
                                    <Typography className="SVTLaunching-Title">Solvent [SVT]</Typography>
                                    <Typography className="SVTLaunching-Title">is Launching</Typography>
                                </Box>
                                <Box className="pb-3">
                                    <Typography className="textClr my-3">
                                        * Below information are provided by the project authority.
                                        Please make your own judgement.
                                    </Typography>
                                    <Typography className="SVTTitle">Solvent is a platform to convert NFTs to fungible tokens
                                        known as droplets, giving the user instant liquidity. The
                                        instant liquidity for NFTs can provide users a platform to
                                        trade NFTs faster than they can today. Droplets can be traded
                                        on AMMs and Serum order books on Solana. Users can trade
                                        the droplets owned by them to redeem NFTs in the Solvent
                                        buckets or swap droplets for $USDC directly from the
                                        platform. They can also stake their liquidity of the droplets
                                        into liquidity pools and earn liquidity rewards. Features like
                                        lending, loans, NFT derivatives, and more exciting
                                        integrations are to be released soon.
                                    </Typography>
                                </Box>
                            </Grid>
                            <Grid item xs={12} md={6} lg={6}>
                                {/* Right Side TAble */}
                                <Card sx={{ minWidth: "auto", maxWidth: "auto" }} className="profile-page-card">
                                    <CardContent>
                                        <Typography sx={{ fontWeight: 600 }} className="SVTTitle pb-2">
                                            Token Allocation
                                        </Typography>
                                        <TableContainer component={Paper} sx={{ background: "var( --card-bg-color)" }} className="mt-4">
                                            <Table sx={{ background: "var( --card-bg-color)" }}>
                                                <TableHead>
                                                    <TableRow sx={{ border: "1px solid var(--input-qr-bg)", borderRight: 0, borderLeft: 0, }}>
                                                        <TableCell sx={{ fontWeight: "bolder !important" }} className="textClr" align="left">
                                                            Type
                                                        </TableCell>
                                                        <TableCell sx={{ fontWeight: "bolder !important" }} className="textClr" align="center">
                                                            Amount
                                                        </TableCell>
                                                        <TableCell sx={{ fontWeight: "bolder !important" }} className="textClr" align="center">
                                                            Percentage
                                                        </TableCell>
                                                    </TableRow>
                                                </TableHead>
                                                <TableBody>
                                                    <TableRow className="svt-subText" sx={{ "&:last-child td, &:last-child th": { border: 0 }, background: "#c4c4c4" }}>
                                                        <TableCell>
                                                            <Typography className="text-dark">Seed Sale</Typography>
                                                        </TableCell>
                                                        <TableCell>
                                                            <Typography className="text-dark" sx={{ fontWeight: 700 }} align={"center"}>
                                                                7,000,000
                                                            </Typography>
                                                        </TableCell>
                                                        <TableCell>
                                                            <Typography className="text-dark" align={"center"}>
                                                                10%
                                                            </Typography>
                                                        </TableCell>
                                                    </TableRow>
                                                    <TableRow sx={{ "&:last-child td, &:last-child th": { border: 0 }, }}>
                                                        <TableCell>
                                                            <Typography className="svt-subText">Strategic Sale</Typography>
                                                        </TableCell>
                                                        <TableCell>
                                                            <Typography className="svt-subText" sx={{ fontWeight: 700 }} align={"center"}>
                                                                7,000,000
                                                            </Typography>
                                                        </TableCell>
                                                        <TableCell>
                                                            <Typography className="svt-subText" align={"center"}>
                                                                25%
                                                            </Typography>
                                                        </TableCell>
                                                    </TableRow>
                                                    <TableRow className="svt-subText" sx={{ "&:last-child td, &:last-child th": { border: 0 }, background: "#c4c4c4" }}>
                                                        <TableCell>
                                                            <Typography className="text-dark">Public Sale</Typography>
                                                        </TableCell>
                                                        <TableCell>
                                                            <Typography className="text-dark" sx={{ fontWeight: 700 }} align={"center"}>
                                                                7,000,000
                                                            </Typography>
                                                        </TableCell>
                                                        <TableCell>
                                                            <Typography className="text-dark" align={"center"}>
                                                                10%
                                                            </Typography>
                                                        </TableCell>
                                                    </TableRow>
                                                    <TableRow sx={{ "&:last-child td, &:last-child th": { border: 0 }, }}>
                                                        <TableCell>
                                                            <Typography className="svt-subText">Team</Typography>
                                                        </TableCell>
                                                        <TableCell>
                                                            <Typography className="svt-subText" sx={{ fontWeight: 700 }} align={"center"}>
                                                                7,000,000
                                                            </Typography>
                                                        </TableCell>
                                                        <TableCell>
                                                            <Typography className="svt-subText" align={"center"}>
                                                                5%
                                                            </Typography>
                                                        </TableCell>
                                                    </TableRow>
                                                    <TableRow className="svt-subText" sx={{ "&:last-child td, &:last-child th": { border: 0 }, background: "#c4c4c4" }}>
                                                        <TableCell>
                                                            <Typography className="text-dark">Advisors</Typography>
                                                        </TableCell>
                                                        <TableCell>
                                                            <Typography className="text-dark" sx={{ fontWeight: 700 }} align={"center"}>
                                                                7,000,000
                                                            </Typography>
                                                        </TableCell>
                                                        <TableCell>
                                                            <Typography className="text-dark" align={"center"}>
                                                                10%
                                                            </Typography>
                                                        </TableCell>
                                                    </TableRow>
                                                    <TableRow sx={{ "&:last-child td, &:last-child th": { border: 0 }, }}>
                                                        <TableCell>
                                                            <Typography className="svt-subText">Solvent Liquidty</Typography>
                                                        </TableCell>
                                                        <TableCell>
                                                            <Typography className="svt-subText" sx={{ fontWeight: 700 }} align={"center"}>
                                                                7,000,000
                                                            </Typography>
                                                        </TableCell>
                                                        <TableCell>
                                                            <Typography className="svt-subText" align={"center"}>
                                                                10%
                                                            </Typography>
                                                        </TableCell>
                                                    </TableRow>
                                                </TableBody>
                                            </Table>
                                        </TableContainer>
                                    </CardContent>
                                </Card>
                                {/* Highlight Card */}
                                <Card sx={{ minWidth: "auto", maxWidth: "auto", mt: 3 }} className="profile-page-card">
                                    <CardContent>
                                        <Typography sx={{ fontWeight: 600 }} className="pb-2 SVTTitle">
                                            Project Highlights
                                        </Typography>
                                        <Typography className="SVTTitle">
                                            - Instant Liquidity to NFTS:
                                            <div className="SVTTitle">Solvent is an instant liquidity platform where you can exchange your NFT assets for getting instant liquidity. You get instant liquidity in form of droplets (fungible tokens) of that NFT project, which are tradable on Serum, and can even be swapped for $USDC.</div>
                                        </Typography>
                                        <Typography className="SVTTitle my-3">
                                            - Liquidity Mining and Yield farming:
                                            <div className="SVTTitle"> NFT traders can exchange their NFTs for droplets and provide liquidity to the pools on AMMs like Atrix finance. The LP tokens can also be staked for receiving $SVT rewards. We have 30% allocation of the platform token $SVT as rewards towards liquidity mining.</div>
                                        </Typography>
                                        <Typography className="SVTTitle my-3">
                                            - $SVT staking:
                                            <div className="SVTTitle"> $SVT is the governance token for the Solvent platform. A portion of the platform minting fees will be used to buyback $SVT tokens from the market and will be distributed to the holders staking the $SVT token.</div>
                                        </Typography>
                                        <Typography className="SVTTitle">
                                            - Community governance
                                            <div className="SVTTitle">$SVT token holders will also be able to participate in the community governance and help shape the future of Solvent and NFT liquidity.</div>
                                        </Typography>
                                    </CardContent>
                                </Card>
                            </Grid>
                        </Grid>
                    </CardContent>
                </Card>
            </Container>
        </div>
    );
};
export default MdayPastEvent;
