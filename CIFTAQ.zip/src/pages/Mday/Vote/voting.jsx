import React, {useState} from "react";
import {
    Avatar,
    Box,
    Button,
    Paper,
    Table,
    TableBody,
    TableCell,
    TableContainer,
    TableHead,
    TableRow,
} from "@mui/material";
import SearchIcon from "@mui/icons-material/Search";
import Card from "@mui/material/Card";
import CardContent from "@mui/material/CardContent";
import { Container } from "@mui/system";
import { Grid, Typography, } from "@mui/material";
import { Link } from 'react-router-dom'
import "../index.css";
import VOTEBG from '../../../components/assets/images/voteBg.png';
import rank1 from '../../../components/assets/images/raking1.png';
import rank2 from '../../../components/assets/images/raking2.png';
import rank3 from '../../../components/assets/images/raking3.png';
import ProjectModels from "../../../components/ProjectModel/projectModel";


const Voting = () => {
        //Exchange Modal
        const [ProjectModel, setOpenProjectModel] = React.useState(false);

        const handleClickOpen = () => {
            setOpenProjectModel(true);
        };   
        const handleClose = () => {
            setOpenProjectModel(false);
        };
    
    
    return (
        <div>
             <ProjectModels ProjectModel={ProjectModel} handleClickOpen={handleClickOpen} handleClose={handleClose} />
            <Container sx={{ mb: 7, mt: 4 }}>
                <div className="d-flex">
                    <Grid item container>
                        <Grid xs={12} sm={12} md={8} lg={7}>
                            <div className="d-block d-sm-flex">
                                <Typography className="mb-3 text-white" variant="h4">
                                    Vote for renewal and obtain rewards
                                </Typography>
                                <Button variant="contained" size="small" className="endBtnClr mb-4 my-1 ms-2">Ended</Button>
                            </div>

                            <Typography className="ps-1 text-white">Participate in the voting event in the assessment zone and obtain the trading fee reward</Typography>

                            {/* Countdown */}
                            <Box className="mt-5 mb-4">
                                <Grid container>
                                    <Grid item xs={12} md={12} lg={12} className="pb-3 d-flex justify-content-sm-center justify-content-md-center justify-content-lg-start">
                                        <Grid item xs={12} md={6} lg={6} className="d-flex justify-content-center justify-content-sm-start">
                                            <Box>
                                                <Card sx={{ minWidth: "auto", maxWidth: "auto" }} className="countCardBg me-sm-4 marginEnd">
                                                    <CardContent className="d-flex justify-content-center align-items-center">
                                                        <Typography variant="h4" className="countNumber">00</Typography>
                                                    </CardContent>
                                                </Card>
                                                <Typography className="textClr ps-4 ms-2 pt-2">D</Typography>
                                            </Box><Typography className="text-white pe-lg-4 paddingEndPoin" variant="h4">:</Typography>
                                            <Box>
                                                <Card sx={{ minWidth: "auto", maxWidth: "auto" }} className="countCardBg me-sm-4 marginEnd">
                                                    <CardContent className="d-flex justify-content-center align-items-center">
                                                        <Typography variant="h4" className="countNumber">00</Typography>
                                                    </CardContent>
                                                </Card>
                                                <Typography className="textClr ps-4 ms-2 pt-2">H</Typography>
                                            </Box><Typography className="text-white pe-lg-4 paddingEndPoin" variant="h4">:</Typography>
                                            <Box>
                                                <Card sx={{ minWidth: "auto", maxWidth: "auto" }} className="countCardBg me-sm-4 marginEnd">
                                                    <CardContent className="d-flex justify-content-center align-items-center">
                                                        <Typography variant="h4" className="countNumber ">00</Typography>
                                                    </CardContent>
                                                </Card>
                                                <Typography className="textClr ps-4 ms-2 pt-2">M</Typography>
                                            </Box><Typography className="text-white pe-lg-4 paddingEndPoin" variant="h4">:</Typography>
                                            <Box>
                                                <Card sx={{ minWidth: "auto", maxWidth: "auto" }} className="countCardBg">
                                                    <CardContent className="d-flex justify-content-center align-items-center">
                                                        <Typography variant="h4" className="countNumber">00</Typography>
                                                    </CardContent>
                                                </Card>
                                                <Typography className="textClr ps-4 ms-2 pt-2">S</Typography>
                                            </Box>
                                        </Grid>
                                    </Grid>
                                </Grid>
                            </Box>
                        </Grid>
                        <Grid xs={12} sm={12} md={4} lg={5}>
                            <img src={VOTEBG} className='img-fluid' />
                        </Grid>
                    </Grid>
                </div>

                {/*Top Card*/}
                <Card
                    className="profile-page-card"
                    sx={{ minWidth: "auto", maxWidth: "auto" }}
                >
                    <CardContent>
                        <Container className='my-2'>
                            <Grid item xs={12} sm={12} md={12} lg={12}>
                                <Box className="d-flex justify-content-between">
                                    <div>
                                        <Typography className="card-text fw-bold" sx={{ fontSize: 18 }}>Issue 18</Typography>
                                    </div>
                                    <div className="d-flex">
                                        <Link to='/slotVote' className="linkTag me-4 py-2"> <Typography className="card-text fw-bold" sx={{ color: '#1A94AE', fontSize: 14 }}>My Votes</Typography></Link>
                                        <div className="mb-2 mb-sm-0">
                                            <input
                                                type="text"
                                                id="searchBar"
                                                className="form-control input-typing-space seachbarVote-bg"
                                                placeholder="Search Token"
                                            />
                                            <span className="search-iconProp pe-2 text-dark">
                                                <SearchIcon className="search-icon-color" />
                                            </span>
                                        </div>
                                    </div>
                                </Box>
                                <Box className="my-2">
                                    <div>
                                        <Typography className="card-text fw-bold" sx={{ fontSize: 18 }}>Voting rules:</Typography>
                                        <Typography className="DarkgreyTxt" sx={{ fontSize: 16 }}>
                                            1. MX tokens will be used for voting. Users may vote as many times as they like during the voting period. There is no limit on the number of votes for each user.</Typography>
                                        <Typography className="DarkgreyTxt" sx={{ fontSize: 16 }}>
                                            2. The MX Tokens used for voting will be frozen until the end of the voting period or renewal. Users will not be able to trade or transfer the frozen tokens, but they can still participate in M-Day and SpaceM events.</Typography>
                                        <Typography className="DarkgreyTxt" sx={{ fontSize: 16 }}>
                                            CIFDAQ reserves the right for the final interpretation of the vote.</Typography>

                                    </div>
                                </Box>

                                <Box>
                                    <TableContainer component={Paper} className="profile-page-card">
                                        <Table sx={{ minWidth: 650 }} className="profile-page-card" aria-label="simple table">

                                            <TableBody>

                                                <TableRow
                                                    sx={{ 'td,th': { border: 0 } }} >
                                                    <TableCell component="th" scope="row">
                                                        <div className="d-flex">
                                                            <div>
                                                                <img src={rank1} style={{ width: '50px', height: '50px' }} />
                                                            </div>
                                                            <div className="my-2 d-flex ms-2">
                                                                <Typography className='blck-Txt fw-bold'>DFD</Typography>
                                                                <Typography sx={{ fontSize: 12 }} className='text-muted fw-bold ms-1 my-1'>DFD</Typography>
                                                            </div>
                                                        </div>
                                                    </TableCell>
                                                    <TableCell className='blck-Txt' align="center" sx={{ fontWeight: 700 }}><span style={{ fontWeight: 500 }}>Number of votes </span> : 173603
                                                        <span style={{ fontWeight: 500 }}> votes </span></TableCell>
                                                    <TableCell className='blck-Txt' align="right" sx={{ fontWeight: 700 }}> <Button variant="contained" onClick={handleClickOpen} className="btn-hv" sx={{ background: '#1a94ae', color: 'white', textTransform: 'none' }}>More</Button></TableCell>
                                                </TableRow>
                                                <TableRow
                                                    sx={{ 'td,th': { border: 0 } }} >
                                                    <TableCell component="th" scope="row">
                                                        <div className="d-flex">
                                                            <div>
                                                                <img src={rank2} style={{ width: '50px', height: '50px' }} />
                                                            </div>
                                                            <div className="my-2 d-flex ms-2">
                                                                <Typography className='blck-Txt fw-bold'>DFD</Typography>
                                                                <Typography sx={{ fontSize: 12 }} className='text-muted fw-bold ms-1 my-1'>DFD</Typography>
                                                            </div>
                                                        </div>
                                                    </TableCell>
                                                    <TableCell className='blck-Txt' align="center" sx={{ fontWeight: 700 }}><span style={{ fontWeight: 500 }}>Number of votes </span> : 173603
                                                        <span style={{ fontWeight: 500 }}> votes </span></TableCell>
                                                    <TableCell className='blck-Txt' align="right" sx={{ fontWeight: 700 }}> <Button variant="contained" onClick={handleClickOpen} className="btn-hv" sx={{ background: '#1a94ae', color: 'white', textTransform: 'none' }}>More</Button></TableCell>
                                                </TableRow>
                                                <TableRow
                                                    sx={{ 'td,th': { border: 0 } }} >
                                                    <TableCell component="th" scope="row">
                                                        <div className="d-flex">
                                                            <div>
                                                                <img src={rank3} style={{ width: '50px', height: '50px' }} />
                                                            </div>
                                                            <div className="my-2 d-flex ms-2">
                                                                <Typography className='blck-Txt fw-bold'>DFD</Typography>
                                                                <Typography sx={{ fontSize: 12 }} className='text-muted fw-bold ms-1 my-1'>DFD</Typography>
                                                            </div>
                                                        </div>
                                                    </TableCell>
                                                    <TableCell className='blck-Txt' align="center" sx={{ fontWeight: 700 }}> <span style={{ fontWeight: 500 }}>Number of votes </span> : 173603
                                                        <span style={{ fontWeight: 500 }}> votes </span></TableCell>
                                                    <TableCell className='blck-Txt' align="right" sx={{ fontWeight: 700 }}> <Button onClick={handleClickOpen} variant="contained" className="btn-hv" sx={{ background: '#1a94ae', color: 'white', textTransform: 'none' }}>More</Button></TableCell>
                                                </TableRow>
                                            </TableBody>
                                        </Table>
                                    </TableContainer>
                                </Box>
                            </Grid>
                        </Container>
                    </CardContent>
                </Card>
            </Container>
        </div>
    );
};
export default Voting;
