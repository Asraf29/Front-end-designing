import React, { useState } from 'react'
import { Avatar, Box, Button, Paper, Table, TableBody, TableCell, TableContainer, TableHead, TableRow } from "@mui/material";
import Card from "@mui/material/Card";
import CardContent from "@mui/material/CardContent";
import { Container } from "@mui/system";
import { Checkbox, Grid, ListItemButton, ListItemIcon, ListItemText, Typography } from '@mui/material';
import ArrowBackIosIcon from '@mui/icons-material/ArrowBackIos';
import { Link } from 'react-router-dom';
import SearchIcon from "@mui/icons-material/Search";
import topBg from "../../components/assets/images/top-bg.png"
import NODATA from "../../components/assets/images/nodata.png";
import dougnut from "../../components/assets/images/dougnut.png"
import './index.css'
const data = ['1', '2', '3'];


const InviteFriends = () => {
    return (
        <div>
            <Container sx={{ mb: 7 }}>
                <Box className="d-md-flex justify-content-md-between align-items-center">
                    <div className='text-center mt-3 text-sm-start mt-sm-0'>
                        <Typography className='text-prop' variant="h3">Invite Friends</Typography>
                        <Typography className="text-prop-sub my-2">Enjoy trading rewards</Typography>
                    </div>
                    <div>
                        <Box component="img" alt="topbar-bg" src={topBg} className="imageSize img-fluid" />
                    </div>
                </Box>
                {/*Invite Link Cards*/}
                <Card className="profile-page-card" sx={{ minWidth: "auto", maxWidth: "auto" }}>
                    <CardContent>
                        <Box className='d-flex justify-content-between mb-3'>
                            <div><Typography variant="h6" className="fontsize-card card-text">My invitation link</Typography></div>
                        </Box>
                        <Grid container sx={{ mt: 2 }} spacing={2}>
                            <Grid item xs={12} sm={6} md={3} lg={3}>
                                <Box>
                                    <Typography className="text-prop-card">Poster</Typography>
                                    <div className="d-grid"><Button variant="contained" className=" choose-poster-btn mt-2">Choose the poster</Button></div>
                                </Box>
                            </Grid>
                            <Grid item xs={12} sm={6} md={5} lg={5}>
                                <Box>
                                    <Typography className="text-prop-card">Link</Typography>
                                    <div className="input-group mt-2">
                                        <input type="text" className="form-control copyInput " value="https://m.mexc.com/auth/signup?inviteCode=1Kasw" aria-describedby="copyButton" />
                                        <button className="input-group-text" id="copyButton">Copy</button>
                                    </div>
                                </Box>
                            </Grid>
                            <Grid item xs={12} sm={6} md={4} lg={4}>
                                <Box>
                                    <Typography className="text-prop-card">Referral Code</Typography>
                                    <div className="input-group mt-2">
                                        <input type="text" className="form-control copyInput " value="Kasw" aria-describedby="copyButton" />
                                        <button className="input-group-text" id="copyButton">Copy</button>
                                    </div>
                                </Box>
                            </Grid>
                        </Grid>
                    </CardContent>
                </Card>
                {/* Referral History common  Card*/}
                <Card className="profile-page-card" sx={{ mt: 3 }}>
                    <Box className="px-3">
                        <Box className="py-3 d-block d-lg-flex justify-content-lg-between align-items-lg-center">
                            <div><Typography className="fontsize-card card-text px-2 px-sm-3 px-lg-0 mb-2 mb-lg-0 " variant="h6">Referral History</Typography></div>
                            <div className="d-sm-flex align-items-sm-center px-2 mt-md-3 mt-lg-0 px-md-3 px-lg-0 px-lg-0">
                                <ul className="nav nav-pills mb-3 border-tab p-1" id="referralTab" role="tablist">
                                    <li className="nav-item" role="presentation">
                                        <button className="textColors nav-link active" data-bs-toggle="pill" data-bs-target="#monthTab" type="button" role="tab" >Today</button>
                                    </li>
                                    <li className="nav-item" role="presentation">
                                        <button className="textColors nav-link" data-bs-toggle="pill" data-bs-target="#monthTab" type="button" role="tab">This week</button>
                                    </li>
                                    <li className="nav-item" role="presentation">
                                        <button className="textColors  nav-link" data-bs-toggle="pill" data-bs-target="#monthTab" type="button" role="tab">Month</button>
                                    </li>
                                    <li className="nav-item" role="presentation">
                                        <button className="textColors nav-link" data-bs-toggle="pill" data-bs-target="#monthTab" type="button" role="tab">All</button>
                                    </li>
                                </ul>
                                <div className="d-block d-md-flex">
                                    <div className='ms-md-3 mb-2'>
                                        <input type="text" className='form-control datePicker' name="daterange" value="01/01/2018 - 01/15/2018" />
                                    </div>
                                    <div className=' d-grid ms-md-3 mb-1rem'>
                                        <Button variant="outlined" className="paddingBtn btnStyles">Export</Button>
                                    </div>
                                </div>
                            </div>
                        </Box>
                        <div className="tab-content" id="pills-tabContent">
                            <div className="tab-pane fade" id="todayTab" role="tabpanel" ></div>
                            <div className="tab-pane fade" id="thisWeekTab" role="tabpanel"></div>
                            <div className="tab-pane fade show active" id="monthTab" role="tabpanel">
                                {/* Referral History Graph Card*/}
                                <Grid container sx={{ mt: 2 }} spacing={2}>
                                    <Grid item xs={12} sm={12} md={2} lg={2}>
                                        <Card className="card-bg-green pb-1-7rem" sx={{ minWidth: "auto", maxWidth: "auto" }}>
                                            <CardContent className="text-center text-lg-start">
                                                <Typography className="graph-text pb-2">Person(s) Referred</Typography>
                                                <Typography variant="h4">0</Typography>
                                            </CardContent>
                                        </Card>
                                    </Grid>
                                    <Grid item xs={12} sm={12} md={10} lg={10}>
                                        <Card className="card-bg-green" sx={{ minWidth: "auto", maxWidth: "auto" }}>
                                            <CardContent>
                                                <Grid container>
                                                    <Grid item xs={12} sm={12} md={2} lg={2} className="d-flex justify-content-center align-items-center">
                                                        <Box component="img" alt="graph" src={dougnut} className="img-fluid" />
                                                    </Grid>
                                                    <Grid item xs={6} sm={12} md={10} lg={10} className="mt-3 mt-lg-0 d-block d-lg-flex justify-content-lg-between">
                                                        <Box className="text-center text-lg-start">
                                                            <Typography className="graph-text mb-2">Person(s) Referred</Typography>
                                                            <Typography variant="h4">0</Typography>
                                                        </Box>
                                                        <Box className="text-center text-lg-start">
                                                            <Typography className="graph-text mb-2">Spot(USDT)</Typography>
                                                            <Typography variant="h4">0</Typography>
                                                        </Box>
                                                        <Box className="text-center text-lg-start">
                                                            <Typography className="graph-text mb-2">Margin(USDT)</Typography>
                                                            <Typography variant="h4">0</Typography>
                                                        </Box>
                                                        <Box className="text-center text-lg-start">
                                                            <Typography className="graph-text mb-2">Futures(USDT)</Typography>
                                                            <Typography variant="h4">0</Typography>
                                                        </Box>
                                                    </Grid>
                                                </Grid>
                                            </CardContent>
                                        </Card>
                                    </Grid>
                                </Grid>
                            </div>
                            <div className="tab-pane fade" id="allTab" role="tabpanel">...</div>
                        </div>
                        {/* Referral History Table */}
                        <ul class="nav nav-pills my-4 padding-left-0" id="HistoryTabs" role="tablist">
                            <li class="nav-item" role="presentation">
                                <button class="nav-link active button-green" data-bs-toggle="pill" data-bs-target="#referralHistory" type="button" role="tab">My Referral History</button>
                            </li>
                            <li class="nav-item" role="presentation">
                                <button class="nav-link button-green marginRewardBtn ms-sm-4" data-bs-toggle="pill" data-bs-target="#rewardHistory" type="button" role="tab" aria-controls="pills-profile" aria-selected="false">My Reward History</button>
                            </li>
                        </ul>
                        <TableContainer component={Paper} sx={{ background: "var( --card-bg-color)" }} className="px-3">
                            {/* Referral History */}
                            <div class="tab-content" id="pills-tabContent">
                                <div class="tab-pane fade show active" id="referralHistory" role="tabpanel">
                                    <Table sx={{ minWidth: 650 }} aria-label="simple table" className='table-color px-3'>
                                        <TableHead>
                                            <TableRow sx={{ border: "1px solid grey", borderTop: 0, borderRight: 0, borderLeft: 0 }}>
                                                <TableCell sx={{ fontWeight: "bolder !important", color: "grey !important" }} align="start">
                                                    Referee
                                                </TableCell>
                                                <TableCell sx={{ fontWeight: "bolder !important", color: "grey !important" }} align="left">
                                                    <div className="d-flex me-2">Referee ID</div>
                                                </TableCell>
                                                <TableCell sx={{ fontWeight: "bolder !important", color: "grey !important" }} align="left">
                                                    <div className="d-flex me-2">Time</div>
                                                </TableCell>
                                                <TableCell sx={{ fontWeight: "bolder !important", color: "grey !important" }} align="left">
                                                    <div className="d-flex me-2">Total(USDT)</div>
                                                </TableCell>
                                                <TableCell sx={{ fontWeight: "bolder !important", color: "grey !important" }} align="left">
                                                    <div className="d-flex me-2">Spot(USDT)</div>
                                                </TableCell>
                                                <TableCell sx={{ fontWeight: "bolder !important", color: "grey !important" }} align="left">
                                                    <div className="d-flex me-2">Margin(USDT)</div>
                                                </TableCell>
                                                <TableCell sx={{ fontWeight: "bolder !important", color: "grey !important" }} align="left">
                                                    Futures(USDT)
                                                </TableCell>
                                            </TableRow>
                                        </TableHead>
                                        <TableBody>
                                            <TableRow sx={{ "&:last-child td, &:last-child th": { border: 0 } }}>
                                                <TableCell className='py-5' align="center" colSpan={7} sx={{ justifyContent: "center", alignItems: "center" }} S>
                                                    <img src={NODATA} />
                                                </TableCell>
                                            </TableRow>
                                        </TableBody>
                                    </Table>
                                </div>
                                {/* Reward History */}
                                <div class="tab-pane fade" id="rewardHistory" role="tabpanel" >
                                    <Table sx={{ minWidth: 650 }} aria-label="simple table" className='table-color px-3'>
                                        <TableHead>
                                            <TableRow sx={{ border: "1px solid grey", borderTop: 0, borderRight: 0, borderLeft: 0 }}>
                                                <TableCell sx={{ fontWeight: "bolder !important", color: "grey !important" }} align="start">
                                                    Referee
                                                </TableCell>
                                                <TableCell sx={{ fontWeight: "bolder !important", color: "grey !important" }} align="left">
                                                    <div className="d-flex me-2">Referee ID</div>
                                                </TableCell>
                                                <TableCell sx={{ fontWeight: "bolder !important", color: "grey !important" }} align="left">
                                                    <div className="d-flex me-2">Time</div>
                                                </TableCell>
                                                <TableCell sx={{ fontWeight: "bolder !important", color: "grey !important" }} align="left">
                                                    <div className="d-flex me-2">Total(USDT)</div>
                                                </TableCell>
                                                <TableCell sx={{ fontWeight: "bolder !important", color: "grey !important" }} align="left">
                                                    <div className="d-flex me-2">Spot(USDT)</div>
                                                </TableCell>
                                                <TableCell sx={{ fontWeight: "bolder !important", color: "grey !important" }} align="left">
                                                    <div className="d-flex me-2">Margin(USDT)</div>
                                                </TableCell>
                                                <TableCell sx={{ fontWeight: "bolder !important", color: "grey !important" }} align="left">
                                                    Futures(USDT)
                                                </TableCell>
                                            </TableRow>
                                        </TableHead>
                                        <TableBody>
                                            <TableRow sx={{ "&:last-child td, &:last-child th": { border: 0 } }}>
                                                <TableCell className='py-5' align="center" colSpan={7} sx={{ justifyContent: "center", alignItems: "center" }} S>
                                                    <img src={NODATA} />
                                                </TableCell>
                                            </TableRow>
                                        </TableBody>
                                    </Table>
                                </div>
                            </div>

                        </TableContainer>
                    </Box>
                </Card>
                {/* Referral Event Reward Rules */}
                <Card className="profile-page-card mt-3" sx={{ minWidth: "auto", maxWidth: "auto" }}>
                    <CardContent className="px-4">
                        <Box className='d-flex justify-content-between my-3'>
                            <div><Typography variant="h6" className="fontsize-card card-text">Referral Event Reward Rules</Typography></div>
                        </Box>
                        <Box className="pb-3">
                            <Typography className="textClr">1.Users can complete registration by sharing promotion codes or promotion links. For each spot trade, ETF transaction and futures trade generated by their friends, the sharer can receive a corresponding proportion of service fee reward. For friends who are invited to open an account by the sharer after December 18, 2020, the friends can also get a 10% commission reward separately.</Typography>
                            <Typography className="textClr my-3">2.Commission Structure for Spot & ETF trades: The commission received by the referrer is dependent on their daily/average MX Token holdings. The formula is as follows:</Typography>
                            <Box>
                                <Typography className="textClr">(1) Users with less than 10,000 MX Tokens will receive 30% of the trading fees generated by their referees as commission.</Typography>
                                <Typography className="textClr">(2) Users with between 10,000 to 100,000 MX Tokens will receive 40% of the trading fees generated by their referees as commission.</Typography>
                                <Typography className="textClr">(3) Users with more than 100,000 MX Tokens will receive 50% of the trading fees generated by their referees as commission.</Typography>
                                <Typography className="textClr">(4) MEXC Community Node Partners can contact official platform staff directly to learn more about the increased rewards they are entitled to.</Typography>
                            </Box>
                            <Typography className="textClr my-3">Community Node Partners can contact official platform staff directly to learn more about the increased rewards they are entitled to. Commission Structure for Futures Trades: The commission received by the referrer is dependent on their daily/average MX Token holdings.The formula is as follows:</Typography>
                            <Box>
                                <Typography className="textClr">(1) Users with less than 10,000 MX Tokens will receive 30% of the trading fees generated by their referees as commission.</Typography>
                                <Typography className="textClr">(2) Users with between 10,000 to 100,000 MX Tokens will receive 40% of the trading fees generated by their referees as commission.</Typography>
                                <Typography className="textClr">(3) Users with more than 100,000 MX Tokens will receive 50% of the trading fees generated by their referees as commission.</Typography>
                                <Typography className="textClr">(4) MEXC Community Node Partners can contact official platform staff directly to learn more about the increased rewards they are entitled to.</Typography>
                            </Box>
                            <Typography className="textClr mt-3">
                                3. Form of reward: the reward actually obtained by the sharer will be returned in the actual cryptocurrency used by the friend to settle the transaction handling fee. For example, when your friend uses ETH to settle transaction fees, the rewards actually obtained by the sharer will be returned with ETH. When a friend's transaction fee is deducted and settled by MX, the rewards actually obtained by the sharer and the friend will be returned by MX.
                            </Typography>
                            <Typography className="textClr mt-3">
                                4. Reward distribution time: a friend's spot trade reward will be issued after 00:00 (UTC + 8). A friend's futures trade reward will be issued after 15:00 (UTC + 8). The actual issuing time may be delayed, and the actual issuing time of the next day shall prevail.
                            </Typography>
                            <Typography className="textClr mt-3">
                                5. Service fee reward amount = service fee actually collected by the system after transaction* reward proportion.
                            </Typography>
                            <Typography className="textClr mt-3">
                                6. Reward validity period: for users whose friend registration time is before April 5, 2021, the validity period of invitation will be 1080 days from that date. For users registered after April 5, 2021, the invitation is valid from the registration date and the rebate is valid for 1080 days.
                            </Typography>
                            <Typography className="textClr mt-3">7. Reward for not participating in promotion activities such as handling charges for deposit/withdraw of cryptocurrency and leverage interest, handling charges arising from abnormal trading behavior, and spot trades in the assessment zone or transfer to other zone from the assessment zone are not included in the reward for promotion activities.</Typography>
                            <Typography className="textClr mt-3">8. There is no limit on the number of friends a user can refer.</Typography>
                            <Typography className="textClr mt-3"> 9. MEXC forbids users from creating multiple accounts for self-invitation purposes. If users are caught doing so, all referrals will be deemed invalid and any rewards will be forfeited.</Typography>
                            <Typography className="textClr mt-3">10. MEXC reserves the right to modify the rules of this event anytime at their sole discretion.</Typography>
                        </Box>
                    </CardContent>
                </Card>
            </Container>
        </div >
    )
}
export default InviteFriends;