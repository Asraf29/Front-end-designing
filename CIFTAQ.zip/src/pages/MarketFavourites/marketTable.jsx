import * as React from "react";
import Table from "@mui/material/Table";
import TableBody from "@mui/material/TableBody";
import TableCell from "@mui/material/TableCell";
import TableContainer from "@mui/material/TableContainer";
import TableHead from "@mui/material/TableHead";
import TableRow from "@mui/material/TableRow";
import Paper from "@mui/material/Paper";
import NODATA from "../../components/assets/images/nodata.png";
import bitcoin from "../../components/assets/images/BTC.png";
import { TabContext, TabList, TabPanel } from "@mui/lab";
import { Tab, Typography } from "@mui/material";
import { Link } from "react-router-dom";
import "./index.css";
import { Box } from "@mui/system";
const MarketTable = (props) => {
  const { data, name, buttons, textOptions, ETF, trendingTab } = props;
  const [newData, setNewData] = React.useState(data);
  const [trend, setTrending] = React.useState("01");
  const trending = (event, trendingTab) => {
    setTrending(trendingTab);
  };
  return (
    <div>
      <TableContainer
        component={Paper}
        sx={{ background: "var(--card-bg-color)" }}
      >
        <Table sx={{ minWidth: 650 }} aria-label="simple table">
          <TableHead>
            {ETF ? (
              <button className="btn btn-sm my-3 mb-0 ms-3 btn-primary">
                ETF
              </button>
            ) : (
              ""
            )}
            {name ? (
              ""
            ) : (
              <>
                <button className="btn btn-sm my-3 ms-2 btn-primary">
                  USDT-🅜
                </button>
                <button className="btn btn-secondary btn-sm ms-2">
                  Coin-🅜
                </button>
              </>
            )}
            {buttons ? (
              <>
                <button className="btn btn-sm my-3 ms-3  btn-primary">
                  Main
                </button>
                <button className="btn btn-secondary btn-sm ms-2">
                  Innovation
                </button>
                <button className="btn btn-secondary btn-sm ms-2">
                  Assessment
                </button>
                <div className="dropdown">
                  <a
                    className="btn text-white  btn-sm ms-2 dropdown-toggle btn-secondary"
                    href="#"
                    role="button"
                    id="dropdownMenuLink"
                    data-bs-toggle="dropdown"
                    aria-expanded="false"
                  >
                    Zones
                  </a>

                  <ul
                    className="dropdown-menu bg-secondary"
                    aria-labelledby="dropdownMenuLink"
                  >
                    <li>
                      <a className="dropdown-item text-white" href="#">
                        SQI
                      </a>
                    </li>
                    <li>
                      <a className="dropdown-item text-white" href="#">
                        Coinbase
                      </a>
                    </li>
                    <li>
                      <a className="dropdown-item text-white" href="#">
                        Metaverse
                      </a>
                    </li>
                    <li>
                      <a className="dropdown-item text-white" href="#">
                        Storage
                      </a>
                    </li>
                  </ul>
                </div>
              </>
            ) : (
              ""
            )}
            {textOptions ? (
              <div className="d-flex fw-bold my-2 ms-2 mb-0">
                <span className="border-style-txt ms-2 me-1" style={{color:'var(--txt-placeholder)'}}>
                  <p>ALL</p>
                </span>
                <span className="border-style-txt ms-2  me-1">
                  <p className="text-primary">USDT</p>
                </span>
                <span className="border-style-txt ms-2 me-1" style={{color:'var(--txt-placeholder)'}}>
                  <p>ETH</p>
                </span>
                <span className=" ms-2 me-1" style={{color:'var(--txt-placeholder)'}}>
                  <p>BTC</p>
                </span>
              </div>
            ) : (
              ""
            )}
            <div>
              {trendingTab ? (
                <>
                  <TabContext value={trending}>
                    <Box sx={{ marginTop: "10px" }}>
                      <TabList
                        variant="scrollable"
                        onChange={trending}
                        aria-label="lab API tabs example"
                      >
                        <Tab
                          sx={{
                            fontSize: "15px",
                            color: "",
                            fontWeight: 500,
                            textTransform: "none",
                          }}
                          label="Limit order [0]"
                          value="01"
                        />
                        <Tab
                          label="Stop-Limit order"
                          sx={{
                            fontSize: "15px",
                            color: " black",
                            fontWeight: 500,
                            textTransform: "none",
                          }}
                          value="02"
                        />
                        <Tab
                          label="Order History"
                          sx={{
                            fontSize: "15px",
                            color: " black",
                            fontWeight: 500,
                            textTransform: "none",
                          }}
                          value="03"
                        />
                      </TabList>
                    </Box>
                  </TabContext>
                </>
              ) : (
                ""
              )}
            </div>
            <TableRow>
              <TableCell
                sx={{
                  fontWeight: "bolder !important",
                  color: "var(--txt-sub) !important",
                }}
              >
                Trading Pair{" "}
              </TableCell>
              <TableCell
                sx={{
                  fontWeight: "bolder !important",
                  color: "var(--txt-sub) !important",
                }}
                align="left"
              >
                <div className="d-flex me-2">
                  Last Price{" "}
                  {
                    <div className="my-1">
                      <i
                        className="bi bi-caret-up d-block ms-2"
                        style={{ fontSize: "9px" }}
                      ></i>{" "}
                      <i
                        className="bi bi-caret-down ms-2"
                        style={{ fontSize: "9px" }}
                      ></i>{" "}
                    </div>
                  }{" "}
                </div>
              </TableCell>
              <TableCell
                sx={{
                  fontWeight: "bolder !important",
                  color: "var(--txt-sub) !important",
                }}
                align="left"
              >
                <div className="d-flex me-2">
                  Change [%]{" "}
                  {
                    <div className="my-1">
                      <i
                        className="bi bi-caret-up d-block ms-2"
                        style={{ fontSize: "9px" }}
                      ></i>{" "}
                      <i
                        className="bi bi-caret-down ms-2"
                        style={{ fontSize: "9px" }}
                      ></i>{" "}
                    </div>
                  }{" "}
                </div>
              </TableCell>
              <TableCell
                sx={{
                  fontWeight: "bolder !important",
                  color: "var(--txt-sub) !important",
                }}
                align="left"
              >
                <div className="d-flex me-2">
                  24h High
                  {
                    <div className="my-1">
                      <i
                        className="bi bi-caret-up d-block ms-2"
                        style={{ fontSize: "9px" }}
                      ></i>{" "}
                      <i
                        className="bi bi-caret-down ms-2"
                        style={{ fontSize: "9px" }}
                      ></i>{" "}
                    </div>
                  }{" "}
                </div>
              </TableCell>
              <TableCell
                sx={{
                  fontWeight: "bolder !important",
                  color: "var(--txt-sub) !important",
                }}
                align="left"
              >
                <div className="d-flex me-2">
                  24h Low
                  {
                    <div className="my-1">
                      <i
                        className="bi bi-caret-up d-block ms-2"
                        style={{ fontSize: "9px" }}
                      ></i>{" "}
                      <i
                        className="bi bi-caret-down ms-2"
                        style={{ fontSize: "9px" }}
                      ></i>{" "}
                    </div>
                  }{" "}
                </div>
              </TableCell>
              <TableCell
                sx={{
                  fontWeight: "bolder !important",
                  color: "var(--txt-sub) !important",
                }}
                align="left"
              >
                <div className="d-flex me-2">
                  24h Volume
                  {
                    <div className="my-1">
                      <i
                        className="bi bi-caret-up d-block ms-2"
                        style={{ fontSize: "9px" }}
                      ></i>{" "}
                      <i
                        className="bi bi-caret-down ms-2"
                        style={{ fontSize: "9px" }}
                      ></i>{" "}
                    </div>
                  }{" "}
                </div>
              </TableCell>
              <TableCell
                sx={{
                  fontWeight: "bolder !important",
                  color: "var(--txt-sub) !important",
                }}
                align="left"
              >
                Action{" "}
              </TableCell>
            </TableRow>
          </TableHead>

          <TableBody>
            {newData.length > 0 ? (
              newData.map((tableData, index) => (
                <TableRow
                  sx={{ "&:last-child td, &:last-child th": { border: 0 } }}
                  key={index}
                >
                  <TableCell component="th" scope="row">
                    <i
                      className="bi bi-star-fill me-2"
                      style={{ color: "grey" }}
                    />
                    <img
                      className="me-1"
                      src={bitcoin}
                      style={{ width: "25px", height: "25px" }}
                    />
                    <span style={{ color: "var(--card-txt)" }}>
                      {" "}
                      <b>{tableData.cointype}</b>{" "}
                    </span>{" "}
                    <span
                      className="p-1"
                      style={{
                        backgroundColor: "#feefd0",
                        color: "#FAAD34",
                        position: "relative",
                        bottom: "2px",
                        borderRadius: "5px",
                        fontSize: "10px",
                        padding: "5px",
                      }}
                    >
                      {" "}
                      <b>{tableData.speed}</b>{" "}
                    </span>
                    <p className="mx-5 ps-3 text-muted">{tableData.coinname}</p>
                  </TableCell>
                  <TableCell component="th" scope="row">
                    <b style={{ color: "var(--card-txt)" }}>
                      {tableData.lastprice}
                    </b>
                    <p className="text-muted py-1">{tableData.subPrice}</p>
                  </TableCell>
                  <TableCell component="th" scope="row">
                    <span className="text-success">
                      {" "}
                      <b>{tableData.change}</b>{" "}
                    </span>
                  </TableCell>
                  <TableCell
                    sx={{ color: "var(--card-txt)" }}
                    component="th"
                    scope="row"
                  >
                    <b>{tableData.High}</b>
                  </TableCell>
                  <TableCell
                    sx={{ color: "var(--card-txt)" }}
                    component="th"
                    scope="row"
                  >
                    <b>{tableData.Low}</b>
                  </TableCell>
                  <TableCell
                    sx={{ color: "var(--card-txt)" }}
                    component="th"
                    scope="row"
                  >
                    <b>{tableData.Volume}</b>
                  </TableCell>
                  <TableCell component="th" scope="row">
                    <button
                      data-bs-toggle="offcanvas"
                      data-bs-target="#offcanvasRight"
                      aria-controls="offcanvasRight"
                      className="fw-bold btn-sm btn border"
                      style={{ textDecoration: "none", color:'var(--card-txt)' }}
                    >
                      Info
                    </button>
                    <Link to="/exchange">
                      <button
                        className="fw-bold ms-lg-2 my-2 my-lg-0 my-sm-0 my-md-2 btn-sm btn border text-primary"
                        style={{ textDecoration: "none" }}
                      >
                        Trade
                      </button>
                    </Link>
                  </TableCell>
                </TableRow>
              ))
            ) : (
              <TableRow>
                <TableCell
                  align="center"
                  colSpan={7}
                  sx={{ justifyContent: "center", alignItems: "center" }}
                >
                  <img src={NODATA} />
                </TableCell>
              </TableRow>
            )}
          </TableBody>
        </Table>
      </TableContainer>
      {/* offcanvas */}
      <div
        className="offcanvas offcanvas-end ofcanvas-info"
        style={{background: "var(--card-bg-color)"}}
        tabindex="-1"
        id="offcanvasRight"
        aria-labelledby="offcanvasRightLabel"
      >
        <div className="offcanvas-header">
          <h5
            className="offcanvas-title text-dark fw-bold"
            id="offcanvasRightLabel"
            style={{ fontSize: "14px" }}
          >
            Overview
          </h5>
          <button
            type="button"
            className="btn-close"
            data-bs-dismiss="offcanvas"
            aria-label="Close"
          ></button>
        </div>
        <div className="offcanvas-body" style={{color:'var(--card-txt)'}}>
          <div className="d-flex justify-content-between">
            <b>MX/USDT</b>
            <button
              className="btn btn-sm"
              style={{
                background: "#1A94AE",
                fontWeight: "bold",
                color: "white",
              }}
            >
              Trade
            </button>
          </div>
          <div className="d-flex justify-content-between my-4">
            <Typography>Crypto name</Typography>
            <b>MX</b>
          </div>
          <div className="d-flex justify-content-between my-4">
            <Typography>English name</Typography>
            <b>MX</b>
          </div>
          <div className="d-flex justify-content-between my-4">
            <Typography sx={{ whiteSpace: "nowrap" }}>Issue Time</Typography>
            <span style={{ whiteSpace: "nowrap" }}>
              <b>2021-06-30 00:00:00</b>{" "}
            </span>
          </div>
          <div className="d-flex justify-content-between my-4">
            <Typography>Issue Price</Typography>
            <b>0.0092 USDT</b>
          </div>

          <div className="d-flex justify-content-between my-4">
            <Typography>Token Amount</Typography>
            <b>450,000,000</b>
          </div>
          <div className="d-flex justify-content-between my-4">
            <Typography>Withdrawal Status</Typography>
            <b>Available</b>
          </div>
          <div className="d-flex justify-content-between my-4">
            <Typography>Deposit Status</Typography>
            <b>Can be deposited</b>
          </div>
          <div className="d-flex justify-content-between my-4" style={{color:'var(--card-txt)'}}>
            <Typography>Related links</Typography>
            <span className="text-primary">
              <b>Official Website</b>
            </span>
          </div>
          <b style={{color:'var(--card-txt)'}}>Introduction</b>
          <Typography
            sx={{ textAlign: "justify", fontSize: 14, marginTop: "5px",color:'var(--card-txt)' }}
          >
            MX TOKEN (MX) is a decentralized digital asset developed by the MEXC
            platform based on the Ethereum blockchain. As MEXC’s native token,
            the MX ecosystem is gradually improved each day in order to empower
            users and builders. The main focus of MX Token is to provide users
            with a safe and stable trading experience, and to become an industry
            leader. MX is also the proof of MEXC community's rights. Holders
            have the right to vote on business decisions, team elections and
            gain priority participation in activities, etc. MEXC also fully
            adopts the community's voting proposals and restructures the rights
            and interests allocation mechanism based on the results of voting.
            Starting from January 2022, 40% of the entire profit of the platform
            will be allocated to the repurchase and burning of MX from the
            secondary market on a quarterly basis. The initial total supply of
            MX is 1 billion tokens. 550 million tokens have currently been
            destroyed, and the goal of 100 million tokens in circulation remains
            unchanged. MX holders are entitled to a number of benefits at MEXC
          </Typography>
        </div>
      </div>
    </div>
  );
};
export default MarketTable;
