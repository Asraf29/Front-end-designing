import * as React from "react";
import Box from "@mui/material/Box";
import Card from "@mui/material/Card";
import SearchIcon from "@mui/icons-material/Search";
import { green } from "@mui/material/colors";
import CardContent from "@mui/material/CardContent";
import NODATA from "../../components/assets/images/nodata.png";
import MarketTableJson from "../../hooks/marketTable";
import LogoutIcon from "@mui/icons-material/Logout";
import ArrowForwardIosIcon from "@mui/icons-material/ArrowForwardIos";
import Table from "@mui/material/Table";
import TableBody from "@mui/material/TableBody";
import TableCell from "@mui/material/TableCell";
import StarIcon from "@mui/icons-material/Star";
import PlayCircleIcon from "@mui/icons-material/PlayCircle";
import SignalCellularAltIcon from "@mui/icons-material/SignalCellularAlt";
import TableContainer from "@mui/material/TableContainer";
import TableHead from "@mui/material/TableHead";
import TableRow from "@mui/material/TableRow";
import Paper from "@mui/material/Paper";
import Button from "@mui/material/Button";
import Typography from "@mui/material/Typography";
import CachedIcon from "@mui/icons-material/Cached";
import { FormControl, Grid, MenuItem, Select } from "@mui/material";
import Tabs from "@mui/material/Tabs";
import Tab from "@mui/material/Tab";
import VerticalSplitIcon from "@mui/icons-material/VerticalSplit";
import SegmentIcon from "@mui/icons-material/Segment";
import graph from "../../components/assets/images/graph.png";
import { TabContext, TabList, TabPanel } from "@mui/lab";
import "./index.css";
import FullscreenIcon from "@mui/icons-material/Fullscreen";
import filter from "../../components/assets/images/filter.png";
import fullscreen from "../../components/assets/images/fullscreen.png";
import speed from "../../components/assets/images/speedmeter.png";
import MarketTable from "./marketTable";
function createData(name, calories, fat, carbs, protein) {
  return { name, calories, fat, carbs, protein };
}

export default function Exchange() {
  const [value, setValue] = React.useState("1");
  const primary = green[500];

  const handleChange = (event, newValue) => {
    setValue(newValue);
  };
  const [icon, setIcon] = React.useState(0);
  ////FAV TABS///
  const [tabs, setTabs] = React.useState("1");
  const [sportTabs, setSportTabs] = React.useState("01");

  const tabChange = (event, newTab) => {
    setTabs(newTab);
  };
  const sportTab = (event, sportTab) => {
    setSportTabs(sportTab);
  };
  const [trend, setTrending] = React.useState("01");
  const trending = (event, trendingTab) => {
    setTrending(trendingTab);
  };

  const [data, setData] = React.useState(MarketTableJson);
  const [redSportTabs, setRedSportTabs] = React.useState("01");
  const redTab = (event, redTab) => {
    setRedSportTabs(redTab);
  };
  const [graphTab, setGraphTab] = React.useState("1");

  const graphChange = (event, newGraph) => {
    setGraphTab(newGraph);
  };
  const onChange = (event, newIcon) => {
    setIcon(newIcon);
  };
  const [digit, setDigit] = React.useState("10");

  const Change = (event) => {
    setDigit(event.target.value);
  };
  ///TABLE DATA////
  const rows = [
    createData("0.067312", "2.5 M", 17.19999),
    createData("0.0025", "2.5 M", 17.19999),
    createData("0.0025", "2.5 M", 17.1952),
    createData("0.0025", "2.5 M", 17.1952),
    createData("0.0025", "2.5 M", 17.1952),
    createData("0.0025", "2.5 M", 17.1952),
    createData("0.0025", "2.5 M", 17.1952),
  ];

  return (
    <div>
      <div className="container-fluid my-4">
        <Grid container spacing={2}>
          <Grid item xs={12} lg={3} md={3}>
            <Card
              sx={{
                minWidth: 100,
                background: "var(--market-order-card-bg-color)",
              }}
            >
              <CardContent>
                <Box sx={{ width: "100%", typography: "body1" }}>
                  <TabContext value={value}>
                    <Box>
                      <TabList
                        onChange={onChange}
                        aria-label="lab API tabs example"
                        TabIndicatorProps={{
                          style: { backgroundColor: '#1f8bb7' }
                        }}
                      >
                        <Tab
                          style={{
                            borderBottom: "2px solid #1A94AE",
                            fontSize: "16px",
                          }}
                          label="Order Book"
                          value="1"
                          className="MuiButtonBase-root MuiTab-root MuiTab-textColorPrimary Mui-selected css-1h9z7r5-MuiButtonBase-root-MuiTab-root"
                        />
                      </TabList>
                    </Box>
                    <div className="d-flex justify-content-between">
                      <div>
                        <ul
                          className="nav nav-pills pills mb-2 my-2"
                          id="pills-tab pills-icons"
                          role="tablist"
                        >
                          <li className="nav-item" role="presentation">
                            <button
                              className="nav-link active btn-sm btn"
                              id="pills-home-tab"
                              data-bs-toggle="pill"
                              data-bs-target="#pills-home"
                              role="tab"
                              aria-controls="pills-home"
                              aria-selected="true"
                            >
                              <SegmentIcon
                                sx={{ color: "var(--icon-color)" }}
                              />
                            </button>
                          </li>
                          <li className="nav-item" role="presentation">
                            <button
                              className="nav-link btn-sm btn"
                              id="pills-profile-tab"
                              data-bs-toggle="pill"
                              data-bs-target="#pills-profile"
                              role="tab"
                              aria-controls="pills-profile"
                              aria-selected="false"
                            >
                              <VerticalSplitIcon
                                sx={{ color: "var(--icon-color)" }}
                              />
                            </button>
                          </li>
                          <li className="nav-item" role="presentation">
                            <button
                              className="nav-link btn-sm btn"
                              id="pills-contact-tab"
                              data-bs-toggle="pill"
                              data-bs-target="#pills-contact"
                              role="tab"
                              aria-controls="pills-contact"
                              aria-selected="false"
                            >
                              <SegmentIcon
                                sx={{ color: "var(--icon-color)" }}
                              />
                            </button>
                          </li>
                        </ul>
                      </div>
                      <div>
                        <FormControl
                          sx={{
                            m: 1,
                            minWidth: 120,
                            backgroundColor: "var( --form-control-bg)",
                            width: "130px",
                            height: "25px",
                            borderRadius: 1,
                          }}
                        >
                          <Select
                            sx={{
                              width: "130px",
                              height: "25px",
                              color: "white",
                            }}
                            value={digit}
                            onChange={Change}
                            displayEmpty
                            inputProps={{ "aria-label": "Without label" }}
                          >
                            <MenuItem value={10}>0.000001</MenuItem>
                            <MenuItem value={20}>00.1</MenuItem>
                            <MenuItem value={30}>000.2</MenuItem>
                          </Select>
                        </FormControl>
                        <div />
                      </div>
                    </div>
                    <div className="tab-content" id="pills-tabContent">
                      <div
                        className="tab-pane fade show active"
                        id="pills-home"
                        role="tabpanel"
                        aria-labelledby="pills-home-tab"
                      >
                        <TableContainer
                          component={Paper}
                          sx={{
                            background: "var(--market-order-card-bg-color)", boxShadow: 'none !important',
                          }}
                        >
                          <Table
                            sx={{
                              minWidth: "auto",
                              maxWidth: "auto",
                              backgroundColor:
                                "var(--market-order-card-bg-color)",
                            }}
                            aria-label="simple table"
                          >
                            <TableHead sx={{ border: 0 }}>
                              <TableRow>
                                <TableCell
                                  align="left"
                                  sx={{
                                    color: "white",
                                    fontSize: "10px",
                                    marginRight: "5px",
                                    padding: "4px 16px ",
                                    borderBottom: "none",
                                  }}
                                >
                                  Price(USDT)
                                </TableCell>
                                <TableCell
                                  align="left"
                                  sx={{
                                    color: "white",
                                    fontSize: "10px",
                                    marginRight: 15,
                                    borderBottom: "none",
                                    padding: "4px 16px ",
                                  }}
                                >
                                  Quantity(SOS)
                                </TableCell>
                                <TableCell
                                  align="left"
                                  sx={{
                                    color: "white",
                                    fontSize: "10px",
                                    marginRight: 50,
                                    borderBottom: "none",
                                    padding: "4px 16px ",
                                  }}
                                >
                                  Amount(USDT){" "}
                                  <CachedIcon
                                    sx={{ fontSize: "15px", marginLeft: "4px" }}
                                  />
                                </TableCell>
                              </TableRow>
                            </TableHead>
                            <TableBody>
                              {rows.map((row) => (
                                <TableRow
                                  key={row.name}
                                  sx={{ "td, th": { border: 0 } }}
                                >
                                  <TableCell
                                    sx={{
                                      color: "var(--icon-color)",
                                      padding: "4px 16px ",
                                    }}
                                    component="th"
                                    scope="row"
                                  >
                                    {row.name}
                                  </TableCell>
                                  <TableCell
                                    align="left"
                                    sx={{
                                      color: "white",
                                      padding: "4px 16px ",
                                    }}
                                  >
                                    {row.calories}
                                  </TableCell>
                                  <TableCell
                                    align="left"
                                    sx={{ padding: "4px 16px " }}
                                  >
                                    <span
                                      className="text-white"
                                      style={{
                                        background:
                                          "var(--market-order-card-bg-color)",
                                        padding: 4,
                                        borderRadius: 5,
                                      }}
                                    >
                                      {" "}
                                      {row.fat}
                                    </span>
                                  </TableCell>
                                </TableRow>
                              ))}
                            </TableBody>
                          </Table>
                          <div
                            className="d-flex justify-content-between mb-2"
                            style={{
                              border: "2px solid rgba(26, 148, 174, 0.2)",
                              borderRight: 0,
                              borderLeft: 0,
                              padding: 10,
                              background: "var(--market-order-card-bg-color)",
                            }}
                          >
                            <div className="d-flex">
                              <Typography
                                sx={{
                                  color: "white",
                                  fontWeight: 500,
                                  marginLeft: 2,
                                }}
                              >
                                0.0000067113
                              </Typography>
                              <Typography
                                sx={{
                                  marginLeft: 2,
                                  color: "#848c9c",
                                  fontWeight: 700,
                                }}
                              >
                                ≈ $ 0.0000064
                              </Typography>
                            </div>
                            <Typography>
                              <SignalCellularAltIcon
                                sx={{
                                  fontSize: "25px",
                                  marginRight: 2,
                                  color: "var(--icon-color)",
                                }}
                              />
                            </Typography>
                          </div>
                          <TableBody
                            sx={{
                              background: "var(--market-order-card-bg-color)",
                            }}
                          >
                            {rows.map((row) => (
                              <TableRow
                                key={row.name}
                                sx={{ "td, th": { border: 0 }, marginTop: 5 }}
                              >
                                <TableCell
                                  sx={{
                                    color: "var(--icon-color)",
                                    padding: "4px 16px",
                                  }}
                                  component="th"
                                  scope="row"
                                >
                                  {row.name}
                                </TableCell>
                                <TableCell
                                  align="left"
                                  sx={{ color: "white", padding: "4px 16px " }}
                                >
                                  {row.calories}
                                </TableCell>
                                <TableCell
                                  align="right"
                                  sx={{ padding: "4px 16px " }}
                                >
                                  <span
                                    className="text-white ms-5"
                                    style={{
                                      background: "#0f3445",
                                      padding: 4,
                                      borderRadius: 5,
                                    }}
                                  >
                                    {" "}
                                    {row.fat}
                                  </span>
                                </TableCell>
                              </TableRow>
                            ))}
                          </TableBody>
                        </TableContainer>
                      </div>
                      <div
                        className="tab-pane fade"
                        id="pills-profile"
                        role="tabpanel"
                        aria-labelledby="pills-profile-tab"
                      >
                        <TableContainer
                          component={Paper} sx={{
                            background: "var(--market-order-card-bg-color)", boxShadow: 'none !important',
                          }}
                        >
                          <Table
                            sx={{
                              minWidth: "auto",
                              maxWidth: "auto",
                              background: "var(--market-order-card-bg-color)",
                              boxShadow: 'none !important',
                            }}
                            aria-label="simple table"
                          >
                            <TableHead sx={{ border: 0 }}>
                              <TableRow>
                                <TableCell
                                  align="left"
                                  sx={{
                                    color: "white",
                                    fontSize: "10px",
                                    marginRight: "5px",
                                    padding: "4px 16px ",
                                    borderBottom: "none",
                                  }}
                                >
                                  Price(USDT)
                                </TableCell>
                                <TableCell
                                  align="left"
                                  sx={{
                                    color: "white",
                                    fontSize: "10px",
                                    marginRight: 15,
                                    borderBottom: "none",
                                    padding: "4px 16px ",
                                  }}
                                >
                                  Quantity(SOS)
                                </TableCell>
                                <TableCell
                                  align="left"
                                  sx={{
                                    color: "white",
                                    fontSize: "10px",
                                    marginRight: 50,
                                    borderBottom: "none",
                                    padding: "4px 16px ",
                                  }}
                                >
                                  Amount(USDT){" "}
                                  <CachedIcon
                                    sx={{ fontSize: "15px", marginLeft: "4px" }}
                                  />
                                </TableCell>
                              </TableRow>
                            </TableHead>
                            <TableBody>
                              {rows.map((row) => (
                                <TableRow
                                  key={row.name}
                                  sx={{ "td, th": { border: 0 } }}
                                >
                                  <TableCell
                                    sx={{
                                      color: "var(--icon-color)",
                                      padding: "4px 16px ",
                                    }}
                                    component="th"
                                    scope="row"
                                  >
                                    {row.name}
                                  </TableCell>
                                  <TableCell
                                    align="left"
                                    sx={{
                                      color: "white",
                                      padding: "4px 16px ",
                                    }}
                                  >
                                    {row.calories}
                                  </TableCell>
                                  <TableCell
                                    align="left"
                                    sx={{ padding: "4px 16px " }}
                                  >
                                    <span
                                      className="text-white"
                                      style={{
                                        background: "#4b203e",
                                        padding: 4,
                                        borderRadius: 5,
                                      }}
                                    >
                                      {" "}
                                      {row.fat}
                                    </span>
                                  </TableCell>
                                </TableRow>
                              ))}
                            </TableBody>
                          </Table>
                          <div
                            className="d-flex justify-content-between mb-2"
                            style={{
                              border: "2px solid rgba(26, 148, 174, 0.2)",
                              borderRight: 0,
                              borderLeft: 0,
                              padding: 10,
                            }}
                          >
                            <div className="d-flex">
                              <Typography
                                sx={{
                                  color: "white",
                                  fontWeight: 500,
                                  marginLeft: 2,
                                }}
                              >
                                0.0000067113
                              </Typography>
                              <Typography
                                sx={{
                                  marginLeft: 2,
                                  color: "#848c9c",
                                  fontWeight: 700,
                                }}
                              >
                                ≈ $ 0.0000064
                              </Typography>
                            </div>
                            <Typography>
                              <SignalCellularAltIcon
                                sx={{
                                  fontSize: "25px",
                                  marginRight: 2,
                                  color: "var(--icon-color)",
                                }}
                              />
                            </Typography>
                          </div>
                          <TableBody>
                            {rows.map((row) => (
                              <TableRow
                                key={row.name}
                                sx={{ "td, th": { border: 0 }, marginTop: 5 }}
                              >
                                <TableCell
                                  sx={{
                                    color: "var(--icon-color)",
                                    padding: "4px 16px",
                                  }}
                                  component="th"
                                  scope="row"
                                >
                                  {row.name}
                                </TableCell>
                                <TableCell
                                  align="left"
                                  sx={{ color: "white", padding: "4px 16px " }}
                                >
                                  {row.calories}
                                </TableCell>
                                <TableCell
                                  align="right"
                                  sx={{ padding: "4px 16px " }}
                                >
                                  <span
                                    className="text-white ms-5"
                                    style={{
                                      background: "#0f3445",
                                      padding: 4,
                                      borderRadius: 5,
                                    }}
                                  >
                                    {" "}
                                    {row.fat}
                                  </span>
                                </TableCell>
                              </TableRow>
                            ))}
                          </TableBody>
                        </TableContainer>
                      </div>
                      <div
                        className="tab-pane fade"
                        id="pills-contact"
                        role="tabpanel"
                        aria-labelledby="pills-contact-tab"
                      >
                        <TableContainer
                          component={Paper}
                          sx={{
                            background: "var(--market-order-card-bg-color)", boxShadow: 'none !important',
                          }}
                        >
                          <Table
                            sx={{
                              minWidth: "auto",
                              maxWidth: "auto",
                                background: "var(--market-order-card-bg-color)", 
                                boxShadow:'none !important'
                            }}
                            aria-label="simple table"
                          >
                            <TableHead sx={{ border: 0 }}>
                              <TableRow>
                                <TableCell
                                  align="left"
                                  sx={{
                                    color: "white",
                                    fontSize: "10px",
                                    marginRight: "5px",
                                    padding: "4px 16px ",
                                    borderBottom: "none",
                                  }}
                                >
                                  Price(USDT)
                                </TableCell>
                                <TableCell
                                  align="left"
                                  sx={{
                                    color: "white",
                                    fontSize: "10px",
                                    marginRight: 15,
                                    borderBottom: "none",
                                    padding: "4px 16px ",
                                  }}
                                >
                                  Quantity(SOS)
                                </TableCell>
                                <TableCell
                                  align="left"
                                  sx={{
                                    color: "white",
                                    fontSize: "10px",
                                    marginRight: 50,
                                    borderBottom: "none",
                                    padding: "4px 16px ",
                                  }}
                                >
                                  Amount(USDT){" "}
                                  <CachedIcon
                                    sx={{ fontSize: "15px", marginLeft: "4px" }}
                                  />
                                </TableCell>
                              </TableRow>
                            </TableHead>
                            <TableBody>
                              {rows.map((row) => (
                                <TableRow
                                  key={row.name}
                                  sx={{ "td, th": { border: 0 } }}
                                >
                                  <TableCell
                                    sx={{
                                      color: "var(--icon-color)",
                                      padding: "4px 16px ",
                                    }}
                                    component="th"
                                    scope="row"
                                  >
                                    {row.name}
                                  </TableCell>
                                  <TableCell
                                    align="left"
                                    sx={{
                                      color: "white",
                                      padding: "4px 16px ",
                                    }}
                                  >
                                    {row.calories}
                                  </TableCell>
                                  <TableCell
                                    align="left"
                                    sx={{ padding: "4px 16px " }}
                                  >
                                    <span
                                      className="text-white"
                                      style={{
                                        background: "#4b203e",
                                        padding: 4,
                                        borderRadius: 5,
                                      }}
                                    >
                                      {" "}
                                      {row.fat}
                                    </span>
                                  </TableCell>
                                </TableRow>
                              ))}
                            </TableBody>
                          </Table>
                          <div
                            className="d-flex justify-content-between mb-2"
                            style={{
                              border: "2px solid rgba(26, 148, 174, 0.2)",
                              borderRight: 0,
                              borderLeft: 0,
                              padding: 10,
                            }}
                          >
                            <div className="d-flex">
                              <Typography
                                sx={{
                                  color: "white",
                                  fontWeight: 500,
                                  marginLeft: 2,
                                }}
                              >
                                0.0000067113
                              </Typography>
                              <Typography
                                sx={{
                                  marginLeft: 2,
                                  color: "#848c9c",
                                  fontWeight: 700,
                                }}
                              >
                                ≈ $ 0.0000064
                              </Typography>
                            </div>
                            <Typography>
                              <SignalCellularAltIcon
                                sx={{
                                  fontSize: "25px",
                                  marginRight: 2,
                                  color: "var(--icon-color)",
                                }}
                              />
                            </Typography>
                          </div>
                          <TableBody>
                            {rows.map((row) => (
                              <TableRow
                                key={row.name}
                                sx={{ "td, th": { border: 0 }, marginTop: 5 }}
                              >
                                <TableCell
                                  sx={{
                                    color: "var(--icon-color)",
                                    padding: "4px 16px",
                                  }}
                                  component="th"
                                  scope="row"
                                >
                                  {row.name}
                                </TableCell>
                                <TableCell
                                  align="left"
                                  sx={{ color: "white", padding: "4px 16px " }}
                                >
                                  {row.calories}
                                </TableCell>
                                <TableCell
                                  align="right"
                                  sx={{ padding: "4px 16px " }}
                                >
                                  <span
                                    className="text-white ms-5"
                                    style={{
                                      background: "#0f3445",
                                      padding: 4,
                                      borderRadius: 5,
                                    }}
                                  >
                                    {" "}
                                    {row.fat}
                                  </span>
                                </TableCell>
                              </TableRow>
                            ))}
                          </TableBody>
                        </TableContainer>
                      </div>
                    </div>
                  </TabContext>
                </Box>
                <Typography variant="h5" component="div"></Typography>
              </CardContent>
            </Card>
          </Grid>
          <Grid item xs={12} md={6} lg={6}>
            <Box sx={{ marginBottom: 2 }}>
              <Card
                sx={{
                  overflowX: "auto",
                  height: "60px",
                  background: "var(--market-center-bg-card)",
                }}
              >
                <CardContent>
                  <div className="d-flex justify-content-between">
                    <Grid item xs={12} md={2} lg={2}>
                      <Typography className="SOS-txt txt-main" sx={{ mb: 1.5, color: "white" }}>
                        SOS/USDT
                        <StarIcon
                          className="text-secondary"
                          sx={{ fontSize: "15px" }}
                        />
                      </Typography>
                    </Grid>
                    <Grid item xs={12} md={2} lg={2}>
                      <div className="d-flex">
                        <Typography className='txt-main mb-0 pb-0' sx={{ color: "white" }}>
                          0.00067113
                        </Typography>
                        <Typography
                          className="text-success ms-1 grn-txt green-txt"
                        >
                          +15.331%
                        </Typography>
                      </div>
                      <Typography
                        className="text-secondary mb-0 txt-sec txt-main"
                      >
                        $ 0.0000064{" "}
                      </Typography>
                    </Grid>

                    <Grid item xs={12} md={2} lg={2}>
                      <Typography
                        className="text-center txt-main"
                        sx={{ mb: 1.5, color: "white", fontSize: "14px" }}
                      >
                        24h High
                        <Typography
                          className="text-secondary txt-main"
                          sx={{ fontSize: "12px", marginLeft: 2 }}
                        >
                          0.0000068397{" "}
                        </Typography>
                      </Typography>
                    </Grid>

                    <Grid item xs={12} md={2} lg={2}>
                      <Typography
                        className="text-center txt-main"
                        sx={{ mb: 1.5, color: "white", fontSize: "14px" }}
                      >
                        24h Low
                        <Typography
                          className="text-secondary txt-main"
                          sx={{ fontSize: "12px", marginLeft: 2 }}
                        >
                          0.0000053346{" "}
                        </Typography>
                      </Typography>
                    </Grid>

                    <Grid item xs={12} md={2} lg={2}>
                      <Typography
                        className="me-1 VolHR txt-main"
                        sx={{ mb: 1.5, color: "white" }}
                      >
                        24h Volume[SOS]
                        <Typography
                          className="text-secondary txt-main"
                          sx={{ fontSize: "12px", marginLeft: 2 }}
                        >
                          2140.29B
                        </Typography>
                      </Typography>
                    </Grid>

                    <Grid item xs={12} md={2} lg={2}>
                      <Typography
                        sx={{ mb: 1.5, color: "white", fontSize: "14px" }}
                      >
                        <PlayCircleIcon
                          className="text-muted txt-video my-1 txt-main"
                        />
                        <span className="text-muted txt-video txt-main"> Video Tutorial </span>
                      </Typography>
                    </Grid>
                  </div>
                </CardContent>
              </Card>
            </Box>
            <Card
              sx={{ minWidth: 275, background: "var(--market-center-bg-card)" }}
            >
              <CardContent>
                <Box sx={{ width: "100%", typography: "body1" }}>
                  <TabContext value={value}>
                    <div className="d-flex justify-content-between">
                      <div>
                        <Box>
                          <TabList
                            onChange={handleChange}
                            aria-label="lab API tabs example"
                          >
                            <Tab
                              sx={{ color: "white", textTransform: "none" }}
                              label="K-Line"
                              value="1"
                            />
                            <Tab
                              sx={{ color: "white", textTransform: "none" }}
                              label="Token information"
                              value="2"
                            />
                          </TabList>
                        </Box>
                      </div>

                      <div style={{ marginLeft: "auto" }}>
                        <ul
                          className="nav nav-pills pills mb-2 my-2"
                          id="pills-tab pills-icons"
                          role="tablist"
                        >
                          <li className="nav-item" role="presentation">
                            <button
                              className="nav-link active btn-sm btn"
                              style={{ color: "white" }}
                              id="pills-basic-tab"
                              data-bs-toggle="pill"
                              data-bs-target="#pills-basic"
                              role="tab"
                              aria-controls="pills-basic"
                              aria-selected="true"
                            >
                              Basic
                            </button>
                          </li>
                          <li className="nav-item" role="presentation">
                            <button
                              className="nav-link btn-sm btn"
                              id="pills-proffessional-tab"
                              style={{ color: "white" }}
                              data-bs-toggle="pill"
                              data-bs-target="#pills-proffessional"
                              role="tab"
                              aria-controls="pills-professional"
                              aria-selected="false"
                            >
                              Professional
                            </button>
                          </li>
                          <li className="nav-item" role="presentation">
                            <button
                              className="nav-link btn-sm btn"
                              id="pills-depth-tab"
                              style={{ color: "white" }}
                              data-bs-toggle="pill"
                              data-bs-target="#pills-depth"
                              role="tab"
                              aria-controls="pills-depth"
                              aria-selected="false"
                            >
                              Depth
                            </button>
                          </li>
                        </ul>
                      </div>
                    </div>
                    <div className="d-flex justify-content-between">
                      <div>
                        <ul
                          className="nav nav-pills pills mb-2 my-2"
                          id="pills-tab pills-icons"
                          role="tablist"
                        >
                          <li className="nav-item" role="presentation">
                            <button
                              className="nav-link active btn-sm btn"
                              style={{ color: "white" }}
                              id="pills-basic-tab"
                              data-bs-toggle="pill"
                              data-bs-target="#pills-basic"
                              role="tab"
                              aria-controls="pills-basic"
                              aria-selected="true"
                            >
                              1 min
                            </button>
                          </li>
                          <li className="nav-item" role="presentation">
                            <button
                              className="nav-link btn-sm btn"
                              id="pills-proffessional-tab"
                              style={{ color: "white" }}
                              data-bs-toggle="pill"
                              data-bs-target="#pills-proffessional"
                              role="tab"
                              aria-controls="pills-professional"
                              aria-selected="false"
                            >
                              5 min
                            </button>
                          </li>
                          <li className="nav-item" role="presentation">
                            <button
                              className="nav-link btn-sm btn"
                              id="pills-depth-tab"
                              style={{ color: "white" }}
                              data-bs-toggle="pill"
                              data-bs-target="#pills-depth"
                              role="tab"
                              aria-controls="pills-depth"
                              aria-selected="false"
                            >
                              15 min
                            </button>
                          </li>
                          <li className="nav-item" role="presentation">
                            <button
                              className="nav-link btn-sm btn"
                              id="pills-depth-tab"
                              style={{ color: "white" }}
                              data-bs-toggle="pill"
                              data-bs-target="#pills-depth"
                              role="tab"
                              aria-controls="pills-depth"
                              aria-selected="false"
                            >
                              30 min
                            </button>
                          </li>
                          <li className="nav-item" role="presentation">
                            <button
                              className="nav-link btn-sm btn"
                              id="pills-depth-tab"
                              style={{ color: "white" }}
                              data-bs-toggle="pill"
                              data-bs-target="#pills-depth"
                              role="tab"
                              aria-controls="pills-depth"
                              aria-selected="false"
                            >
                              30 min
                            </button>
                          </li>
                          <li className="nav-item" role="presentation">
                            <button
                              className="nav-link btn-sm btn"
                              id="pills-depth-tab"
                              style={{ color: "white" }}
                              data-bs-toggle="pill"
                              data-bs-target="#pills-depth"
                              role="tab"
                              aria-controls="pills-depth"
                              aria-selected="false"
                            >
                              1hour
                            </button>
                          </li>
                          <li className="nav-item" role="presentation">
                            <button
                              className="nav-link btn-sm btn"
                              id="pills-depth-tab"
                              style={{ color: "white" }}
                              data-bs-toggle="pill"
                              data-bs-target="#pills-depth"
                              role="tab"
                              aria-controls="pills-depth"
                              aria-selected="false"
                            >
                              4hour
                            </button>
                          </li>
                          <li className="nav-item" role="presentation">
                            <button
                              className="nav-link btn-sm btn"
                              id="pills-depth-tab"
                              style={{ color: "white" }}
                              data-bs-toggle="pill"
                              data-bs-target="#pills-depth"
                              role="tab"
                              aria-controls="pills-depth"
                              aria-selected="false"
                            >
                              1day
                            </button>
                          </li>
                          <div className="dropdown">
                            <button
                              className="btn btn-sm btn-secondary dropdown-toggle p-0 ps-1 pe-1 my-lg-1"
                              id="dropdownMenuButton1"
                              data-bs-toggle="dropdown"
                              aria-expanded="false"
                            >
                              More
                            </button>
                            <ul
                              className="dropdown-menu bg-secondary"
                              aria-labelledby="dropdownMenuButton1"
                            >
                              <li>
                                <a className="dropdown-item" href="#">
                                  1 min{" "}
                                  <StarIcon
                                    sx={{ fontSize: "10px", color: "#ffbf00" }}
                                  />
                                </a>
                              </li>
                              <li>
                                <a className="dropdown-item" href="#">
                                  1 min{" "}
                                  <StarIcon
                                    sx={{ fontSize: "10px", color: "#ffbf00" }}
                                  />
                                </a>
                              </li>
                              <li>
                                <a className="dropdown-item" href="#">
                                  1 min{" "}
                                  <StarIcon
                                    sx={{ fontSize: "10px", color: "#ffbf00" }}
                                  />
                                </a>
                              </li>
                            </ul>
                          </div>
                        </ul>
                      </div>
                      <div>
                        <ul
                          className="nav nav-pills pills mb-2 my-2"
                          id="pills-tab pills-icons"
                          role="tablist"
                        >
                          <li className="nav-item" role="presentation">
                            <button
                              className="nav-link active btn-sm btn"
                              style={{ color: "white" }}
                              id="pills-basic-tab"
                              data-bs-toggle="pill"
                              data-bs-target="#pills-basic"
                              role="tab"
                              aria-controls="pills-basic"
                              aria-selected="true"
                            >
                              <img src={filter} />{" "}
                            </button>
                          </li>
                          <li className="nav-item" role="presentation">
                            <button
                              className="nav-link btn-sm btn"
                              id="pills-proffessional-tab"
                              style={{ color: "white" }}
                              data-bs-toggle="pill"
                              data-bs-target="#pills-proffessional"
                              role="tab"
                              aria-controls="pills-professional"
                              aria-selected="false"
                            >
                              fx
                            </button>
                          </li>
                          <li className="nav-item" role="presentation">
                            <button
                              className="nav-link btn-sm btn"
                              id="pills-depth-tab"
                              style={{ color: "white" }}
                              data-bs-toggle="pill"
                              data-bs-target="#pills-depth"
                              role="tab"
                              aria-controls="pills-depth"
                              aria-selected="false"
                            >
                              <img
                                src={speed}
                                style={{ width: "18px", height: "18px" }}
                              />
                            </button>
                          </li>
                          <li className="nav-item" role="presentation">
                            <button
                              className="nav-link btn-sm btn"
                              id="pills-depth-tab"
                              style={{ color: "white" }}
                              data-bs-toggle="pill"
                              data-bs-target="#pills-depth"
                              role="tab"
                              aria-controls="pills-depth"
                              aria-selected="false"
                            >
                              <img src={fullscreen} />
                            </button>
                          </li>
                        </ul>
                      </div>
                    </div>
                    <TabPanel sx={{ background: "#c4c4c4" }} value="1">
                      <div>
                        <div className="tab-content" id="pills-tabContent">
                          <div
                            className="tab-pane fade show active"
                            id="pills-basic"
                            role="tabpanel"
                            aria-labelledby="pills-basic-tab"
                          >
                            <div className=" d-flex justify-content-center">
                              <img src={graph} className="img-fluid" />
                            </div>
                          </div>
                        </div>
                      </div>
                    </TabPanel>
                    <TabPanel value="2">
                      <div className=" d-flex justify-content-center">
                        <img src={graph} className="img-fluid" />
                      </div>
                    </TabPanel>
                    <TabPanel value="3">
                      <div className=" d-flex justify-content-center">
                        <img src={graph} className="img-fluid" />
                      </div>
                    </TabPanel>
                  </TabContext>
                </Box>
              </CardContent>
            </Card>

            {/* /////////SPOT MARKET////// */}
            <Grid item xs={12} md={12} lg={12}>
              <Card
                sx={{
                  minWidth: 275,
                  background: "var(--market-center-bg-card)",
                  marginTop: 3,
                }}
              >
                <CardContent>
                  <Box sx={{ width: "100%", typography: "body1" }}>
                    <TabContext value={value}>
                      <div className="d-flex">
                        <div>
                          <Box>
                            <TabList
                              onChange={handleChange}
                              aria-label="lab API tabs example"
                            >
                              <Tab
                                sx={{ color: "white", textTransform: "none" }}
                                label="Spot Market"
                                value="1"
                              />
                            </TabList>
                          </Box>
                        </div>

                        <div style={{ marginLeft: "auto" }}>
                          <ul
                            className="nav nav-pills pills mb-2 my-2"
                            id="pills-tab pills-icons"
                            role="tablist"
                          >
                            <li className="nav-item" role="presentation">
                              <button
                                className="nav-link btn-danger btn-sm btn"
                                style={{
                                  color: "#dd2942",
                                  background: "#752742",
                                }}
                              >
                                3X Short
                              </button>
                            </li>
                            <li className="nav-item" role="presentation">
                              <button
                                className="nav-link btn-sm btn btn-success"
                                style={{
                                  color: "var(--icon-color)",
                                  background: "#145c56",
                                }}
                              >
                                3X Long
                              </button>
                            </li>
                            <li className="nav-item" role="presentation">
                              <button
                                className="nav-link  btn-sm btn btn-warning"
                                style={{
                                  color: "#efa734",
                                  background: "#846b3c",
                                }}
                              >
                                4X Margin
                              </button>
                            </li>
                            <li className="nav-item" role="presentation">
                              <button
                                className="nav-link  btn-sm btn"
                                style={{
                                  color: "var(--icon-color)",
                                  background: "#145c56",
                                  whiteSpace: "nowrap",
                                }}
                              >
                                5X-20X Futures Markets
                              </button>
                            </li>
                            <li className="nav-item" role="presentation">
                              <button className="nav-link  btn-sm btn text-muted">
                                Buy With
                              </button>
                            </li>
                            <li className="nav-item d-flex" role="presentation">
                              <button
                                className="nav-link btn-sm btn text-nowrap"
                                style={{ color: "white" }}
                              >
                                USD{" "}
                              </button>
                              <span>
                                {" "}
                                <ArrowForwardIosIcon
                                  sx={{
                                    fontSize: "20px",
                                    marginTop: "5px",
                                    color: "white",
                                  }}
                                />
                              </span>
                            </li>
                          </ul>
                        </div>
                      </div>

                      <div className="row ">
                        <div className="col-lg-6  my-2 col-sm-12 col-md-12">
                          <TabContext value={sportTabs}>
                            <div className="d-flex justify-content-between">
                              <div>
                                <Typography sx={{ color: "white" }}>
                                  Available 0 USDT
                                </Typography>
                              </div>
                              <div>
                                <Typography
                                  sx={{ color: "var(--icon-color)" }}
                                  className="fw-bold"
                                >
                                  <LogoutIcon fontSize={"small"} /> Deposit
                                </Typography>
                              </div>
                            </div>
                            <Box sx={{ marginTop: 1 }}>
                              <TabList
                                variant="scrollable"
                                onChange={sportTab}
                                TabIndicatorProps={{
                                  style: { backgroundColor: '#1b9368' }
                                }}
                                aria-label="lab API tabs example"
                              >
                                <Tab
                                  className="greenTab"
                                  sx={{
                                    fontSize: "15px",
                                    color: "white",
                                    fontWeight: 500,
                                    textTransform: "none",
                                  }}
                                  label="Limit"
                                  value="01"
                                />
                                <Tab
                                  className="greenTab"
                                  label="Market"
                                  sx={{
                                    fontSize: "15px",
                                    color: " white",
                                    fontWeight: 500,
                                    textTransform: "none",
                                  }}
                                  value="02"
                                />
                                <Tab
                                  className="greenTab"
                                  label="Stop-Limit"
                                  sx={{
                                    fontSize: "15px",
                                    color: " white",
                                    fontWeight: 500,
                                    textTransform: "none",
                                  }}
                                  value="03"
                                />
                              </TabList>
                            </Box>

                            <TabPanel
                              value="01"
                              sx={{ padding: "0 !important" }}
                            >
                              <div
                                className="mb-2 d-flex  mt-2"
                                style={{ height: "60px" }}
                              >
                                <span className="priceTag pe-2">
                                  <b className="text-center text-muted">
                                    Price
                                  </b>
                                </span>
                                <input
                                  type="text"
                                  className="form-control form-control-usd form-input-usd"
                                  style={{
                                    border: "none",
                                    borderTopRightRadius: 0,
                                    borderBottomRightRadius: 0,

                                    height: "40px",
                                  }}
                                />

                                <select
                                  className="form-select form-select-sm text-muted form-control-usd selction-bg"
                                  style={{
                                    width: "5rem",
                                    height: "40px",
                                    fontWeight: 700,
                                    fontSize: "15px",
                                    border: "none",
                                    borderTopLeftRadius: 0,
                                    borderBottomLeftRadius: 0,
                                  }}
                                  aria-label="Default select example"
                                >
                                  <option value="1" className="selectionText">
                                    {" "}
                                    USD{" "}
                                  </option>
                                  <option value="2" className="selectionText">
                                    {" "}
                                    USDT
                                  </option>
                                  <option value="3" className="selectionText">
                                    {" "}
                                    USTD
                                  </option>
                                </select>
                              </div>
                              <div
                                className="mb-2 d-flex  mt-2"
                                style={{ height: "60px" }}
                              >
                                <span className="priceTag pe-2">
                                  <b className="text-center text-muted">
                                    Quantity
                                  </b>
                                </span>
                                <input
                                  type="text"
                                  className="form-control form-control-usd form-input-usd"
                                  style={{
                                    border: "none",
                                    borderTopRightRadius: 0,
                                    borderBottomRightRadius: 0,

                                    height: "40px",
                                  }}
                                />

                                <select
                                  className="form-select form-select-sm text-muted form-control-usd selction-bg"
                                  style={{
                                    width: "5rem",
                                    height: "40px",
                                    fontWeight: 700,
                                    fontSize: "15px",
                                    border: "none",
                                    borderTopLeftRadius: 0,
                                    borderBottomLeftRadius: 0,
                                  }}
                                  aria-label="Default select example"
                                >
                                  <option value="1" className="selectionText">
                                    {" "}
                                    SOS{" "}
                                  </option>
                                  <option value="2" className="selectionText">
                                    {" "}
                                    USDT
                                  </option>
                                  <option value="3" className="selectionText">
                                    {" "}
                                    USTD
                                  </option>
                                </select>
                              </div>
                              <input
                                type="range"
                                style={{ width: "98%" }}
                                id="green"
                                className="input-green"
                                name="vol"
                                min="0"
                                max="100"
                              />
                              <div className="d-flex justify-content-between ms-1">
                                <Typography sx={{ color: "white" }}>
                                  Amount
                                </Typography>
                                <Typography sx={{ color: "white" }}>
                                  0 USDT--
                                </Typography>
                              </div>
                              <div className="d-grid my-4">
                                <button
                                  className="btn"
                                  style={{
                                    background: "var(--icon-color)",
                                    color: "white",
                                  }}
                                  type="button"
                                >
                                  Button
                                </button>
                              </div>
                            </TabPanel>
                          </TabContext>
                        </div>
                        <div className="col-lg-6 col-sm-12 col-md-12">
                          <div className="d-flex justify-content-between my-2">
                            <div>
                              <Typography sx={{ color: "white" }}>
                                Available 0 USDT
                              </Typography>
                            </div>
                            <div>
                              <Typography
                                sx={{ color: "#dd2942" }}
                                className="fw-bold"
                              >
                                <LogoutIcon fontSize={"small"} /> Deposit
                              </Typography>
                            </div>
                          </div>
                          <>
                            <TabContext value={redSportTabs}>
                              <Box sx={{ marginTop: "10px" }}>
                                <TabList
                                  variant="scrollable"
                                  onChange={redTab}
                                  TabIndicatorProps={{
                                    style: { backgroundColor: 'red' }
                                  }}
                                  aria-label="lab API tabs example"
                                >
                                  <Tab
                                    className="redTab"
                                    sx={{
                                      fontSize: "15px",
                                      color: "white",
                                      fontWeight: 500,
                                      textTransform: "none",
                                    }}
                                    label="Limit"
                                    value="01"
                                  />
                                  <Tab
                                    className="redTab"
                                    label="Market"
                                    sx={{
                                      fontSize: "15px",
                                      color: " white",
                                      fontWeight: 500,
                                      textTransform: "none",
                                    }}
                                    value="02"
                                  />
                                  <Tab
                                    className="redTab"
                                    label="Stop-Limit"
                                    sx={{
                                      fontSize: "15px",
                                      color: " white",
                                      fontWeight: 500,
                                      textTransform: "none",
                                    }}
                                    value="03"
                                  />
                                </TabList>
                              </Box>
                              <div
                                className="mb-2 d-flex  mt-2"
                                style={{ height: "60px" }}
                              >
                                <span className="priceTag pe-2">
                                  <b className="text-center text-muted">
                                    Price
                                  </b>
                                </span>
                                <input
                                  type="text"
                                  className="form-control form-control-usd form-input-usd"
                                  style={{
                                    border: "none",
                                    borderTopRightRadius: 0,
                                    borderBottomRightRadius: 0,

                                    height: "40px",
                                  }}
                                />

                                <select
                                  className="form-select form-select-sm text-muted form-control-usd selction-bg"
                                  style={{
                                    width: "5rem",
                                    height: "40px",
                                    fontWeight: 700,
                                    fontSize: "15px",
                                    border: "none",
                                    borderTopLeftRadius: 0,
                                    borderBottomLeftRadius: 0,
                                  }}
                                  aria-label="Default select example"
                                >
                                  <option value="1" className="selectionText">
                                    {" "}
                                    USD{" "}
                                  </option>
                                  <option value="2" className="selectionText">
                                    {" "}
                                    USDT
                                  </option>
                                  <option value="3" className="selectionText">
                                    {" "}
                                    USTD
                                  </option>
                                </select>
                              </div>
                              <div
                                className="mb-2 d-flex  mt-2"
                                style={{ height: "60px" }}
                              >
                                <span className="priceTag pe-2">
                                  <b className="text-center text-muted">
                                    Quantity
                                  </b>
                                </span>
                                <input
                                  type="text"
                                  className="form-control form-control-usd form-input-usd"
                                  style={{
                                    border: "none",
                                    borderTopRightRadius: 0,
                                    borderBottomRightRadius: 0,

                                    height: "40px",
                                  }}
                                />

                                <select
                                  className="form-select form-select-sm text-muted form-control-usd selction-bg"
                                  style={{
                                    width: "5rem",
                                    height: "40px",
                                    fontWeight: 700,
                                    fontSize: "15px",
                                    border: "none",
                                    borderTopLeftRadius: 0,
                                    borderBottomLeftRadius: 0,
                                  }}
                                  aria-label="Default select example"
                                >
                                  <option value="1" className="selectionText">
                                    {" "}
                                    SOS{" "}
                                  </option>
                                  <option value="2" className="selectionText">
                                    {" "}
                                    USDT
                                  </option>
                                  <option value="3" className="selectionText">
                                    {" "}
                                    USTD
                                  </option>
                                </select>
                              </div>
                              <input
                                type="range"
                                id="red"
                                style={{ width: "99%" }}
                                className="input-green"
                                name="vol"
                                min="0"
                                max="100"
                              />
                              <div className="d-flex justify-content-between ms-1">
                                <Typography sx={{ color: "white" }}>
                                  Amount
                                </Typography>
                                <Typography sx={{ color: "white" }}>
                                  0 USDT--
                                </Typography>
                              </div>
                              <div className="d-grid my-4">
                                <button
                                  className="btn "
                                  style={{
                                    background: "#DD2942",
                                    color: "white",
                                  }}
                                  type="button"
                                >
                                  Button
                                </button>
                              </div>
                            </TabContext>
                          </>
                        </div>
                      </div>
                    </TabContext>
                  </Box>
                </CardContent>
              </Card>
              <Box></Box>
            </Grid>
          </Grid>
          <Grid item xs={12} md={3} lg={3}>
            <Card
              sx={{
                minWidth: 100,
                background: "var(--market-fav-card-bg-color)",
              }}
            >
              <CardContent>
                <div className="my-3">
                  <input
                    type="text"
                    className="form-control input-typing-space col-sm-5 col-md-5 border-0"
                    style={{ height: "50px", background: "#255b73" }}
                    placeholder="Search Token"
                  />
                  <span className="search-icon pe-2 text-dark">
                    <SearchIcon sx={{ color: "#88a4b2" }} />
                  </span>
                </div>
                <Box sx={{ typography: "body1" }}>
                  <TabContext value={tabs}>
                    <Box>
                      <TabList
                        variant="scrollable"
                        onChange={tabChange}
                        aria-label="lab API tabs example"
                      >
                        <Tab
                          sx={{
                            fontSize: "15px",
                            color: " rgba(255, 255, 255, 0.5)",
                            fontWeight: 500,
                            textTransform: "none",
                          }}
                          label="Favourites"
                          value="1"
                        />
                        <Tab
                          label="Main"
                          sx={{
                            fontSize: "15px",
                            color: " rgba(255, 255, 255, 0.5)",
                            fontWeight: 500,
                            textTransform: "none",
                          }}
                          value="2"
                        />
                        <Tab
                          label="ETF"
                          value="3"
                          sx={{
                            fontSize: "15px",
                            color: " rgba(255, 255, 255, 0.5)",
                            fontWeight: 500,
                            textTransform: "none",
                          }}
                        />
                        <Tab
                          label="Innovation"
                          value="4"
                          sx={{
                            fontSize: "15px",
                            color: " rgba(255, 255, 255, 0.5)",
                            fontWeight: 500,
                            textTransform: "none",
                          }}
                        />
                        <Tab
                          label="Assessment"
                          value="5"
                          sx={{
                            fontSize: "15px",
                            color: " rgba(255, 255, 255, 0.5)",
                            fontWeight: 500,
                            textTransform: "none",
                          }}
                        />
                        <Tab
                          label="Zones"
                          value="6"
                          sx={{
                            fontSize: "15px",
                            color: " rgba(255, 255, 255, 0.5)",
                            fontWeight: 500,
                            textTransform: "none",
                          }}
                        />
                      </TabList>
                    </Box>
                    <TabPanel value="1" sx={{ padding: "0 !important" }}>
                      <TableContainer className="table-resp">
                        <Table
                          className="table-responsive"
                          component={Paper}
                          sx={{
                            background: "var(--market-fav-card-bg-color)",
                            minWidth: "auto",
                            maxWidth: "auto",
                          }}
                          aria-label="simple table"
                        >
                          <TableHead sx={{ border: 0 }}>
                            <TableRow>
                              <TableCell
                                align="left"
                                sx={{
                                  color: "#7b8d9b",
                                  fontSize: "15px",
                                  fontWeight: 600,
                                  marginRight: "5px",
                                  borderBottom: "none",
                                  padding: "4px 16px ",
                                }}
                              >
                                <div className="d-flex me-2">
                                  Token
                                  {
                                    <div className="my-1">
                                      <i
                                        className="bi bi-caret-up d-block ms-2"
                                        style={{ fontSize: "9px" }}
                                      ></i>{" "}
                                      <i
                                        className="bi bi-caret-down ms-2"
                                        style={{ fontSize: "9px" }}
                                      ></i>{" "}
                                    </div>
                                  }{" "}
                                </div>
                              </TableCell>
                              <TableCell
                                align="left"
                                sx={{
                                  color: "#7b8d9b",
                                  fontSize: "15px",
                                  fontWeight: 600,
                                  marginRight: 15,
                                  borderBottom: "none",
                                  padding: "4px 16px ",
                                }}
                              >
                                <div className="d-flex me-2">
                                  Price
                                  {
                                    <div className="my-1">
                                      <i
                                        className="bi bi-caret-up d-block ms-2"
                                        style={{ fontSize: "9px" }}
                                      ></i>{" "}
                                      <i
                                        className="bi bi-caret-down ms-2"
                                        style={{ fontSize: "9px" }}
                                      ></i>{" "}
                                    </div>
                                  }{" "}
                                </div>
                              </TableCell>
                              <TableCell
                                align="left"
                                sx={{
                                  color: "#7b8d9b",
                                  fontSize: "15px",
                                  fontWeight: 600,
                                  marginRight: 50,
                                  borderBottom: "none",
                                  padding: "4px 16px ",
                                }}
                              >
                                <div className="d-flex me-2">
                                  Change%
                                  {
                                    <div className="my-1">
                                      <i
                                        className="bi bi-caret-up d-block ms-2"
                                        style={{ fontSize: "9px" }}
                                      ></i>{" "}
                                      <i
                                        className="bi bi-caret-down ms-2"
                                        style={{ fontSize: "9px" }}
                                      ></i>{" "}
                                    </div>
                                  }{" "}
                                </div>
                              </TableCell>
                            </TableRow>
                          </TableHead>
                          <TableBody>
                            {rows.map((row) => (
                              <TableRow
                                key={row.name}
                                sx={{ "td, th": { border: 0 } }}
                              >
                                <TableCell
                                  sx={{ color: "white", padding: "4px 16px " }}
                                  component="th"
                                  scope="row"
                                >
                                  <Typography>
                                    <span className="d-flex">
                                      BTC/{" "}
                                      <span className="text-muted"> USDT </span>{" "}
                                      <span
                                        style={{
                                          fontSize: "10px",
                                          backgroundColor: "#FFBF0080",
                                          color: "#FFBF00",
                                          padding: "4px",
                                          marginLeft: "4px",
                                          borderRadius: "5px",
                                        }}
                                      >
                                        10X
                                      </span>
                                    </span>
                                  </Typography>
                                  <span className="text-muted">Bitcoin</span>
                                </TableCell>
                                <TableCell
                                  align="left"
                                  sx={{ color: "white", padding: "4px 16px" }}
                                >
                                  <Typography> 2.22198</Typography>
                                  <span className="text-muted">$4.57</span>
                                </TableCell>
                                <TableCell
                                  align="left"
                                  sx={{ padding: "4px 16px" }}
                                >
                                  {" "}
                                  <div className="d-flex">
                                    {" "}
                                    <div>
                                      <Typography
                                        sx={{
                                          color: "var(--icon-color)",
                                          fontWeight: 600,
                                        }}
                                      >
                                        +1.12%
                                      </Typography>
                                      <span className="text-muted">$4.57</span>{" "}
                                    </div>
                                    <StarIcon
                                      sx={{ color: "#FFBF00" }}
                                      className="ms-2"
                                    />{" "}
                                  </div>
                                </TableCell>
                              </TableRow>
                            ))}
                          </TableBody>
                        </Table>
                        <div
                          className="mb-2"
                          style={{
                            border: "2px solid rgba(26, 148, 174, 0.2)",
                            borderRight: 0,
                            borderLeft: 0,
                            padding: 10,
                          }}
                        >
                          <TabContext value={value}>
                            <Box>
                              <TabList
                                onChange={onChange}
                                aria-label="lab API tabs example"
                                TabIndicatorProps={{
                                  style: { backgroundColor: '#1f8bb7' }
                                }}
                              >
                                <Tab
                                  style={{
                                    borderBottom: "2px solid #1A94AE",
                                    fontSize: "10px",
                                    marginLeft: 4,
                                  }}
                                  label="Market Trades"
                                  value="1"
                                  className="MuiButtonBase-root MuiTab-root MuiTab-textColorPrimary Mui-selected css-1h9z7r5-MuiButtonBase-root-MuiTab-root"
                                />
                              </TabList>
                            </Box>

                            <div className="tab-content" id="pills-tabContent">
                              <div
                                className="tab-pane fade show active"
                                id="pills-home"
                                role="tabpanel"
                                aria-labelledby="pills-home-tab"
                              >
                                <TableContainer className="table-resp">
                                  <TableHead sx={{ border: 0 }}>
                                    <TableRow>
                                      <TableCell
                                        align="left"
                                        sx={{
                                          color: "rgba(255, 255, 255, 0.5);",
                                          fontSize: "15px",
                                          marginRight: "5px",
                                          padding: "4px 16px ",
                                          borderBottom: "none",
                                        }}
                                      >
                                        Price(USDT)
                                      </TableCell>
                                      <TableCell
                                        align="right"
                                        sx={{
                                          color: "rgba(255, 255, 255, 0.5);",
                                          fontSize: "15px",
                                          marginRight: 15,
                                          borderBottom: "none",
                                          padding: "4px 16px ",
                                        }}
                                      >
                                        Quantity(SOS)
                                      </TableCell>
                                      <TableCell
                                        align="right"
                                        sx={{
                                          color: "rgba(255, 255, 255, 0.5);",
                                          fontSize: "15px",
                                          marginRight: 50,
                                          borderBottom: "none",
                                          padding: "4px 16px ",
                                        }}
                                      >
                                        Time
                                      </TableCell>
                                    </TableRow>
                                  </TableHead>
                                  <TableBody>
                                    {rows.map((row) => (
                                      <TableRow
                                        key={row.name}
                                        sx={{
                                          "td, th": { border: 0 },
                                          marginTop: 5,
                                        }}
                                      >
                                        <TableCell
                                          sx={{
                                            color: "var(--icon-color)",
                                            padding: "4px 16px",
                                          }}
                                          component="th"
                                          scope="row"
                                        >
                                          {row.name}
                                        </TableCell>
                                        <TableCell
                                          align="center"
                                          sx={{
                                            color: "white",
                                            padding: "4px 16px ",
                                          }}
                                        >
                                          {row.calories}
                                        </TableCell>
                                        <TableCell
                                          align="left"
                                          sx={{ padding: "4px 16px " }}
                                        >
                                          <span
                                            className="text-white ms-2"
                                            style={{
                                              background: "#0f3445",
                                              padding: 4,
                                              borderRadius: 5,
                                            }}
                                          >
                                            1750
                                          </span>
                                        </TableCell>
                                      </TableRow>
                                    ))}
                                  </TableBody>
                                </TableContainer>
                              </div>
                            </div>
                          </TabContext>
                        </div>
                      </TableContainer>
                    </TabPanel>
                    <TabPanel value="2" sx={{ padding: "0 !important" }}>
                      <TableContainer className="table-resp">
                        <Table
                          className="table-responsive"
                          component={Paper}
                          sx={{
                            background: "var(--market-fav-card-bg-color)",
                            minWidth: "auto",
                            maxWidth: "auto",
                            backgroundColor: "var(--market-fav-card-bg-color)",
                          }}
                          aria-label="simple table"
                        >
                          <TableHead sx={{ border: 0 }}>
                            <TableRow>
                              <TableCell
                                align="left"
                                sx={{
                                  color: "#7b8d9b",
                                  fontSize: "15px",
                                  fontWeight: 600,
                                  marginRight: "5px",
                                  borderBottom: "none",
                                  padding: "4px 16px ",
                                }}
                              >
                                <div className="d-flex me-2">
                                  Token
                                  {
                                    <div className="my-1">
                                      <i
                                        className="bi bi-caret-up d-block ms-2"
                                        style={{ fontSize: "9px" }}
                                      ></i>{" "}
                                      <i
                                        className="bi bi-caret-down ms-2"
                                        style={{ fontSize: "9px" }}
                                      ></i>{" "}
                                    </div>
                                  }{" "}
                                </div>
                              </TableCell>
                              <TableCell
                                align="left"
                                sx={{
                                  color: "#7b8d9b",
                                  fontSize: "15px",
                                  fontWeight: 600,
                                  marginRight: 15,
                                  borderBottom: "none",
                                  padding: "4px 16px ",
                                }}
                              >
                                <div className="d-flex me-2">
                                  Price
                                  {
                                    <div className="my-1">
                                      <i
                                        className="bi bi-caret-up d-block ms-2"
                                        style={{ fontSize: "9px" }}
                                      ></i>{" "}
                                      <i
                                        className="bi bi-caret-down ms-2"
                                        style={{ fontSize: "9px" }}
                                      ></i>{" "}
                                    </div>
                                  }{" "}
                                </div>
                              </TableCell>
                              <TableCell
                                align="left"
                                sx={{
                                  color: "#7b8d9b",
                                  fontSize: "15px",
                                  fontWeight: 600,
                                  marginRight: 50,
                                  borderBottom: "none",
                                  padding: "4px 16px ",
                                }}
                              >
                                <div className="d-flex me-2">
                                  Change%
                                  {
                                    <div className="my-1">
                                      <i
                                        className="bi bi-caret-up d-block ms-2"
                                        style={{ fontSize: "9px" }}
                                      ></i>{" "}
                                      <i
                                        className="bi bi-caret-down ms-2"
                                        style={{ fontSize: "9px" }}
                                      ></i>{" "}
                                    </div>
                                  }{" "}
                                </div>
                              </TableCell>
                            </TableRow>
                          </TableHead>
                          <TableBody>
                            {rows.map((row) => (
                              <TableRow
                                key={row.name}
                                sx={{ "td, th": { border: 0 } }}
                              >
                                <TableCell
                                  sx={{ color: "white", padding: "4px 16px " }}
                                  component="th"
                                  scope="row"
                                >
                                  <Typography>
                                    <span className="d-flex">
                                      BTC/{" "}
                                      <span className="text-muted"> USDT </span>{" "}
                                      <span
                                        style={{
                                          fontSize: "10px",
                                          backgroundColor: "#FFBF0080",
                                          color: "#FFBF00",
                                          padding: "4px",
                                          marginLeft: "4px",
                                          borderRadius: "5px",
                                        }}
                                      >
                                        10X
                                      </span>
                                    </span>
                                  </Typography>
                                  <span className="text-muted">Bitcoin</span>
                                </TableCell>
                                <TableCell
                                  align="left"
                                  sx={{ color: "white", padding: "4px 16px" }}
                                >
                                  <Typography> 2.22198</Typography>
                                  <span className="text-muted">$4.57</span>
                                </TableCell>
                                <TableCell
                                  align="left"
                                  sx={{ padding: "4px 16px" }}
                                >
                                  {" "}
                                  <div className="d-flex">
                                    {" "}
                                    <div>
                                      <Typography
                                        sx={{
                                          color: "var(--icon-color)",
                                          fontWeight: 600,
                                        }}
                                      >
                                        +1.12%
                                      </Typography>
                                      <span className="text-muted">$4.57</span>{" "}
                                    </div>
                                    <StarIcon
                                      sx={{ color: "#FFBF00" }}
                                      className="ms-2"
                                    />{" "}
                                  </div>
                                </TableCell>
                              </TableRow>
                            ))}
                          </TableBody>
                        </Table>
                        <div
                          className="mb-2"
                          style={{
                            border: "2px solid rgba(26, 148, 174, 0.2)",
                            borderRight: 0,
                            borderLeft: 0,
                            padding: 10,
                          }}
                        >
                          <TabContext value={value}>
                            <Box>
                              <TabList
                                onChange={onChange}
                                aria-label="lab API tabs example"
                              >
                                <Tab
                                  style={{
                                    borderBottom: "2px solid #1A94AE",
                                    fontSize: "10px",
                                    marginLeft: 4,
                                  }}
                                  label="Market Trades"
                                  value="1"
                                  className="MuiButtonBase-root MuiTab-root MuiTab-textColorPrimary Mui-selected css-1h9z7r5-MuiButtonBase-root-MuiTab-root"
                                />
                              </TabList>
                            </Box>

                            <div className="tab-content" id="pills-tabContent">
                              <div
                                className="tab-pane fade show active"
                                id="pills-home"
                                role="tabpanel"
                                aria-labelledby="pills-home-tab"
                              >
                                <TableContainer className="table-resp">
                                  <TableHead sx={{ border: 0 }}>
                                    <TableRow>
                                      <TableCell
                                        align="left"
                                        sx={{
                                          color: "rgba(255, 255, 255, 0.5);",
                                          fontSize: "15px",
                                          marginRight: "5px",
                                          padding: "4px 16px ",
                                          borderBottom: "none",
                                        }}
                                      >
                                        Price(USDT)
                                      </TableCell>
                                      <TableCell
                                        align="right"
                                        sx={{
                                          color: "rgba(255, 255, 255, 0.5);",
                                          fontSize: "15px",
                                          marginRight: 15,
                                          borderBottom: "none",
                                          padding: "4px 16px ",
                                        }}
                                      >
                                        Quantity(SOS)
                                      </TableCell>
                                      <TableCell
                                        align="right"
                                        sx={{
                                          color: "rgba(255, 255, 255, 0.5);",
                                          fontSize: "15px",
                                          marginRight: 50,
                                          borderBottom: "none",
                                          padding: "4px 16px ",
                                        }}
                                      >
                                        Time
                                      </TableCell>
                                    </TableRow>
                                  </TableHead>
                                  <TableBody>
                                    {rows.map((row) => (
                                      <TableRow
                                        key={row.name}
                                        sx={{
                                          "td, th": { border: 0 },
                                          marginTop: 5,
                                        }}
                                      >
                                        <TableCell
                                          sx={{
                                            color: "var(--icon-color)",
                                            padding: "4px 16px",
                                          }}
                                          component="th"
                                          scope="row"
                                        >
                                          {row.name}
                                        </TableCell>
                                        <TableCell
                                          align="center"
                                          sx={{
                                            color: "white",
                                            padding: "4px 16px ",
                                          }}
                                        >
                                          {row.calories}
                                        </TableCell>
                                        <TableCell
                                          align="left"
                                          sx={{ padding: "4px 16px " }}
                                        >
                                          <span
                                            className="text-white ms-2"
                                            style={{
                                              background: "#0f3445",
                                              padding: 4,
                                              borderRadius: 5,
                                            }}
                                          >
                                            1750
                                          </span>
                                        </TableCell>
                                      </TableRow>
                                    ))}
                                  </TableBody>
                                </TableContainer>
                              </div>
                            </div>
                          </TabContext>
                        </div>
                      </TableContainer>
                    </TabPanel>
                    <TabPanel value="3" sx={{ padding: "0 !important" }}>
                      <TableContainer className="table-resp">
                        <Table
                          className="table-responsive"
                          component={Paper}
                          sx={{
                            background: "var(--market-fav-card-bg-color)",
                            minWidth: "auto",
                            maxWidth: "auto",
                            backgroundColor: "var(--market-fav-card-bg-color)",
                          }}
                          aria-label="simple table"
                        >
                          <TableHead sx={{ border: 0 }}>
                            <TableRow>
                              <TableCell
                                align="left"
                                sx={{
                                  color: "#7b8d9b",
                                  fontSize: "15px",
                                  fontWeight: 600,
                                  marginRight: "5px",
                                  borderBottom: "none",
                                  padding: "4px 16px ",
                                }}
                              >
                                <div className="d-flex me-2">
                                  Token
                                  {
                                    <div className="my-1">
                                      <i
                                        className="bi bi-caret-up d-block ms-2"
                                        style={{ fontSize: "9px" }}
                                      ></i>{" "}
                                      <i
                                        className="bi bi-caret-down ms-2"
                                        style={{ fontSize: "9px" }}
                                      ></i>{" "}
                                    </div>
                                  }{" "}
                                </div>
                              </TableCell>
                              <TableCell
                                align="left"
                                sx={{
                                  color: "#7b8d9b",
                                  fontSize: "15px",
                                  fontWeight: 600,
                                  marginRight: 15,
                                  borderBottom: "none",
                                  padding: "4px 16px ",
                                }}
                              >
                                <div className="d-flex me-2">
                                  Price
                                  {
                                    <div className="my-1">
                                      <i
                                        className="bi bi-caret-up d-block ms-2"
                                        style={{ fontSize: "9px" }}
                                      ></i>{" "}
                                      <i
                                        className="bi bi-caret-down ms-2"
                                        style={{ fontSize: "9px" }}
                                      ></i>{" "}
                                    </div>
                                  }{" "}
                                </div>
                              </TableCell>
                              <TableCell
                                align="left"
                                sx={{
                                  color: "#7b8d9b",
                                  fontSize: "15px",
                                  fontWeight: 600,
                                  marginRight: 50,
                                  borderBottom: "none",
                                  padding: "4px 16px ",
                                }}
                              >
                                <div className="d-flex me-2">
                                  Change%
                                  {
                                    <div className="my-1">
                                      <i
                                        className="bi bi-caret-up d-block ms-2"
                                        style={{ fontSize: "9px" }}
                                      ></i>{" "}
                                      <i
                                        className="bi bi-caret-down ms-2"
                                        style={{ fontSize: "9px" }}
                                      ></i>{" "}
                                    </div>
                                  }{" "}
                                </div>
                              </TableCell>
                            </TableRow>
                          </TableHead>
                          <TableBody>
                            {rows.map((row) => (
                              <TableRow
                                key={row.name}
                                sx={{ "td, th": { border: 0 } }}
                              >
                                <TableCell
                                  sx={{ color: "white", padding: "4px 16px " }}
                                  component="th"
                                  scope="row"
                                >
                                  <Typography>
                                    <span className="d-flex">
                                      BTC/{" "}
                                      <span className="text-muted"> USDT </span>{" "}
                                      <span
                                        style={{
                                          fontSize: "10px",
                                          backgroundColor: "#FFBF0080",
                                          color: "#FFBF00",
                                          padding: "4px",
                                          marginLeft: "4px",
                                          borderRadius: "5px",
                                        }}
                                      >
                                        10X
                                      </span>
                                    </span>
                                  </Typography>
                                  <span className="text-muted">Bitcoin</span>
                                </TableCell>
                                <TableCell
                                  align="left"
                                  sx={{ color: "white", padding: "4px 16px" }}
                                >
                                  <Typography> 2.22198</Typography>
                                  <span className="text-muted">$4.57</span>
                                </TableCell>
                                <TableCell
                                  align="left"
                                  sx={{ padding: "4px 16px" }}
                                >
                                  {" "}
                                  <div className="d-flex">
                                    {" "}
                                    <div>
                                      <Typography
                                        sx={{
                                          color: "var(--icon-color)",
                                          fontWeight: 600,
                                        }}
                                      >
                                        +1.12%
                                      </Typography>
                                      <span className="text-muted">$4.57</span>{" "}
                                    </div>
                                    <StarIcon
                                      sx={{ color: "#FFBF00" }}
                                      className="ms-2"
                                    />{" "}
                                  </div>
                                </TableCell>
                              </TableRow>
                            ))}
                          </TableBody>
                        </Table>
                        <div
                          className="mb-2"
                          style={{
                            border: "2px solid rgba(26, 148, 174, 0.2)",
                            borderRight: 0,
                            borderLeft: 0,
                            padding: 10,
                          }}
                        >
                          <TabContext value={value}>
                            <Box>
                              <TabList
                                onChange={onChange}
                                aria-label="lab API tabs example"
                              >
                                <Tab
                                  style={{
                                    borderBottom: "2px solid #1A94AE",
                                    fontSize: "10px",
                                    marginLeft: 4,
                                  }}
                                  label="Market Trades"
                                  value="1"
                                  className="MuiButtonBase-root MuiTab-root MuiTab-textColorPrimary Mui-selected css-1h9z7r5-MuiButtonBase-root-MuiTab-root"
                                />
                              </TabList>
                            </Box>

                            <div className="tab-content" id="pills-tabContent">
                              <div
                                className="tab-pane fade show active"
                                id="pills-home"
                                role="tabpanel"
                                aria-labelledby="pills-home-tab"
                              >
                                <TableContainer className="table-resp">
                                  <TableHead sx={{ border: 0 }}>
                                    <TableRow>
                                      <TableCell
                                        align="left"
                                        sx={{
                                          color: "rgba(255, 255, 255, 0.5);",
                                          fontSize: "15px",
                                          marginRight: "5px",
                                          padding: "4px 16px ",
                                          borderBottom: "none",
                                        }}
                                      >
                                        Price(USDT)
                                      </TableCell>
                                      <TableCell
                                        align="right"
                                        sx={{
                                          color: "rgba(255, 255, 255, 0.5);",
                                          fontSize: "15px",
                                          marginRight: 15,
                                          borderBottom: "none",
                                          padding: "4px 16px ",
                                        }}
                                      >
                                        Quantity(SOS)
                                      </TableCell>
                                      <TableCell
                                        align="right"
                                        sx={{
                                          color: "rgba(255, 255, 255, 0.5);",
                                          fontSize: "15px",
                                          marginRight: 50,
                                          borderBottom: "none",
                                          padding: "4px 16px ",
                                        }}
                                      >
                                        Time
                                      </TableCell>
                                    </TableRow>
                                  </TableHead>
                                  <TableBody>
                                    {rows.map((row) => (
                                      <TableRow
                                        key={row.name}
                                        sx={{
                                          "td, th": { border: 0 },
                                          marginTop: 5,
                                        }}
                                      >
                                        <TableCell
                                          sx={{
                                            color: "var(--icon-color)",
                                            padding: "4px 16px",
                                          }}
                                          component="th"
                                          scope="row"
                                        >
                                          {row.name}
                                        </TableCell>
                                        <TableCell
                                          align="center"
                                          sx={{
                                            color: "white",
                                            padding: "4px 16px ",
                                          }}
                                        >
                                          {row.calories}
                                        </TableCell>
                                        <TableCell
                                          align="left"
                                          sx={{ padding: "4px 16px " }}
                                        >
                                          <span
                                            className="text-white ms-2"
                                            style={{
                                              background: "#0f3445",
                                              padding: 4,
                                              borderRadius: 5,
                                            }}
                                          >
                                            1750
                                          </span>
                                        </TableCell>
                                      </TableRow>
                                    ))}
                                  </TableBody>
                                </TableContainer>
                              </div>
                            </div>
                          </TabContext>
                        </div>
                      </TableContainer>
                    </TabPanel>
                    <TabPanel value="4" sx={{ padding: "0 !important" }}>
                      <TableContainer className="table-resp">
                        <Table
                          className="table-responsive"
                          component={Paper}
                          sx={{
                            minWidth: "auto",
                            maxWidth: "auto",
                            backgroundColor: " var(--market-fav-card-bg-color)",
                          }}
                          aria-label="simple table"
                        >
                          <TableHead sx={{ border: 0 }}>
                            <TableRow>
                              <TableCell
                                align="left"
                                sx={{
                                  color: "#7b8d9b",
                                  fontSize: "15px",
                                  fontWeight: 600,
                                  marginRight: "5px",
                                  borderBottom: "none",
                                  padding: "4px 16px ",
                                }}
                              >
                                <div className="d-flex me-2">
                                  Token
                                  {
                                    <div className="my-1">
                                      <i
                                        className="bi bi-caret-up d-block ms-2"
                                        style={{ fontSize: "9px" }}
                                      ></i>{" "}
                                      <i
                                        className="bi bi-caret-down ms-2"
                                        style={{ fontSize: "9px" }}
                                      ></i>{" "}
                                    </div>
                                  }{" "}
                                </div>
                              </TableCell>
                              <TableCell
                                align="left"
                                sx={{
                                  color: "#7b8d9b",
                                  fontSize: "15px",
                                  fontWeight: 600,
                                  marginRight: 15,
                                  borderBottom: "none",
                                  padding: "4px 16px ",
                                }}
                              >
                                <div className="d-flex me-2">
                                  Price
                                  {
                                    <div className="my-1">
                                      <i
                                        className="bi bi-caret-up d-block ms-2"
                                        style={{ fontSize: "9px" }}
                                      ></i>{" "}
                                      <i
                                        className="bi bi-caret-down ms-2"
                                        style={{ fontSize: "9px" }}
                                      ></i>{" "}
                                    </div>
                                  }{" "}
                                </div>
                              </TableCell>
                              <TableCell
                                align="left"
                                sx={{
                                  color: "#7b8d9b",
                                  fontSize: "15px",
                                  fontWeight: 600,
                                  marginRight: 50,
                                  borderBottom: "none",
                                  padding: "4px 16px ",
                                }}
                              >
                                <div className="d-flex me-2">
                                  Change%
                                  {
                                    <div className="my-1">
                                      <i
                                        className="bi bi-caret-up d-block ms-2"
                                        style={{ fontSize: "9px" }}
                                      ></i>{" "}
                                      <i
                                        className="bi bi-caret-down ms-2"
                                        style={{ fontSize: "9px" }}
                                      ></i>{" "}
                                    </div>
                                  }{" "}
                                </div>
                              </TableCell>
                            </TableRow>
                          </TableHead>
                          <TableBody>
                            {rows.map((row) => (
                              <TableRow
                                key={row.name}
                                sx={{ "td, th": { border: 0 } }}
                              >
                                <TableCell
                                  sx={{ color: "white", padding: "4px 16px " }}
                                  component="th"
                                  scope="row"
                                >
                                  <Typography>
                                    <span className="d-flex">
                                      BTC/{" "}
                                      <span className="text-muted"> USDT </span>{" "}
                                      <span
                                        style={{
                                          fontSize: "10px",
                                          backgroundColor: "#FFBF0080",
                                          color: "#FFBF00",
                                          padding: "4px",
                                          marginLeft: "4px",
                                          borderRadius: "5px",
                                        }}
                                      >
                                        10X
                                      </span>
                                    </span>
                                  </Typography>
                                  <span className="text-muted">Bitcoin</span>
                                </TableCell>
                                <TableCell
                                  align="left"
                                  sx={{ color: "white", padding: "4px 16px" }}
                                >
                                  <Typography> 2.22198</Typography>
                                  <span className="text-muted">$4.57</span>
                                </TableCell>
                                <TableCell
                                  align="left"
                                  sx={{ padding: "4px 16px" }}
                                >
                                  {" "}
                                  <div className="d-flex">
                                    {" "}
                                    <div>
                                      <Typography
                                        sx={{
                                          color: "var(--icon-color)",
                                          fontWeight: 600,
                                        }}
                                      >
                                        +1.12%
                                      </Typography>
                                      <span className="text-muted">$4.57</span>{" "}
                                    </div>
                                    <StarIcon
                                      sx={{ color: "#FFBF00" }}
                                      className="ms-2"
                                    />{" "}
                                  </div>
                                </TableCell>
                              </TableRow>
                            ))}
                          </TableBody>
                        </Table>
                        <div
                          className="mb-2"
                          style={{
                            border: "2px solid rgba(26, 148, 174, 0.2)",
                            borderRight: 0,
                            borderLeft: 0,
                            padding: 10,
                          }}
                        >
                          <TabContext value={value}>
                            <Box>
                              <TabList
                                onChange={onChange}
                                aria-label="lab API tabs example"
                              >
                                <Tab
                                  style={{
                                    borderBottom: "2px solid #1A94AE",
                                    fontSize: "10px",
                                    marginLeft: 4,
                                  }}
                                  label="Market Trades"
                                  value="1"
                                  className="MuiButtonBase-root MuiTab-root MuiTab-textColorPrimary Mui-selected css-1h9z7r5-MuiButtonBase-root-MuiTab-root"
                                />
                              </TabList>
                            </Box>

                            <div className="tab-content" id="pills-tabContent">
                              <div
                                className="tab-pane fade show active"
                                id="pills-home"
                                role="tabpanel"
                                aria-labelledby="pills-home-tab"
                              >
                                <TableContainer className="table-resp">
                                  <TableHead sx={{ border: 0 }}>
                                    <TableRow>
                                      <TableCell
                                        align="left"
                                        sx={{
                                          color: "rgba(255, 255, 255, 0.5);",
                                          fontSize: "15px",
                                          marginRight: "5px",
                                          padding: "4px 16px ",
                                          borderBottom: "none",
                                        }}
                                      >
                                        Price(USDT)
                                      </TableCell>
                                      <TableCell
                                        align="right"
                                        sx={{
                                          color: "rgba(255, 255, 255, 0.5);",
                                          fontSize: "15px",
                                          marginRight: 15,
                                          borderBottom: "none",
                                          padding: "4px 16px ",
                                        }}
                                      >
                                        Quantity(SOS)
                                      </TableCell>
                                      <TableCell
                                        align="right"
                                        sx={{
                                          color: "rgba(255, 255, 255, 0.5);",
                                          fontSize: "15px",
                                          marginRight: 50,
                                          borderBottom: "none",
                                          padding: "4px 16px ",
                                        }}
                                      >
                                        Time
                                      </TableCell>
                                    </TableRow>
                                  </TableHead>
                                  <TableBody>
                                    {rows.map((row) => (
                                      <TableRow
                                        key={row.name}
                                        sx={{
                                          "td, th": { border: 0 },
                                          marginTop: 5,
                                        }}
                                      >
                                        <TableCell
                                          sx={{
                                            color: "var(--icon-color)",
                                            padding: "4px 16px",
                                          }}
                                          component="th"
                                          scope="row"
                                        >
                                          {row.name}
                                        </TableCell>
                                        <TableCell
                                          align="center"
                                          sx={{
                                            color: "white",
                                            padding: "4px 16px ",
                                          }}
                                        >
                                          {row.calories}
                                        </TableCell>
                                        <TableCell
                                          align="left"
                                          sx={{ padding: "4px 16px " }}
                                        >
                                          <span
                                            className="text-white ms-2"
                                            style={{
                                              background: "#0f3445",
                                              padding: 4,
                                              borderRadius: 5,
                                            }}
                                          >
                                            1750
                                          </span>
                                        </TableCell>
                                      </TableRow>
                                    ))}
                                  </TableBody>
                                </TableContainer>
                              </div>
                            </div>
                          </TabContext>
                        </div>
                      </TableContainer>
                    </TabPanel>
                    <TabPanel value="5" sx={{ padding: "0 !important" }}>
                      <TableContainer className="table-resp">
                        <Table
                          className="table-responsive"
                          component={Paper}
                          sx={{
                            background: "var(--market-fav-card-bg-color)",
                            minWidth: "auto",
                            maxWidth: "auto",
                            backgroundColor: "var(--market-fav-card-bg-color)",
                          }}
                          aria-label="simple table"
                        >
                          <TableHead sx={{ border: 0 }}>
                            <TableRow>
                              <TableCell
                                align="left"
                                sx={{
                                  color: "#7b8d9b",
                                  fontSize: "15px",
                                  fontWeight: 600,
                                  marginRight: "5px",
                                  borderBottom: "none",
                                  padding: "4px 16px ",
                                }}
                              >
                                <div className="d-flex me-2">
                                  Token
                                  {
                                    <div className="my-1">
                                      <i
                                        className="bi bi-caret-up d-block ms-2"
                                        style={{ fontSize: "9px" }}
                                      ></i>{" "}
                                      <i
                                        className="bi bi-caret-down ms-2"
                                        style={{ fontSize: "9px" }}
                                      ></i>{" "}
                                    </div>
                                  }{" "}
                                </div>
                              </TableCell>
                              <TableCell
                                align="left"
                                sx={{
                                  color: "#7b8d9b",
                                  fontSize: "15px",
                                  fontWeight: 600,
                                  marginRight: 15,
                                  borderBottom: "none",
                                  padding: "4px 16px ",
                                }}
                              >
                                <div className="d-flex me-2">
                                  Price
                                  {
                                    <div className="my-1">
                                      <i
                                        className="bi bi-caret-up d-block ms-2"
                                        style={{ fontSize: "9px" }}
                                      ></i>{" "}
                                      <i
                                        className="bi bi-caret-down ms-2"
                                        style={{ fontSize: "9px" }}
                                      ></i>{" "}
                                    </div>
                                  }{" "}
                                </div>
                              </TableCell>
                              <TableCell
                                align="left"
                                sx={{
                                  color: "#7b8d9b",
                                  fontSize: "15px",
                                  fontWeight: 600,
                                  marginRight: 50,
                                  borderBottom: "none",
                                  padding: "4px 16px ",
                                }}
                              >
                                <div className="d-flex me-2">
                                  Change%
                                  {
                                    <div className="my-1">
                                      <i
                                        className="bi bi-caret-up d-block ms-2"
                                        style={{ fontSize: "9px" }}
                                      ></i>{" "}
                                      <i
                                        className="bi bi-caret-down ms-2"
                                        style={{ fontSize: "9px" }}
                                      ></i>{" "}
                                    </div>
                                  }{" "}
                                </div>
                              </TableCell>
                            </TableRow>
                          </TableHead>
                          <TableBody>
                            {rows.map((row) => (
                              <TableRow
                                key={row.name}
                                sx={{ "td, th": { border: 0 } }}
                              >
                                <TableCell
                                  sx={{ color: "white", padding: "4px 16px " }}
                                  component="th"
                                  scope="row"
                                >
                                  <Typography>
                                    <span className="d-flex">
                                      BTC/{" "}
                                      <span className="text-muted"> USDT </span>{" "}
                                      <span
                                        style={{
                                          fontSize: "10px",
                                          backgroundColor: "#FFBF0080",
                                          color: "#FFBF00",
                                          padding: "4px",
                                          marginLeft: "4px",
                                          borderRadius: "5px",
                                        }}
                                      >
                                        10X
                                      </span>
                                    </span>
                                  </Typography>
                                  <span className="text-muted">Bitcoin</span>
                                </TableCell>
                                <TableCell
                                  align="left"
                                  sx={{ color: "white", padding: "4px 16px" }}
                                >
                                  <Typography> 2.22198</Typography>
                                  <span className="text-muted">$4.57</span>
                                </TableCell>
                                <TableCell
                                  align="left"
                                  sx={{ padding: "4px 16px" }}
                                >
                                  {" "}
                                  <div className="d-flex">
                                    {" "}
                                    <div>
                                      <Typography
                                        sx={{
                                          color: "var(--icon-color)",
                                          fontWeight: 600,
                                        }}
                                      >
                                        +1.12%
                                      </Typography>
                                      <span className="text-muted">$4.57</span>{" "}
                                    </div>
                                    <StarIcon
                                      sx={{ color: "#FFBF00" }}
                                      className="ms-2"
                                    />{" "}
                                  </div>
                                </TableCell>
                              </TableRow>
                            ))}
                          </TableBody>
                        </Table>
                        <div
                          className="mb-2"
                          style={{
                            border: "2px solid rgba(26, 148, 174, 0.2)",
                            borderRight: 0,
                            borderLeft: 0,
                            padding: 10,
                          }}
                        >
                          <TabContext value={value}>
                            <Box>
                              <TabList
                                onChange={onChange}
                                aria-label="lab API tabs example"
                              >
                                <Tab
                                  style={{
                                    borderBottom: "2px solid #1A94AE",
                                    fontSize: "10px",
                                    marginLeft: 4,
                                  }}
                                  label="Market Trades"
                                  value="1"
                                  className="MuiButtonBase-root MuiTab-root MuiTab-textColorPrimary Mui-selected css-1h9z7r5-MuiButtonBase-root-MuiTab-root"
                                />
                              </TabList>
                            </Box>

                            <div className="tab-content" id="pills-tabContent">
                              <div
                                className="tab-pane fade show active"
                                id="pills-home"
                                role="tabpanel"
                                aria-labelledby="pills-home-tab"
                              >
                                <TableContainer className="table-resp">
                                  <TableHead sx={{ border: 0 }}>
                                    <TableRow>
                                      <TableCell
                                        align="left"
                                        sx={{
                                          color: "rgba(255, 255, 255, 0.5);",
                                          fontSize: "15px",
                                          marginRight: "5px",
                                          padding: "4px 16px ",
                                          borderBottom: "none",
                                        }}
                                      >
                                        Price(USDT)
                                      </TableCell>
                                      <TableCell
                                        align="right"
                                        sx={{
                                          color: "rgba(255, 255, 255, 0.5);",
                                          fontSize: "15px",
                                          marginRight: 15,
                                          borderBottom: "none",
                                          padding: "4px 16px ",
                                        }}
                                      >
                                        Quantity(SOS)
                                      </TableCell>
                                      <TableCell
                                        align="right"
                                        sx={{
                                          color: "rgba(255, 255, 255, 0.5);",
                                          fontSize: "15px",
                                          marginRight: 50,
                                          borderBottom: "none",
                                          padding: "4px 16px ",
                                        }}
                                      >
                                        Time
                                      </TableCell>
                                    </TableRow>
                                  </TableHead>
                                  <TableBody>
                                    {rows.map((row) => (
                                      <TableRow
                                        key={row.name}
                                        sx={{
                                          "td, th": { border: 0 },
                                          marginTop: 5,
                                        }}
                                      >
                                        <TableCell
                                          sx={{
                                            color: "var(--icon-color)",
                                            padding: "4px 16px",
                                          }}
                                          component="th"
                                          scope="row"
                                        >
                                          {row.name}
                                        </TableCell>
                                        <TableCell
                                          align="center"
                                          sx={{
                                            color: "white",
                                            padding: "4px 16px ",
                                          }}
                                        >
                                          {row.calories}
                                        </TableCell>
                                        <TableCell
                                          align="left"
                                          sx={{ padding: "4px 16px " }}
                                        >
                                          <span
                                            className="text-white ms-2"
                                            style={{
                                              background: "#0f3445",
                                              padding: 4,
                                              borderRadius: 5,
                                            }}
                                          >
                                            1750
                                          </span>
                                        </TableCell>
                                      </TableRow>
                                    ))}
                                  </TableBody>
                                </TableContainer>
                              </div>
                            </div>
                          </TabContext>
                        </div>
                      </TableContainer>
                    </TabPanel>
                    <TabPanel value="6" sx={{ padding: "0 !important" }}>
                      <TableContainer className="table-resp">
                        <Table
                          className="table-responsive"
                          component={Paper}
                          sx={{
                            background: "var(--market-fav-card-bg-color)",
                            minWidth: "auto",
                            maxWidth: "auto",
                            backgroundColor: "var(--market-fav-card-bg-color)",
                          }}
                          aria-label="simple table"
                        >
                          <TableHead sx={{ border: 0 }}>
                            <TableRow>
                              <TableCell
                                align="left"
                                sx={{
                                  color: "#7b8d9b",
                                  fontSize: "15px",
                                  fontWeight: 600,
                                  marginRight: "5px",
                                  borderBottom: "none",
                                  padding: "4px 16px ",
                                }}
                              >
                                <div className="d-flex me-2">
                                  Token
                                  {
                                    <div className="my-1">
                                      <i
                                        className="bi bi-caret-up d-block ms-2"
                                        style={{ fontSize: "9px" }}
                                      ></i>{" "}
                                      <i
                                        className="bi bi-caret-down ms-2"
                                        style={{ fontSize: "9px" }}
                                      ></i>{" "}
                                    </div>
                                  }{" "}
                                </div>
                              </TableCell>
                              <TableCell
                                align="left"
                                sx={{
                                  color: "#7b8d9b",
                                  fontSize: "15px",
                                  fontWeight: 600,
                                  marginRight: 15,
                                  borderBottom: "none",
                                  padding: "4px 16px ",
                                }}
                              >
                                <div className="d-flex me-2">
                                  Price
                                  {
                                    <div className="my-1">
                                      <i
                                        className="bi bi-caret-up d-block ms-2"
                                        style={{ fontSize: "9px" }}
                                      ></i>{" "}
                                      <i
                                        className="bi bi-caret-down ms-2"
                                        style={{ fontSize: "9px" }}
                                      ></i>{" "}
                                    </div>
                                  }{" "}
                                </div>
                              </TableCell>
                              <TableCell
                                align="left"
                                sx={{
                                  color: "#7b8d9b",
                                  fontSize: "15px",
                                  fontWeight: 600,
                                  marginRight: 50,
                                  borderBottom: "none",
                                  padding: "4px 16px ",
                                }}
                              >
                                <div className="d-flex me-2">
                                  Change%
                                  {
                                    <div className="my-1">
                                      <i
                                        className="bi bi-caret-up d-block ms-2"
                                        style={{ fontSize: "9px" }}
                                      ></i>{" "}
                                      <i
                                        className="bi bi-caret-down ms-2"
                                        style={{ fontSize: "9px" }}
                                      ></i>{" "}
                                    </div>
                                  }{" "}
                                </div>
                              </TableCell>
                            </TableRow>
                          </TableHead>
                          <TableBody>
                            {rows.map((row) => (
                              <TableRow
                                key={row.name}
                                sx={{ "td, th": { border: 0 } }}
                              >
                                <TableCell
                                  sx={{ color: "white", padding: "4px 16px " }}
                                  component="th"
                                  scope="row"
                                >
                                  <Typography>
                                    <span className="d-flex">
                                      BTC/{" "}
                                      <span className="text-muted"> USDT </span>{" "}
                                      <span
                                        style={{
                                          fontSize: "10px",
                                          backgroundColor: "#FFBF0080",
                                          color: "#FFBF00",
                                          padding: "4px",
                                          marginLeft: "4px",
                                          borderRadius: "5px",
                                        }}
                                      >
                                        10X
                                      </span>
                                    </span>
                                  </Typography>
                                  <span className="text-muted">Bitcoin</span>
                                </TableCell>
                                <TableCell
                                  align="left"
                                  sx={{ color: "white", padding: "4px 16px" }}
                                >
                                  <Typography> 2.22198</Typography>
                                  <span className="text-muted">$4.57</span>
                                </TableCell>
                                <TableCell
                                  align="left"
                                  sx={{ padding: "4px 16px" }}
                                >
                                  {" "}
                                  <div className="d-flex">
                                    {" "}
                                    <div>
                                      <Typography
                                        sx={{
                                          color: "var(--icon-color)",
                                          fontWeight: 600,
                                        }}
                                      >
                                        +1.12%
                                      </Typography>
                                      <span className="text-muted">$4.57</span>{" "}
                                    </div>
                                    <StarIcon
                                      sx={{ color: "#FFBF00" }}
                                      className="ms-2"
                                    />{" "}
                                  </div>
                                </TableCell>
                              </TableRow>
                            ))}
                          </TableBody>
                        </Table>
                        <div
                          className="mb-2"
                          style={{
                            border: "2px solid rgba(26, 148, 174, 0.2)",
                            borderRight: 0,
                            borderLeft: 0,
                            padding: 10,
                          }}
                        >
                          <TabContext value={value}>
                            <Box>
                              <TabList
                                onChange={onChange}
                                aria-label="lab API tabs example"
                              >
                                <Tab
                                  style={{
                                    borderBottom: "2px solid #1A94AE",
                                    fontSize: "10px",
                                    marginLeft: 4,
                                  }}
                                  label="Market Trades"
                                  value="1"
                                  className="MuiButtonBase-root MuiTab-root MuiTab-textColorPrimary Mui-selected css-1h9z7r5-MuiButtonBase-root-MuiTab-root"
                                />
                              </TabList>
                            </Box>

                            <div className="tab-content" id="pills-tabContent">
                              <div
                                className="tab-pane fade show active"
                                id="pills-home"
                                role="tabpanel"
                                aria-labelledby="pills-home-tab"
                              >
                                <TableContainer className="table-resp">
                                  <TableHead sx={{ border: 0 }}>
                                    <TableRow>
                                      <TableCell
                                        align="left"
                                        sx={{
                                          color: "rgba(255, 255, 255, 0.5);",
                                          fontSize: "15px",
                                          marginRight: "5px",
                                          padding: "4px 16px ",
                                          borderBottom: "none",
                                        }}
                                      >
                                        Price(USDT)
                                      </TableCell>
                                      <TableCell
                                        align="right"
                                        sx={{
                                          color: "rgba(255, 255, 255, 0.5);",
                                          fontSize: "15px",
                                          marginRight: 15,
                                          borderBottom: "none",
                                          padding: "4px 16px ",
                                        }}
                                      >
                                        Quantity(SOS)
                                      </TableCell>
                                      <TableCell
                                        align="right"
                                        sx={{
                                          color: "rgba(255, 255, 255, 0.5);",
                                          fontSize: "15px",
                                          marginRight: 50,
                                          borderBottom: "none",
                                          padding: "4px 16px ",
                                        }}
                                      >
                                        Time
                                      </TableCell>
                                    </TableRow>
                                  </TableHead>
                                  <TableBody>
                                    {rows.map((row) => (
                                      <TableRow
                                        key={row.name}
                                        sx={{
                                          "td, th": { border: 0 },
                                          marginTop: 5,
                                        }}
                                      >
                                        <TableCell
                                          sx={{
                                            color: "var(--icon-color)",
                                            padding: "4px 16px",
                                          }}
                                          component="th"
                                          scope="row"
                                        >
                                          {row.name}
                                        </TableCell>
                                        <TableCell
                                          align="center"
                                          sx={{
                                            color: "white",
                                            padding: "4px 16px ",
                                          }}
                                        >
                                          {row.calories}
                                        </TableCell>
                                        <TableCell
                                          align="left"
                                          sx={{ padding: "4px 16px " }}
                                        >
                                          <span
                                            className="text-white ms-2"
                                            style={{
                                              background: "#0f3445",
                                              padding: 4,
                                              borderRadius: 5,
                                            }}
                                          >
                                            1750
                                          </span>
                                        </TableCell>
                                      </TableRow>
                                    ))}
                                  </TableBody>
                                </TableContainer>
                              </div>
                            </div>
                          </TabContext>
                        </div>
                      </TableContainer>
                    </TabPanel>
                  </TabContext>
                </Box>
              </CardContent>
            </Card>
          </Grid>
        </Grid>
        <Grid item xs={12} lg={12} md={3}>
          <Box className="my-4">
            <TableContainer component={Paper}>
              <Table
                sx={{ minWidth: 650, background: "var(--market-table-bg-clr)" }}
                aria-label="simple table"
              >
                <TableHead>
                  <div>
                    <>
                      <TabContext value={trending}>
                        <Box sx={{ marginTop: "10px" }}>
                          <TabList
                            variant="scrollable"
                            onChange={trending}
                            aria-label="lab API tabs example"
                          >
                            <Tab
                              sx={{
                                fontSize: "15px",
                                color: "white",
                                fontWeight: 500,
                                textTransform: "none",
                              }}
                              label="Limit Order [0]"
                              value="01"
                            />
                            <Tab
                              label="Stop-Limit order"
                              sx={{
                                fontSize: "15px",
                                color: " white",
                                fontWeight: 500,
                                textTransform: "none",
                              }}
                              value="02"
                            />
                            <Tab
                              label="Order History"
                              sx={{
                                fontSize: "15px",
                                color: " white",
                                fontWeight: 500,
                                textTransform: "none",
                              }}
                              value="03"
                            />
                          </TabList>
                        </Box>
                      </TabContext>
                    </>
                  </div>
                  <TableRow
                    sx={{
                      border: "2px solid grey",
                      borderRight: 0,
                      borderLeft: 0,
                    }}
                  >
                    <TableCell
                      sx={{
                        fontWeight: "bolder !important",
                        color: "grey !important",
                      }}
                      align="center"
                    >
                      Trending Pair
                    </TableCell>
                    <TableCell
                      sx={{
                        fontWeight: "bolder !important",
                        color: "grey !important",
                      }}
                      align="left"
                    >
                      <div className="d-flex me-2">
                        Time{" "}
                        {
                          <div className="my-1">
                            <i
                              className="bi bi-caret-up d-block ms-2"
                              style={{ fontSize: "9px" }}
                            ></i>{" "}
                            <i
                              className="bi bi-caret-down ms-2"
                              style={{ fontSize: "9px" }}
                            ></i>{" "}
                          </div>
                        }{" "}
                      </div>
                    </TableCell>
                    <TableCell
                      sx={{
                        fontWeight: "bolder !important",
                        color: "grey !important",
                      }}
                      align="left"
                    >
                      <div className="d-flex me-2">
                        Direction{" "}
                        {
                          <div className="my-1">
                            <i
                              className="bi bi-caret-up d-block ms-2"
                              style={{ fontSize: "9px" }}
                            ></i>{" "}
                            <i
                              className="bi bi-caret-down ms-2"
                              style={{ fontSize: "9px" }}
                            ></i>{" "}
                          </div>
                        }{" "}
                      </div>
                    </TableCell>
                    <TableCell
                      sx={{
                        fontWeight: "bolder !important",
                        color: "grey !important",
                      }}
                      align="left"
                    >
                      <div className="d-flex me-2">
                        Price
                        {
                          <div className="my-1">
                            <i
                              className="bi bi-caret-up d-block ms-2"
                              style={{ fontSize: "9px" }}
                            ></i>{" "}
                            <i
                              className="bi bi-caret-down ms-2"
                              style={{ fontSize: "9px" }}
                            ></i>{" "}
                          </div>
                        }{" "}
                      </div>
                    </TableCell>
                    <TableCell
                      sx={{
                        fontWeight: "bolder !important",
                        color: "grey !important",
                      }}
                      align="left"
                    >
                      <div className="d-flex me-2">
                        Filled/Quality
                        {
                          <div className="my-1">
                            <i
                              className="bi bi-caret-up d-block ms-2"
                              style={{ fontSize: "9px" }}
                            ></i>{" "}
                            <i
                              className="bi bi-caret-down ms-2"
                              style={{ fontSize: "9px" }}
                            ></i>{" "}
                          </div>
                        }{" "}
                      </div>
                    </TableCell>
                    <TableCell
                      sx={{
                        fontWeight: "bolder !important",
                        color: "grey !important",
                      }}
                      align="left"
                    >
                      <div className="d-flex me-2">
                        Amount
                        {
                          <div className="my-1">
                            <i
                              className="bi bi-caret-up d-block ms-2"
                              style={{ fontSize: "9px" }}
                            ></i>{" "}
                            <i
                              className="bi bi-caret-down ms-2"
                              style={{ fontSize: "9px" }}
                            ></i>{" "}
                          </div>
                        }{" "}
                      </div>
                    </TableCell>
                    <TableCell
                      sx={{
                        fontWeight: "bolder !important",
                        color: "grey !important",
                      }}
                      align="left"
                    >
                      <button className="btn text-muted fw-bold">
                        Cancel All
                      </button>
                    </TableCell>
                  </TableRow>
                </TableHead>
                <TableBody>
                  <TableRow
                    sx={{ "&:last-child td, &:last-child th": { border: 0 } }}
                  >
                    <TableCell
                      align="center"
                      colSpan={7}
                      sx={{ justifyContent: "center", alignItems: "center" }}
                    >
                      <img src={NODATA} />
                    </TableCell>
                  </TableRow>
                </TableBody>
              </Table>
            </TableContainer>
          </Box>
        </Grid>
      </div>
    </div>
  );
}
