import { Box, Container } from "@mui/system";
import React, { useState } from "react";
import "./index.css";
import redWave from "../../components/assets/images/redwave.png";
import SearchIcon from "@mui/icons-material/Search";
import Tab from "@mui/material/Tab";
import { TabPanel, TabList, TabContext } from "@mui/lab";
import { makeStyles } from "@mui/styles";
import MarketTable from "./marketTable";
import { Tabs, Typography } from "@mui/material";
import MarketTableJson from "../../hooks/marketTable";
const useStyles = makeStyles({
  MUITab: {
    color: "white !important",
    fontSize: "16px !important",
  },
});
export default function MarketFavourites() {
  const [data, setData] = useState(MarketTableJson);
  const [value, setValue] = React.useState("1");
  const handleChange = (event, newValue) => {
    setValue(newValue);
  };
  const classes = useStyles();
  return (
    <div>
      <Box sx={{ width: "100%", typography: "body1", color: "white" }}>
        <Box>
          <div
            className="box-style mb-4 d-flex p-1"
            style={{ width: "100%", overflowX: "scroll" }}
          >
            <div className="col-lg-2 col-md-3 col-sm-6 p-3 border-style mb-2">
              <Typography sx={{ fontWeight: 700, lineHeight: "38px" }}>
                BTC/USDT
                <span className="ms-2" style={{ color: "red" }}>
                  -1.17%
                </span>
              </Typography>
              <div className="d-flex justify-content-between">
                <Typography
                  sx={{ fontWeight: 700, lineHeight: "38px", marginTop: 1 }}
                >
                  48306.49
                </Typography>
                <img src={redWave} className="img-size" />
              </div>

              <Typography
                color={"grey"}
                sx={{ fontWeight: 700, lineHeight: "38px" }}
              >
                24H VOL 1,222.279
              </Typography>
            </div>
            <div className="col-lg-2 col-md-3 col-sm-6 p-3 border-style mb-2">
              <Typography sx={{ fontWeight: 700, lineHeight: "38px" }}>
                BTC/USDT{" "}
                <span className="ms-2" style={{ color: "red" }}>
                  -1.17%
                </span>
              </Typography>
              <div className="d-flex justify-content-between">
                <Typography
                  sx={{ fontWeight: 700, lineHeight: "38px", marginTop: 1 }}
                >
                  48306.49
                </Typography>
                <img src={redWave} className="img-size" />
              </div>

              <Typography
                color={"grey"}
                sx={{ fontWeight: 700, lineHeight: "38px" }}
              >
                24H VOL 1,222.279
              </Typography>
            </div>
            <div className="col-lg-2 col-md-3 col-sm-6 p-3 border-style mb-2">
              <Typography sx={{ fontWeight: 700, lineHeight: "38px" }}>
                BTC/USDT{" "}
                <span className="ms-2" style={{ color: "red" }}>
                  -1.17%
                </span>
              </Typography>
              <div className="d-flex justify-content-between">
                <Typography
                  sx={{ fontWeight: 700, lineHeight: "38px", marginTop: 1 }}
                >
                  48306.49
                </Typography>
                <img src={redWave} className="img-size" />
              </div>

              <Typography
                color={"grey"}
                sx={{ fontWeight: 700, lineHeight: "38px" }}
              >
                24H VOL 1,222.279
              </Typography>
            </div>
            <div className="col-lg-2 col-md-3 col-sm-6 p-3 border-style mb-2">
              <Typography sx={{ fontWeight: 700, lineHeight: "38px" }}>
                BTC/USDT{" "}
                <span className="ms-2" style={{ color: "red" }}>
                  -1.17%
                </span>
              </Typography>
              <div className="d-flex justify-content-between">
                <Typography
                  sx={{ fontWeight: 700, lineHeight: "38px", marginTop: 1 }}
                >
                  48306.49
                </Typography>
                <img src={redWave} className="img-size" />
              </div>

              <Typography
                color={"grey"}
                sx={{ fontWeight: 700, lineHeight: "38px" }}
              >
                24H VOL 1,222.279
              </Typography>
            </div>
            <div className="col-lg-2 col-md-3 col-sm-6 p-3 border-style mb-2">
              <Typography sx={{ fontWeight: 700, lineHeight: "38px" }}>
                BTC/USDT{" "}
                <span className="ms-2" style={{ color: "red" }}>
                  -1.17%
                </span>
              </Typography>
              <div className="d-flex justify-content-between">
                <Typography
                  sx={{ fontWeight: 700, lineHeight: "38px", marginTop: 1 }}
                >
                  48306.49
                </Typography>
                <img src={redWave} className="img-size" />
              </div>

              <Typography
                color={"grey"}
                sx={{ fontWeight: 700, lineHeight: "38px" }}
              >
                24H VOL 1,222.279
              </Typography>
            </div>
            <div className="col-lg-2 col-md-3 col-sm-6 p-3  mb-2">
              <Typography sx={{ fontWeight: 700, lineHeight: "38px" }}>
                BTC/USDT{" "}
                <span className="ms-2" style={{ color: "red" }}>
                  -1.17%
                </span>
              </Typography>
              <div className="d-flex justify-content-between">
                <Typography
                  sx={{ fontWeight: 700, lineHeight: "38px", marginTop: 1 }}
                >
                  48306.49
                </Typography>
                <img src={redWave} className="img-size" />
              </div>

              <Typography
                color={"grey"}
                sx={{ fontWeight: 700, lineHeight: "38px" }}
              >
                24H VOL 1,222.279
              </Typography>
            </div>
          </div>
        </Box>
        <Container>
          <TabContext value={value}>
            <Container
              sx={{ display: "flex", justifyContent: "space-between" }}
            >
              <Tabs
                value={value}
                onChange={handleChange}
                variant="scrollable"
                scrollButtons="auto"
                aria-label="scrollable auto tabs example"
              >
                <Tab className={classes.MUITab} label="Favourites" value="1" />
                <Tab
                  className={classes.MUITab}
                  label="Spot Markets"
                  value="2"
                />
                <Tab className={classes.MUITab} label="Margin" value="3" />
                <Tab className={classes.MUITab} label="ETF Markets" value="4" />
                <Tab
                  className={classes.MUITab}
                  label="Futures Markets"
                  value="5"
                />
              </Tabs>
              <div>
                <input
                  type="text"
                  className="form-control input-typing-space col-sm-5 market-input-bg"
                />
                <span className="search-icon pe-2 text-dark">
                  <SearchIcon className="search-icon-clr"/>
                </span>
              </div>
            </Container>
            <TabPanel value="1">
              <MarketTable data={data[0].Favourites} name={true} textOptions={false} ETF={false}/>
            </TabPanel>
            <TabPanel value="2">
              <MarketTable data={data[0].SpotMarkets} name={true} buttons={true} textOptions={true} ETF={false}/>
            </TabPanel>
            <TabPanel value="3">
              <MarketTable data={data[0].Margin} name={true} buttons={true} textOptions={false} ETF={false}/>
            </TabPanel>
            <TabPanel value="4">
              <MarketTable data={data[0].ETFMarkets} name={true} textOptions={false} ETF={true}/>
            </TabPanel>
            <TabPanel value="5">
              <MarketTable data={data[0].FuturesMarkets} name={false} buttons={false} textOptions={false} ETF={false}/>
            </TabPanel>
          </TabContext>
        </Container>
      </Box>
    </div>
  );
}
