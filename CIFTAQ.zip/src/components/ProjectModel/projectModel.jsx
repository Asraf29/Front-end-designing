import * as React from 'react';
import Button from '@mui/material/Button';
import { styled } from '@mui/material/styles';
import Dialog from '@mui/material/Dialog';
import DialogTitle from '@mui/material/DialogTitle';
import DialogContent from '@mui/material/DialogContent';
import DialogActions from '@mui/material/DialogActions';
import IconButton from '@mui/material/IconButton';
import CloseIcon from '@mui/icons-material/Close';
import InputLabel from '@mui/material/InputLabel';
import MenuItem from '@mui/material/MenuItem';
import FormHelperText from '@mui/material/FormHelperText';
import FormControl from '@mui/material/FormControl';
import Select, { SelectChangeEvent } from '@mui/material/Select';
import './index.css'
import { FormControlLabel, Grid, Typography } from '@mui/material';
import AutorenewIcon from '@mui/icons-material/Autorenew';
import { Box } from '@mui/system';
const BootstrapDialog = styled(Dialog)(({ theme }) => ({
    '& .MuiDialogContent-root': {
        padding: theme.spacing(2),
    },
    '& .MuiDialogActions-root': {
        padding: theme.spacing(1),
    },
}));

const BootstrapDialogTitle = (props) => {
    const { children, onClose, ...other } = props;

    return (
        <DialogTitle sx={{ m: 0, p: 2 }} {...other}>
            {children}
            {onClose ? (
                <IconButton
                    aria-label="close"
                    onClick={onClose}
                    sx={{
                        position: 'absolute',
                        right: 8,
                        top: 8,
                        color: (theme) => theme.palette.grey[500],
                    }}
                >
                    <CloseIcon />
                </IconButton>
            ) : null}
        </DialogTitle>
    );
};

const ProjectModels = (props) => {
    const { ProjectModel, handleClickOpen, handleClose } = props;


    return (
        <div>
            <BootstrapDialog
                onClose={() => { handleClose() }}
                aria-labelledby="customized-dialog-title"
                open={ProjectModel}
                className="modal-bg-color"
            >
                <BootstrapDialogTitle id="customized-dialog-title" className="fw-bold" onClose={handleClose}>
                Project details
                </BootstrapDialogTitle>
                <DialogContent className="modal-width-project">
<div className='d-flex card-text'>
    <Typography sx={{fontSize:20, fontWeight:800}}>DFD</Typography>
    <Typography className='text-muted ms-2 fw-bold' sx={{fontSize:15}}>DFD</Typography>
    <Button className='ms-2 mb-4 btn-hv'  variant='contained'  size="small" sx={{background:'#1a94ae'}}>ISSUE 18</Button>
</div>
<div className='card-text'>
    <b className='me-4' style={{fontSize:'14px'}}>Number of votes <span style={{color:'#1a94ae'}}>179852</span> votes</b>
    <b style={{fontSize:'14px'}}>Ranking <span style={{color:'#1a94ae'}}>1</span></b>
    
</div>
                </DialogContent>
            
            </BootstrapDialog>
        </div>
    );
}
export default ProjectModels; 
