import * as React from "react";
import Button from "@mui/material/Button";
import { styled } from "@mui/material/styles";
import Dialog from "@mui/material/Dialog";
import DialogTitle from "@mui/material/DialogTitle";
import DialogContent from "@mui/material/DialogContent";
import DialogActions from "@mui/material/DialogActions";
import IconButton from "@mui/material/IconButton";
import CloseIcon from "@mui/icons-material/Close";
import { Box, Card, CardContent, Grid, Paper, Table, TableBody, TableCell, TableContainer, TableHead, TableRow, Typography } from "@mui/material";
import './index.css'
const BootstrapDialog = styled(Dialog)(({ theme }) => ({
    "& .MuiDialogContent-root": {
        padding: theme.spacing(2),
    },
    "& .MuiDialogActions-root": {
        padding: theme.spacing(1),
    },
}));

const BootstrapDialogTitle = (props) => {
    const { children, onClose, ...other } = props;

    return (
        <DialogTitle sx={{ m: 0, p: 2 }} {...other}>
            {children}
            {onClose ? (
                <IconButton
                    aria-label="close"
                    onClick={onClose}
                    sx={{
                        position: "absolute",
                        right: 8,
                        top: 8,
                        color: (theme) => theme.palette.grey[500],
                    }}
                >
                    <CloseIcon />
                </IconButton>
            ) : null}
        </DialogTitle>
    );
};

const SnapshotModal = (props) => {
    const { openSnapshotModal, handleSnapshotClickOpen, handleSnapshotModalClose } = props;

    return (
        <div>
            <BootstrapDialog onClose={() => { handleSnapshotClickOpen(); }} aria-labelledby="customized-dialog-title" open={openSnapshotModal} className="modal-bg-color">
                <BootstrapDialogTitle id="customized-dialog-title" className="fw-bold text-center fontsize-title-sm pt-4 pb-0 mb-0" onClose={handleSnapshotModalClose}>
                    MX position snapshot(UTC+8)
                </BootstrapDialogTitle>
                <DialogContent className="snapShotMoadl-width pb-0">
                    <TableContainer component={Paper} sx={{ background: "var( --card-bg-color)" }} className="mt-4">
                        <Table sx={{ background: "var( --card-bg-color)" }}>
                            <TableHead>
                                <TableRow>
                                    <TableCell sx={{ fontWeight: "bolder !important" }} className="table-head-clr border-0 py-0" align="left">
                                        SnapShot time(UTC+8)
                                    </TableCell>
                                    <TableCell sx={{ fontWeight: "bolder !important" }} className="table-head-clr border-0 py-0" align="center">
                                        First snapshot
                                    </TableCell>
                                    <TableCell sx={{ fontWeight: "bolder !important" }} className="table-head-clr border-0 py-0" align="center">
                                        Second snapshot
                                    </TableCell>
                                    <TableCell sx={{ fontWeight: "bolder !important" }} className="table-head-clr border-0 py-1" align="center">
                                        Third snapshot
                                    </TableCell>
                                </TableRow>
                            </TableHead>
                            <TableBody>
                                <TableRow className="border-0">
                                    <TableCell colSpan={4} sx={{ fontWeight: "bolder !important" }} className="textClr border-0" align="left">
                                        <Typography className="text-center emptyDataClr fw-bold">No data</Typography>
                                    </TableCell>
                                </TableRow>
                            </TableBody>
                        </Table>
                    </TableContainer>
                </DialogContent>
                <DialogActions className="my-1 me-2">
                    <Button autoFocus onClick={() => handleSnapshotModalClose()} className="modal-greenbtn">
                        <span style={{ opacity: "80%", fontWeight: "400px", textTransform: 'none' }}>Confirm</span>
                    </Button>
                </DialogActions>
            </BootstrapDialog>
        </div>
    );
};
export default SnapshotModal;
