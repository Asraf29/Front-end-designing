import * as React from 'react';
import Button from '@mui/material/Button';
import { styled } from '@mui/material/styles';
import Dialog from '@mui/material/Dialog';
import DialogTitle from '@mui/material/DialogTitle';
import DialogContent from '@mui/material/DialogContent';
import DialogActions from '@mui/material/DialogActions';
import IconButton from '@mui/material/IconButton';
import CloseIcon from '@mui/icons-material/Close';
import AutorenewIcon from '@mui/icons-material/Autorenew';
// import './index.css'
const BootstrapDialog = styled(Dialog)(({ theme }) => ({
    '& .MuiDialogContent-root': {
        padding: theme.spacing(2),
    },
    '& .MuiDialogActions-root': {
        padding: theme.spacing(1),
    },
}));

const BootstrapDialogTitle = (props) => {
    const { children, onClose, ...other } = props;

    return (
        <DialogTitle sx={{ m: 0, p: 2 }} {...other}>
            {children}
            {onClose ? (
                <IconButton
                    aria-label="close"
                    onClick={onClose}
                    sx={{
                        position: 'absolute',
                        right: 8,
                        top: 8,
                        color: (theme) => theme.palette.grey[500],
                    }}
                >
                    <CloseIcon />
                </IconButton>
            ) : null}
        </DialogTitle>
    );
};


export default function TransferModal(props) {
    const { tranferModals, openTransferModal, TransferhandleClose } = props;


    return (
        <div>

            <BootstrapDialog
                onClose={() => { TransferhandleClose() }}
                aria-labelledby="customized-dialog-title"
                open={tranferModals}
                className="modal-bg-color"
            >
                <BootstrapDialogTitle id="customized-dialog-title" onClose={TransferhandleClose}>
                    Transfer
                </BootstrapDialogTitle>
                <DialogContent className="modal-width">

                    <label className='mb-2 textClr'><b className='pe-1'></b>Crypco</label>
                    <select id="form-select"
                        className="form-select mb-2"
                        aria-label="Default select example">
                        <option value="1" className='textClr'> USD </option>
                        <option value="2" className='textClr' >USDT</option>
                        <option value="3" className='textClr'>ETH</option>
                    </select>
                    <div className='d-flex'>
                        <div className='col-lg-5'>
                            <label className='mb-2 textClr'><b className='pe-1'></b>From</label>
                            <select id="form-select"
                                className="form-select"
                                aria-label="Default select example">
                                <option value="1" className='textClr'> USD </option>
                                <option value="2" className='textClr' >USDT</option>
                                <option value="3" className='textClr'>BNB</option>
                            </select>
                            <p className='textClr m-1' style={{ fontSize: '14px' }}>Balance: 0.00 USDT</p>
                        </div>
                        <div className='col-lg-2 text-center my-4 textClr'>
                            <AutorenewIcon className='my-3' fontSize={'small'} />
                        </div>

                        <div className='me-2 col-lg-5'>

                            <label className='mb-2 textClr'><b className='pe-1'></b>To</label>
                            <select id="form-select"
                                className="form-select"
                                aria-label="Default select example">
                                <option value="1" className='textClr'> USD </option>
                                <option value="2" className='textClr' >USDT</option>
                                <option value="3" className='textClr'>BNB</option>
                            </select>
                            <p className="textClr m-1" style={{ fontSize: '14px' }}>Balance: 0.00 USDT</p>
                        </div>
                    </div>
                    <div className="my-3">
                        <input
                            type="text" id="input-bg"
                            className="form-control input-typing-space-transfer col-sm-5 col-md-5"
                        />
                        <span className="input-txt-left d-flex justify-content-between pe-2 text-dark">
                            <div> <p className='textClr'>Quantity</p> </div>
                        </span>
                        <span className='input-txt-right me-2'>
                            <p className='textClr'>USDT</p>
                        </span>
                    </div>
                    <p className='textClr'>Available : 0.00USDT <a className='ms-2 linkTag' style={{color:'#1A94AE'}}>Transfer all</a> </p>
                </DialogContent>
                <DialogActions>
                    <Button size="small" autoFocus onClick={() => TransferhandleClose()} className="modal-whitebtn  m-2">
                        <span style={{ opacity: "80%", fontWeight: "400px" }}>
                            Cancel
                        </span>
                    </Button>
                    <Button size="small" autoFocus onClick={() => TransferhandleClose()} className="modal-greenbtn m-2">
                        <span style={{ opacity: "80%", fontWeight: "400px" }}>
                            Conform
                        </span>
                    </Button>
                </DialogActions>
            </BootstrapDialog>
        </div>
    );
}
