import * as React from "react";
import Button from "@mui/material/Button";
import { styled } from "@mui/material/styles";
import Dialog from "@mui/material/Dialog";
import DialogTitle from "@mui/material/DialogTitle";
import DialogContent from "@mui/material/DialogContent";
import DialogActions from "@mui/material/DialogActions";
import IconButton from "@mui/material/IconButton";
import CloseIcon from "@mui/icons-material/Close";
import InputLabel from "@mui/material/InputLabel";
import MenuItem from "@mui/material/MenuItem";
import FormHelperText from "@mui/material/FormHelperText";
import FormControl from "@mui/material/FormControl";
import Select, { SelectChangeEvent } from "@mui/material/Select";
import "./index.css";
import { FormControlLabel, Grid, Typography } from "@mui/material";
import AutorenewIcon from "@mui/icons-material/Autorenew";
import { Box } from "@mui/system";
const BootstrapDialog = styled(Dialog)(({ theme }) => ({
  "& .MuiDialogContent-root": {
    padding: theme.spacing(2),
  },
  "& .MuiDialogActions-root": {
    padding: theme.spacing(1),
  },
}));

const BootstrapDialogTitle = (props) => {
  const { children, onClose, ...other } = props;

  return (
    <DialogTitle sx={{ m: 0, p: 2 }} {...other}>
      {children}
      {onClose ? (
        <IconButton
          aria-label="close"
          onClick={onClose}
          sx={{
            position: "absolute",
            right: 8,
            top: 8,
            color: (theme) => theme.palette.grey[500],
          }}
        >
          <CloseIcon />
        </IconButton>
      ) : null}
    </DialogTitle>
  );
};

const TransferAsset = (props) => {
  const { openAssetTransferModal, handleAssetsClickOpen, handleAssetsClose } =
    props;

  return (
    <div>
      <BootstrapDialog
        onClose={() => {
          handleAssetsClickOpen();
        }}
        aria-labelledby="customized-dialog-title"
        open={openAssetTransferModal}
        className="modal-bg-color"
      >
        <BootstrapDialogTitle
          id="customized-dialog-title"
          onClose={handleAssetsClose}
        >
          Asset transfer
        </BootstrapDialogTitle>
        <DialogContent>
          <Box className="d-sm-flex align-items-center">
            <div className="d-block col-lg-5 col-md-5">
              <div>
                <label className="textColors">From</label>
              </div>
              <div>
                <select
                  style={{ width: "100%", height: "40px" }}
                  className="fw-bold inputBg textColors"
                >
                  <option value="MX">MX</option>
                </select>
              </div>
              <div>
                <label className="textClr" style={{ fontSize: "12px" }}>
                  Balance: 0 MX
                </label>
              </div>
            </div>
            <div className="d-flex col-lg-2 justify-content-center ps-0 ps-md-3 justify-content-sm-start">
              <AutorenewIcon className="text-blue" />
            </div>
            <div className="d-block col-lg-5 col-md-5">
              <div>
                <label className="textColors">To</label>
              </div>
              <div>
                <select
                  style={{ width: "100%", height: "40px" }}
                  className="fw-bold inputBg textColors"
                >
                  <option value="TMX">TMX</option>
                </select>
              </div>
              <div>
                <label className="textClr" style={{ fontSize: "12px" }}>
                  Balance: 0 TMX
                </label>
              </div>
            </div>
          </Box>
          <label className="select-title">Token</label>
          <select
            style={{ width: "100%", height: "40px" }}
            className="fw-bold my-2 inputBg textColors"
          >
            <option value="TMX">USDT</option>
          </select>
          <div className="form-group mt-3 mb-2">
            <label className="mb-2  select-title">
              <b className="require-clr pe-1">*</b>Quantity
            </label>
            <div className="d-flex">
              <div className="input-group">
                <input type="text" className="form-control quantity-placeholder inputBg" placeholder="Recipient's username" aria-label="Recipient's username" aria-describedby="basic-addon2" />
                <div className="input-group-append">
                  <button className="btn btn-outline-secondary btn-hvrs textColors inputBg">USDT</button>
                </div>
              </div>
              <button
                className="btn d-flex align-items-center getCodeBtn px-5  ms-1"
                role="button"
              >
                All
              </button>
            </div>
          </div>
        </DialogContent>
        <DialogActions className="my-1 me-2">
          <Button
            autoFocus
            onClick={() => handleAssetsClose()}
            className="modal-whitebtn"
          >
            <span style={{ opacity: "80%", fontWeight: "400px", textTransform: 'none' }}>Cancel</span>
          </Button>
          <Button
            autoFocus
            onClick={() => handleAssetsClose()}
            className="modal-greenbtn"
          >
            <span style={{ opacity: "80%", fontWeight: "400px", textTransform: 'none' }}>
              Transfer now
            </span>
          </Button>
        </DialogActions>
      </BootstrapDialog>
    </div>
  );
};
export default TransferAsset;
