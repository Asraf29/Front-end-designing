import * as React from 'react';
import Button from '@mui/material/Button';
import { styled } from '@mui/material/styles';
import Dialog from '@mui/material/Dialog';
import DialogTitle from '@mui/material/DialogTitle';
import DialogContent from '@mui/material/DialogContent';
import DialogActions from '@mui/material/DialogActions';
import IconButton from '@mui/material/IconButton';
import CloseIcon from '@mui/icons-material/Close';
import InputLabel from '@mui/material/InputLabel';
import MenuItem from '@mui/material/MenuItem';
import FormHelperText from '@mui/material/FormHelperText';
import FormControl from '@mui/material/FormControl';
import Select, { SelectChangeEvent } from '@mui/material/Select';
import InfoOutlinedIcon from '@mui/icons-material/InfoOutlined';
import './index.css'
import { ListItemText } from '@mui/material';
const BootstrapDialog = styled(Dialog)(({ theme }) => ({
    '& .MuiDialogContent-root': {
        padding: theme.spacing(2),
    },
    '& .MuiDialogActions-root': {
        padding: theme.spacing(1),
    },
}));

const BootstrapDialogTitle = (props) => {
    const { children, onClose, ...other } = props;

    return (
        <DialogTitle sx={{ m: 0, p: 2 }} {...other}>
            {children}
            {onClose ? (
                <IconButton
                    aria-label="close"
                    onClick={onClose}
                    sx={{
                        position: 'absolute',
                        right: 8,
                        top: 8,
                        color: (theme) => theme.palette.grey[500],
                    }}
                >
                    <CloseIcon />
                </IconButton>
            ) : null}
        </DialogTitle>
    );
};

const ChangePassword = (props) => {
    const [passwordShown, setPasswordShown] = React.useState(false);
    const { openChangePasswordModal, handleClose } = props;
    const togglePasswords = () => {
        setPasswordShown(!passwordShown);
    };

    return (
        <div>
            <BootstrapDialog
                onClose={() => { handleClose() }}
                aria-labelledby="customized-dialog-title"
                open={openChangePasswordModal}
                className="modal-bg-color"
            >
                <BootstrapDialogTitle id="changePasswordTitle"  onClose={handleClose}>
                    Change login password
                </BootstrapDialogTitle>
                <DialogContent className="security-modal-width">
                    <div className="d-flex px-2 bg-yellow border-radius-10 py-2 my-3 mb-5">
                        <InfoOutlinedIcon className="iconProperty fs-3" />
                        <div><ListItemText className="ps-2 text-color-black fontsize-modal-text" primary={'No withdrawal and FiAT trading within 24 hours after changing the login password'} /></div>
                    </div>
                    <div className="mb-3 form-group">
                        <label className='mb-2 text-color-black'><b className='require-clr pe-1'>*</b>Old Password</label>
                        <div>
                            <input
                                type={passwordShown ? "text" : "password"}
                                className="form-control change-pwd placeHolderColor"
                                placeholder="Please enter the old password"
                            />
                            <span className="field-icon pe-2">
                                {passwordShown ? (
                                    <i
                                        onClick={togglePasswords}
                                        className="bi bi-eye textClr"
                                    />
                                ) : (
                                    <i
                                        onClick={togglePasswords}
                                        className="bi bi-eye-slash textClr"
                                    />
                                )}
                            </span>
                        </div>
                    </div>
                    <div className="mb-3 form-group">
                        <label className='mb-2 text-color-black'><b className='require-clr pe-1'>*</b>New Password</label>
                        <div>
                            <input
                                type={passwordShown ? "text" : "password"}
                                className="form-control change-pwd placeHolderColor"
                                placeholder="Please enter the new password"
                            />
                            <span className="field-icon pe-2">
                                {passwordShown ? (
                                    <i
                                        onClick={togglePasswords}
                                        className="bi bi-eye textClr"
                                    />
                                ) : (
                                    <i
                                        onClick={togglePasswords}
                                        className="bi bi-eye-slash textClr"
                                    />
                                )}
                            </span>
                        </div>
                    </div>
                    <div className="mb-3 form-group">
                        <label className='mb-2 text-color-black'><b className='require-clr pe-1'>*</b>Confrim new password</label>
                        <div>
                            <input
                                type={passwordShown ? "text" : "password"}
                                className="form-control change-pwd placeHolderColor"
                                placeholder="Please enter the confirm password"
                            />
                            <span className="field-icon pe-2">
                                {passwordShown ? (
                                    <i
                                        onClick={togglePasswords}
                                        className="bi bi-eye textClr"
                                    />
                                ) : (
                                    <i
                                        onClick={togglePasswords}
                                        className="bi bi-eye-slash textClr"
                                    />
                                )}
                            </span>
                        </div>
                    </div>
                </DialogContent>
                <DialogActions>
                    <Button autoFocus onClick={() => handleClose()} className="modal-whitebtn mb-3">
                        <span style={{ opacity: "80%", fontWeight: "400px" }}>
                            Cancel
                        </span>
                    </Button>
                    <Button autoFocus onClick={() => handleClose()} className="modal-greenbtn mb-3 me-3">
                        <span style={{ opacity: "80%", fontWeight: "400px" }}>
                            Submit
                        </span>
                    </Button>
                </DialogActions>
            </BootstrapDialog>
        </div>
    );
}
export default ChangePassword 