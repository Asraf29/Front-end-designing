import * as React from "react";
import Button from "@mui/material/Button";
import { styled } from "@mui/material/styles";
import Dialog from "@mui/material/Dialog";
import DialogTitle from "@mui/material/DialogTitle";
import DialogContent from "@mui/material/DialogContent";
import DialogActions from "@mui/material/DialogActions";
import IconButton from "@mui/material/IconButton";
import CloseIcon from "@mui/icons-material/Close";
import InputLabel from "@mui/material/InputLabel";
import MenuItem from "@mui/material/MenuItem";
import FormHelperText from "@mui/material/FormHelperText";
import FormControl from "@mui/material/FormControl";
import Select, { SelectChangeEvent } from "@mui/material/Select";
import "./index.css";
import { FormControlLabel, Grid, Typography } from "@mui/material";
import AutorenewIcon from "@mui/icons-material/Autorenew";
import { Box } from "@mui/system";
const BootstrapDialog = styled(Dialog)(({ theme }) => ({
  "& .MuiDialogContent-root": {
    padding: theme.spacing(2),
  },
  "& .MuiDialogActions-root": {
    padding: theme.spacing(1),
  },
}));

const BootstrapDialogTitle = (props) => {
  const { children, onClose, ...other } = props;

  return (
    <DialogTitle sx={{ m: 0, p: 2 }} {...other}>
      {children}
      {onClose ? (
        <IconButton
          aria-label="close"
          onClick={onClose}
          sx={{
            position: "absolute",
            right: 8,
            top: 8,
            color: (theme) => theme.palette.grey[500],
          }}
        >
          <CloseIcon />
        </IconButton>
      ) : null}
    </DialogTitle>
  );
};

const RepaymentModel = (props) => {
  const {
    openRepaymentModal,
    handleRepaymentClickOpen,
    handleRepaymentClose,
  } = props;

  return (
    <div>
      <BootstrapDialog
        onClose={() => {
          handleRepaymentClickOpen();
        }}
        aria-labelledby="customized-dialog-title"
        open={openRepaymentModal}
        className="modal-bg-color"
      >
        <BootstrapDialogTitle
          id="customized-dialog-title"
          onClose={handleRepaymentClose}
        >
          Repayment
        </BootstrapDialogTitle>
        <DialogContent>
          <select
            style={{ width: "100%", height: "40px" }}
            className="my-2 inputBg orderSelect"
          >
            <option value="TMX">Please select the order</option>
          </select>
          <div className="form-group mb-2">
            <label className="mb-2  select-title" style={{fontSize:'13px'}}>Quantity</label>
            <div className="d-flex">
              <div className="input-group">
                <input
                  type="text"
                  className="form-control quantity-placeholder inputBg"
                  placeholder="Recipient's username"
                />
              </div>
              <button
                className="btn d-flex align-items-center getCodeBtn px-5  ms-1"
                role="button"
              >
                All
              </button>
            </div>
            <div className="d-flex justify-content-between">   
            <div className="d-block">
                  <div>
                  <label className="textClr" style={{ fontSize: "13px" }}>
                  Loan amount
                </label>
                  </div>
                  <div>
                  <label className="textClr" style={{ fontSize: "13px" }}>
                ---
                </label>
                  </div>
                  <div>
                  <label className="textClr" style={{ fontSize: "13px" }}>
                  Unpaid amount
                </label>
                  </div>
              </div>
              <div className="d-block">
                  <div>
                  <label className="textClr" style={{ fontSize: "13px" }}>
                The latest interest rate
                </label>
                  </div>
                  <div className="d-flex justify-content-end">
                  <label className="textClr" style={{ fontSize: "13px" }}>
                0%
                </label>
                  </div>
                  <div className="d-flex justify-content-end">
                  <label className="textClr" style={{ fontSize: "13px" }}>
                  Unpaid interest
                </label>
                  </div>
              </div>
              </div>
          </div>
        </DialogContent>
        <DialogActions className="my-1 me-2">
          <Button
            autoFocus
            onClick={handleRepaymentClose}
            className="modal-whitebtn"
          >
            <span
              style={{
                opacity: "80%",
                fontWeight: "400px",
                textTransform: "none",
              }}
            >
              Cancel
            </span>
          </Button>
          <Button
            autoFocus
            onClick={handleRepaymentClose}
            className="modal-greenbtn"
          >
            <span
              style={{
                opacity: "80%",
                fontWeight: "400px",
                textTransform: "none",
              }}
            >
             Repayment
            </span>
          </Button>
        </DialogActions>
      </BootstrapDialog>
    </div>
  );
};
export default RepaymentModel;
