import * as React from 'react';
import { styled } from '@mui/material/styles';
import Box from '@mui/material/Box';
import Paper from '@mui/material/Paper';
import Grid from '@mui/material/Grid';
import { Typography } from '@mui/material';
import { makeStyles } from '@mui/styles';
import twitter from '../assets/images/twitter.png';
import game from '../assets/images/game.png';
import telegram from '../assets/images/telegram.png';
import Logo from '../assets/images/Logo.png'
import MenuItem from '@mui/material/MenuItem';
import FormControl from '@mui/material/FormControl';
import Select from '@mui/material/Select';
import fb from '../assets/images/fb.png';
import linked from '../assets/images/linked.png';
import gitlab from '../assets/images/gitlab.png';
import insta from '../assets/images/insta.png';
import skype from '../assets/images/skype.png';
import './index.css'
import { useState } from 'react';

const useStyles = makeStyles({
  root: {
    background: 'linear-gradient(45deg, #FE6B8B 30%, #FF8E53 90%)',
    border: 0,
    borderRadius: 3,
    boxShadow: '0 3px 5px 2px rgba(255, 105, 135, .3)',
    color: 'white',
    height: 48,
    padding: '0 30px',
  },
  type: {
    opacity: 0.5
  },
  socialicons: {
    '@media (width: 1024px)': {
      paddingLeft: 4
    }
  },
  logoss: {
    '@media(min-width:900px)': {
      height: "100%"
    },
    '@media(width:1024px)': {
      height: "100%"
    }
  },
  logos: {

    '@media(width:1024px)': {
      marginRight: '-28px'
    }
  }
});

const Item = styled(Paper)(({ theme }) => ({
  backgroundColor: theme.palette.mode === 'dark' ? '#1A2027' : '#fff',
  ...theme.typography.body2,
  padding: theme.spacing(1),
  textAlign: 'center',
  color: theme.palette.text.secondary,
}));

export default function ColumnsGrid() {
  const [language, setLanguage] = useState(10);
  const handleChange = (event) => {
    setLanguage(event.target.value);
  };
  const classes = useStyles();

  return (
    <Box sx={{ flexGrow: 1 }} className="footer">
      <Grid container spacing={3} sx={{ color: 'white' }}>
        <Grid item xs={12} lg={2} md={2} sm={6}>
          <div className={classes.logoss} style={{ display: "flex", flexDirection: "column", justifyContent: "space-between" }}>
            <div>
              <Typography sx={{ fontWeight: 700, marginLeft: 1 }} className={classes.type}>CIFDAQ</Typography>
              <Typography sx={{ fontWeight: 700, marginLeft: 1 }} className={classes.type}>Trade Crypto Fast with CIFDAQ</Typography>
            </div>
            <select className="py-3 PropertySelection px-2">
              <option value="1">English/USD</option>
              <option value="2">Spanish</option>
              <option value="3">French</option>
            </select>
            <Grid className={classes.logos} >
              <Box
                component="img"
                sx={{
                  marginTop: '5px',
                  height: 44,
                  width: 190,
                  maxHeight: { xs: 180, md: 150 },
                  maxWidth: { xs: 180, md: 150 },
                }}
                alt="Logo"
                src={Logo}
              />
              <Typography className='textClr pt-1 ps-4'>2021 CIFDAQ Ltd</Typography>
            </Grid>
          </div>
        </Grid>
        <Grid item xs={12} lg={2} md={2} sm={6}>
          <Typography variant="h5" gutterBottom color="white">About</Typography>
          <Typography variant="subtitle1" className={classes.type} gutterBottom>About Us</Typography>
          <Typography gutterBottom component="div" className={classes.type}>Downloads</Typography>
          <Typography gutterBottom component="div" className={classes.type}>Fees</Typography>
          <Typography gutterBottom component="div" className={classes.type}>User Agreement and Privacy Policy</Typography>
          <Typography gutterBottom component="div" className={classes.type}>Risk Disclosure</Typography>
          <Typography gutterBottom component="div" className={classes.type}>Announcements</Typography>
        </Grid>
        <Grid item xs={12} lg={2} md={2} sm={6}>
          <Typography variant="h5" gutterBottom component="div">Products</Typography>
          <Typography gutterBottom component="div" className={classes.type}>PUSH</Typography>
          <Typography gutterBottom component="div" className={classes.type}>N Defi</Typography>
          <Typography gutterBottom component="div" className={classes.type}>SpaceM</Typography>
          <Typography gutterBottom component="div" className={classes.type}>M-Day</Typography>
        </Grid>
        <Grid item xs={12} lg={2} md={2} sm={6}>
          <Typography variant="h5" gutterBottom component="div">Support</Typography>
          <Typography gutterBottom component="div" className={classes.type}>List your token with MEXC</Typography>
          <Typography gutterBottom component="div" className={classes.type}>API Documentation</Typography>
          <Typography gutterBottom component="div" className={classes.type}>Help Center</Typography>
          <Typography gutterBottom component="div" className={classes.type}>Official verification Channel</Typography>
          <Typography gutterBottom component="div" className={classes.type}>VIP Priviteges</Typography>
          <Typography gutterBottom component="div" className={classes.type}>Law Enforcement Requests</Typography>
          <Typography gutterBottom component="div" className={classes.type}>Product Suggestion</Typography>
        </Grid>
        <Grid item xs={12} lg={2} md={2} sm={6}>
          <Typography variant="h5" gutterBottom component="div">Contact Us</Typography>
          <Typography gutterBottom component="div" className={classes.type}>MEXC</Typography>
          <Typography gutterBottom component="div" className={classes.type}>Let’s Collaborate (Businesses)</Typography>
          <Typography gutterBottom component="div" className={classes.type}>Let’s Collaborate (Institutions)</Typography>
          <Typography gutterBottom component="div" className={classes.type}>OTC Merchant Application</Typography>
          <Typography gutterBottom component="div" className={classes.type}>Submit a Request</Typography>
          <Typography gutterBottom component="div" className={classes.type}>Complaints and Suggestions</Typography>
          <Typography gutterBottom component="div" className={classes.type}>Media Center</Typography>
        </Grid>
        <Grid item xs={12} lg={2} md={2} sm={6}>
          <Typography variant="h5" gutterBottom component="div">Community</Typography>
          <Grid sx={{ display: 'grid', gridTemplateColumns: 'repeat(6, 1fr)' }} >
            <Grid item xs={12} lg={2} md={6} sm={6}>
              <Box
                component="img"
                sx={{
                  height: 30,
                  width: 30,
                  maxHeight: { xs: 100, md: 100 },
                  maxWidth: { xs: 100, md: 100 },
                }}
                alt="twitter"
                src={twitter}
              />
            </Grid>
            <Grid column item xs={12} lg={4} md={4} sm={6}>
              <Box
                component="img"
                className={classes.socialicons}
                sx={{
                  height: 30,
                  width: 30,
                  maxHeight: { xs: 100, md: 100 },
                  maxWidth: { xs: 100, md: 100 },
                }}
                alt="linked"
                src={linked}
              />
            </Grid>
            <Grid column item xs={12} lg={2} md={4} sm={6}>
              <Box
                component="img"
                className={classes.socialicons}
                sx={{
                  height: 30,
                  width: 30,
                  maxHeight: { xs: 100, md: 100 },
                  maxWidth: { xs: 100, md: 100 },
                }}
                alt="fb"
                src={fb}
              />
            </Grid>
            <Grid column item xs={12} lg={2} md={4} sm={6}>
              <Box
                component="img"
                className={classes.socialicons}
                sx={{
                  height: 30,
                  width: 30,
                  maxHeight: { xs: 100, md: 100 },
                  maxWidth: { xs: 100, md: 100 },
                }}
                alt="game"
                src={game}
              />
            </Grid>
          </Grid>
          <Grid sx={{ marginTop: 1, display: 'grid', gridTemplateColumns: 'repeat(6, 1fr)' }} >
            <Grid item xs={12} lg={2} md={6} sm={6}>
              <Box
                component="img"
                className={classes.socialicons}
                sx={{
                  height: 30,
                  width: 30,
                  maxHeight: { xs: 100, md: 100 },
                  maxWidth: { xs: 100, md: 100 },
                }}
                alt="telegram"
                src={telegram}
              />
            </Grid>
            <Grid column item xs={12} lg={4} md={4} sm={6}>
              <Box
                component="img"
                className={classes.socialicons}
                sx={{
                  height: 30,
                  width: 30,
                  maxHeight: { xs: 100, md: 100 },
                  maxWidth: { xs: 100, md: 100 },
                }}
                alt="gitlab"
                src={gitlab}
              />
            </Grid>
            <Grid column item xs={12} lg={2} md={4} sm={6}>
              <Box
                component="img"
                className={classes.socialicons}
                sx={{
                  height: 30,
                  width: 30,
                  maxHeight: { xs: 100, md: 100 },
                  maxWidth: { xs: 100, md: 100 },
                }}
                alt="skype"
                src={skype}
              />
            </Grid>
            <Grid column item xs={12} lg={2} md={4} sm={6}>
              <Box
                component="img"
                className={classes.socialicons}
                sx={{
                  height: 30,
                  width: 30,
                  maxHeight: { xs: 100, md: 100 },
                  maxWidth: { xs: 100, md: 100 },
                }}
                alt="insta"
                src={insta}
              />
            </Grid>
          </Grid>
        </Grid>
      </Grid>
    </Box>
  );
}