import * as React from 'react';
import Box from '@mui/material/Box';
import Button from '@mui/material/Button';
import Typography from '@mui/material/Typography';
import Modal from '@mui/material/Modal';
import CloseIcon from '@mui/icons-material/Close';
import CheckCircleOutlineOutlinedIcon from '@mui/icons-material/CheckCircleOutlineOutlined';
const style = {
  position: 'absolute',
  top: '50%',
  left: '50%',
  transform: 'translate(-50%, -50%)',
  bgcolor: 'var(--modal-bg)',
  boxShadow: 24,
  borderRadius:'8px',
  p: 4,
  minWidth:300, 
  maxWidth:465
  
};
export default function AlertBoxOne() {
  const [open, setOpen] = React.useState(false);
  const handleOpen = () => setOpen(true);
  const handleClose = () => setOpen(false);

  return (
    <div>
      <Button onClick={handleOpen}>Open modal</Button>
      <Modal
        open={open}
        onClose={handleClose}
        aria-labelledby="modal-modal-title"
        aria-describedby="modal-modal-description"
      >
       
        <Box sx={style}>
        <span style={{color:'var(--txt-alert)'}} className='d-flex justify-content-end'><CloseIcon onClick={handleClose}/></span>
            <div className='d-flex justify-content-center'>
          <Typography id="modal-modal-title" variant="h6" component="h2">
       <CheckCircleOutlineOutlinedIcon sx={{color:'var(--txt-alert)'}} fontSize={'large'}/>    </Typography> </div>
         <Typography  className='text-center ms-0 ms-sm-5' sx={{color:'var(--txt-alert)'}}>Successfully accepted!</Typography>
         <Typography  className='text-center ms-sm-5 ms-0 text-muted' sx={{textAlign:'justify'}}>Et leo, enim in non sed quis sed. Auctor natoque auctor.</Typography>
          <div class="d-grid gap-2 my-4 mb-0">
  <button onClick={handleClose} class="btn" type="button"  style={{background:'#4F4F4F', color:'white'}}>Dashboard</button>
  <button onClick={handleClose} class="btn" type="button"style={{ border: '1px solid #4F4F4F', borderRadius:'8px', color:'var(--txt-alert)'}}>Undo</button>
</div>
        </Box>
      </Modal>
    </div>
  );
}
