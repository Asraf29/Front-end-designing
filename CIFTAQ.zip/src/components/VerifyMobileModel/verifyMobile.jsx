import * as React from "react";
import Button from "@mui/material/Button";
import { styled } from "@mui/material/styles";
import Dialog from "@mui/material/Dialog";
import DialogTitle from "@mui/material/DialogTitle";
import DialogContent from "@mui/material/DialogContent";
import DialogActions from "@mui/material/DialogActions";
import IconButton from "@mui/material/IconButton";
import CloseIcon from "@mui/icons-material/Close";
// import './index.css'
const BootstrapDialog = styled(Dialog)(({ theme }) => ({
  "& .MuiDialogContent-root": {
    padding: theme.spacing(2),
  },
  "& .MuiDialogActions-root": {
    padding: theme.spacing(1),
  },
}));

const BootstrapDialogTitle = (props) => {
  const { children, onClose, ...other } = props;

  return (
    <DialogTitle sx={{ m: 0, p: 2 }} {...other}>
      {children}
      {onClose ? (
        <IconButton
          aria-label="close"
          onClick={onClose}
          sx={{
            position: "absolute",
            right: 8,
            top: 8,
            color: (theme) => theme.palette.grey[500],
          }}
        >
          <CloseIcon />
        </IconButton>
      ) : null}
    </DialogTitle>
  );
};

export default function VerifyMobileModel(props) {
  const { verifyMobileModel, openModel, closeModel } = props;

  return (
    <div>
      <BootstrapDialog
        onClose={closeModel}
        aria-labelledby="customized-dialog-title"
        open={verifyMobileModel}
        className="modal-bg-color"
      >
        <BootstrapDialogTitle id="customized-dialog-title" className="fw-bold" sx={{fontSize:'17px'}} onClose={closeModel}>
          Verify the mobile phone number
        </BootstrapDialogTitle>
        <DialogContent className="modal-width">
          <div>
            <label htmlFor="exampleInputEmail1" className="form-label  txtClr">
              <b className="text-danger">*</b> Phone
            </label>
            <div className="mb-2 d-flex">
              <select
                className="form-select form-select-sm inputbg login-form-select me-2"
                style={{
                  width: "8rem",
                }}
                aria-label="Default select example"
              >
                <option value="1"> 🏴‍☠️ +95 </option>
                <option value="2"> 🏳️‍🌈 +93</option>
                <option value="3"> 🏳️‍🌈+96</option>
              </select>

              <input
                type="number"
                placeholder="Please enter the mobile phone number"
                className="txtClr-placeholder form-control inputbg login-form-control form-border"
                style={{
                  borderTopLeftRadius: 0,
                  borderBottomLeftRadius: 0,
                }}
                aria-label="Text input with dropdown button"
              />
            </div>
            <div className="form-group mb-3">
              <label htmlFor="VerificationCode" className="txtClr mb-2">
                <b className="text-danger">*</b> SMS Code
              </label>
              <div className="d-flex">
                <div className="w-75">
                  <input
                    type="number"
                    placeholder="Enter the verification code from the new email"
                    className="txtClr-placeholder form-control inputbg login-form-control vericationNumber"
                  />
                </div>
                <button
                  className="btn d-flex align-items-center getCodeBtn px-lg-3 ms-1"
                  role="button"
                >
                  Get Code
                </button>
              </div>
              <p className="txtClr my-1" style={{ fontSize: "14px" }}>
                SMS code not received?{" "}
                <span className="text-primary ms-1"> Help</span>
              </p>
            </div>
          </div>
          <div className="form-group mb-3">
            <label htmlFor="VerificationCode" className="txtClr mb-2">
              <b className="text-danger">*</b> Google Aunthenticator
            </label>
            <div className="d-flex">
              <div className="w-100">
                <input
                  type="number"
                  placeholder="Please enter the Google Authenticator verification code"
                  className="txtClr-placeholder form-control inputbg login-form-control vericationNumber"
                />
              </div>
            </div>
          </div>
        </DialogContent>
        <DialogActions>
          <Button
            autoFocus
            size={"small"}
            onClick={closeModel}
            className="modal-whitebtn"
          >
            <span
              style={{
                opacity: "80%",
                fontWeight: "400px",
                textTransform: "none",
              }}
            >
              Cancel
            </span>
          </Button>
          <Button
            autoFocus
            size={"small"}
            onClick={closeModel}
            className="modal-greenbtn"
          >
            <span
              style={{
                opacity: "80%",
                fontWeight: "400px",
                textTransform: "none",
              }}
            >
              Confirm
            </span>
          </Button>
        </DialogActions>
      </BootstrapDialog>
    </div>
  );
}
