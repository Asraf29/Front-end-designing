import * as React from 'react';
import Button from '@mui/material/Button';
import { styled } from '@mui/material/styles';
import Dialog from '@mui/material/Dialog';
import DialogTitle from '@mui/material/DialogTitle';
import DialogContent from '@mui/material/DialogContent';
import DialogActions from '@mui/material/DialogActions';
import IconButton from '@mui/material/IconButton';
import CloseIcon from '@mui/icons-material/Close';
import InputLabel from '@mui/material/InputLabel';
import MenuItem from '@mui/material/MenuItem';
import FormHelperText from '@mui/material/FormHelperText';
import FormControl from '@mui/material/FormControl';
import Select, { SelectChangeEvent } from '@mui/material/Select';
import './index.css'
import { FormControlLabel, Grid, Typography } from '@mui/material';
import AutorenewIcon from '@mui/icons-material/Autorenew';
import { Box } from '@mui/system';
const BootstrapDialog = styled(Dialog)(({ theme }) => ({
    '& .MuiDialogContent-root': {
        padding: theme.spacing(2),
    },
    '& .MuiDialogActions-root': {
        padding: theme.spacing(1),
    },
}));

const BootstrapDialogTitle = (props) => {
    const { children, onClose, ...other } = props;

    return (
        <DialogTitle sx={{ m: 0, p: 2 }} {...other}>
            {children}
            {onClose ? (
                <IconButton
                    aria-label="close"
                    onClick={onClose}
                    sx={{
                        position: 'absolute',
                        right: 8,
                        top: 8,
                        color: (theme) => theme.palette.grey[500],
                    }}
                >
                    <CloseIcon />
                </IconButton>
            ) : null}
        </DialogTitle>
    );
};

const ExchageModal = (props) => {
    const { openExchangeModal, handleClickOpen, handleClose } = props;


    return (
        <div>
            <BootstrapDialog
                onClose={() => { handleClose() }}
                aria-labelledby="customized-dialog-title"
                open={openExchangeModal}
                className="modal-bg-color"
            >
                <BootstrapDialogTitle id="customized-dialog-title" onClose={handleClose}>
                    Asset exchange
                </BootstrapDialogTitle>
                <DialogContent className="modal-width">

                    <Box className="d-sm-flex align-items-center">
                        <div>
                            <label className="textColors">From</label>
                            <div class="input-group border-gray">
                                <div class="input-group-prepend">
                                    <span class="input-group-text change-addon-bg" id="basic-addon1">MX</span>
                                </div>
                                <input type="text" class="form-control inputBg-change py-3" />
                            </div>
                            <label className="textClr mt-2">Balance: 0 MX</label>
                        </div>
                        <div className='d-flex justify-content-center justify-content-sm-start'><AutorenewIcon className='text-blue' /></div>
                        <div>
                            <label className="textColors">To</label>
                            <div class="input-group  border-gray">
                                <div class="input-group-prepend">
                                    <span class="input-group-text change-addon-bg" id="basic-addon2">TMX</span>
                                </div>
                                <input type="text" class="form-control inputBg-change py-3" />
                            </div>
                            <label className="textClr mt-2">Balance: 0 TMX</label>
                        </div>
                    </Box>
                    <div className="form-group mt-3 mb-2">
                        <label className='mb-2  select-title'><b className='require-clr pe-1'>*</b>Quantity</label>
                        <div className="d-flex">
                            <div className="w-75">
                                <input
                                    type="number"
                                    className="form-control login-form-control vericationNumber"
                                />
                            </div>
                            <button className="btn d-flex align-items-center getCodeBtn px-5  ms-1" role="button">All</button>
                        </div>
                    </div>
                </DialogContent>
                <DialogActions className="my-1 me-2">
                    <Button autoFocus onClick={() => handleClose()} className="modal-whitebtn">
                        <span style={{ opacity: "80%", fontWeight: "400px" }}>
                            Cancel
                        </span>
                    </Button>
                    <Button autoFocus onClick={() => handleClose()} className="modal-greenbtn">
                        <span style={{ opacity: "80%", fontWeight: "400px" }}>
                            Exchange now
                        </span>
                    </Button>
                </DialogActions>
            </BootstrapDialog>
        </div>
    );
}
export default ExchageModal; 
