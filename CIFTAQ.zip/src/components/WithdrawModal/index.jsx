import * as React from 'react';
import Button from '@mui/material/Button';
import { styled } from '@mui/material/styles';
import Dialog from '@mui/material/Dialog';
import DialogTitle from '@mui/material/DialogTitle';
import DialogContent from '@mui/material/DialogContent';
import DialogActions from '@mui/material/DialogActions';
import IconButton from '@mui/material/IconButton';
import CloseIcon from '@mui/icons-material/Close';
import Typography from '@mui/material/Typography';
import './index.css'

const BootstrapDialog = styled(Dialog)(({ theme }) => ({
  '& .MuiDialogContent-root': {
    padding: theme.spacing(2),
  },
  '& .MuiDialogActions-root': {
    padding: theme.spacing(1),
  },
}));

const BootstrapDialogTitle = (props) => {
  const { children, onClose, ...other } = props;

  return (
    <DialogTitle sx={{ m: 0, p: 2 }} {...other}>
      {children}
      {onClose ? (
        <IconButton
          aria-label="close"
          onClick={onClose}
          sx={{
            position: 'absolute',
            right: 8,
            top: 8,
            color: (theme) => theme.palette.grey[500],
          }}
        >
          <CloseIcon />
        </IconButton>
      ) : null}
    </DialogTitle>
  );
};

const WithdrawModal=(props)=> {
  const { openWithdrawModal, WithdrawhandleClose ,  } = props;
  return (
    <div>
      <BootstrapDialog
        onClose={() => { WithdrawhandleClose()}}
        aria-labelledby="customized-dialog-title"
        open={openWithdrawModal}
      >
        <BootstrapDialogTitle id="customized-dialog-title" onClose={WithdrawhandleClose}>
        Add Withdrawal address
        </BootstrapDialogTitle>
        <DialogContent dividers>
            <div className='d-flex d-sm-block d-lg-flex'>
          <div className='col-lg-6 col-sm-12'>
          <Typography gutterBottom className='textClr' >
         <span className='text-danger'>* </span>Crypco:
          </Typography>
          <select style={{fontWeight:600}}  className="inputbg form-select">
  <option className='textClr' selected>Select currency</option>
  <option className='textClr' value="1" >BTC</option>
  <option className='textClr' value="2">USDT</option>
  <option className='textClr' value="3">USD</option>
</select>
</div>
<div className='col-lg-6 col-sm-12 ms-2'>
          <Typography gutterBottom className='textClr' >
         <span className='text-danger'>* </span>Chain type:
          </Typography>
          <select style={{fontWeight:600}}  className="inputbg form-select textClr"  aria-label="Default select example">
  <option className='textClr' selected>Select chain type</option>
  <option className='textClr' value="1">BTC</option>
  <option className='textClr' value="2">USDT</option>
  <option className='textClr' value="3">USD</option>
</select>
</div>
</div>
<div className='col-lg-12 col-sm-12 my-2'>
          <Typography gutterBottom className='textClr' >
         <span className='text-danger'>* </span>Withdrawal address:
          </Typography>
          <select style={{fontWeight:600}}  className="inputbg form-select textClr"  aria-label="Default select example">
  <option className='textClr' selected>Please enter the withdrawal addess</option>
  <option className='textClr' value="1">BTC</option>
  <option className='textClr' value="2">USDT</option>
  <option className='textClr' value="3">USD</option>
</select>
</div>
<div className='col-lg-12 col-sm-12 my-2'>
          <Typography gutterBottom className='textClr' >
         <span className='text-danger'>* </span>Address label:
          </Typography>
          <select style={{fontWeight:600}}  className="inputbg form-select textClr"  aria-label="Default select example">
  <option className='textClr' selected>Please enter the Address labels</option>
  <option className='textClr' value="1">BTC</option>
  <option className='textClr' value="2">USDT</option>
  <option className='textClr' value="3">USD</option>
</select>
</div>
        </DialogContent>
        <DialogActions>
          <Button size="small" autoFocus onClick={() => WithdrawhandleClose()} className="modal-whitebtn  m-2">
                        <span style={{ opacity: "80%", fontWeight: "400px" }}>
                            Cancel
                        </span>
                    </Button>
                    <Button size="small" autoFocus onClick={() => WithdrawhandleClose()} className="modal-greenbtn m-2">
                        <span style={{ opacity: "80%", fontWeight: "400px" }}>
                            Confirm
                        </span>
                    </Button>
        </DialogActions>
      </BootstrapDialog>
    </div>
  );
}
export default  WithdrawModal;