import { Box } from '@mui/system';
import React, { useState } from 'react'
import Logo from '../assets/images/Logo.png'
import { Typography, Button, ListItemText } from '@mui/material';
import SettingsIcon from '@mui/icons-material/Settings';
import { Link } from 'react-router-dom'
import { useThemeSwitcher } from 'react-css-theme-switcher';
// Dropdown images
import margin from '../../components/assets/images/margin.png';
import Buy from '../../components/assets/images/buy.png';
import push from '../../components/assets/images/push.png';
import futureMarket from '../../components/assets/images/futureMarket.png';
import Rocket from '../../components/assets/images/launchpad.png';
import sun from '../../components/assets/images/kickstarticon.png';
import Hammer from '../../components/assets/images/mxdefi.png'
import mDAy from '../../components/assets/images/mday.png'
import mxZone from '../../components/assets/images/mxZone.png'
import slot from '../../components/assets/images/slot.png'
import vote from '../../components/assets/images/vote.png'
import pool from '../../components/assets/images/pool.png'
import stake from '../../components/assets/images/stake.png'
import './index.css'
const Navbar = () => {
  const { switcher, themes, currentTheme, status } = useThemeSwitcher();
  const [isDarkMode, setIsDarkMode] = React.useState(false);

  const [navbarBg, setNavbarBg] = useState(false);
  /*Theme Change */
  const toggleDarkMode = () => {
    setIsDarkMode(!isDarkMode)
    switcher({ theme: isDarkMode ? themes.light : themes.dark });

  };
  return (
    <div>
      {/* Navbar */}
      <nav className="navbar navbar-expand-lg  navBg " id='navBar'>
        <div className="container-fluid">
          <Link to='/' className="navbar-brand text-color d-flex align-items-center">
            <Box component="img" className='img-fluid logoSize pb-2 pb-lg-0' alt="Logo" src={Logo} />
          </Link>
          <button className=" ms-auto pb-2 pe-2 toggleBtn d-block d-lg-none d-flex align-items-center displayOffcanvas" type="button" >
            <Link to="/userlogin" className='loginText me-2 linkTag'>Login</Link>
            <svg xmlns="http://www.w3.org/2000/svg" width="25" height="25" fill="white" className="bi bi-list" viewBox="0 0 16 16" data-bs-toggle="offcanvas"
              data-bs-target="#offcanvasleft" aria-controls="offcanvasleft">
              <path
                d="M2.5 12a.5.5 0 0 1 .5-.5h10a.5.5 0 0 1 0 1H3a.5.5 0 0 1-.5-.5zm0-4a.5.5 0 0 1 .5-.5h10a.5.5 0 0 1 0 1H3a.5.5 0 0 1-.5-.5zm0-4a.5.5 0 0 1 .5-.5h10a.5.5 0 0 1 0 1H3a.5.5 0 0 1-.5-.5z" />
            </svg>
          </button>
          <div className="collapse navbar-collapse" id="navbarText">
            <ul className="navbar-nav me-auto mb-2 mb-lg-0  ">
              <li className="nav-item ">
                <Link className="nav-link text-color active " to='/market' aria-current="page">Markets</Link>
              </li>
              <li className="nav-item">
                <a className="nav-link text-color">Buy Crypto</a>
              </li>
              {/* Trdes Dropdown */}
              <li className="nav-item customDropdown" aria-hidden="true">
                <a className="nav-link text-color dropdownText">Trade<i class="bi bi-chevron-down ps-1 text-color dropdownIcon"></i></a>
                <div class="dropdown-content trad-width py-2">
                  <Link to="/spot" className="dropdown-sub-text linkTag px-2 pb-2 d-flex" >
                    <Box component="img" className="img-fluid dropdown-icon mt-2 pt-1" src={margin} />
                    <ListItemText className="listTitle dropdownSubText ps-2" primary={'Spot'} secondary={'Trade on our award-winning platform'} />
                  </Link>
                  <hr className="m-0 text-muted" />
                  <Link to="/spot" className="dropdown-sub-text linkTag  px-2 pb-2 d-flex">
                    <Box component="img" className="img-fluid dropdown-icon mt-2 pt-1" src={margin} />
                    <ListItemText className="listTitle dropdownSubText ps-2" primary={'Margin'} secondary={'Maximise profit with leverage'} />
                  </Link>
                  <hr className="m-0 text-muted" />
                  <Link to="/marketBuy" className="dropdown-sub-text linkTag px-2 pb-2 d-flex">
                    <Box component="img" className="img-fluid dropdown-icon mt-2 pt-1" src={Buy} />
                    <ListItemText className="listTitle dropdownSubText ps-2" primary={'Buy Crypto with visa,mastercard'} secondary={'Maximise profit with leverage'} />
                  </Link>
                  <hr className="m-0 text-muted" />
                  <Link to="/marketBuy" className="dropdown-sub-text linkTag px-2 pb- d-flex">
                    <Box component="img" className="img-fluid dropdown-icon mt-2 pt-1" src={push} />
                    <ListItemText className="listTitle dropdownSubText ps-2" primary={'PUSH'} secondary={'Peer-to-peer exchange,bank transfer and more option'} />
                  </Link>
                </div>
              </li>
              {/* Derivatives Dropdown */}
              <li className="nav-item customDropdown">
                <a className="nav-link text-color dropdownText">Derivatives<i class="bi bi-chevron-down ps-1 text-color"></i></a>
                <div class="dropdown-content derivatives-width py-2">
                  <div className="dropdown-sub-text  px-2 pb-2 d-flex">
                    <Box component="img" className="img-fluid dropdown-icon mt-2 pt-1" src={margin} />
                    <ListItemText className="listTitle dropdownSubText ps-2" primary={'ETF Margin'} secondary={'Increased Leverage, no liquidation risk'} />
                  </div>
                  <hr className="m-0 text-muted" />
                  <Link to="/futuresMarkets" className="dropdown-sub-text linkTag  px-2 pb-2 d-flex">
                    <Box component="img" className="img-fluid dropdown-icon mt-2 pt-1" src={futureMarket} />
                    <ListItemText className="listTitle dropdownSubText ps-2" primary={'Futures Markets'} secondary={'Up to 125x leverage with better Spreads'} />
                  </Link>
                  <hr className="m-0 text-muted" />
                  <Link to="/indexETF" className="dropdown-sub-text linkTag px-2 pb- d-flex">
                    <Box component="img" className="img-fluid dropdown-icon mt-2 pt-1" src={push} />
                    <ListItemText className="listTitle dropdownSubText ps-2" primary={'ETF Index'} secondary={'Invest into multiple assets and diversify the risk'} />
                  </Link>
                </div>
              </li>
              {/* Finance Dropdown */}
              <li className="nav-item customDropdown">
                <a className="nav-link text-color dropdownText">Finance<i class="bi bi-chevron-down ps-1 text-color"></i></a>
                <div class="dropdown-content Finance-width py-2">
                  <Link to="/launchpad" className="dropdown-sub-text linkTag px-2 pb-2 d-flex">
                    <Box component="img" className="img-fluid dropdown-icon mt-2 pt-1" src={Rocket} />
                    <ListItemText className="listTitle dropdownSubText ps-2" primary={'Launchpad'} secondary={'Exclusively for MX Holders'} />
                  </Link>
                  <hr className="m-0 text-muted" />
                  <Link to="/kickstart" className="dropdown-sub-text linkTag px-2 pb-2 d-flex">
                    <Box component="img" className="img-fluid dropdown-icon mt-2 pt-1" src={sun} />
                    <ListItemText className="listTitle dropdownSubText ps-2" primary={'Kickstarter'} secondary={'Vote and receive airdrops'} />
                  </Link>
                  <hr className="m-0 text-muted" />
                  <Link to="/mxDefi" className="dropdown-sub-text linkTag px-2 pb- d-flex">
                    <Box component="img" className="img-fluid dropdown-icon mt-2 pt-1" src={Hammer} />
                    <ListItemText className="listTitle dropdownSubText ps-2" primary={'MX-DeFi'} secondary={'MIne rewards by connecting to the pool'} />
                  </Link>
                  <hr className="m-0 text-muted" />
                  <Link to="/mday" className="dropdown-sub-text linkTag px-2 pb-2 d-flex">
                    <Box component="img" className="img-fluid dropdown-icon mt-2 pt-1" src={mDAy} />
                    <ListItemText className="listTitle dropdownSubText ps-2" primary={'M-Day'} secondary={'Trade or hold selected token and win free airdrops'} />
                  </Link>
                  <hr className="m-0 text-muted" />
                  <Link to="/mxZone" className="dropdown-sub-text linkTag  px-2 pb-2 d-flex">
                    <Box component="img" className="img-fluid dropdown-icon mt-2 pt-1" src={mxZone} />
                    <ListItemText className="listTitle dropdownSubText ps-2" primary={'MX Zone'} secondary={'Privileges/Rewards of MX token holders'} />
                  </Link>
                  <hr className="m-0 text-muted" />
                  <Link to="/slotAuction" className="dropdown-sub-text linkTag px-2 pb- d-flex">
                    <Box component="img" className="img-fluid dropdown-icon mt-2 pt-1" src={slot} />
                    <ListItemText className="listTitle dropdownSubText ps-2" primary={'Slot Auction'} secondary={'Participate in KSM&DOT parachain auctions and governance vote'} />
                  </Link>
                  <hr className="m-0 text-muted" />
                  <Link to="/voting" className="dropdown-sub-text linkTag px-2 pb-2 d-flex">
                    <Box component="img" className="img-fluid dropdown-icon mt-2 pt-1" src={vote} />
                    <ListItemText className="listTitle dropdownSubText ps-2" primary={'Voting'} secondary={'Vote to renewal and rewards with MX tokens'} />
                  </Link>
                  <hr className="m-0 text-muted" />
                  <Link to="/posPool" className="dropdown-sub-text linkTag px-2 pb-2 d-flex">
                    <Box component="img" className="img-fluid dropdown-icon mt-2 pt-1" src={pool} />
                    <ListItemText className="listTitle dropdownSubText ps-2" primary={'POS Pool'} secondary={'Simple & Secure Way to earn Crypto'} />
                  </Link>
                  <hr className="m-0 text-muted" />
                  <Link to="/ETH2.0" className="dropdown-sub-text linkTag px-2 pb- d-flex">
                    <Box component="img" className="img-fluid dropdown-icon mt-2 pt-1" src={stake} />
                    <ListItemText className="listTitle dropdownSubText ps-2" primary={'Stake ETH'} secondary={'One-click stake'} />
                  </Link>
                </div>
              </li>
              <li className="nav-item">
                <Link to="/rewardCenter" className="nav-link text-color">Reward Center</Link>
              </li>
              <li className="nav-item">
                <Link to="/launchpad" className="nav-link text-color">Launchpad</Link>
              </li>
            </ul>
            <div className='d-flex align-items-center'>
              {/* <ul className="navbar-nav me-auto mb-2 mb-lg-0  ">
                  <li className="nav-item">
                    <a className="nav-link text-color">Assets</a>
                  </li>
                  <li className="nav-item">
                    <a className="nav-link text-color">Order</a>
                  </li>
                </ul> */}
              <Link className="linkTag" to='/userlogin'><Button variant="text" sx={{ color: 'white' }} className="LoginTextSize">Log in</Button></Link>
              <Link className="pe-3 linkTag" to='/register'><Button variant="outlined" sx={{ color: 'white' }} className='SignupTextSize'>sign up</Button></Link>
              <Link to="/profile" className='text-color pe-3 borderStart linkTag'><i class="bi bi-person-circle fs-4"></i></Link>
              <div className='text-color pe-3'><i class="bi bi-download "></i></div>
              <Typography sx={{ color: 'white', pr: 3 }} className="LanguageTextSize">English/USD</Typography>
              <SettingsIcon sx={{ color: 'white' }} onClick={toggleDarkMode} />
            </div>
          </div>
        </div>
      </nav>
      {/*---------------offcanvas for mobile-------------- */}
      <nav className='nav' id='offcanvasText'>
        <div className="offcanvas offcanvas-end bgOffcanvas" id="offcanvasleft"
          aria-labelledby="offcanvasleftLabel" data-bs-backdrop="false">
          <div className="offcanvas-header borderBtm linkTag">
            <Link to="/userlogin" className='linkTag' id="offcanvasRightLabel"> <b>Login</b></Link>
            <i className="bi bi-x closeBtn" data-bs-dismiss="offcanvas"></i>
          </div>
          <div className="offcanvas-body">
            <ul className="navbar-nav me-auto  mb-lg-0">
              <li className="nav-item">
                <Link to="/market" className="nav-link active text-color" aria-current="page">Markets</Link>
              </li>
              <li className="accordion" id="accordionExample">
                <div className="accordion-item accordionBorder bgAccordion">
                  <div className='d-flex justify-content-between align-items-center' data-bs-toggle="collapse" data-bs-target="#buyCrypto">
                    <a className='nav-link text-color'>Buy Crypto</a>
                    <div><i className="bi bi-chevron-down"></i></div>
                  </div>
                  <div id="buyCrypto" className="accordion-collapse collapse show" aria-labelledby="headingOne" data-bs-parent="#accordionExample">
                    <div className="accordionBody">
                      <Link to="/marketBuy" className='nav-link text-color'>P2P Trading</Link>
                      <a className='nav-link text-color'>Third Party Payment</a>
                      <Link to="/marketBuy" className='nav-link text-color'>PUSH</Link>
                    </div>
                  </div>
                </div>
              </li>
              <li className="accordion " id="accordionExample">
                <div className="accordion-item accordionBorder bgAccordion">
                  <div className='d-flex justify-content-between align-items-center' data-bs-toggle="collapse" data-bs-target="#trade">
                    <a className='nav-link text-color'>Trade</a>
                    <div><i className="bi bi-chevron-down"></i></div>
                  </div>
                  <div id="trade" className="accordion-collapse collapse show" aria-labelledby="headingOne" data-bs-parent="#accordionExample">
                    <div className="accordionBody">
                      <Link to="/spot" className='nav-link text-color'>Spot</Link>
                      <Link to="/spot" className='nav-link text-color'>Margin</Link>
                    </div>
                  </div>
                </div>
              </li>
              <li className="accordion" id="accordionExample">
                <div className="accordion-item accordionBorder bgAccordion">
                  <div className='d-flex justify-content-between align-items-center' data-bs-toggle="collapse" data-bs-target="#Derivatives">
                    <a className='nav-link text-color'>Derivatives &#128293;</a>
                    <div><i className="bi bi-chevron-down"></i></div>
                  </div>
                  <div id="Derivatives" className="accordion-collapse collapse show" aria-labelledby="headingOne" data-bs-parent="#accordionExample">
                    <div className="accordionBody">
                      <a className='nav-link text-color'>Leveraged ETFs</a>
                      <Link to="/futuresMarkets" className='nav-link text-color'>Futures <small className='bgOrange px-1'>&#128293;Get$1000</small></Link>
                      <Link to="/indexETF" className='nav-link text-color'>index ETFs</Link>
                      <a className='nav-link text-color'>MEXC 2nd Futures Trading Competition</a>
                    </div>
                  </div>
                </div>
              </li>
              <li className="accordion" id="accordionExample">
                <div className="accordion-item accordionBorder bgAccordion">
                  <div className='d-flex justify-content-between align-items-center' data-bs-toggle="collapse" data-bs-target="#Earn">
                    <a className='nav-link text-color'>Earn</a>
                    <div><i className="bi bi-chevron-down"></i></div>
                  </div>
                  <div id="Earn" className="accordion-collapse collapse show" aria-labelledby="headingOne" data-bs-parent="#accordionExample">
                    <div className="accordionBody">
                      <Link to="/launchpad" className='nav-link text-color'>Launchpad</Link>
                      <Link to="/kickstart" className='nav-link text-color'>KickStarter</Link>
                      <Link to="/mxDefi" className='nav-link text-color'>MX-DeFi</Link>
                      <Link to="/mday" className='nav-link text-color'>M-Day &#128293;</Link>
                      <Link to="/mxZone" className='nav-link text-color'>MX-Zone</Link>
                      <Link to="/slotAuction" className='nav-link text-color'>Slot Auction</Link>
                      <Link to="/ETH2.0" className='nav-link text-color'>ETH 2.0 Stacking</Link>
                      <Link to="/voting" className='nav-link text-color'>NFT Voting</Link>
                    </div>
                  </div>
                </div>
              </li>
              <li className="nav-item">
                <Link to="/rewardCenter" className="nav-link text-color">Reward Center</Link>
              </li>
              <li className="nav-item">
                <Link to="/futuresMarkets" className="nav-link text-color">Futures &#128293;</Link>
              </li>
              <li className="nav-item">
                <a className="nav-link text-color" href="#">institutional Service</a>
              </li>
              <li className="nav-item">
                <a className="nav-link text-color" href="#">Download CIFTAQ Global</a>
              </li>
              <li className="nav-item">
                <a className="nav-link text-color" href="#">English/USD</a>
              </li>
              <li className="nav-item">
                <a className="nav-link text-color" href="#">Preferences</a>
              </li>
            </ul>
          </div>

        </div>

      </nav>
    </div>
  )
}
export default Navbar;
