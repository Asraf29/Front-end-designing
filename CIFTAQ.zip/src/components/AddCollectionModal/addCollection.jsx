import * as React from 'react';
import Button from '@mui/material/Button';
import { styled } from '@mui/material/styles';
import Dialog from '@mui/material/Dialog';
import DialogTitle from '@mui/material/DialogTitle';
import DialogContent from '@mui/material/DialogContent';
import DialogActions from '@mui/material/DialogActions';
import IconButton from '@mui/material/IconButton';
import CloseIcon from '@mui/icons-material/Close';
import InputLabel from '@mui/material/InputLabel';
import MenuItem from '@mui/material/MenuItem';
import FormHelperText from '@mui/material/FormHelperText';
import FormControl from '@mui/material/FormControl';
import Select, { SelectChangeEvent } from '@mui/material/Select';
import './index.css'
const BootstrapDialog = styled(Dialog)(({ theme }) => ({
    '& .MuiDialogContent-root': {
        padding: theme.spacing(2),
    },
    '& .MuiDialogActions-root': {
        padding: theme.spacing(1),
    },
}));

const BootstrapDialogTitle = (props) => {
    const { children, onClose, ...other } = props;

    return (
        <DialogTitle sx={{ m: 0, p: 2 }} {...other}>
            {children}
            {onClose ? (
                <IconButton
                    aria-label="close"
                    onClick={onClose}
                    sx={{
                        position: 'absolute',
                        right: 8,
                        top: 8,
                        color: (theme) => theme.palette.grey[500],
                    }}
                >
                    <CloseIcon />
                </IconButton>
            ) : null}
        </DialogTitle>
    );
};

export default function AddCollectionModal(props) {
    const { addCollectionModal, handleClickOpen, handleClose } = props;


    return (
        <div>
            <BootstrapDialog
                onClose={() => { handleClose() }}
                aria-labelledby="customized-dialog-title"
                open={addCollectionModal}
                className="modal-bg-color"
            >
                <BootstrapDialogTitle id="customized-dialog-title" onClose={handleClose}>
                Add Collection Method
                </BootstrapDialogTitle>
                <DialogContent  className="modal-width">
                    <select id="form-select"
                        className="form-select txtClr"
                        aria-label="Default select example">
                        <option value="1" className='txtClr'>Bank Account </option>
                    </select>
                    <div className='d-block'>
                        <div>
                    <label className='mt-3 mb-2 txtClr'>Bank Account Number</label>
                    </div>
                    <div>
                    <input placeholder='Please enter Bank account number' className='txtClr w-100 inputbg' style={{height:'30px'}}/>
                    </div>
                    </div>
                    <div className='d-block'>
                        <div>
                    <label className='mt-3 mb-2 txtClr'>Bank Name</label>
                    </div>
                    <div>
                    <input placeholder="Please enter Bank Name"className='txtClr w-100 inputbg' style={{height:'30px'}}/>
                    </div>
                    </div>
                    <div className='d-block'>
                        <div>
                    <label className='mt-3 mb-2 txtClr'>Branch Address</label>
                    </div>
                    <div>
                    <input placeholder='Please enter Bank Address' className='txtClr w-100 inputbg' style={{height:'30px'}}/>
                    </div>
                    </div>
                </DialogContent>
                <div className="d-grid m-3">
                    <button  onClick={() => handleClose()} className="modal-greenbtn btn">
                        <span style={{ opacity: "80%", fontWeight: "400px" }}>
                            Submit
                        </span>
                    </button>
                    </div>
              
            </BootstrapDialog>
        </div>
    );
}
