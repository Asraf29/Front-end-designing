import * as React from "react";
import Button from "@mui/material/Button";
import { styled } from "@mui/material/styles";
import Dialog from "@mui/material/Dialog";
import DialogTitle from "@mui/material/DialogTitle";
import DialogContent from "@mui/material/DialogContent";
import DialogActions from "@mui/material/DialogActions";
import IconButton from "@mui/material/IconButton";
import CloseIcon from "@mui/icons-material/Close";
import InputLabel from "@mui/material/InputLabel";
import MenuItem from "@mui/material/MenuItem";
import FormHelperText from "@mui/material/FormHelperText";
import FormControl from "@mui/material/FormControl";
import Select, { SelectChangeEvent } from "@mui/material/Select";
import "./index.css";
import { FormControlLabel, Grid, Typography } from "@mui/material";
import AutorenewIcon from "@mui/icons-material/Autorenew";
import { Box } from "@mui/system";
const BootstrapDialog = styled(Dialog)(({ theme }) => ({
  "& .MuiDialogContent-root": {
    padding: theme.spacing(2),
  },
  "& .MuiDialogActions-root": {
    padding: theme.spacing(1),
  },
}));

const BootstrapDialogTitle = (props) => {
  const { children, onClose, ...other } = props;

  return (
    <DialogTitle sx={{ m: 0, p: 2 }} {...other}>
      {children}
      {onClose ? (
        <IconButton
          aria-label="close"
          onClick={onClose}
          sx={{
            position: "absolute",
            right: 8,
            top: 8,
            color: (theme) => theme.palette.grey[500],
          }}
        >
          <CloseIcon />
        </IconButton>
      ) : null}
    </DialogTitle>
  );
};

const TransferCrypto = (props) => {
  const { openCryptoTransferModal, handleCryptoClickOpen, handleCryptoModalClose } =
    props;

  return (
    <div>
      <BootstrapDialog
        onClose={() => { handleCryptoClickOpen(); }} aria-labelledby="customized-dialog-title" open={openCryptoTransferModal} className="modal-bg-color">
        <BootstrapDialogTitle id="customized-dialog-title fw-bold" onClose={handleCryptoModalClose}>
          Crypto transfer
        </BootstrapDialogTitle>
        <DialogContent>
          <Box className="d-sm-flex justify-content-between align-items-center">
            <div className="d-block col-lg-5 col-md-5">
              <div>
                <label className="textColors pb-1">From</label>
              </div>
              <div>
                <input type="text" id="cryptoInput" className="form-control inputBg textColors inputvalueText py-2" value="Spot account "/>
              </div>
              <div>
              </div>
            </div>
            <div className="d-flex col-lg-2 justify-content-center align-items-center ms-2 pt-3">
              <AutorenewIcon className="text-blue" />
            </div>
            <div className="d-block col-lg-5 col-md-5">
              <div>
                <label className="textColors pb-1">To</label>
              </div>
              <div>
                <input type="text" id="cryptoInput" className="form-control inputBg textColors inputvalueText py-2" value="Perpetual Futures"/>
              </div>
            </div>
          </Box>
          <div className="form-group mt-3 mb-2">
            <label className="mb-2  select-title">
              <b className="require-clr pe-1">*</b>Quantity
            </label>
            <div className="d-flex">
              <div className="input-group">
                <input type="text" className="form-control quantity-placeholder inputBg" aria-label="Recipient's username" aria-describedby="basic-addon2" />
                <div  className="input-group-append">
                  <button className="btn btn-outline-secondary btn-hvrs textColors inputBg">USDT</button>
                </div>
              </div>
              <button className="btn d-flex align-items-center getCodeBtn px-5  ms-1" role="button">
                All
              </button>
            </div>
            <Typography className="textClr py-1">Available for transfer:<span className="ps-1 fw-bold textColors">0 USDT</span></Typography>
          </div>
        </DialogContent>
        <DialogActions className="my-1 mb-3 me-2">
          <Button autoFocus onClick={() => handleCryptoModalClose()} className="modal-whitebtn">
            <span style={{ opacity: "80%", fontWeight: "400px", textTransform: 'none' }}>Cancel</span>
          </Button>
          <Button autoFocus onClick={() => handleCryptoModalClose()} className="modal-greenbtn">
            <span style={{ opacity: "80%", fontWeight: "400px", textTransform: 'none' }}>
              Confrim
            </span>
          </Button>
        </DialogActions>
      </BootstrapDialog>
    </div>
  );
};
export default TransferCrypto;
