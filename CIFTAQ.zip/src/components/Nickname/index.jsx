import * as React from 'react';
import Button from '@mui/material/Button';
import { styled } from '@mui/material/styles';
import Dialog from '@mui/material/Dialog';
import DialogTitle from '@mui/material/DialogTitle';
import DialogContent from '@mui/material/DialogContent';
import DialogActions from '@mui/material/DialogActions';
import IconButton from '@mui/material/IconButton';
import CloseIcon from '@mui/icons-material/Close';
import Typography from '@mui/material/Typography';
import { TextField } from '@mui/material';

const BootstrapDialog = styled(Dialog)(({ theme }) => ({
  '& .MuiDialogContent-root': {
    padding: theme.spacing(2),
  },
  '& .MuiDialogActions-root': {
    padding: theme.spacing(1),
  },
}));

const BootstrapDialogTitle = (props) => {
  const { children, onClose, ...other } = props;

  return (
    <DialogTitle sx={{ m: 0, p: 2 }} {...other}>
      {children}
      {onClose ? (
        <IconButton
          aria-label="close"
          onClick={onClose}
          sx={{
            position: 'absolute',
            right: 8,
            top: 8,
            color: (theme) => theme.palette.grey[500],
          }}
        >
          <CloseIcon />
        </IconButton>
      ) : null}
    </DialogTitle>
  );
};

export default function NicknameModal(props) {
  const { openNickName, handleClose } = props;
  return (
    <div>
      <BootstrapDialog
        onClose={() => { handleClose(); console.error(openNickName) }}
        aria-labelledby="customized-dialog-title"
        open={openNickName}
      >
        <BootstrapDialogTitle id="customized-dialog-title" onClose={handleClose}>
        My Nickname
        </BootstrapDialogTitle>
        <DialogContent dividers>
          <Typography gutterBottom>
            My Nickname
          </Typography>
          <TextField
            id="outlined-basic" label="Enter the nickname" sx={{ width: "100%", margin: "12px 0" }} variant="outlined" >
          </TextField>
          <Typography gutterBottom>
            1. Your nickname can only be set and change three times. Please edit it carefully.<br />

            2. Your nickname will be reviewed. If any insulting, political sensitive words involved, your nickname will not pass the review.<br />

            3. Your nickname will be reviewed occasionally. If any rule violations are found, your nickname will become invalid and you'll have to apply to another one.
          </Typography>
        </DialogContent>
        <DialogActions>
          <Button autoFocus onClick={() => handleClose()} sx={{ background: "#C4C4C4", color: "#000000" }}>
            <span style={{ opacity: "80%", fontWeight: "400px" }}>
              Cancel
            </span>
          </Button>
          <Button autoFocus onClick={() => handleClose()} sx={{ background: "#1A94AE", color: "#000000" }}>
            <span style={{ opacity: "80%", fontWeight: "400px" }}>
              Submit
            </span>
          </Button>
        </DialogActions>
      </BootstrapDialog>
    </div>
  );
}
