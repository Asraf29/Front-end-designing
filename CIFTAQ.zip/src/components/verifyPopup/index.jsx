import * as React from 'react';
import Button from '@mui/material/Button';
import { styled } from '@mui/material/styles';
import Dialog from '@mui/material/Dialog';
import DialogTitle from '@mui/material/DialogTitle';
import DialogContent from '@mui/material/DialogContent';
import DialogActions from '@mui/material/DialogActions';
import IconButton from '@mui/material/IconButton';
import CloseIcon from '@mui/icons-material/Close';
import { Grid, Typography } from '@mui/material';
import './index.css'
import QRCode from '../../components/assets/images/Verification.png'
import { Box } from '@mui/system';
const BootstrapDialog = styled(Dialog)(({ theme }) => ({
    '& .MuiDialogContent-root': {
        padding: theme.spacing(2),
    },
    '& .MuiDialogActions-root': {
        padding: theme.spacing(1),
    },
}));
/*Copy Search Field Text*/
// $(function () {
//     $(".share_search .copyBtn").click(function () {
//       $(".share_search input").select();
//       document.execCommand("copy");

//     });
//   });
const BootstrapDialogTitle = (props) => {
    const { children, onClose, ...other } = props;

    return (
        <DialogTitle sx={{ m: 0, p: 2 }} {...other}>
            {children}
            {onClose ? (
                <IconButton
                    aria-label="close"
                    onClick={onClose}
                    sx={{
                        position: 'absolute',
                        right: 8,
                        top: 8,
                        color: (theme) => theme.palette.grey[500],
                    }}
                >
                    <CloseIcon />
                </IconButton>
            ) : null}
        </DialogTitle>
    );
};

export default function AdvancedKycModal(props) {
    // const { openKycModal, handleClickOpen, handleClose } = props;

    const [openKycModal, setOpenKycModal] = React.useState(false);

    const handleClickOpen = () => {
        setOpenKycModal(true);
    };

    const handleClose = () => {
        setOpenKycModal(false);
    };

    return (
        <div>
            <Button onClick={() => { handleClickOpen() }}>Open</Button>
            <BootstrapDialog
                onClose={() => { handleClose() }}
                open={openKycModal}
                className="modalBackgroundcolor"
                id="customized-dialog-title"
            >
                <BootstrapDialogTitle onClose={handleClose}></BootstrapDialogTitle>
                <DialogContent className="Verifymodal-width pt-3">
                    <Grid container spacing={4}>
                        <Grid item xs={12} sm={6} md={6} lg={6} className="d-flex justify-content-center justify-content-sm-start">
                            <Box component="img" alt="Scan me" src={QRCode} className="img-fluid py-3" />
                        </Grid>
                        <Grid item xs={12} sm={6} md={6} lg={6} className="my-sm-5">
                            <Typography className="modal-text-clr fontSize-small">
                                Send only USDT to this address.
                                Ensure the network is<Typography className="text-primary fontSize-small">Binance Smart Chain (BEP20).</Typography>
                            </Typography>
                            <Box className="my-3">
                                <Typography className="textClr fontSize-small">Minimum Deposit</Typography>
                                <Typography className="modal-text-clr fontSize-small">0.00000001 USDT</Typography>
                            </Box>
                            <Box>
                                <Typography className="textClr fontSize-small">Expected arrival & unlock</Typography>
                                <Typography className="modal-text-clr fontSize-small">15 Network Confirmations</Typography>
                            </Box>
                        </Grid>
                    </Grid>
                    <div className="d-grid pb-3">
                        <div className="share_search d-inline-flex"> 
                            <input type="text"className="copy_search py-4 form-control"  value="0xec7842178520bb71f30523bcce4c10adc7e1cec40"/>
                            <button
                                type="button"
                                className="copyBtn pe-3 text-primary d-flex align-items-center"
                                style={{ cursor: "pointer" }}
                                data-icon="fa6-solid:copy">
                                    
                                Copy <span className="iconify text-primary" data-icon="fa6-solid:copy"></span>
                            </button>
                        </div>
                    </div>
                </DialogContent>
            </BootstrapDialog>
        </div >
    );
}
