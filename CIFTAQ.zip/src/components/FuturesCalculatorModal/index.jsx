import * as React from "react";
import Button from "@mui/material/Button";
import { styled } from "@mui/material/styles";
import Dialog from "@mui/material/Dialog";
import DialogTitle from "@mui/material/DialogTitle";
import DialogContent from "@mui/material/DialogContent";
import DialogActions from "@mui/material/DialogActions";
import IconButton from "@mui/material/IconButton";
import CloseIcon from "@mui/icons-material/Close";
import { Box, Card, CardContent, Grid, Typography } from "@mui/material";
import './index.css'
const BootstrapDialog = styled(Dialog)(({ theme }) => ({
    "& .MuiDialogContent-root": {
        padding: theme.spacing(2),
    },
    "& .MuiDialogActions-root": {
        padding: theme.spacing(1),
    },
}));

const BootstrapDialogTitle = (props) => {
    const { children, onClose, ...other } = props;

    return (
        <DialogTitle sx={{ m: 0, p: 2 }} {...other}>
            {children}
            {onClose ? (
                <IconButton
                    aria-label="close"
                    onClick={onClose}
                    sx={{
                        position: "absolute",
                        right: 8,
                        top: 8,
                        color: (theme) => theme.palette.grey[500],
                    }}
                >
                    <CloseIcon />
                </IconButton>
            ) : null}
        </DialogTitle>
    );
};

const FuturesCalculator = (props) => {
    const { openCalculatorModal, handleClaculatorClickOpen, handleCalculatorModalClose } = props;

    return (
        <div>
            <BootstrapDialog
                onClose={() => { handleClaculatorClickOpen(); }} aria-labelledby="customized-dialog-title" open={openCalculatorModal} className="modal-bg-color">
                <BootstrapDialogTitle id="customized-dialog-title" className="fw-bold mb-0 pb-0" onClose={handleCalculatorModalClose}>
                    Futures Calculator
                </BootstrapDialogTitle>
                <DialogContent className="cryptoTransferMoadl-width mb-5">
                    <Box>
                        <ul id="cryptoTransfer" className="nav nav-pills cryptoTransfer mb-2 my-2 px-0" role="tablist">
                            <li className="nav-item" role="presentation">
                                <button className="nav-link  ps-0 active textClr" data-bs-toggle="pill" data-bs-target="#profitandLossTab" role="tab">
                                    Profit and loss Calculation
                                </button>
                            </li>
                            <li className="nav-item" role="presentation">
                                <button className="nav-link  textClr ps-0" data-bs-toggle="pill" data-bs-target="#targetCalculationTab" role="tab">
                                    Target Calculation
                                </button>
                            </li>
                            <li className="nav-item" role="presentation">
                                <button className="nav-link  textClr ps-320" data-bs-toggle="pill" data-bs-target="#FLPriceTab" role="tab">
                                    FL Price
                                </button>
                            </li>
                        </ul>
                    </Box>
                    <div className="tab-content">
                        {/*  Profit and loss Calculation Data */}
                        <div className="tab-pane fade show active" id="profitandLossTab" role="tabpanel">
                            <Grid container spacing={1}>
                                <Grid item xs={12} sm={6} md={6} lg={6}>
                                    <Grid container spacing={2}>
                                        <Grid item xs={6} sm={6} md={6} lg={6}><Box className="d-grid"><Button variant="contained" className="greenBtn">Long</Button></Box></Grid>
                                        <Grid item xs={6} sm={6} md={6} lg={6}><Box className="d-grid"><Button variant="contained" className="grayBtn">Short</Button></Box></Grid>
                                    </Grid>
                                    <input type="range" style={{ width: "100%" }} id="green" className="input-green my-3" name="vol" min="0" max="100" />
                                    <div className="input-group mb-2">
                                        <input type="text" className="form-control cryptoTransferInput" placeholder="Opening Price" aria-describedby="basic-addon2" />
                                        <div className="input-group-append">
                                            <button className="btn btn-outline-secondary cryptoTransferInput textColors fw-bold">USDT</button>
                                        </div>
                                    </div>
                                    <div className="input-group mb-2">
                                        <input type="text" className="form-control cryptoTransferInput" placeholder="Close Price" aria-describedby="basic-addon2" />
                                        <div className="input-group-append">
                                            <button className="btn btn-outline-secondary cryptoTransferInput textColors fw-bold">USDT</button>
                                        </div>
                                    </div>
                                    <div className="input-group my-2">
                                        <input type="text" className="form-control cryptoTransferInput" placeholder="Trade quantity" aria-describedby="basic-addon2" />
                                        <div className="input-group-append">
                                            <button className="btn btn-outline-secondary cryptoTransferInput textColors fw-bold">Cont</button>
                                        </div>
                                    </div>
                                    <Typography className="fw-bold themeText">Futures<span className="ps-1">BTC_USDT_SWAP</span></Typography>
                                    <Box className="d-grid my-2"><Button variant="contained" className="greenBtn">Start calculation</Button></Box>
                                </Grid>
                                <Grid item xs={12} sm={6} md={6} lg={6}>
                                    <Card sx={{ minWidth: 100, background: "#e6e6e6", boxShadow: 'none' }}>
                                        <CardContent>
                                            <Typography className="fw-bold themeText mt-1 pt-1">Result of the calculation</Typography>
                                            <Box className="d-flex justify-content-between my-3">
                                                <Typography className="textClr">Margin used(USDT)</Typography>
                                                <Typography className="fw-bold themeText">0</Typography>
                                            </Box>
                                            <Box className="d-flex justify-content-between my-3">
                                                <Typography className="textClr">Earnings</Typography>
                                                <Typography className="fw-bold themeText">0</Typography>
                                            </Box>
                                            <Box className="d-flex justify-content-between my-3">
                                                <Typography className="textClr">Yield rate[%]</Typography>
                                                <Typography className="fw-bold themeText">0%</Typography>
                                            </Box>
                                        </CardContent>
                                    </Card>
                                    <Typography className=" textClr text-center fontSizePara pt-2">
                                        The calculated result is for reference only. There might be deviation due to trading fee or changes in the funding rate
                                    </Typography>
                                </Grid>
                            </Grid>
                        </div>
                        <div className="tab-pane fade" id="targetCalculationTab" role="tabpanel">
                            <Grid container spacing={1}>
                                <Grid item xs={12} sm={6} md={6} lg={6}>
                                    <Grid container spacing={2}>
                                        <Grid item xs={6} sm={6} md={6} lg={6}><Box className="d-grid"><Button variant="contained" className="greenBtn">Long</Button></Box></Grid>
                                        <Grid item xs={6} sm={6} md={6} lg={6}><Box className="d-grid"><Button variant="contained" className="grayBtn">Short</Button></Box></Grid>
                                    </Grid>
                                    <input type="range" style={{ width: "100%" }} id="green" className="input-green my-3" name="vol" min="0" max="100" />
                                    <div className="input-group mb-2">
                                        <input type="text" className="form-control cryptoTransferInput" placeholder="Opening Price" aria-describedby="basic-addon2" />
                                        <div className="input-group-append">
                                            <button className="btn btn-outline-secondary cryptoTransferInput textColors fw-bold">USDT</button>
                                        </div>
                                    </div>
                                    <div className="input-group mb-2">
                                        <input type="text" className="form-control cryptoTransferInput" placeholder="Yeild rate" aria-describedby="basic-addon2" />
                                        <div className="input-group-append">
                                            <button className="btn btn-outline-secondary cryptoTransferInput textColors fw-bold">%</button>
                                        </div>
                                    </div>
                                    <div className="input-group my-2">
                                        <input type="text" className="form-control cryptoTransferInput" placeholder="Trade quantity" aria-describedby="basic-addon2" />
                                        <div className="input-group-append">
                                            <button className="btn btn-outline-secondary cryptoTransferInput textColors fw-bold">Cont</button>
                                        </div>
                                    </div>
                                    <Typography className="fw-bold themeText">Futures<span className="ps-1">BTC_USDT_SWAP</span></Typography>
                                    <Box className="d-grid my-2"><Button variant="contained" className="greenBtn">Start calculation</Button></Box>
                                </Grid>
                                <Grid item xs={12} sm={6} md={6} lg={6}>
                                    <Card sx={{ minWidth: 100, background: "#e6e6e6", boxShadow: 'none' }}>
                                        <CardContent>
                                            <Typography className="fw-bold themeText mt-1 pt-1">Result of the calculation</Typography>
                                            <Box className="d-flex justify-content-between my-3">
                                                <Typography className="textClr">Target price</Typography>
                                                <Typography className="fw-bold themeText">0 USDT</Typography>
                                            </Box>
                                            <Box className="d-flex justify-content-between my-3">
                                                <Typography className="textClr">Margin</Typography>
                                                <Typography className="fw-bold themeText">0 USDT</Typography>
                                            </Box>
                                            <Box className="d-flex justify-content-between my-3">
                                                <Typography className="textClr">Earnings</Typography>
                                                <Typography className="fw-bold themeText">0 USDT</Typography>
                                            </Box>
                                        </CardContent>
                                    </Card>
                                    <Typography className=" textClr text-center fontSizePara pt-2">
                                        The calculated result is for reference only. There might be deviation due to trading fee or changes in the funding rate
                                    </Typography>
                                </Grid>
                            </Grid>
                        </div>
                        <div className="tab-pane fade" id="FLPriceTab" role="tabpanel">
                            <Grid container spacing={1}>
                                <Grid item xs={12} sm={6} md={6} lg={6}>
                                    <Grid container spacing={2}>
                                        <Grid item xs={6} sm={6} md={6} lg={6}><Box className="d-grid"><Button variant="contained" className="greenBtn">Long</Button></Box></Grid>
                                        <Grid item xs={6} sm={6} md={6} lg={6}><Box className="d-grid"><Button variant="contained" className="grayBtn">Short</Button></Box></Grid>
                                    </Grid>
                                    <input type="range" style={{ width: "100%" }} id="green" className="input-green my-3" name="vol" min="0" max="100" />
                                    <div className="input-group mb-2">
                                        <input type="text" className="form-control cryptoTransferInput" placeholder="Opening Price" aria-describedby="basic-addon2" />
                                        <div className="input-group-append">
                                            <button className="btn btn-outline-secondary cryptoTransferInput textColors fw-bold">USDT</button>
                                        </div>
                                    </div>
                                    <div className="input-group mb-2">
                                        <input type="text" className="form-control cryptoTransferInput" placeholder="Trade quantity" aria-describedby="basic-addon2" />
                                        <div className="input-group-append">
                                            <button className="btn btn-outline-secondary cryptoTransferInput textColors fw-bold">Cont</button>
                                        </div>
                                    </div>
                                    <Typography className="fw-bold themeText">BTC_USDT_SWAP</Typography>
                                    <Box className="d-grid my-2"><Button variant="contained" className="greenBtn">Start calculation</Button></Box>
                                </Grid>
                                <Grid item xs={12} sm={6} md={6} lg={6}>
                                    <Card sx={{ minWidth: 100, background: "#e6e6e6", boxShadow: 'none' }}>
                                        <CardContent>
                                            <Typography className="fw-bold themeText mt-1 pt-1">Result of the calculation</Typography>
                                            <Box className="d-flex justify-content-between mt-3 mb-5 pb-1">
                                                <Typography className="textClr">FL Price</Typography>
                                                <Typography className="fw-bold themeText">0 USDT</Typography>
                                            </Box>
                                        </CardContent>
                                    </Card>
                                    <Typography className=" textClr text-center fontSizePara pt-2">
                                        The calculated result is for reference only. There might be deviation due to trading fee or changes in the funding rate
                                    </Typography>
                                </Grid>
                            </Grid>
                        </div>
                    </div>
                </DialogContent>
            </BootstrapDialog>
        </div>
    );
};
export default FuturesCalculator;
