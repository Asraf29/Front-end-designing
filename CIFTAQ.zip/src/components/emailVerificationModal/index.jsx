import * as React from 'react';
import Button from '@mui/material/Button';
import { styled } from '@mui/material/styles';
import Dialog from '@mui/material/Dialog';
import DialogTitle from '@mui/material/DialogTitle';
import DialogContent from '@mui/material/DialogContent';
import DialogActions from '@mui/material/DialogActions';
import IconButton from '@mui/material/IconButton';
import CloseIcon from '@mui/icons-material/Close';
import InputLabel from '@mui/material/InputLabel';
import MenuItem from '@mui/material/MenuItem';
import FormHelperText from '@mui/material/FormHelperText';
import FormControl from '@mui/material/FormControl';
import Select, { SelectChangeEvent } from '@mui/material/Select';
import InfoOutlinedIcon from '@mui/icons-material/InfoOutlined';
import './index.css'
import { ListItemText, Typography } from '@mui/material';
import { Box } from '@mui/system';
const BootstrapDialog = styled(Dialog)(({ theme }) => ({
    '& .MuiDialogContent-root': {
        padding: theme.spacing(2),
    },
    '& .MuiDialogActions-root': {
        padding: theme.spacing(1),
    },
}));

const BootstrapDialogTitle = (props) => {
    const { children, onClose, ...other } = props;

    return (
        <DialogTitle sx={{ m: 0, p: 2 }} {...other}>
            {children}
            {onClose ? (
                <IconButton
                    aria-label="close"
                    onClick={onClose}
                    sx={{
                        position: 'absolute',
                        right: 8,
                        top: 8,
                        color: (theme) => theme.palette.grey[500],
                    }}
                >
                    <CloseIcon />
                </IconButton>
            ) : null}
        </DialogTitle>
    );
};

const EmailVerification = (props) => {
    const [passwordShown, setPasswordShown] = React.useState(false);
    const { openEmailVerification, handleClose } = props;
    const togglePasswords = () => {
        setPasswordShown(!passwordShown);
    };

    return (
        <div>
            <BootstrapDialog
                onClose={() => { handleClose() }}
                aria-labelledby="customized-dialog-title"
                open={openEmailVerification}
                className="modal-bg-color"
            >
                <BootstrapDialogTitle id="emailVerificationTitle" onClose={handleClose}>
                    Email Verification
                </BootstrapDialogTitle>
                <DialogContent className="emailVerification-modal-width">
                    <div className="d-flex px-2 bg-yellow border-radius-10 py-2 my-3 mb-5">
                        <InfoOutlinedIcon className="iconProperty fs-3" />
                        <div><ListItemText className="ps-2 text-color-black fontsize-modal-text text-center" primary={'No withdrawal and FiAT trading within 24 hours after changing the Bount email password'} /></div>
                    </div>
                    <div className="mb-3 form-group">
                        <label className='mb-2 text-color-black'><b className='require-clr pe-1'>*</b>New email address</label>
                        <div>
                            <input
                                type="email"
                                className="form-control email-verification emailPlaceHolder"
                                placeholder="Please enter a new email address"
                            />
                        </div>
                    </div>
                    <div className="mb-3 form-group">
                        <label className='mb-2 text-color-black'><b className='require-clr pe-1'>*</b>New email verification code</label>
                        <div className="form-group mb-3">
                            <div className="d-flex">
                                <div className="w-75">
                                    <input
                                        type="number"
                                        className="form-control email-verification emailPlaceHolder vericationNumber"
                                        placeholder="Please enter the verification code from the new email"
                                    />
                                </div>
                                <button className="btn d-flex align-items-center getCodeBtn px-lg-3 ms-1" role="button">Get Code</button>
                            </div>
                        </div>
                    </div>
                    <div className="form-group">
                        <label className='mb-2 text-color-black'><b className='require-clr pe-1'>*</b>Old email verification code</label>
                        <div className="form-group">
                            <div className="d-flex">
                                <div className="w-75">
                                    <input
                                        type="number"
                                        className="form-control email-verification emailPlaceHolder vericationNumber"
                                        placeholder="Please enter the verification code from the old email"
                                    />
                                </div>
                                <button className="btn d-flex align-items-center getCodeBtn px-lg-3 ms-1" role="button">Get Code</button>
                            </div>
                        </div>
                    </div>
                    <Box className="py-1"><Typography className="helpBtn">Email verification code not received?<span className="helpBtn ps-1 color-lightgreen">Help</span></Typography></Box>
                    <div className="mt-3 form-group">
                        <label className='mb-2 text-color-black'><b className='require-clr pe-1'>*</b>Google Aunthenticator</label>
                        <div>
                            <input
                                type="email"
                                className="form-control email-verification emailPlaceHolder"
                                placeholder="Please enter the Google Authenticator verification code"
                            />
                        </div>
                    </div>
                </DialogContent>
                <DialogActions>
                    <Button autoFocus onClick={() => handleClose()} className="modal-whitebtn mb-3">
                        <span style={{ opacity: "80%", fontWeight: "400px" }}>
                            Cancel
                        </span>
                    </Button>
                    <Button autoFocus onClick={() => handleClose()} className="modal-greenbtn mb-3 me-3">
                        <span style={{ opacity: "80%", fontWeight: "400px" }}>
                            Submit
                        </span>
                    </Button>
                </DialogActions>
            </BootstrapDialog>
        </div>
    );
}
export default EmailVerification;