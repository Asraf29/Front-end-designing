import * as React from "react";
import Button from "@mui/material/Button";
import { styled } from "@mui/material/styles";
import Dialog from "@mui/material/Dialog";
import DialogTitle from "@mui/material/DialogTitle";
import DialogContent from "@mui/material/DialogContent";
import DialogActions from "@mui/material/DialogActions";
import IconButton from "@mui/material/IconButton";
import CloseIcon from "@mui/icons-material/Close";
import InputLabel from "@mui/material/InputLabel";
import MenuItem from "@mui/material/MenuItem";
import FormHelperText from "@mui/material/FormHelperText";
import FormControl from "@mui/material/FormControl";
import Select, { SelectChangeEvent } from "@mui/material/Select";
import "./index.css";
import { FormControlLabel, Grid, Typography } from "@mui/material";
import AutorenewIcon from "@mui/icons-material/Autorenew";
import { Box } from "@mui/system";
const BootstrapDialog = styled(Dialog)(({ theme }) => ({
  "& .MuiDialogContent-root": {
    padding: theme.spacing(2),
  },
  "& .MuiDialogActions-root": {
    padding: theme.spacing(1),
  },
}));

const BootstrapDialogTitle = (props) => {
  const { children, onClose, ...other } = props;

  return (
    <DialogTitle sx={{ m: 0, p: 2 }} {...other}>
      {children}
      {onClose ? (
        <IconButton
          aria-label="close"
          onClick={onClose}
          sx={{
            position: "absolute",
            right: 8,
            top: 8,
            color: (theme) => theme.palette.grey[500],
          }}
        >
          <CloseIcon />
        </IconButton>
      ) : null}
    </DialogTitle>
  );
};

const LoanModel = (props) => {
  const { openLoanModal, handleClickOpen, handleClose } = props;

  return (
    <div>
      <BootstrapDialog
        onClose={() => {
          handleClose();
        }}
        aria-labelledby="customized-dialog-title"
        open={openLoanModal}
        className="modal-bg-color"
      >
        <BootstrapDialogTitle
          id="customized-dialog-title"
          onClose={handleClose} className='fw-bold'
        >
          Loan
        </BootstrapDialogTitle>
        <DialogContent className="modal-width">
          <Box className="d-sm-flex">
            <div class="col-lg-6 me-sm-1 mb-2 mb-sm-0">
              <button class="btn w-100 btn-style-bg" type="button">
                CEEK
              </button>
            </div>
            <div class="col-lg-6">
              <button
                class="btn w-100 borderRadius"
                style={{
                  border: "1px solid var(--txt-placeholder)",
                  color: "var(--txt-placeholder)",
                }}
                type="button"
              >
                USDT
              </button>
            </div>
          </Box>
          <div className="form-group mt-3 mb-2">
            <label className="mb-2  select-title fntSize">Quantity</label>
            <div className="d-flex mb-2">
              <div className="w-75">
                <input
                  type="number"
                  placeholder="Please enter your loan amount"
                  className="form-control login-form-control vericationNumber placeholderTxtClr"
                />
              </div>
              <button
                className="btn d-flex align-items-center getCodeBtn px-5  ms-1"
                role="button"
              >
                All
              </button>
            </div>
            <div className="d-block d-sm-flex">
              <div className="col-lg-4 me-md-3 me-lg-0">
                <label className="select-title fntSizeLoan">
                  Minimum loan amount
                </label>
                <Typography className="fontSizeBold select-title">200 CEEK</Typography>
              </div>
              <div className="col-lg-4 me-md-3">
                <label className="select-title fntSizeLoan">
                  Available for loan
                </label>
                <Typography className="fontSizeBold select-title">0 CEEK</Typography>
              </div>
              <div className="col-lg-4">
                <label className="select-title fntSizeLoan">
                  Hourly interest rate
                </label>
                <Typography className="fontSizeBold select-title">0.008333%</Typography>
              </div>
            </div>
            <Box
              className="bgBlue my-2"
              sx={{ background: "rgba(26, 148, 174, 0.3)" }}
            >
              <Typography className="textSizeTip">
                Tip: Your actual loan amount may not be consistent with the
                prompt on the page due to the fluctuation of market price. In
                this case, the actual loan amount shall take precedence.
              </Typography>
            </Box>
          </div>
        </DialogContent>
        <DialogActions className="my-1 me-2">
          <Button
            autoFocus
            onClick={() => handleClose()}
            className="modal-whitebtn"
          >
            <span style={{ opacity: "80%", fontWeight: "400px", textTransform:'none' }}>Cancel</span>
          </Button>
          <Button
            autoFocus
            onClick={() => handleClose()}
            className="modal-greenbtn"
          >
            <span style={{ opacity: "80%", fontWeight: "400px", textTransform:'none' }}>Loan</span>
          </Button>
        </DialogActions>
      </BootstrapDialog>
    </div>
  );
};
export default LoanModel;
