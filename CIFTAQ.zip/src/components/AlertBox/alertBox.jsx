import * as React from 'react';
import Box from '@mui/material/Box';
import Button from '@mui/material/Button';
import Typography from '@mui/material/Typography';
import Modal from '@mui/material/Modal';
import CheckCircleOutlineOutlinedIcon from '@mui/icons-material/CheckCircleOutlineOutlined';
const style = {
  position: 'absolute',
  top: '50%',
  left: '50%',
  transform: 'translate(-50%, -50%)',
  bgcolor: 'var(--modal-bg)',
  boxShadow: 24,
  borderRadius:'8px',
  p: 4,
  minWidth:300,
  maxWidth:545
};

export default function AlertBox() {
  const [open, setOpen] = React.useState(false);
  const handleOpen = () => setOpen(true);
  const handleClose = () => setOpen(false);

  return (
    <div>
      <Button onClick={handleOpen}>Open modal</Button>
      <Modal
        open={open}
        onClose={handleClose}
        aria-labelledby="modal-modal-title"
        aria-describedby="modal-modal-description"
      >
        <Box sx={style}>
          <Typography id="modal-modal-title" variant="h6" component="h2">
         <span className='py-2' style={{background:'var(--alert-icon-bg)', padding:5, borderRadius:'8px'}}> <CheckCircleOutlineOutlinedIcon fontSize={'small'} className='mb-1 ms-2' sx={{color:'var(--icon-alert)'}}/> </span> <span style={{color:'var(--txt-alert)', fontSize:'20px'}} className='ms-2 fw-bold'> Sure you want to <span className='ms-5 ms-sm-0'>accept?</span></span>
         <Typography  className='text-center ms-5 text-muted'>Are you sure you want to accept this?</Typography>
          </Typography>
        
          <Typography id="modal-modal-description" className='d-flex justify-content-between' sx={{ mt: 2 }}>
           <button onClick={handleClose} className='btn me-2 me-sm-0' style={{ border: '1px solid #4F4F4F', borderRadius:'8px', color:'var(--txt-alert)'}}>No, cancel</button>
           <button onClick={handleClose} className='btn' style={{background:'#4F4F4F', color:'white'}}>Yes, confirm</button>
          </Typography>
        </Box>
      </Modal>
    </div>
  );
}
