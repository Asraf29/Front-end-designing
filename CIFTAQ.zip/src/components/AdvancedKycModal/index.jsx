import * as React from 'react';
import Button from '@mui/material/Button';
import { styled } from '@mui/material/styles';
import Dialog from '@mui/material/Dialog';
import DialogTitle from '@mui/material/DialogTitle';
import DialogContent from '@mui/material/DialogContent';
import DialogActions from '@mui/material/DialogActions';
import IconButton from '@mui/material/IconButton';
import CloseIcon from '@mui/icons-material/Close';
import InputLabel from '@mui/material/InputLabel';
import MenuItem from '@mui/material/MenuItem';
import FormHelperText from '@mui/material/FormHelperText';
import FormControl from '@mui/material/FormControl';
import Select, { SelectChangeEvent } from '@mui/material/Select';
import './index.css'
const BootstrapDialog = styled(Dialog)(({ theme }) => ({
    '& .MuiDialogContent-root': {
        padding: theme.spacing(2),
    },
    '& .MuiDialogActions-root': {
        padding: theme.spacing(1),
    },
}));

const BootstrapDialogTitle = (props) => {
    const { children, onClose, ...other } = props;

    return (
        <DialogTitle sx={{ m: 0, p: 2 }} {...other}>
            {children}
            {onClose ? (
                <IconButton
                    aria-label="close"
                    onClick={onClose}
                    sx={{
                        position: 'absolute',
                        right: 8,
                        top: 8,
                        color: (theme) => theme.palette.grey[500],
                    }}
                >
                    <CloseIcon />
                </IconButton>
            ) : null}
        </DialogTitle>
    );
};

export default function AdvancedKycModal(props) {
    const { openKycModal, handleClickOpen, handleClose } = props;


    return (
        <div>
            <BootstrapDialog
                onClose={() => { handleClose() }}
                aria-labelledby="customized-dialog-title"
                open={openKycModal}
                className="modal-bg-color"
            >
                <BootstrapDialogTitle id="customized-dialog-title" onClose={handleClose}>
                    Advanced KYC
                </BootstrapDialogTitle>
                <DialogContent  className="modal-width">
                    
                    <label className='mb-2 textClr'><b className='require-clr pe-1'>*</b>Nationality</label>
                    <select id="form-select"
                        className="form-select"
                        aria-label="Default select example">
                        <option value="1" className='textClr'> India </option>
                        <option value="2" className='textClr' >United States</option>
                        <option value="3" className='textClr'>United Kingdom</option>
                    </select>
                    <label className='mt-3 mb-2 textClr'><b className='require-clr pe-1'>*</b>ID Type:</label>
                    <select id="form-select"
                        className="form-select"
                        aria-label="Default select example">
                        <option value="1" className='textClr'> Please select ID Type </option>
                        <option value="2" className='textClr' >1</option>
                        <option value="3" className='textClr'>2</option>
                    </select>

                </DialogContent>
                <DialogActions>
                    <Button autoFocus onClick={() => handleClose()} className="modal-whitebtn">
                        <span style={{ opacity: "80%", fontWeight: "400px" }}>
                            Cancel
                        </span>
                    </Button>
                    <Button autoFocus onClick={() => handleClose()} className="modal-greenbtn">
                        <span style={{ opacity: "80%", fontWeight: "400px" }}>
                            Submit
                        </span>
                    </Button>
                </DialogActions>
            </BootstrapDialog>
        </div>
    );
}
