import image from '../components/assets/images/BTC.png';


export const usePlantData = () => {
    const [manufacturePlantData, setManufacturePlantData] = useState([])
    const ManufacturerPlant = async () => {
      const resp = await axios({
        method: 'get',
        url: '/marketTable.json'
      });
      setManufacturePlantData(resp.data)
    }
    useEffect(() => {
      ManufacturerPlant();
    }, [])
    return {manufacturePlantData}
  }