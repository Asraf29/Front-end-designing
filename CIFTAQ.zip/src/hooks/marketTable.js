
const MarketTableJson =
    [
        {
            "Favourites":
            {
                "image": "'../components/assets/images/BTC.png'",
                "cointype": "BTC/USDT",
                "speed": "2X",
                "coinname": "Bitcoin",
                "lastprice": "50850.17",
                "subPrice": "$ 48902.42",
                "change": "+1.59%",
                "High": "50810.25",
                "Low": "198.50",
                "Volume": "967.20"
            }
            ,
            "SpotMarkets":
                [{
                    "image": "../../components/assets/images/BTC.png",
                    "cointype": "BTC/USTD",
                    "speed": "2X",
                    "coinname": "Bitcoin",
                    "lastprice": "2597.17",
                    "subPrice": "$ 5842.42",
                    "change": "+2.59%",
                    "High": "6580.25",
                    "Low": "100.50",
                    "Volume": "500.20"
                },
                {
                    "image": "../../components/assets/images/BTC.png",
                    "cointype": "BTC/USTD",
                    "speed": "6X",
                    "coinname": "Bitcoin",
                    "lastprice": "507.17",
                    "subPrice": "$ 5842.42",
                    "change": "+2.59%",
                    "High": "6580.25",
                    "Low": "100.50",
                    "Volume": "500.20"
                },
                {
                    "image": "../../components/assets/images/BTC.png",
                    "cointype": "BTC/USTD",
                    "speed": "4X",
                    "coinname": "Bitcoin",
                    "lastprice": "4587.17",
                    "subPrice": "$ 5842.42",
                    "change": "+2.59%",
                    "High": "6580.25",
                    "Low": "100.50",
                    "Volume": "500.20"
                },
                {
                    "image": "../../components/assets/images/BTC.png",
                    "cointype": "BTC/USTD",
                    "speed": "4X",
                    "coinname": "Bitcoin",
                    "lastprice": "2587.17",
                    "subPrice": "$ 5842.42",
                    "change": "+2.59%",
                    "High": "6580.25",
                    "Low": "100.50",
                    "Volume": "500.20"
                },
                {
                    "image": "../../components/assets/images/BTC.png",
                    "cointype": "BTC/USTD",
                    "speed": "4X",
                    "coinname": "Bitcoin",
                    "lastprice": "2587.17",
                    "subPrice": "$ 5842.42",
                    "change": "+2.59%",
                    "High": "6580.25",
                    "Low": "100.50",
                    "Volume": "500.20"
                },
                {
                    "image": "../../components/assets/images/BTC.png",
                    "cointype": "BTC/USTD",
                    "speed": "4X",
                    "coinname": "Bitcoin",
                    "lastprice": "2587.17",
                    "subPrice": "$ 5842.42",
                    "change": "+2.59%",
                    "High": "6580.25",
                    "Low": "100.50",
                    "Volume": "500.20"
                }
                ]
            ,
            "Margin":
                [{
                    "image": "../../components/assets/images/BTC.png",
                    "cointype": "BTC/USTD",
                    "speed": "8X",
                    "coinname": "Bitcoin",
                    "lastprice": "2586.17",
                    "subPrice": "$ 7896.42",
                    "change": "+4.59%",
                    "High": "7580.25",
                    "Low": "300.50",
                    "Volume": "100.20"
                },
                {
                    "image": "../../components/assets/images/BTC.png",
                    "cointype": "BTC/USTD",
                    "speed": "8X",
                    "coinname": "Bitcoin",
                    "lastprice": "2586.17",
                    "subPrice": "$ 7896.42",
                    "change": "+4.59%",
                    "High": "7580.25",
                    "Low": "300.50",
                    "Volume": "100.20"
                },
                {
                    "image": "../../components/assets/images/BTC.png",
                    "cointype": "BTC/USTD",
                    "speed": "8X",
                    "coinname": "Bitcoin",
                    "lastprice": "2586.17",
                    "subPrice": "$ 7896.42",
                    "change": "+4.59%",
                    "High": "7580.25",
                    "Low": "300.50",
                    "Volume": "100.20"
                },
                {
                    "image": "../../components/assets/images/BTC.png",
                    "cointype": "BTC/USTD",
                    "speed": "8X",
                    "coinname": "Bitcoin",
                    "lastprice": "2586.17",
                    "subPrice": "$ 7896.42",
                    "change": "+4.59%",
                    "High": "7580.25",
                    "Low": "300.50",
                    "Volume": "100.20"
                },
                {
                    "image": "../../components/assets/images/BTC.png",
                    "cointype": "BTC/USTD",
                    "speed": "8X",
                    "coinname": "Bitcoin",
                    "lastprice": "2586.17",
                    "subPrice": "$ 7896.42",
                    "change": "+4.59%",
                    "High": "7580.25",
                    "Low": "300.50",
                    "Volume": "100.20"
                }
                ]
            ,
            "ETFMarkets":
                [
                    {
                        "image": "../../components/assets/images/BTC.png",
                        "cointype": "BTC/USTD",
                        "speed": "8X",
                        "coinname": "Bitcoin",
                        "lastprice": "4586.17",
                        "subPrice": "$ 6896.42",
                        "change": "+4.59%",
                        "High": "3580.25",
                        "Low": "100.50",
                        "Volume": "800.20"
                    }
                ]
            ,
            "FuturesMarkets":
                [
                    {
                        "image": "../../components/assets/images/BTC.png",
                        "cointype": "BTC/USTD",
                        "speed": "1X",
                        "coinname": "Bitcoin",
                        "lastprice": "9586.17",
                        "subPrice": "$ 7896.42",
                        "change": "+1.59%",
                        "High": "6580.25",
                        "Low": "900.50",
                        "Volume": "200.20"
                    },
                    {
                        "image": "../../components/assets/images/BTC.png",
                        "cointype": "BTC/USTD",
                        "speed": "1X",
                        "coinname": "Bitcoin",
                        "lastprice": "4586.17",
                        "subPrice": "$ 4896.42",
                        "change": "+1.59%",
                        "High": "6580.25",
                        "Low": "900.50",
                        "Volume": "200.20"
                    },
                    {
                        "image": "../../components/assets/images/BTC.png",
                        "cointype": "BTC/USTD",
                        "speed": "1X",
                        "coinname": "Bitcoin",
                        "lastprice": "586.17",
                        "subPrice": "$ 4896.42",
                        "change": "+1.59%",
                        "High": "9580.25",
                        "Low": "100.50",
                        "Volume": "200.20"
                    },
                    {
                        "image": "../../components/assets/images/BTC.png",
                        "cointype": "BTC/USTD",
                        "speed": "1X",
                        "coinname": "Bitcoin",
                        "lastprice": "586.17",
                        "subPrice": "$ 4896.42",
                        "change": "+1.59%",
                        "High": "4580.25",
                        "Low": "900.50",
                        "Volume": "200.20"
                    }
                ]

        }
    ]

export default MarketTableJson;