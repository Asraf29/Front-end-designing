import AppRoutes from "./routes";
import '../node_modules/bootstrap/dist/css/bootstrap.min.css';
import '../src/components/assets/css/style.css'
function App() {
  return (
    
    <AppRoutes/>
  );
}

export default App;
